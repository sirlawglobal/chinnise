<?php
$pageCSS = ["../manage-projects.css", "./style.css", "../budget-management.css"];
include_once '../components/header.php';
?>
<style>
  .total {
    color: black;
  }

  .open {
    color: #003E9C;
  }

  .closed {
    color: #5fbc4a;
  }

  .critical {
    color: rgb(197, 32, 32);
    ;
  }
</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<div class="modal" style="display: none">
  <div class="modal-content">
    <span class="close">×</span>
    <h2 class="con">Create Issue</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Project Name</label>
          <input type="hidden" name="user_id" value="<?= $_SESSION['user_id'] ?>">
          <select name="project_id" class="project_loads need-select" required>
            <option value="">Please Select</option>
            <!-- Options will be populated dynamically -->
          </select>
        </div>
        <div class="col">
          <label>Issue Status</label>
          <select name="issue_status" required>
            <option value="">Please Select</option>
            <option value="Open">Open</option>
            <option value="Closed">Closed</option>
            <option value="Critical">Critical</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Issue Title</label>
          <input type="text" name="issue_title" required />
        </div>
        <div class="col">
          <label>Issue Priority</label>
          <select name="issue_priority" required>
            <option value="">Please Select</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Issue Description</label>
          <textarea name="issue_description" rows="3" placeholder="Enter a brief description" required></textarea>
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>
<div class="modal2" style="display: none">
  <div class="modal-content">
    <span class="close2">×</span>
    <h2 class="con">Edit Issue</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Project Name</label>
          <input type="hidden" name="user_id" value="<?= $_SESSION['user_id'] ?>">
          <input type="hidden" name="id" value="">
          <select name="project_id" class="project_loads need-select" required>
            <option value="">Please Select</option>
            <!-- Options will be populated dynamically -->
          </select>
        </div>
        <div class="col">
          <label>Issue Status</label>
          <select name="issue_status" required>
            <option value="">Please Select</option>
            <option value="Open">Open</option>
            <option value="Closed">Closed</option>
            <option value="Critical">Critical</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Issue Title</label>
          <input type="text" name="issue_title" required />
        </div>
        <div class="col">
          <label>Issue Priority</label>
          <select name="issue_priority" required>
            <option value="">Please Select</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Issue Description</label>
          <textarea name="issue_description" rows="3" placeholder="Enter a brief description" required></textarea>
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update</button>
      </div>
    </form>
  </div>
</div>
<div id="confirmationModal" class="modal-overlay">
  <div class="project-modal-content">
    <h3>Are you sure you want to delete this item?</h3>
    <p>This action cannot be undone.</p>
    <div class="modal-buttons">
      <button id="cancelDeleteBtn" class="modal-button cancel">No, Cancel</button>
      <button id="confirmDeleteBtn" class="modal-button confirm" data-item-id="" data-source-key="" data-category-key="">Yes, Delete</button>
    </div>
  </div>
</div>

<div id="response-message-toast" class="response-message-toast" role="alert" aria-live="polite"></div>
<style>
  .stat-card {
    min-width: unset;
  }
</style>
<!-- Main content -->
<div class="main">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content">
    <div class="project-management-section">
      <div class="section-header">
        <div class="section-header-left">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 20 20">
            <path
              fill="currentColor"
              d="M10 3a1.5 1.5 0 1 0 0 3a1.5 1.5 0 0 0 0-3M7.5 4.5a2.5 2.5 0 1 1 5 0a2.5 2.5 0 0 1-5 0m8-.5a1 1 0 1 0 0 2a1 1 0 0 0 0-2m-2 1a2 2 0 1 1 4 0a2 2 0 0 1-4 0m-10 0a1 1 0 1 1 2 0a1 1 0 0 1-2 0m1-2a2 2 0 1 0 0 4a2 2 0 0 0 0-4m.6 11.998L5 15a2 2 0 0 1-2-2V9.25A.25.25 0 0 1 3.25 9h1.764c.04-.367.17-.708.365-1H3.25C2.56 8 2 8.56 2 9.25V13a3 3 0 0 0 3.404 2.973a5 5 0 0 1-.304-.975m9.496.975Q14.794 16 15 16a3 3 0 0 0 3-3V9.25C18 8.56 17.44 8 16.75 8h-2.129c.196.292.325.633.365 1h1.764a.25.25 0 0 1 .25.25V13a2 2 0 0 1-2.1 1.998a5 5 0 0 1-.304.975M7.25 8C6.56 8 6 8.56 6 9.25V14a4 4 0 0 0 8 0V9.25C14 8.56 13.44 8 12.75 8zM7 9.25A.25.25 0 0 1 7.25 9h5.5a.25.25 0 0 1 .25.25V14a3 3 0 1 1-6 0z" />
          </svg>
          <span class="section-title-text">Overview</span>
        </div>
        <div class="section-header-right">
          <button class="action-button search-button">
            <i class="fas fa-search"></i>
            <span>Search</span>
          </button>
          <button class="action-button new-issue-button add-new-button">
            Add New Issue
          </button>
        </div>
      </div>

      <div class="stats">
        <div class="stat-card">
          <p class="stat-title">Total Issues</p>
          <p class="stat-value total">0</p>
          <span class="stat-icon">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M7.5 10.5312V3C7.5 2.71875 7.71875 2.5 8 2.5C8.28125 2.5 8.5 2.71875 8.5 3V10.5312H7.5ZM7.5 11.5156H8.5V12.4531H7.5V11.5156ZM0 8C0 3.57812 3.57812 0 8 0C12.4219 0 16 3.57812 16 8C16 12.4219 12.4219 16 8 16C3.57812 16 0 12.4219 0 8ZM15.0156 8C15.0156 4.14062 11.8594 1 8 1C4.14062 1 1 4.14062 1 8C1 11.8594 4.14062 15 8 15C11.8594 15 15.0156 11.8594 15.0156 8Z" fill="black" />
            </svg>
          </span>
        </div>
        <div class="stat-card">
          <p class="stat-title">Open Issues</p>
          <p class="stat-value open">0</p>
          <span class="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12.75 7C12.75 6.80109 12.671 6.61032 12.5303 6.46967C12.3897 6.32902 12.1989 6.25 12 6.25C11.8011 6.25 11.6103 6.32902 11.4697 6.46967C11.329 6.61032 11.25 6.80109 11.25 7V12C11.2499 12.1272 11.2822 12.2522 11.3438 12.3635C11.4054 12.4747 11.4942 12.5685 11.602 12.636L14.602 14.511C14.7707 14.6166 14.9744 14.6508 15.1683 14.6061C15.2643 14.584 15.355 14.5433 15.4353 14.4861C15.5155 14.4289 15.5837 14.3565 15.636 14.273C15.6883 14.1895 15.7236 14.0965 15.7399 13.9993C15.7562 13.9022 15.7532 13.8027 15.7311 13.7067C15.709 13.6107 15.6683 13.52 15.6111 13.4397C15.5539 13.3595 15.4815 13.2913 15.398 13.239L12.75 11.584V7Z" fill="#003E9C" />
              <path fill-rule="evenodd" clip-rule="evenodd" d="M12 3.25C9.67936 3.25 7.45376 4.17187 5.81282 5.81282C4.17187 7.45376 3.25 9.67936 3.25 12C3.25 14.3206 4.17187 16.5462 5.81282 18.1872C7.45376 19.8281 9.67936 20.75 12 20.75C14.3206 20.75 16.5462 19.8281 18.1872 18.1872C19.8281 16.5462 20.75 14.3206 20.75 12C20.75 9.67936 19.8281 7.45376 18.1872 5.81282C16.5462 4.17187 14.3206 3.25 12 3.25ZM4.75 12C4.75 11.0479 4.93753 10.1052 5.30187 9.22554C5.66622 8.34593 6.20025 7.5467 6.87348 6.87348C7.5467 6.20025 8.34593 5.66622 9.22554 5.30187C10.1052 4.93753 11.0479 4.75 12 4.75C12.9521 4.75 13.8948 4.93753 14.7745 5.30187C15.6541 5.66622 16.4533 6.20025 17.1265 6.87348C17.7997 7.5467 18.3338 8.34593 18.6981 9.22554C19.0625 10.1052 19.25 11.0479 19.25 12C19.25 13.9228 18.4862 15.7669 17.1265 17.1265C15.7669 18.4862 13.9228 19.25 12 19.25C10.0772 19.25 8.23311 18.4862 6.87348 17.1265C5.51384 15.7669 4.75 13.9228 4.75 12Z" fill="#003E9C" />
            </svg>
          </span>
        </div>
        <div class="stat-card">
          <p class="stat-title">Closed Issues</p>
          <p class="stat-value closed">0</p>
          <span class="stat-icon">
            <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M5 8L8 10.5L12 5.5M8.5 15C7.58075 15 6.6705 14.8189 5.82122 14.4672C4.97194 14.1154 4.20026 13.5998 3.55025 12.9497C2.90024 12.2997 2.38463 11.5281 2.03284 10.6788C1.68106 9.82951 1.5 8.91925 1.5 8C1.5 7.08075 1.68106 6.1705 2.03284 5.32122C2.38463 4.47194 2.90024 3.70026 3.55025 3.05025C4.20026 2.40024 4.97194 1.88463 5.82122 1.53284C6.6705 1.18106 7.58075 1 8.5 1C10.3565 1 12.137 1.7375 13.4497 3.05025C14.7625 4.36301 15.5 6.14348 15.5 8C15.5 9.85652 14.7625 11.637 13.4497 12.9497C12.137 14.2625 10.3565 15 8.5 15Z" stroke="#5FBC4A" stroke-width="2" />
            </svg>
          </span>
        </div>
        <div class="stat-card">
          <p class="stat-title">Critical Issues</p>
          <p class="stat-value critical">0</p>
          <span class="stat-icon">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M7.5 10.5312V3C7.5 2.71875 7.71875 2.5 8 2.5C8.28125 2.5 8.5 2.71875 8.5 3V10.5312H7.5ZM7.5 11.5156H8.5V12.4531H7.5V11.5156ZM0 8C0 3.57812 3.57812 0 8 0C12.4219 0 16 3.57812 16 8C16 12.4219 12.4219 16 8 16C3.57812 16 0 12.4219 0 8ZM15.0156 8C15.0156 4.14062 11.8594 1 8 1C4.14062 1 1 4.14062 1 8C1 11.8594 4.14062 15 8 15C11.8594 15 15.0156 11.8594 15.0156 8Z" fill="#C52020" />
            </svg>
          </span>
        </div>

      </div>

      <section class="budget-management-container">
        <div>
          <div class="budget-filters">
            <div class="filter-dropdown">
              <select id="projectFilter">
                <option value="All">All Projects</option>
              </select>
              <i class="fas fa-chevron-down dropdown-arrow"></i>
            </div>
            <div class="filter-dropdown">
              <select id="typeFilter">
                <option value="All">All Statuses</option>
                <option value="Open">Open</option>
                <option value="Closed">Closed</option>
                <option value="Critical">Critical</option>
              </select>
              <i class="fas fa-chevron-down dropdown-arrow"></i>
            </div>
          </div>
        </div>

        <div class="table-wrapper">
          <table id="issueTable">
            <thead>
              <tr>
                <th class="sortable" data-sort="issue_code">Issue ID <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="project_id">Project ID <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="project">Project Name <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="issue_priority">Priority <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="issue_status">Status <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="issue_title">Issue Title <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="created_at">Date Added <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="added_by">Added By <i class="fas fa-sort"></i></th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="issueTableBody">
            </tbody>
          </table>
        </div>

      </section>
    </div>
  </section>
</div>
<script src="../assets/risk-management.js"></script>
<?php include_once '../components/cashflow_footer.php'; ?>
<script>
  $(document).ready(function() {
    $('.need-select').select2({
      placeholder: "Select Project",
      fontSize: '1rem',
      width: '100%'
    });
    $('.project_loads').css('font-size', '1rem');
  });
</script>