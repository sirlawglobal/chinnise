<?php
$pageCSS = ["./style.css", "../budget-management.css"];
include_once '../components/header.php';
?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<div class="modal" style="display: none">
  <div class="modal-content">
    <span class="close">×</span>
    <h2 class="con">Create Budget</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Project Name</label>
          <input type="hidden" name="user_id" value="<?= $_SESSION['user_id'] ?>">
          <select name="project_id" class="project_loads need-select" required>
            <option value="">Please Select</option>
            <!-- Options will be populated dynamically -->
          </select>
        </div>
        <div class="col">
          <label>Cost Type</label>
          <select name="cost_type" required>
            <option value="">Please Select</option>
            <option value="Direct">Direct</option>
            <option value="Indirect">Indirect</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Cost Item</label>
          <input type="text" name="cost_item" required />
        </div>
        <div class="col">
          <label>Amount</label>
          <input type="number" name="amount" placeholder="0.00" step="0.01" required />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Note</label>
          <textarea name="description" rows="3" placeholder="Enter a brief description" required></textarea>
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>
<!-- <div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">View Project</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Project ID</label>
          <select name="viewProjectId" id="viewProjectId" disabled>
            <option value="">Please Select</option>

          </select>
        </div>
        <div class="col">
          <label>Project Name</label>
          <input type="text" name="viewProjectName" id="viewProjectName" readonly />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Cost Type</label>
          <select name="viewCostType" id="viewCostType" disabled>
            <option value="">Please Select</option>
            <option value="Direct">Direct</option>
            <option value="Indirect">Indirect</option>
          </select>
        </div>

        <div class="col">
          <label>Cost Item</label>
          <input type="text" name="viewCostItem" id="viewCostItem" readonly />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Amount</label>
          <input type="number" name="viewAmount" id="viewAmount" placeholder="0.00" step="0.01" readonly />
        </div>
        <div class="col">
          <label>Description</label>
          <textarea name="viewDescription" id="viewDescription" rows="3" placeholder="Enter a brief description" readonly></textarea>
        </div>
      </div>
    </form>
  </div>
</div> -->
<div class="modal2" id="edit">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Project</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Project ID</label>
          <input type="hidden" name="user_id" value="<?= $_SESSION['user_id'] ?>">
          <input type="hidden" name="id" value="">
          <select name="project_id" class="project_loads need-select">
            <option value="">Please Select</option>
            <!-- Options will be populated dynamically -->
          </select>
        </div>
        <div class="col">
          <label>Cost Type</label>
          <select name="cost_type">
            <option value="">Please Select</option>
            <option value="Direct">Direct</option>
            <option value="Indirect">Indirect</option>
          </select>
        </div>
      </div>
      <div class="row">


        <div class="col">
          <label>Cost Item</label>
          <input type="text" name="cost_item" />
        </div>
        <div class="col">
          <label>Amount</label>
          <input type="number" name="amount" placeholder="0.00" step="0.01" />
        </div>
      </div>
      <div class="row">

        <div class="col">
          <label>Description</label>
          <textarea name="description" rows="3" placeholder="Enter a brief description"></textarea>
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update</button>
      </div>
    </form>
  </div>
</div>
<div id="confirmationModal" class="modal-overlay">
  <div class="project-modal-content">
    <h3>Are you sure you want to delete this item?</h3>
    <p>This action cannot be undone.</p>
    <div class="modal-buttons">
      <button id="cancelDeleteBtn" class="modal-button cancel">No, Cancel</button>
      <button id="confirmDeleteBtn" class="modal-button confirm" data-item-id="" data-source-key="" data-category-key="">Yes, Delete</button>
    </div>
  </div>
</div>
<div id="response-message-toast" class="response-message-toast" role="alert" aria-live="polite"></div>


<!-- Main content -->
<div class="main">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content">
    <div class="project-management-section">
      <div class="section-header">
        <div class="section-header-left">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 20 20">
            <path
              fill="currentColor"
              d="M10 3a1.5 1.5 0 1 0 0 3a1.5 1.5 0 0 0 0-3M7.5 4.5a2.5 2.5 0 1 1 5 0a2.5 2.5 0 0 1-5 0m8-.5a1 1 0 1 0 0 2a1 1 0 0 0 0-2m-2 1a2 2 0 1 1 4 0a2 2 0 0 1-4 0m-10 0a1 1 0 1 1 2 0a1 1 0 0 1-2 0m1-2a2 2 0 1 0 0 4a2 2 0 0 0 0-4m.6 11.998L5 15a2 2 0 0 1-2-2V9.25A.25.25 0 0 1 3.25 9h1.764c.04-.367.17-.708.365-1H3.25C2.56 8 2 8.56 2 9.25V13a3 3 0 0 0 3.404 2.973a5 5 0 0 1-.304-.975m9.496.975Q14.794 16 15 16a3 3 0 0 0 3-3V9.25C18 8.56 17.44 8 16.75 8h-2.129c.196.292.325.633.365 1h1.764a.25.25 0 0 1 .25.25V13a2 2 0 0 1-2.1 1.998a5 5 0 0 1-.304.975M7.25 8C6.56 8 6 8.56 6 9.25V14a4 4 0 0 0 8 0V9.25C14 8.56 13.44 8 12.75 8zM7 9.25A.25.25 0 0 1 7.25 9h5.5a.25.25 0 0 1 .25.25V14a3 3 0 1 1-6 0z" />
          </svg>
          <span class="section-title-text">Overview</span>
        </div>
        <div class="section-header-right">
          <button class="action-button search-button">
            <i class="fas fa-search"></i>
            <span>Search</span>
          </button>
        </div>
      </div>

      <div class="section-description">
        <div>
          <h2>Budget Management</h2>
          <p>
            Manually input and track all project costs - direct and indirect
          </p>
        </div>
        <button class="action-button create-budget-button add-new-button">
          Add Cost Entry
        </button>
      </div>

      <div class="stats">
        <div class="stat-card">
          <p class="stat-title">Total Budget</p>
          <p class="stat-value" id="total">&#8358;0</p>
          <span class="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M16.5 5.625H7.5C7.40054 5.625 7.30516 5.66451 7.23483 5.73484C7.16451 5.80516 7.125 5.90054 7.125 6V10.5C7.125 10.5995 7.16451 10.6948 7.23483 10.7652C7.30516 10.8355 7.40054 10.875 7.5 10.875H16.5C16.5995 10.875 16.6948 10.8355 16.7652 10.7652C16.8355 10.6948 16.875 10.5995 16.875 10.5V6C16.875 5.90054 16.8355 5.80516 16.7652 5.73484C16.6948 5.66451 16.5995 5.625 16.5 5.625ZM16.125 10.125H7.875V6.375H16.125V10.125ZM18.75 2.625H5.25C4.95163 2.625 4.66548 2.74353 4.4545 2.9545C4.24353 3.16548 4.125 3.45163 4.125 3.75V20.25C4.125 20.5484 4.24353 20.8345 4.4545 21.0455C4.66548 21.2565 4.95163 21.375 5.25 21.375H18.75C19.0484 21.375 19.3345 21.2565 19.5455 21.0455C19.7565 20.8345 19.875 20.5484 19.875 20.25V3.75C19.875 3.45163 19.7565 3.16548 19.5455 2.9545C19.3345 2.74353 19.0484 2.625 18.75 2.625ZM19.125 20.25C19.125 20.3495 19.0855 20.4448 19.0152 20.5152C18.9448 20.5855 18.8495 20.625 18.75 20.625H5.25C5.15054 20.625 5.05516 20.5855 4.98484 20.5152C4.91451 20.4448 4.875 20.3495 4.875 20.25V3.75C4.875 3.65054 4.91451 3.55516 4.98484 3.48484C5.05516 3.41451 5.15054 3.375 5.25 3.375H18.75C18.8495 3.375 18.9448 3.41451 19.0152 3.48484C19.0855 3.55516 19.125 3.65054 19.125 3.75V20.25ZM9 13.875C9 14.0233 8.95601 14.1683 8.8736 14.2917C8.79119 14.415 8.67406 14.5111 8.53701 14.5679C8.39997 14.6247 8.24917 14.6395 8.10368 14.6106C7.9582 14.5816 7.82456 14.5102 7.71967 14.4053C7.61478 14.3004 7.54335 14.1668 7.51441 14.0213C7.48547 13.8758 7.50032 13.725 7.55709 13.588C7.61386 13.4509 7.70999 13.3338 7.83332 13.2514C7.95666 13.169 8.10166 13.125 8.25 13.125C8.44891 13.125 8.63968 13.204 8.78033 13.3447C8.92098 13.4853 9 13.6761 9 13.875ZM12.75 13.875C12.75 14.0233 12.706 14.1683 12.6236 14.2917C12.5412 14.415 12.4241 14.5111 12.287 14.5679C12.15 14.6247 11.9992 14.6395 11.8537 14.6106C11.7082 14.5816 11.5746 14.5102 11.4697 14.4053C11.3648 14.3004 11.2933 14.1668 11.2644 14.0213C11.2355 13.8758 11.2503 13.725 11.3071 13.588C11.3639 13.4509 11.46 13.3338 11.5833 13.2514C11.7067 13.169 11.8517 13.125 12 13.125C12.1989 13.125 12.3897 13.204 12.5303 13.3447C12.671 13.4853 12.75 13.6761 12.75 13.875ZM16.5 13.875C16.5 14.0233 16.456 14.1683 16.3736 14.2917C16.2912 14.415 16.1741 14.5111 16.037 14.5679C15.9 14.6247 15.7492 14.6395 15.6037 14.6106C15.4582 14.5816 15.3246 14.5102 15.2197 14.4053C15.1148 14.3004 15.0434 14.1668 15.0144 14.0213C14.9855 13.8758 15.0003 13.725 15.0571 13.588C15.1139 13.4509 15.21 13.3338 15.3333 13.2514C15.4567 13.169 15.6017 13.125 15.75 13.125C15.9489 13.125 16.1397 13.204 16.2803 13.3447C16.421 13.4853 16.5 13.6761 16.5 13.875ZM9 17.625C9 17.7733 8.95601 17.9183 8.8736 18.0417C8.79119 18.165 8.67406 18.2611 8.53701 18.3179C8.39997 18.3747 8.24917 18.3895 8.10368 18.3606C7.9582 18.3316 7.82456 18.2602 7.71967 18.1553C7.61478 18.0504 7.54335 17.9168 7.51441 17.7713C7.48547 17.6258 7.50032 17.475 7.55709 17.338C7.61386 17.2009 7.70999 17.0838 7.83332 17.0014C7.95666 16.919 8.10166 16.875 8.25 16.875C8.44891 16.875 8.63968 16.954 8.78033 17.0947C8.92098 17.2353 9 17.4261 9 17.625ZM12.75 17.625C12.75 17.7733 12.706 17.9183 12.6236 18.0417C12.5412 18.165 12.4241 18.2611 12.287 18.3179C12.15 18.3747 11.9992 18.3895 11.8537 18.3606C11.7082 18.3316 11.5746 18.2602 11.4697 18.1553C11.3648 18.0504 11.2933 17.9168 11.2644 17.7713C11.2355 17.6258 11.2503 17.475 11.3071 17.338C11.3639 17.2009 11.46 17.0838 11.5833 17.0014C11.7067 16.919 11.8517 16.875 12 16.875C12.1989 16.875 12.3897 16.954 12.5303 17.0947C12.671 17.2353 12.75 17.4261 12.75 17.625ZM16.5 17.625C16.5 17.7733 16.456 17.9183 16.3736 18.0417C16.2912 18.165 16.1741 18.2611 16.037 18.3179C15.9 18.3747 15.7492 18.3895 15.6037 18.3606C15.4582 18.3316 15.3246 18.2602 15.2197 18.1553C15.1148 18.0504 15.0434 17.9168 15.0144 17.7713C14.9855 17.6258 15.0003 17.475 15.0571 17.338C15.1139 17.2009 15.21 17.0838 15.3333 17.0014C15.4567 16.919 15.6017 16.875 15.75 16.875C15.9489 16.875 16.1397 16.954 16.2803 17.0947C16.421 17.2353 16.5 17.4261 16.5 17.625Z" fill="#0000FF" />
            </svg>
          </span>
        </div>
        <div class="stat-card">
          <p class="stat-title">Direct Costs</p>
          <p class="stat-value" id="direct">&#8358;0</p>
          <span class="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12.75 7C12.75 6.80109 12.671 6.61032 12.5303 6.46967C12.3897 6.32902 12.1989 6.25 12 6.25C11.8011 6.25 11.6103 6.32902 11.4697 6.46967C11.329 6.61032 11.25 6.80109 11.25 7V12C11.2499 12.1272 11.2822 12.2522 11.3438 12.3635C11.4054 12.4747 11.4942 12.5685 11.602 12.636L14.602 14.511C14.7707 14.6166 14.9744 14.6508 15.1683 14.6061C15.2643 14.584 15.355 14.5433 15.4353 14.4861C15.5155 14.4289 15.5837 14.3565 15.636 14.273C15.6883 14.1895 15.7236 14.0965 15.7399 13.9993C15.7562 13.9022 15.7532 13.8027 15.7311 13.7067C15.709 13.6107 15.6683 13.52 15.6111 13.4397C15.5539 13.3595 15.4815 13.2913 15.398 13.239L12.75 11.584V7Z" fill="#FACC15" />
              <path fill-rule="evenodd" clip-rule="evenodd" d="M12 3.25C9.67936 3.25 7.45376 4.17187 5.81282 5.81282C4.17187 7.45376 3.25 9.67936 3.25 12C3.25 14.3206 4.17187 16.5462 5.81282 18.1872C7.45376 19.8281 9.67936 20.75 12 20.75C14.3206 20.75 16.5462 19.8281 18.1872 18.1872C19.8281 16.5462 20.75 14.3206 20.75 12C20.75 9.67936 19.8281 7.45376 18.1872 5.81282C16.5462 4.17187 14.3206 3.25 12 3.25ZM4.75 12C4.75 11.0479 4.93753 10.1052 5.30187 9.22554C5.66622 8.34593 6.20025 7.5467 6.87348 6.87348C7.5467 6.20025 8.34593 5.66622 9.22554 5.30187C10.1052 4.93753 11.0479 4.75 12 4.75C12.9521 4.75 13.8948 4.93753 14.7745 5.30187C15.6541 5.66622 16.4533 6.20025 17.1265 6.87348C17.7997 7.5467 18.3338 8.34593 18.6981 9.22554C19.0625 10.1052 19.25 11.0479 19.25 12C19.25 13.9228 18.4862 15.7669 17.1265 17.1265C15.7669 18.4862 13.9228 19.25 12 19.25C10.0772 19.25 8.23311 18.4862 6.87348 17.1265C5.51384 15.7669 4.75 13.9228 4.75 12Z" fill="#FACC15" />
            </svg>
          </span>
        </div>
        <div class="stat-card">
          <p class="stat-title">Indirect Costs</p>
          <p class="stat-value" id="indirect">&#8358;0</p>
          <span class="stat-icon">
            <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M5 8L8 10.5L12 5.5M8.5 15C7.58075 15 6.6705 14.8189 5.82122 14.4672C4.97194 14.1154 4.20026 13.5998 3.55025 12.9497C2.90024 12.2997 2.38463 11.5281 2.03284 10.6788C1.68106 9.82951 1.5 8.91925 1.5 8C1.5 7.08075 1.68106 6.1705 2.03284 5.32122C2.38463 4.47194 2.90024 3.70026 3.55025 3.05025C4.20026 2.40024 4.97194 1.88463 5.82122 1.53284C6.6705 1.18106 7.58075 1 8.5 1C10.3565 1 12.137 1.7375 13.4497 3.05025C14.7625 4.36301 15.5 6.14348 15.5 8C15.5 9.85652 14.7625 11.637 13.4497 12.9497C12.137 14.2625 10.3565 15 8.5 15Z" stroke="#5FBC4A" stroke-width="2" />
            </svg>
          </span>
        </div>
      </div>

      <section class="budget-management-container">
        <div>
          <h4>Budget Management</h4>
          <p>
            Manually input and track all project costs - direct and indirect
          </p>
          <div class="budget-filters">
            <div class="filter-dropdown">
              <select id="projectFilter">
                <option value="All">All Projects</option>
                <option value="Oshea Projects">Oshea Projects</option>
              </select>
              <i class="fas fa-chevron-down dropdown-arrow"></i>
            </div>
            <div class="filter-dropdown">
              <select id="typeFilter">
                <option value="All">Types</option>
                <option value="Direct">Direct</option>
                <option value="Indirect">Indirect</option>
              </select>
              <i class="fas fa-chevron-down dropdown-arrow"></i>
            </div>
          </div>
        </div>
        <div class="table-wrapper">
          <table id="budgetTable">
            <thead>
              <tr>
                <th class="sortable" data-sort="id">Project ID <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="project">Project Name <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="costItem">Cost Item <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="costType">Cost Type <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="amount">Amount <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="dateAdded">Date Added <i class="fas fa-sort"></i></th>
                <th class="sortable" data-sort="addedBy">Added By <i class="fas fa-sort"></i></th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="budgetTableBody">
            </tbody>
          </table>
        </div>
      </section>
    </div>
  </section>
</div>
<script src="../assets/budget-management.js"></script>
<?php include_once '../components/cashflow_footer.php'; ?>
<script>
  $(document).ready(function() {
    $('.need-select').select2({
      placeholder: "Select Project",
      fontSize: '1rem',
      width: '100%'
    });
    $('.project_loads').css('font-size', '1rem');
  });
</script>
<style>
  table th, table td {
    /* padding: 12px 15px; */
    text-align: left;
    border-bottom: 1px solid #eee;
    text-align: start;
}
th, td{
  padding: 8px;
}
table th, table td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #eee;
    text-align: start;
}
</style>