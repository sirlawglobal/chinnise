<?php
$pageCSS = ["../project-management.css", "https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Lato:wght@400;700&display=swap", ",/style.css"];
 include_once '../components/header.php'; 
?>

<div class="main">
<?php include_once '../components/common_header.php'; ?>
  <section class="content">
    <div class="main-container">
        <section class="hero-section">
            <div class="hero-content-left">
                <h1 class="crm-title"><span>CRM</span><span class="green">128</span> Project Workspace</h1>
                <p class="description">All of your work in one place: Tasks, Docs, Goals, Whiteboards, Dashboards, & more.</p>
                <p class="tagline">Built exclusively for internal teams</p>

                <div class="social-proof-section">
                    <div class="avatars-container">
                        <img src="https://picsum.photos/70?random=1" alt="Avatar 1" class="avatar static-avatar">
                        <img src="https://picsum.photos/70?random=2" alt="Avatar 2" class="avatar static-avatar">
                        <img src="https://picsum.photos/70?random=3" alt="Avatar 3" class="avatar static-avatar">
                        <img src="https://picsum.photos/70?random=4" alt="Avatar 4" class="avatar static-avatar">
                        <img src="https://picsum.photos/70?random=5" alt="Avatar 5" class="avatar static-avatar">
                        </div>
                    <span class="user-count">2K+</span>
                    <div class="star-rating">
                        <span class="star filled">&#9733;</span>
                        <span class="star filled">&#9733;</span>
                        <span class="star filled">&#9733;</span>
                        <span class="star filled">&#9733;</span>
                        <span class="star half-filled">&#9733;</span>
                    </div>
                    <span class="review-text">Based on 10,000+ reviews</span>
                </div>
            </div>
            <div class="hero-image-right">
                <img src="https://picsum.photos/700/350" alt="Business team meeting" class="hero-image">
            </div>
        </section>

        <section class="features-section">
            <h2 class="section-title">Features</h2>
            <div class="carousel-container">
                <div class="carousel-track" id="featuresCarouselTrack">
                    <div class="feature-card">
                        <h3>Project Overview</h3>
                        <ul>
                            <li>Project Description</li>
                            <li>Status Indicators</li>
                            <li>Assigned Team Members</li>
                            <li>Start & End Dates</li>
                        </ul>
                    </div>
                    <div class="feature-card">
                        <h3>Task Management</h3>
                        <ul>
                            <li>Task lists</li>
                            <li>Assignees & Deadlines</li>
                            <li>Attachments</li>
                            <li>Comments</li>
                        </ul>
                    </div>
                    <div class="feature-card">
                        <h3>Timeline & Scheduling</h3>
                        <ul>
                            <li>Milestone Tracking</li>
                            <li>Gantt charts</li>
                            <li>Calender view</li>
                        </ul>
                    </div>
                    <div class="feature-card">
                        <h3>Collaboration Tools</h3>
                        <ul>
                            <li>Real Time Updates</li>
                            <li>Team Chat</li>
                            <li>Mentions</li>
                        </ul>
                    </div>
                </div>
                <button class="carousel-button prev" id="carouselPrev">&#10094;</button>
                <button class="carousel-button next" id="carouselNext">&#10095;</button>
                </div>
        </section>
    </div>
  </section>
</div>

<script src="script.js"></script>
<?php include_once '../components/cashflow_footer.php'; ?>