<?php
$pageCSS = ["../manage-projects.css", "./style.css"];
include_once '../components/header.php';
?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<style>
  .select2-container--default .select2-selection--multiple .select2-selection__choice {
    background-color: white !important;
    /* Green */
    color: black !important;
    border: none !important;
  }
</style>
<div class="modal" style="display: none">
  <div class="modal-content">
    <span class="close">×</span>
    <h2 class="con">Create Project</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Project Name</label>
          <input type="text" name="name" required />
        </div>
        <div class="col">
          <label>Start Date</label>
          <input type="date" name="start_date" required />
        </div>
        <div class="col">
          <label>Due Date</label>
          <input type="date" name="due_date" required />
        </div>
      </div>
      <div class="row">

        <div class="col">
          <label>Supervised by</label>
          <select name="supervisor" class="supervisor need-select" required>
            <option selected></option>
          </select>
        </div>
        <div class="col">
          <label>Status</label>
          <select name="status" required>
            <option value="Pending">Pending</option>
            <option value="Ongoing">Ongoing</option>
            <option value="Completed">Completed</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Assigned to</label>
          <select name="assignees[]" class="assignees need-select" required multiple>


            <!-- Options will be populated dynamically -->
          </select>

        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>
<div class="modal1" style="display: none">
  <div class="modal-content">
    <span class="close1">×</span>
    <h2 class="con">View Project</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Project Name</label>
          <input type="text" name="name" />
        </div>
        <div class="col">
          <label>Start Date</label>
          <input type="date" name="start_date" />
        </div>
        <div class="col">
          <label>Due Date</label>
          <input type="date" name="due_date" />
        </div>
      </div>
      <div class="row">

        <div class="col">
          <label>Supervised by</label>
          <select name="supervisor" class="supervisor need-select">

          </select>
        </div>
        <div class="col">
          <label>Status</label>
          <select name="status" required>
            <option value="Pending">Pending</option>
            <option value="Ongoing">Ongoing</option>
            <option value="Completed">Completed</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Assigned to</label>
          <select name="assignees[]" class="assignees need-select" required multiple>


            <!-- Options will be populated dynamically -->
          </select>

        </div>
      </div>
    </form>
  </div>
</div>
<div class="modal2" style="display: none">
  <div class="modal-content">
    <span class="close2">×</span>
    <h2 class="con">Edit Project</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Project Name</label>
          <input type="text" name="name" required />
        </div>
        <input type="hidden" name="project_id" value="" />
        <div class="col">
          <label>Start Date</label>
          <input type="date" name="start_date" required />
        </div>
        <div class="col">
          <label>Due Date</label>
          <input type="date" name="due_date" required />
        </div>
      </div>
      <div class="row">

        <div class="col">
          <label>Supervised by</label>
          <select name="supervisor" class="supervisor need-select" required>

          </select>
        </div>
        <div class="col">
          <label>Status</label>
          <select name="status" required>
            <option value="Pending">Pending</option>
            <option value="Ongoing">Ongoing</option>
            <option value="Completed">Completed</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Assigned to</label>
          <select name="assignees[]" class="assignees need-select" required multiple>
          </select>

        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update</button>
      </div>
    </form>
  </div>
</div>
<div id="assigneesModal" class="custom-modal" style="display:none;">
  <div class="custom-modal-content">
    <span class="custom-modal-close" id="closeAssigneesModal">&times;</span>
    <h3>Project Assignees</h3>
    <div id="assigneesModalBody"></div>
  </div>
</div>
<div id="confirmationModal" class="modal-overlay">
  <div class="project-modal-content">
    <h3>Are you sure you want to delete this item?</h3>
    <p>This action cannot be undone.</p>
    <div class="modal-buttons">
      <button id="cancelDeleteBtn" class="modal-button cancel">No, Cancel</button>
      <button id="confirmDeleteBtn" class="modal-button confirm" data-item-id="" data-source-key="" data-category-key="">Yes, Delete</button>
    </div>
  </div>
</div>
<div id="response-message-toast" class="response-message-toast" role="alert" aria-live="polite"></div>
<!-- Main content -->
<div class="main">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content">
    <div class="project-management-section">
      <div class="section-header">
        <div class="section-header-left">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 20 20">
            <path
              fill="currentColor"
              d="M10 3a1.5 1.5 0 1 0 0 3a1.5 1.5 0 0 0 0-3M7.5 4.5a2.5 2.5 0 1 1 5 0a2.5 2.5 0 0 1-5 0m8-.5a1 1 0 1 0 0 2a1 1 0 0 0 0-2m-2 1a2 2 0 1 1 4 0a2 2 0 0 1-4 0m-10 0a1 1 0 1 1 2 0a1 1 0 0 1-2 0m1-2a2 2 0 1 0 0 4a2 2 0 0 0 0-4m.6 11.998L5 15a2 2 0 0 1-2-2V9.25A.25.25 0 0 1 3.25 9h1.764c.04-.367.17-.708.365-1H3.25C2.56 8 2 8.56 2 9.25V13a3 3 0 0 0 3.404 2.973a5 5 0 0 1-.304-.975m9.496.975Q14.794 16 15 16a3 3 0 0 0 3-3V9.25C18 8.56 17.44 8 16.75 8h-2.129c.196.292.325.633.365 1h1.764a.25.25 0 0 1 .25.25V13a2 2 0 0 1-2.1 1.998a5 5 0 0 1-.304.975M7.25 8C6.56 8 6 8.56 6 9.25V14a4 4 0 0 0 8 0V9.25C14 8.56 13.44 8 12.75 8zM7 9.25A.25.25 0 0 1 7.25 9h5.5a.25.25 0 0 1 .25.25V14a3 3 0 1 1-6 0z" />
          </svg>
          <span class="section-title-text">Projects Overview</span>
        </div>
        <div class="section-header-right">
          <button class="action-button search-button">
            <!-- <i class="fas fa-search"></i>
            <span>Search</span> -->
          </button>
          <!-- <button class="action-button view-projects-button">
            View Projects
          </button> -->
          <button class="action-button new-project-button add-new-button">
            New Project
          </button>
        </div>
      </div>

      <nav class="project-navigation-tabs">

        <a href="#" class="nav-tab active ongo" data-tab="ongoing">Ongoing </a>
        <a href="#" class="nav-tab pend" data-tab="pending">Pending </a>
        <a href="#" class="nav-tab comp" data-tab="completed">Completed </a>

        <a href="#" class="nav-tab" data-tab="reports">Project Report</a>
      </nav>

      <section class="project-list-display">
        <h2 class="project-list-title">Ongoing Projects </h2>
        <div id="projectTableContainer" class="table-wrapper"></div>
      </section>
    </div>
  </section>
</div>
<script src="../assets/project-management.js"></script>
<?php include_once '../components/cashflow_footer.php'; ?>

<script>
  $(document).ready(function() {
    $('.need-select').select2({
      placeholder: "Please Select",
      width: '100%'
    });

  });

  // Show modal with assignees
  function showAssigneesModal(assignees) {
    const modal = document.getElementById('assigneesModal');
    const body = document.getElementById('assigneesModalBody');
    if (assignees && assignees.length > 0) {
      body.innerHTML = `
      <ul>
        ${assignees.map(a => 
          `<li><strong>${a.name}</strong> <span style="color:gray;">(${a.email || a.phone || ''})</span></li>`
        ).join('')}
      </ul>
    `;
    } else {
      body.innerHTML = "<em>No assignees found.</em>";
    }
    modal.style.display = 'flex';
  }

  // Hide modal
  document.getElementById('closeAssigneesModal').onclick = function() {
    document.getElementById('assigneesModal').style.display = 'none';
  };

  // Optional: Hide modal when clicking outside content
  document.getElementById('assigneesModal').onclick = function(e) {
    if (e.target === this) this.style.display = 'none';
  };

  // Example: Attach to your eye icon
  document.addEventListener('click', function(event) {
    const eyeIcon = event.target.closest('.assign-view');
    if (eyeIcon) {
      // Get assignees from your data (adjust as needed)
      const rowElement = eyeIcon.closest('tr');
      const activeTab = document.querySelector(".nav-tab.active");
      const dataKey = activeTab ? activeTab.dataset.tab : "ongoing";
      const projectId = rowElement.dataset.projectId;
      const project = projectData[dataKey].rows.find(p => p.id == projectId);
      showAssigneesModal(project ? project.assignees : []);
    }
  });
</script>