document.addEventListener("DOMContentLoaded", () => {
  // --- Hero Section Avatars (Static - No Slider) ---
  // The avatars are now purely CSS-driven for their layout and overlap.
  // No JavaScript needed for them if they are static.

  // --- Features Section Carousel/Slider (Arrows Only) ---
  const carouselTrack = document.getElementById("featuresCarouselTrack");
  const featureCards = Array.from(
    carouselTrack.getElementsByClassName("feature-card")
  );
  const prevButton = document.getElementById("carouselPrev");
  const nextButton = document.getElementById("carouselNext");

  let currentSlideIndex = 0; // Tracks the starting index of the visible cards
  let cardsPerView = getCardsPerView(); // Number of cards visible at once

  function getCardsPerView() {
    if (window.innerWidth <= 768) {
      return 1; // 1 card per view on small screens
    } else if (window.innerWidth <= 1024) {
      return 2; // 2 cards per view on medium screens
    }
    return 3; // 3 cards per view on large screens
  }

  function updateCarousel() {
    // Calculate the width of one card including its margin
    const cardStyle = getComputedStyle(featureCards[0]);
    const cardWidth = featureCards[0].offsetWidth; // Actual width of the content box
    const cardMarginRight = parseFloat(cardStyle.marginRight) * 2.2;
    const cardMarginLeft = parseFloat(cardStyle.marginLeft) * 2.2;
    const totalCardWidth = cardWidth + cardMarginLeft + cardMarginRight;

    // Calculate the translation needed
    // We want to shift by one full card width at a time
    // currentSlideIndex determines which card is at the very left of the view
    const offset = -currentSlideIndex * totalCardWidth;
    carouselTrack.style.transform = `translateX(${offset}px)`;

    // Disable/enable arrows if at the start/end
    prevButton.disabled = currentSlideIndex === 0;
    nextButton.disabled =
      currentSlideIndex + cardsPerView >= featureCards.length;
  }

  // Event Listeners for Navigation Buttons
  prevButton.addEventListener("click", () => {
    currentSlideIndex = Math.max(0, currentSlideIndex - 1);
    updateCarousel();
  });

  nextButton.addEventListener("click", () => {
    // Only advance if there are more cards to show after the current view
    if (currentSlideIndex + cardsPerView < featureCards.length) {
      currentSlideIndex++;
    }
    updateCarousel();
  });

  // Update carousel on window resize to adjust cards per view
  window.addEventListener("resize", () => {
    const newCardsPerView = getCardsPerView();
    if (newCardsPerView !== cardsPerView) {
      cardsPerView = newCardsPerView;
      // When cardsPerView changes, reset currentSlideIndex to prevent empty views
      // or misalignments, or adjust it carefully. Resetting to 0 is simplest.
      currentSlideIndex = 0;
    }
    updateCarousel();
  });

  // Initial setup when the page loads
  updateCarousel();
});
