<?php
session_start();

// Check if user is logged in
if (! isset($_SESSION['user_id'])) {
  // Not logged in, redirect to login page
  header("Location: auth/login.php");
  exit;
}
?>

<?php include_once 'backend/overview/index.php'; ?>

<?php include_once './components/header.php' ?>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php include_once './components/common_header.php' ?>
  <!-- Your page content goes here -->
  <section class="content" style="overflow-y: hidden">
    <div class="dashboard-grid">
      <div class="main-col">
        <h3 style="padding: 1rem">Contact Management</h3>
        <div class="box1">
          <div class="box2">
            <h4 class="box2-title">Active Clients</h4>
            <div class="box2-val"><?php echo htmlspecialchars($activeClients) ?></div>
          </div>
          <div class="box2">
            <h4 class="box2-title">Inactive Clients</h4>
            <div class="box2-val"><?php echo htmlspecialchars($inactiveClients) ?></div>
          </div>
          <div class="box2">
            <h4 class="box2-title">Active Leads</h4>
            <div class="box2-val"><?php echo htmlspecialchars($activeLeads) ?></div>
          </div>
          <div class="box2">
            <h4 class="box2-title">Inactive Leads</h4>
            <div class="box2-val"><?php echo htmlspecialchars($inactiveleads) ?></div>
          </div>
        </div>
        <h3 style="padding: 1rem">Human Resources</h3>
        <div class="box1">
          <?php
          // Make sure the path to your connection file is correct!
          require_once 'settings/connection.php'; // Adjust 'db_connect.php' to your actual file name and path

          try {
            // Query to get total employees, men, and women
            $stmt = $pdo->query("SELECT
                            COUNT(*) AS total_employees,
                            COUNT(CASE WHEN gender = 'Male' THEN 1 END) AS men_count,
                            COUNT(CASE WHEN gender = 'Female' THEN 1 END) AS women_count
                         FROM employees");

            $employee_data = $stmt->fetch();

            $total_employees = $employee_data['total_employees'];
            $men_count       = $employee_data['men_count'];
            $women_count     = $employee_data['women_count'];
          } catch (\PDOException $e) {
            // Handle database query errors gracefully
            error_log("Employee data query error: " . $e->getMessage());
            $total_employees = 'N/A'; // Default values in case of error
            $men_count       = 'N/A';
            $women_count     = 'N/A';
            // Optionally, display a user-friendly error message on the page
            // echo "<p>Error fetching employee data. Please try again later.</p>";
          }
          ?>

          <div class="box2">
            <h4 class="box2-title">Employees</h4>
            <div class="box2__value box2__value--green"><?php echo htmlspecialchars($total_employees); ?></div>
            <div class="box2-split">
              <div class="box2-split-item">
                <div class="box2-split-number"><?php echo htmlspecialchars($men_count); ?></div>
                <div class="box2-split-label">Men</div>
              </div>
              <div class="box2-split-divider"></div>
              <div class="box2-split-item">
                <div class="box2-split-number"><?php echo htmlspecialchars($women_count); ?></div>
                <div class="box2-split-label">Women</div>
              </div>
            </div>
          </div>
          <div class="box2">
            <h4 class="box2-title">Attendances</h4>
            <div class="box2__value box2__value--green"><?php echo htmlspecialchars($time) ?></div>
            <div class="box2-split">
              <div class="box2-split-item">
                <div class="box2-split-number"><?php echo htmlspecialchars($early) ?></div>
                <div class="box2-split-label">Early</div>
              </div>
              <div class="box2-split-divider"></div>

              <div class="box2-split-item">
                <div class="box2-split-number"><?php echo htmlspecialchars($late) ?></div>
                <div class="box2-split-label">Late</div>
              </div>
            </div>
          </div>
          <div class="box2">
            <h4 class="box2-title">Leave Taken</h4>
            <div class="box2__value box2__value--green"><?php echo htmlspecialchars($leave) ?></div>
            <div class="box2-split">
              <div class="box2-split-item">
                <div class="box2-split-number"><?php echo htmlspecialchars($leave_male) ?></div>
                <div class="box2-split-label">Men</div>
              </div>
              <div class="box2-split-divider"></div>

              <div class="box2-split-item">
                <div class="box2-split-number"><?php echo htmlspecialchars($leave_female) ?></div>
                <div class="box2-split-label">Women</div>
              </div>
            </div>
          </div>
        </div>
        <h3 style="padding: 1rem">Inventory</h3>
        <div class="box1">
          <div class="box2">
            <h4 class="box2-title">Current Stocks</h4>
            <div class="box2-val" id="stocks"></div>
          </div>
          <div class="box2">
            <h4 class="box2-title">Items Returned</h4>
            <div class="box2-val" id="returns"></div>
          </div>
          <div class="box2">
            <h4 class="box2-title">Client Return</h4>
            <div class="box2-val" id="creturns"></div>
          </div>
          <div class="box2">
            <h4 class="box2-title">Suppliers Return</h4>
            <div class="box2-val" id="sreturns"></div>
          </div>
        </div>
        <h3 style="padding: 1rem">Cash Flow</h3>
        <div class="box1">
          <div class="box2">
            <h4 class="box2-title">Total Income</h4>
            <div class="box2-val">&#8358;<?php echo htmlspecialchars(number_format($totalIncomes, 2, '.', ',')) ?></div>
          </div>
          <div class="box2">
            <h4 class="box2-title">Total Balance</h4>
            <div class="box2-val">&#8358;<?php echo htmlspecialchars(number_format($netIncome, 2, '.', ',')) ?></div>
          </div>
          <div class="box2">
            <h4 class="box2-title">Total Expenses</h4>
            <div class="box2-val">&#8358;<?php echo htmlspecialchars(number_format($totalExpenses, 2, '.', ',')) ?></div>
          </div>
        </div>
      </div>
      <aside class="sidebar-col">
        <div
          style="
                display: flex;
                justify-content: end;
                margin-top: 1%;
                margin-bottom: 2%;
                font-family: 'UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji';
              ">
          <h4 style="margin-block: 0; padding:10px;" class="sidebar-header">Appointments</h4>
          <button
            onclick="window.location.href = './appointments.php'"
            class="add-appointment-btn"
            style="width: 100%; margin-left: 0; padding: 0;height: 35px">
            <!-- <img src="./assets/plus.svg" alt="Add Appointment" /> -->
            <p>Add Appointment</p>
          </button>
        </div>
        <?php
        require_once 'settings/connection.php'; // make sure this path is correct

        try {
          $stmt         = $pdo->query("SELECT * FROM appointments");
          $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
          echo "<p>Error fetching appointments: " . $e->getMessage() . "</p>";
          $appointments = [];
        }
        ?>

        <div class="box1 ">
          <div id="appointments-list">
            <?php if (count($appointments) > 0): ?>
              <?php foreach ($appointments as $appointment): ?>
                <div class="appointment-card">
                  <h4><strong><?php echo htmlspecialchars($appointment['title']); ?></strong></h4>
                  <p>
                    <?php
                    $start_time = date("h:ia", strtotime($appointment['start']));
                    $start_date = date("F j, Y", strtotime($appointment['start']));
                    $end_time   = date("h:ia", strtotime($appointment['end']));
                    $end_date   = date("F j, Y", strtotime($appointment['end']));

                    echo "<b>From</b> " . $start_time . " on " . $start_date . " <br> <b>To</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $end_time . " on " . $end_date;
                    ?>
                  </p>
                  <p><?php echo htmlspecialchars($appointment['description']); ?></p>
                </div>
              <?php endforeach; ?> <br>
            <?php else: ?>
              <div class="box2">
                <h4 class="box2-title">Upcoming</h4>
                <p>No items</p>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </aside>
    </div>
  </section>
</div>
<?php include_once './components/common_footer.php' ?>
<script>
  async function fetchInventoryStats() {
    try {
      const response = await fetch('./backend/index.php');
      const result = await response.json();
      if (result.success && result.data) {
        document.getElementById('stocks').textContent = result.data.stocks ?? 0;
        document.getElementById('returns').textContent = result.data.returns ?? 0;
        document.getElementById('creturns').textContent = result.data.creturns ?? 0;
        document.getElementById('sreturns').textContent = result.data.sreturns ?? 0;
      }
    } catch (e) {
      // Optionally handle error
      console.error('Failed to fetch inventory stats', e);
    }
  }
  document.addEventListener('DOMContentLoaded', fetchInventoryStats);
</script>

<style>
  h4 {
    margin-block: 20px 10px;
  }
</style>