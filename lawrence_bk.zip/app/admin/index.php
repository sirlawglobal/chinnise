<?php require('../components/header.php')  ?>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php require('../components/common_header.php')  ?>
  <!-- Your page content goes here -->
  <section class="content" style="overflow-y: hidden">
    <div class="tabs tabs2">
      <div class="tab-it tab-active"><a href="./"> Welcome</a></div>
      <div class="tab-it" style="width: 20%">
        <a href="./users"> Staff Record Summary </a>
      </div>
      <div class="tab-it" style="width: 20%">
        <a href="./entry"> Staff Record Entry </a>
      </div>
      <div class="tab-it">
        <a href="./current-user">Current User</a>
      </div>
    </div>
    <div class="over-table" style="height: 97%">
      <div>
        <h2 style="color: #007bff; padding: 0.5rem">Welcome</h2>
        <h3 style="text-align: center">What will you like to do today?</h3>
        <img
          width="20%"
          src="http://crm128.com/app02/assets/images/admin.png" />
        <div style="text-align: center">
          <a href="./users">
            <button
              class="add-new-button"
              style="border-radius: 15px; width: 15%; font-size: 1rem">
              Users
            </button></a>
        </div>
      </div>
    </div>
  </section>
</div>
<?php require('../components/common_footer.php')  ?>