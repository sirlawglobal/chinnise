<?php require('../components/header.php')  ?>

<div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">Profile</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Full Name</label>
          <p>Admin Admin</p>
        </div>
        <div class="col">
          <label>Gender</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Email</label>
          <p>admin@admin.com</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Marital Status</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Phone Number</label>
          <p>23456787654323</p>
        </div>
        <div class="col">
          <label>Date of Birth</label>
          <p>No data</p>
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>State Of Origin</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>NINO</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Name On Account</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Account Number</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Branch</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Staff ID</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Title</label>
          <p>Admin</p>
        </div>
        <div class="col">
          <label>Joining Data</label>
          <p>1990-01-01</p>
        </div>
        <div class="col">
          <label>Department</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label> Medical Condtion </label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Name Of Bank</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Full Staff</label>
          <p>No data</p>
        </div>
      </div>
      <h4>Family Date</h4>
      <div class="row">
        <div class="col">
          <label>Father Name</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Father Phone No.</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Father Occupation</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Father Address</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Mother Name</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Mother Phone Number</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Mother Occupation</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Mother Address</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>No. Of Siblings</label>
          <p>No data</p>
        </div>
      </div>
      <h4>Next Of Kin Data(Parents Or Siblings)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Address</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Other Names</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Phone No.</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Email Address</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Relationship</label>
          <p>No data</p>
        </div>
      </div>
      <h4>Reference 1 Data(Previous Employer/School)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Company</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Other Names</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Address</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Phone Number</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Position</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Email Address</label>
          <p>No data</p>
        </div>
      </div>
      <h4>Reference 2 Data(Previous Employer/School)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Company</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Other Names</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Address</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Phone Number</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Position</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Email Address</label>
          <p>No data</p>
        </div>
      </div>
    </form>
  </div>



</div>
<div class="modal2" id="edit">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Employee</h2>
    <form>

      <h4>Personal Data</h4>
      <div class="row">
        <div class="col">
          <label>Picture</label>
          <input type="file" style="border:none" name="picture">
        </div>
        <div class="col">
          <label>First Name*</label>
          <input type="text" name="first_name">
        </div>
        <div class="col">
          <label>Last Name*</label>
          <input type="text" name="last_name">
        </div>
        <div class="col">
          <label>Date Joined</label>
          <input type="date" name="date_joined">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Position</label>
          <input type="text" name="position">
        </div>
        <div class="col">
          <label>Status*</label>
          <select name="status">
            <option>Please Select</option>
            <option>Full Staff</option>
            <option>Contract</option>
            <option>Probation</option>
            <option>Suspended</option>
          </select>
        </div>
        <div class="col">
          <label>Department</label>
          <select name="department">
            <option>Department</option>
            <option>Information & Technology</option>
            <option>IT Sales</option>
            <option>GN122 Health Care</option>
            <option>GN 122 Child Care</option>
          </select>
        </div>
        <div class="col">
          <label>Location/Branch</label>
          <input type="text" name="location">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Marital Status</label>
          <select name="marital_status">
            <option>Please Select</option>
            <option>Single</option>
            <option>Married</option>
            <option>Widow</option>
            <option>Divorced</option>
            <option>Seperated</option>
          </select>
        </div>
        <div class="col">
          <label>Date of Birth</label>
          <input type="date" name="date_of_birth">
        </div>
        <div class="col">
          <label>Phone</label>
          <input type="text" name="phone">
        </div>
        <div class="col">
          <label>Email</label>
          <input type="email" name="email">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Gender</label>
          <div class="row" style="display:flex">
            <label style="display:flex; align-items: center; gap: 5px">Male
              <input type="radio" value="Male" name="gender" style="border:none">
            </label>
            <label style="display:flex; align-items: center;">Female
              <input type="radio" value="Female" name="gender" style="border:none">
            </label>
          </div>
        </div>
        <div class="col">
          <label>State of Origin</label>
          <input type="text" name="state_of_origin">
        </div>
        <div class="col">
          <label>NINO</label>
          <input type="text" name="nino">
        </div>
        <div class="col">
          <label>Medical Condition</label>
          <input type="text" name="medical_condition">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Name of Bank</label>
          <input type="text" name="bank_name">
        </div>
        <div class="col">
          <label>Name of Account</label>
          <input type="text" name="account_name">
        </div>
        <div class="col">
          <label>Account Number</label>
          <input type="text" name="account_number">
        </div>
      </div>

      <h4>Family Data</h4>
      <div class="row">
        <div class="col">
          <label>Father Name</label>
          <input type="text" name="father_name">
        </div>
        <div class="col">
          <label>Father Occupation</label>
          <input type="text" name="father_occupation">
        </div>
        <div class="col">
          <label>Father Address</label>
          <input type="text" name="father_address">
        </div>
        <div class="col">
          <label>Father Phone No.</label>
          <input type="text" name="father_phone">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Mother Name</label>
          <input type="text" name="mother_name">
        </div>
        <div class="col">
          <label>Mother Occupation</label>
          <input type="text" name="mother_occupation">
        </div>
        <div class="col">
          <label>Mother Address</label>
          <input type="text" name="mother_address">
        </div>
        <div class="col">
          <label>Mother Phone No.</label>
          <input type="text" name="mother_phone">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>No. of Siblings</label>
          <input type="text" name="siblings_number">
        </div>
      </div>

      <h4>Next Of Kin (Parents or Siblings)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <input type="text" name="nok_surname">
        </div>
        <div class="col">
          <label>Other Names</label>
          <input type="text" name="nok_other_names">
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="nok_address">
        </div>
        <div class="col">
          <label>Phone Number</label>
          <input type="text" name="nok_phone">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Email Address</label>
          <input type="email" name="nok_email">
        </div>
        <div class="col">
          <label>Relationship</label>
          <input type="text" name="nok_relationship">
        </div>
      </div>

      <h4>Reference 1 Data (Previous Employer/School)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <input type="text" name="ref1_surname">
        </div>
        <div class="col">
          <label>Other Names</label>
          <input type="text" name="ref1_other_names">
        </div>
        <div class="col">
          <label>Company</label>
          <input type="text" name="ref1_company">
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="ref1_address">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Phone Number</label>
          <input type="number" name="ref1_phone">
        </div>
        <div class="col">
          <label>Position</label>
          <input type="text" name="ref1_position">
        </div>
      </div>

      <h4>Reference 2 Data (Previous Employer/School)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <input type="text" name="ref2_surname">
        </div>
        <div class="col">
          <label>Other Names</label>
          <input type="text" name="ref2_other_names">
        </div>
        <div class="col">
          <label>Company</label>
          <input type="text" name="ref2_company">
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="ref2_address">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Phone Number</label>
          <input type="number" name="ref2_phone">
        </div>
        <div class="col">
          <label>Email Address</label>
          <input type="email" name="ref2_email">
        </div>
        <div class="col">
          <label>Position</label>
          <input type="text" name="ref2_position">
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update</button>
      </div>
    </form>
  </div>
</div>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php require('../components/common_header.php')  ?>

  <!-- Your page content goes here -->
  <section class="content" style="overflow-y: hidden;">
    <div class="tabs tabs2">
      <div class="tab-it"><a href="./"> Welcome</a></div>
      <div class="tab-it tab-active" style="width: 20%">
        <a href="./users"> Staff Record Summary </a>
      </div>
      <div class="tab-it " style="width: 20%">
        <a href="./entry"> Staff Record Entry </a>
      </div>
      <div class="tab-it">
        <a href="./current-user">Current User</a>
      </div>
    </div>
    <div class="row1" style="margin-top: 20px;">
      <div class="col1">
        <label>Filter by Name</label>
        <input type="text" id="filter-name" placeholder="Enter name..." />
      </div>
      <div class="col1">
        <label>Filter by Month</label>
        <select id="filter-month">
          <option value="">All Months</option>
          <option value="01">January</option>
          <option value="02">February</option>
          <option value="03">March</option>
          <option value="04">April</option>
          <option value="05">May</option>
          <option value="06">June</option>
          <option value="07">July</option>
          <option value="08">August</option>
          <option value="09">September</option>
          <option value="10">October</option>
          <option value="11">November</option>
          <option value="12">December</option>
        </select>
      </div>
      <div class="col1">
        <label>Filter by Year</label>
        <select id="filter-year">
          <option value="">All Years</option>
          <!-- You can dynamically generate years using PHP or JavaScript -->
          <option value="2025">2025</option>
          <option value="2024">2024</option>
        </select>
      </div>
      <div class="col1">
        <label>Filter by Type</label>
        <select id="filter-type">
          <option value="">All Types</option>
          <option value="Full Staff">Full Staff</option>
          <option value="Contract">Contract</option>
          <option value="Probation">Probation</option>
          <option value="Suspended">Suspended</option>
        </select>
      </div>
    </div>
    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table>
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>Staff ID</th>
            <th>Surname</th>
            <th>First Name</th>
            <th>Position</th>
            <th>Department</th>
            <th>Joined Date</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          <?php include '../backend/human-resource/employees/fetch_employees.php'; ?>
        </tbody>
      </table>
    </div>

  </section>
</div>

<script>
  document.addEventListener('DOMContentLoaded', () => {
    const viewModal = document.querySelector('.modal1');
    const viewCloseBtn = document.querySelector('.close1');

    // Close modal
    viewCloseBtn.onclick = () => {
      viewModal.style.display = 'none';
    };

    // Utility: Fill <p> by label text
    const fillViewModal = (data) => {
      const fields = {
        "Full Name": `${data.first_name || ''} ${data.last_name || ''}`,
        "Gender": data.gender,
        "Email": data.email,
        "Marital Status": data.marital_status,
        "Phone Number": data.phone,
        "Date of Birth": data.dob,
        "State Of Origin": data.state_of_origin,
        "NINO": data.nino,
        "Name On Account": data.account_name,
        "Account Number": data.account_number,
        "Branch": data.location,
        "Staff ID": data.id,
        "Title": data.position,
        "Joining Data": data.date_joined,
        "Department": data.department,
        "Medical Condtion": data.medical_condition,
        "Name Of Bank": data.bank_name,
        "Full Staff": data.status,

        // Family
        "Father Name": data.father_name,
        "Father Phone No.": data.father_phone,
        "Father Occupation": data.father_occupation,
        "Father Address": data.father_address,
        "Mother Name": data.mother_name,
        "Mother Phone Number": data.mother_phone,
        "Mother Occupation": data.mother_occupation,
        "Mother Address": data.mother_address,
        "No. Of Siblings": data.siblings_number,

        // Next of Kin
        "Surname": data.next_of_kin_surname,
        "Other Names": data.next_of_kin_other_names,
        "Address": data.next_of_kin_address,
        "Phone No.": data.next_of_kin_phone,
        "Email Address": data.next_of_kin_email,
        "Relationship": data.next_of_kin_relationship,

        // Reference 1
        "Company": data.ref1_company,
        "Position": data.ref1_position,
        "Phone Number": data.ref1_phone,
        "Address": data.ref1_address,
        "Other Names": data.ref1_other_names,
        "Surname": data.ref1_surname,
        "Email Address": data.ref1_email || '',

        // Reference 2
        "Company_2": data.ref2_company,
        "Position_2": data.ref2_position,
        "Phone Number_2": data.ref2_phone,
        "Address_2": data.ref2_address,
        "Other Names_2": data.ref2_other_names,
        "Surname_2": data.ref2_surname,
        "Email Address_2": data.ref2_email || ''
      };

      const rows = viewModal.querySelectorAll('label');
      rows.forEach(label => {
        const text = label.textContent.trim();
        const p = label.parentElement.querySelector('p');

        // Handle duplicate labels by label+index if needed
        const value = fields[text] || fields[text + '_2'] || 'No data';
        if (p) p.textContent = value || 'No data';
      });
    };

    // View button click
    document.querySelectorAll('.view-btn').forEach(button => {
      button.onclick = async () => {
        const id = button.dataset.id;
        const res = await fetch(`../backend/human-resource/employees/get_employee.php?id=${id}`);
        if (!res.ok) {
          alert('Failed to fetch employee data.');
          return;
        }
        const data = await res.json();
        fillViewModal(data);
        viewModal.style.display = 'block';
      };
    });
  });
</script>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    const filters = ['#filter-name', '#filter-month', '#filter-year', '#filter-type'];
    filters.forEach(id => document.querySelector(id).addEventListener('input', applyFilters));
    filters.forEach(id => document.querySelector(id).addEventListener('change', applyFilters));

    async function applyFilters() {
      const name = document.querySelector('#filter-name').value;
      const month = document.querySelector('#filter-month').value;
      const year = document.querySelector('#filter-year').value;
      const type = document.querySelector('#filter-type').value;

      const response = await fetch('../backend/human-resource/employees/filter_employees.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name,
          month,
          year,
          type
        })
      });

      const rows = await response.text();
      document.querySelector('.leads-table tbody').innerHTML = rows;
    }
  });
</script>

<style>
   colgroup col:nth-child(1) {
    width: 80px;
  }

  colgroup col:nth-child(2) {
    width: 120px;
  }

  colgroup col:nth-child(3) {
    width: 120px;
  }

  colgroup col:nth-child(4) {
    width: 160px;
  }

  colgroup col:nth-child(5) {
    width: 180px;
  }

  colgroup col:nth-child(6) {
    width: 120px;
  }

  colgroup col:nth-child(7) {
    width: 70px;
  }

  colgroup col:nth-child(8) {
    width: 50px;
  }

  colgroup col:nth-child(9) {
    width: 60px;
  }
</style>
<?php include_once '../components/cashflow_footer.php'; ?>