<?php require('../components/header.php')  ?>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php require('../components/common_header.php') ?>
  <!-- Your page content goes here -->
  <section class="content" style="overflow-y: hidden">
    <div class="tabs tabs2">
      <div class="tab-it"><a href="./"> Welcome</a></div>
      <div class="tab-it" style="width: 20%">
        <a href="./users"> Staff Record Summary </a>
      </div>
      <div class="tab-it" style="width: 20%">
        <a href="./entry"> Staff Record Entry </a>
      </div>
      <div class="tab-it tab-active">
        <a href="./current-user">Current User</a>
      </div>
    </div>
    <div class="over-table" style="height: 97%;padding: 1rem;margin-top: 4.5rem;">

      <form>
        <div class="row">

          <div class="col">
            <label>First Name</label>
            <input type="text" readonly name="first_name" />
          </div>
          <div class="col">
            <label>Last Name</label>
            <input type="text" readonly name="last_name" />
          </div>
          <div class="col">
            <label>Staff ID</label>
            <input type="text" readonly name="staff_id" />
          </div>
        </div>
        <div class="row">

          <div class="col">
            <label>Email</label>
            <input
              type="email"
              name="email"
              readonly
              placeholder="Enter email" />
          </div>
          <div class="col">
            <label>Role</label>
            <input
              type="text"
              name="role"
              readonly
              placeholder="Enter category" />
          </div>
          <div class="col">
            <label>Phone Number</label>
            <input type="tel" readonly name="number" />
          </div>
        </div>
      </form>

  </section>
</div>
<script>
  async function loadUser() {
    try {
      const response = await fetch('../backend/admin/current-user.php');
      const result = await response.json();

      if (response.ok && result.success) {
        const user = result.data;
        document.querySelector('input[name="first_name"]').value = user.firstname || '';
        document.querySelector('input[name="last_name"]').value = user.lastname || '';
        document.querySelector('input[name="staff_id"]').value = user.staff_id || '';
        document.querySelector('input[name="email"]').value = user.email || '';
        document.querySelector('input[name="role"]').value = user.role || '';
        document.querySelector('input[name="number"]').value = user.phonenumber || '';

      } else {
        alert(result.error || 'Failed to fetch User.');
      }
    } catch (error) {
      alert('An error occurred while fetching Users.');
    }
  }
  window.addEventListener('DOMContentLoaded', loadUser);
</script>

<?php require('../components/cashflow_footer.php') ?>