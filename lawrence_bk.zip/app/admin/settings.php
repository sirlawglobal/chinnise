<?php require('../components/header.php')  ?>
<style>
  .card {
    height: initial;
    padding: 1rem;
  }

  .d-flex {
    display: flex;
  }

  .mt-3 {
    margin-top: 1.5rem;
  }

  .img-icon {
    border: 1px solid black;
    width: 130px;
    height: 130px;
    margin-left: 3%;
  }

  .colour-data {
    color: #007bff;
    /* font-weight: 500; */
  }

  .text-sm {
    font-size: 18px;
    padding: 1rem;
  }
</style>
<div class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con">Update Settings</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Company Name</label>
          <input type="text" placeholder="Enter company name" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Company Logo</label>
          <input type="file" placeholder="Enter logo" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Address</label>
          <input type="text" placeholder="Enter address" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Email</label>
          <input type="email" placeholder="Enter email" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Phone Number</label>
          <input type="tel" placeholder="Enter phone number" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Managing Director</label>
          <input type="text" placeholder="Enter Managing Director" />
        </div>
      </div>
      <button type="submit" class="save-btn">Update</button>
    </form>
  </div>
</div>



<div class="main" style="overflow: hidden">
  <?php require('../components/common_header.php') ?>

  <!-- Your page content goes here -->
  <section class="content">
    <div class="tabs">
      <div class="tabs">
        <div style="align-items: center; display: flex">
          <span class="tab">Admin</span>
          <span class="divider"></span>
          <span class="tab active">Settings</span>
        </div>
      </div>
    </div>
    <div class="col-md-12 card settings-card p-3">
      <div class="d-flex">
        <div>
          <span><b>Company's Name:</b></span>
        </div>
        &nbsp;&nbsp;&nbsp;
        <div>
          <span class="colour-data"> Francis Co</span>
        </div>
      </div>
      <div class="d-flex mt-3">
        <div>
          <span><b>Company's Logo:</b></span>
        </div>

        <div>
          <img class="img-icon" src="../../config/uploads/" />
        </div>
      </div>
      <div class="d-flex mt-3">
        <div>
          <span><b>Address:</b></span>
        </div>
        &nbsp;&nbsp;&nbsp;
        <div>
          <span class="colour-data"> No. 31 Unity Rd</span>
        </div>
      </div>
      <div class="d-flex mt-3">
        <div>
          <span><b>Email:</b></span>
        </div>
        &nbsp;&nbsp;&nbsp;
        <div>
          <span class="colour-data"> francisokpani570@gmail</span>
        </div>
      </div>
      <div class="d-flex mt-3">
        <div>
          <span><b>Phone Number:</b></span>
        </div>
        &nbsp;&nbsp;&nbsp;
        <div>
          <span class="colour-data">09036543366</span>
        </div>
      </div>
      <div class="d-flex mt-3">
        <div>
          <span><b>Managing Director:</b></span>
        </div>
        &nbsp;&nbsp;&nbsp;
        <div>
          <span class="colour-data">Mr Gbenga</span>
        </div>
      </div>
      <div class="mt-5" style="text-align: right">
        <button
          data-bs-toggle="modal"
          data-bs-target="#updateSettingsModal"
          class="add-new-button update-settings">
          Update Settings
        </button>
      </div>
    </div>
    <form method="POST">
      <input
        type="hidden"
        name="createAttendanceSettings"
        value="Attendance Settings" />
      <h4 style="padding: 1rem"><strong>Attendance Settings</strong></h4>
      <div class="row text-sm">
        <div class="col2">
          <label class="form-label">Resumption Time</label>
          09:00 PM
          <div class="d-flex">
            <input
              type="time"
              name="resumption_time"
              class="form-control"
              required="" />
            <!-- <select name="from_meridian" required="">
                  <option value="">PM/AM</option>
                  <option value="PM">PM</option>
                  <option value="AM">AM</option>
                </select> -->
          </div>
        </div>
        <div class="col2">
          <div>
            <label class="form-label">Closing Time</label>
            18:15 AM
            <div class="d-flex">
              <input
                type="time"
                name="closing_time"
                class="form-control"
                required="" />
              <!-- <select name="to_meridian" required="">
                    <option value="">PM/AM</option>
                    <option value="PM">PM</option>
                    <option value="AM">AM</option>
                  </select> -->
            </div>
          </div>
        </div>
        <div class="col2">
          <div class="mt-4">
            <button type="submit" class="add-new-button">Update</button>
          </div>
        </div>
      </div>
    </form>
  </section>
</div>
<?php require('../components/common_footer.php')  ?>