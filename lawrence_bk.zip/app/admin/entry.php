<?php require('../components/header.php')  ?>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php require('../components/common_header.php') ?>
  <!-- Your page content goes here -->
  <section class="content" style="overflow-y: hidden">
    <div class="tabs tabs2">
      <div class="tab-it"><a href="./"> Welcome</a></div>
      <div class="tab-it" style="width: 20%">
        <a href="./users"> Staff Record Summary </a>
      </div>
      <div class="tab-it tab-active" style="width: 20%">
        <a href="./entry"> Staff Record Entry </a>
      </div>
      <div class="tab-it">
        <a href="./current-user">Current User</a>
      </div>
    </div>
    <div class="over-table" style="height: 97%">
      <div>
        <div style="text-align: center">
          <a href="../human-resource/employee-management">
            <button
              class="add-new-button"
              style="border-radius: 15px; font-size: 1rem; margin-top: 15%">
              Register New Staff
            </button></a>
        </div>
      </div>
    </div>
  </section>
</div>

<?php require('../components/common_footer.php') ?>