<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
  // Not logged in, redirect to login page
  header("Location: auth/login.php");
  exit;
}
?>

<?php include_once('./components/header.php') ?>
<div class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con"></h2>
    <h2 id="clockin-out">Clock In/Out</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Staff ID</label>
          <input type="text" readonly value="<?php echo $_SESSION['staff_id']; ?>" />
        </div>
        <div class="col">
          <label>Staff Name</label>
          <input type="text" readonly value="<?php echo $_SESSION['surname']; ?> <?php echo $_SESSION['firstname']; ?>" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label id="time-in">From</label>
          <input type="time" id="time-click" readonly value="" />
        </div>
        <div class="col">
          <label>Date</label>
          <input type="date" id="today-date" readonly value="" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Note</label>
          <input type="text" placeholder="Note..." />
        </div>
      </div>
      <button type="submit" class="save-btn">Save</button>
    </form>
  </div>
</div>

<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php include_once('./components/common_header.php') ?>
  <style>
    #clockin-out {
      text-align: center;
    }
  </style>
  <!-- Your page content goes here -->
  <section class="content" style="overflow-y: hidden">
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Human Resources</span>
        <span class="divider"></span>
        <span class="tab active">Daily Attendance</span>
      </div>
      <div class="anb-container">
        <button class="add-new-button clock-in" style="border-radius: 15px">
          Clock In
        </button>
        <button
          class="add-new-button clock-out"
          style="border-radius: 15px">
          Clock Out
        </button>
        <button class="add-new-button" style="border-radius: 15px">
          W/E Overtime
        </button>
      </div>
    </div>
    <h1
      id="clock"
      style="font-size: 4.5rem; text-align: center; color: #007bff">
      13:43
    </h1>
    <?php
    include_once 'settings/connection.php';

    // Fetch all timesheet entries with staff name
    $sql = "
    SELECT 
        t.date,
        s.staff_id,
        CONCAT(s.firstname, ' ', s.lastname) AS employee_name,
        t.time_in,
        t.time_out,
        t.note,
        t.type
    FROM timesheet t
    JOIN staffs s ON t.staff_id = s.id
    ORDER BY t.date DESC
  ";

    $stmt = $pdo->query($sql);
    $timesheets = $stmt->fetchAll();
    ?>

    <div class="over-table">
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Staff ID</th>
            <th>Employee Name</th>
            <th>Time In</th>
            <th>Time Out</th>
            <th>Note</th>
            <th>Late</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($timesheets as $row): ?>
            <tr>
              <td>
                <?= date('d-m-Y', strtotime($row['date'])) ?>
              </td>
              <td><?= htmlspecialchars($row['staff_id']) ?></td>
              <td><?= htmlspecialchars(mb_strimwidth($row['employee_name'], 0, 12, '.')) ?></td>
              <td><?= htmlspecialchars($row['time_in']) ?></td>
              <td><?= htmlspecialchars($row['time_out'] ?? '-') ?></td>
              <td><?= htmlspecialchars($row['note']) ?></td>
              <td>
                <?= ($row['time_in'] > '09:00:00' && $row['type'] === 'NT') ? 'Yes' : 'No' ?>
              </td>
              <td><?= $row['type'] === 'OT' ? 'Overtime' : 'NT' ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="pagination-controls">
      <div class="RPP">
        <label for="rowsPerPage">Rows per page:</label>
        <select id="rowsPerPage">
          <option value="25" selected>25</option>
          <option value="50">50</option>
          <option value="75">75</option>
          <option value="100">100</option>
        </select>
      </div>
      <div>
        <button id="prevPage">Previous</button>
        <span id="pageInfo">Page 1 of 1</span>
        <button id="nextPage">Next</button>
      </div>
    </div>

  </section>
</div>

<script>
  function updateClock() {
    const now = new Date();
    const todayDate = now.toISOString().split("T")[0];
    document.getElementById("today-date").value = todayDate;
    const hours = now.getHours().toString().padStart(2, "0");
    const mins = now.getMinutes().toString().padStart(2, "0");
    document.getElementById("clock").textContent = `${hours}:${mins}`;
    document.getElementById("clockin-out").textContent = `${hours}:${mins}`;
    document.getElementById("time-click").value = `${hours}:${mins}`;
  }
  updateClock();
  setInterval(updateClock, 1000);


  const btnci = document.querySelector(".clock-in");
  const btnco = document.querySelector(".clock-out");
  const modalc = document.querySelector(".modal");
  const closeBtnc = document.querySelector(".close");

  btnci.addEventListener("click", () => {
    const clockInText = document.querySelector(".con");
    clockInText.textContent = "Clock In";
    document.getElementById("time-in").textContent = `Resumption Time`;
    modalc.style.display = "block";
  });
  btnco.addEventListener("click", () => {
    const clockInOutText = document.querySelector(".con");
    clockInOutText.textContent = "Clock Out";
    document.getElementById("time-in").textContent = `Closing Time`;
    modalc.style.display = "block";
  });
  closeBtnc.addEventListener("click", () => {
    modalc.style.display = "none";
  });
  window.addEventListener("click", (event) => {
    if (event.target == modalc) {
      modalc.style.display = "none";
    }
  });
</script>
<script>
  function saveTime(type) {
    const note = document.querySelector('input[placeholder="Note..."]').value;
    const time = document.getElementById("time-click").value;
    const date = document.getElementById("today-date").value;

    fetch('backend/timesheet/save_timesheet.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `type=${type}&note=${note}&time=${time}&date=${date}`
      })
      .then(response => response.text())
      .then(data => {
        alert(data);
        document.querySelector(".clock-in").disabled = true;
        document.querySelector(".clock-out").disabled = true;
        modalc.style.display = "none";
        window.location.reload();
      });
  }

  // Hook to save button
  document.querySelector(".save-btn").addEventListener("click", function(e) {
    e.preventDefault();
    const action = document.querySelector(".con").textContent;
    if (action === "Clock In") {
      saveTime("NT");
    } else if (action === "Clock Out") {
      saveTime("NT");
    } else if (action === "Overtime") {
      saveTime("OT");
    }
  });
</script>
<script>
  const btnot = document.querySelector(".add-new-button:not(.clock-in):not(.clock-out)");

  btnot.addEventListener("click", () => {
    const text = document.querySelector(".con");
    text.textContent = "Overtime";
    document.getElementById("time-in").textContent = `Overtime Start`;
    modalc.style.display = "block";
  });
</script>

<script>
  let currentPage = 1;
  let rowsPerPage = 25;

  const tbody = document.querySelector("tbody");
  const rowsPerPageSelect = document.getElementById("rowsPerPage");
  const prevPageBtn = document.getElementById("prevPage");
  const nextPageBtn = document.getElementById("nextPage");
  const pageInfoSpan = document.getElementById("pageInfo");

  const allRows = Array.from(tbody.querySelectorAll("tr"));

  function paginateRows() {
    const totalPages = Math.ceil(allRows.length / rowsPerPage);
    pageInfoSpan.textContent = `Page ${currentPage} of ${totalPages}`;

    prevPageBtn.disabled = currentPage === 1;
    nextPageBtn.disabled = currentPage === totalPages;

    allRows.forEach((row, index) => {
      const start = (currentPage - 1) * rowsPerPage;
      const end = currentPage * rowsPerPage;
      row.style.display = index >= start && index < end ? "" : "none";
    });
  }

  rowsPerPageSelect.addEventListener("change", () => {
    rowsPerPage = parseInt(rowsPerPageSelect.value);
    currentPage = 1;
    paginateRows();
  });

  prevPageBtn.addEventListener("click", () => {
    if (currentPage > 1) {
      currentPage--;
      paginateRows();
    }
  });

  nextPageBtn.addEventListener("click", () => {
    currentPage++;
    paginateRows();
  });

  document.addEventListener("DOMContentLoaded", paginateRows);
</script>

<?php include_once('./components/common_footer.php') ?>