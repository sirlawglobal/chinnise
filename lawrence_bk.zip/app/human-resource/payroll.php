<?php include_once '../components/header.php'; ?>

<div class="main">
  <?php include_once '../components/common_header.php'; ?>

  <!-- Your page content goes here -->
  <section class="content">
    <header id="payroll-header">
      <div class="tabs">
        <button class="tab-btn active" data-tab="welcome" onclick="location.href='./payroll'">Welcome</button>
        <button class="tab-btn" onclick="location.href='./my-payroll'" data-tab="payroll">Payroll</button>
        <!-- <button class="tab-btn" onclick="location.href='./deductions'" data-tab="deductions">Deductions</button> -->
        <!-- <button class="tab-btn" onclick="location.href='./monthly-bonus'" data-tab="bonus">Monthly Bonus</button> -->
        <!-- <button class="tab-btn" onclick="location.href='./pay-grade'" data-tab="paygrade">Pay Grade</button> -->
        <button class="tab-btn" onclick="location.href='./payment-history'" data-tab="history">Payment History</button>
      </div>
    </header>
    <main>
      <h3 class="welcome-message">Welcome</h3>
      <p class="today">What will you like to do today?</p>
      <img class="payroll-img" src="../assets/payroll.png" alt="payroll" />
    </main>
  </section>
</div>

<?php include_once '../components/cashflow_footer.php'; ?>