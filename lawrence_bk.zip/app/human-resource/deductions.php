<?php include_once '../components/header.php'; ?>
<div class="main">
  <?php include_once '../components/common_header.php'; ?>


  <!-- Your page content goes here -->
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources</a> | <span>Deductions</span>
        </div>
      </div>
    </div>
    <header id="payroll-header">
      <div class="tabs">
        <!--<button class="tab-btn" data-tab="welcome" onclick="location.href='./payroll'">Welcome</button> -->
        <button class="tab-btn" onclick="location.href='./my-payroll'" data-tab="payroll">Payroll</button>
        <button class="tab-btn active" onclick="location.href='./deductions'" data-tab="deductions">Deductions</button>
        <!-- <button class="tab-btn" onclick="location.href='./monthly-bonus'" data-tab="bonus">Monthly Bonus</button> -->
        <!-- <button class="tab-btn" onclick="location.href='./pay-grade'" data-tab="paygrade">Pay Grade</button> -->
        <button class="tab-btn" onclick="location.href='./payment-history'" data-tab="history">Payment History</button>
      </div>
    </header>
    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table class="leads-table">
        <thead>
          <tr>
            <th>Staff ID	</th>
            <th>Surname	</th>
            <th>Firstname	</th>
            <th>Basic Salary	</th>
            <th>Deductions</th>
          </tr>
        </thead>
        <tbody id="deduction-table-body">
  <!-- Rows will be inserted here dynamically -->
</tbody>

      </table>
    </div>
  </section>
</div>
<script>
  fetch('../backend/human-resource/payroll/fetch_deductions.php')
    .then(res => res.json())
    .then(data => {
      const tbody = document.getElementById('deduction-table-body');

      if (data.error) {
        tbody.innerHTML = `<tr><td colspan="5">Error: ${data.error}</td></tr>`;
        return;
      }

      if (data.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5">No deductions found.</td></tr>`;
        return;
      }

      tbody.innerHTML = data.map(row => `
        <tr>
          <td>${row.staff_id}</td>
          <td>${row.surname}</td>
          <td>${row.first_name}</td>
          <td>${Number(row.basic_salary).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
          <td>${Number(row.deductions).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
        </tr>
      `).join('');
    })
    .catch(err => {
      document.getElementById('deduction-table-body').innerHTML = `<tr><td colspan="5">Failed to load data</td></tr>`;
    });
</script>

<?php include_once '../components/cashflow_footer.php'; ?>
