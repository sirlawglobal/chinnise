<?php include_once '../components/header.php'; ?>
<div class="modal" style="display: none;">
  <div class="modal-content">
    <span class="close">×</span>
    <h2 class="con">Add Employee</h2>
    <form action="../backend/human-resource/employees/add_employee.php" method="POST" enctype="multipart/form-data">

      <h4>Personal Data</h4>
      <div class="row">
        <div class="col">
          <label>Picture</label>
          <input type="file" style="border:none" name="picture">
        </div>
        <div class="col">
          <label>First Name*</label>
          <input type="text" name="first_name">
        </div>
        <div class="col">
          <label>Last Name*</label>
          <input type="text" name="last_name">
        </div>
        <div class="col">
          <label>Date Joined</label>
          <input type="date" name="date_joined">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Position</label>
          <input type="text" name="position">
        </div>
        <div class="col">
          <label>Status*</label>
          <select name="status">
            <option>Please Select</option>
            <option>Full Staff</option>
            <option>Contract</option>
            <option>Probation</option>
            <option>Suspended</option>
          </select>
        </div>
        <div class="col">
          <label>Department</label>
          <select name="department">
            <option>Department</option>
            <option>Information & Technology</option>
            <option>IT Sales</option>
            <option>GN122 Health Care</option>
            <option>GN 122 Child Care</option>
          </select>
        </div>
        <div class="col">
          <label>Location/Branch</label>
          <input type="text" name="location">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Marital Status</label>
          <select name="marital_status">
            <option>Please Select</option>
            <option>Single</option>
            <option>Married</option>
            <option>Widow</option>
            <option>Divorced</option>
            <option>Seperated</option>
          </select>
        </div>
        <div class="col">
          <label>Date of Birth</label>
          <input type="date" name="date_of_birth">
        </div>
        <div class="col">
          <label>Phone</label>
          <input type="text" name="phone">
        </div>
        <div class="col">
          <label>Email</label>
          <input type="email" name="email">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Gender</label>
          <div class="row" style="display:flex">
            <label style="display:flex; align-items: center; gap: 5px">Male
              <input type="radio" value="Male" name="gender" style="border:none">
            </label>
            <label style="display:flex; align-items: center;">Female
              <input type="radio" value="Female" name="gender" style="border:none">
            </label>
          </div>
        </div>
        <div class="col">
          <label>State of Origin</label>
          <input type="text" name="state_of_origin">
        </div>
        <div class="col">
          <label>NINO</label>
          <input type="text" name="nino">
        </div>
        <div class="col">
          <label>Medical Condition</label>
          <input type="text" name="medical_condition">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Name of Bank</label>
          <input type="text" name="bank_name">
        </div>
        <div class="col">
          <label>Name of Account</label>
          <input type="text" name="account_name">
        </div>
        <div class="col">
          <label>Account Number</label>
          <input type="text" name="account_number">
        </div>
      </div>

      <h4>Family Data</h4>
      <div class="row">
        <div class="col">
          <label>Father Name</label>
          <input type="text" name="father_name">
        </div>
        <div class="col">
          <label>Father Occupation</label>
          <input type="text" name="father_occupation">
        </div>
        <div class="col">
          <label>Father Address</label>
          <input type="text" name="father_address">
        </div>
        <div class="col">
          <label>Father Phone No.</label>
          <input type="text" name="father_phone">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Mother Name</label>
          <input type="text" name="mother_name">
        </div>
        <div class="col">
          <label>Mother Occupation</label>
          <input type="text" name="mother_occupation">
        </div>
        <div class="col">
          <label>Mother Address</label>
          <input type="text" name="mother_address">
        </div>
        <div class="col">
          <label>Mother Phone No.</label>
          <input type="text" name="mother_phone">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>No. of Siblings</label>
          <input type="text" name="siblings_number">
        </div>
      </div>

      <h4>Next Of Kin (Parents or Siblings)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <input type="text" name="nok_surname">
        </div>
        <div class="col">
          <label>Other Names</label>
          <input type="text" name="nok_other_names">
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="nok_address">
        </div>
        <div class="col">
          <label>Phone Number</label>
          <input type="text" name="nok_phone">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Email Address</label>
          <input type="email" name="nok_email">
        </div>
        <div class="col">
          <label>Relationship</label>
          <input type="text" name="nok_relationship">
        </div>
      </div>

      <h4>Reference 1 Data (Previous Employer/School)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <input type="text" name="ref1_surname">
        </div>
        <div class="col">
          <label>Other Names</label>
          <input type="text" name="ref1_other_names">
        </div>
        <div class="col">
          <label>Company</label>
          <input type="text" name="ref1_company">
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="ref1_address">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Phone Number</label>
          <input type="number" name="ref1_phone">
        </div>
        <div class="col">
          <label>Position</label>
          <input type="text" name="ref1_position">
        </div>
      </div>

      <h4>Reference 2 Data (Previous Employer/School)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <input type="text" name="ref2_surname">
        </div>
        <div class="col">
          <label>Other Names</label>
          <input type="text" name="ref2_other_names">
        </div>
        <div class="col">
          <label>Company</label>
          <input type="text" name="ref2_company">
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="ref2_address">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Phone Number</label>
          <input type="number" name="ref2_phone">
        </div>
        <div class="col">
          <label>Email Address</label>
          <input type="email" name="ref2_email">
        </div>
        <div class="col">
          <label>Position</label>
          <input type="text" name="ref2_position">
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>
<div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">Profile</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Full Name</label>
          <p>Admin Admin</p>
        </div>
        <div class="col">
          <label>Gender</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Email</label>
          <p>admin@admin.com</p>
        </div>
        <div class="col">
          <label>Marital Status</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">

        <div class="col">
          <label>Phone Number</label>
          <p>23456787654323</p>
        </div>
        <div class="col">
          <label>Date of Birth</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>State Of Origin</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>NINO</label>
          <p>No data</p>
        </div>
      </div>

      <div class="row">

        <div class="col">
          <label>Name On Account</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Account Number</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Branch</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Staff ID</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Title</label>
          <p>Admin</p>
        </div>
        <div class="col">
          <label>Joining Data</label>
          <p>1990-01-01</p>
        </div>
        <div class="col">
          <label>Department</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label> Medical Condtion </label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">

        <div class="col">
          <label>Name Of Bank</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Full Staff</label>
          <p>No data</p>
        </div>
      </div>
      <h4>Family Date</h4>
      <div class="row">
        <div class="col">
          <label>Father Name</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Father Phone No.</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Father Occupation</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Father Address</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">

        <div class="col">
          <label>Mother Name</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Mother Phone Number</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Mother Occupation</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Mother Address</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">

        <div class="col">
          <label>No. Of Siblings</label>
          <p>No data</p>
        </div>
      </div>
      <h4>Next Of Kin Data(Parents Or Siblings)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Address</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Other Names</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Phone No.</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">

        <div class="col">
          <label>Email Address</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Relationship</label>
          <p>No data</p>
        </div>
      </div>
      <h4>Reference 1 Data(Previous Employer/School)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Company</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Other Names</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Address</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Phone Number</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Position</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Email Address</label>
          <p>No data</p>
        </div>
      </div>
      <h4>Reference 2 Data(Previous Employer/School)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Company</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Other Names</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Address</label>
          <p>No data</p>
        </div>
      </div>
      <div class="row">

        <div class="col">
          <label>Phone Number</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Position</label>
          <p>No data</p>
        </div>
        <div class="col">
          <label>Email Address</label>
          <p>No data</p>
        </div>
      </div>
    </form>
  </div>



</div>
<div class="modal2" id="edit">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Employee</h2>
    <form>

      <h4>Personal Data</h4>
      <div class="row">
        <div class="col">
          <label>Picture</label>
          <input type="file" style="border:none" name="picture">
        </div>
        <div class="col">
          <label>First Name*</label>
          <input type="text" name="first_name">
        </div>
        <div class="col">
          <label>Last Name*</label>
          <input type="text" name="last_name">
        </div>
        <div class="col">
          <label>Date Joined</label>
          <input type="date" name="date_joined">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Position</label>
          <input type="text" name="position">
        </div>
        <div class="col">
          <label>Status*</label>
          <select name="status">
            <option>Please Select</option>
            <option>Full Staff</option>
            <option>Contract</option>
            <option>Probation</option>
            <option>Suspended</option>
          </select>
        </div>
        <div class="col">
          <label>Department</label>
          <select name="department">
            <option>Department</option>
            <option>Information & Technology</option>
            <option>IT Sales</option>
            <option>GN122 Health Care</option>
            <option>GN 122 Child Care</option>
          </select>
        </div>
        <div class="col">
          <label>Location/Branch</label>
          <input type="text" name="location">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Marital Status</label>
          <select name="marital_status">
            <option>Please Select</option>
            <option>Single</option>
            <option>Married</option>
            <option>Widow</option>
            <option>Divorced</option>
            <option>Seperated</option>
          </select>
        </div>
        <div class="col">
          <label>Date of Birth</label>
          <input type="date" name="date_of_birth">
        </div>
        <div class="col">
          <label>Phone</label>
          <input type="text" name="phone">
        </div>
        <div class="col">
          <label>Email</label>
          <input type="email" name="email">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Gender</label>
          <div class="row" style="display:flex">
            <label style="display:flex; align-items: center; gap: 5px">Male
              <input type="radio" value="Male" name="gender" style="border:none">
            </label>
            <label style="display:flex; align-items: center;">Female
              <input type="radio" value="Female" name="gender" style="border:none">
            </label>
          </div>
        </div>
        <div class="col">
          <label>State of Origin</label>
          <input type="text" name="state_of_origin">
        </div>
        <div class="col">
          <label>NINO</label>
          <input type="text" name="nino">
        </div>
        <div class="col">
          <label>Medical Condition</label>
          <input type="text" name="medical_condition">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Name of Bank</label>
          <input type="text" name="bank_name">
        </div>
        <div class="col">
          <label>Name of Account</label>
          <input type="text" name="account_name">
        </div>
        <div class="col">
          <label>Account Number</label>
          <input type="text" name="account_number">
        </div>
      </div>

      <h4>Family Data</h4>
      <div class="row">
        <div class="col">
          <label>Father Name</label>
          <input type="text" name="father_name">
        </div>
        <div class="col">
          <label>Father Occupation</label>
          <input type="text" name="father_occupation">
        </div>
        <div class="col">
          <label>Father Address</label>
          <input type="text" name="father_address">
        </div>
        <div class="col">
          <label>Father Phone No.</label>
          <input type="text" name="father_phone">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Mother Name</label>
          <input type="text" name="mother_name">
        </div>
        <div class="col">
          <label>Mother Occupation</label>
          <input type="text" name="mother_occupation">
        </div>
        <div class="col">
          <label>Mother Address</label>
          <input type="text" name="mother_address">
        </div>
        <div class="col">
          <label>Mother Phone No.</label>
          <input type="text" name="mother_phone">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>No. of Siblings</label>
          <input type="text" name="siblings_number">
        </div>
      </div>

      <h4>Next Of Kin (Parents or Siblings)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <input type="text" name="nok_surname">
        </div>
        <div class="col">
          <label>Other Names</label>
          <input type="text" name="nok_other_names">
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="nok_address">
        </div>
        <div class="col">
          <label>Phone Number</label>
          <input type="text" name="nok_phone">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Email Address</label>
          <input type="email" name="nok_email">
        </div>
        <div class="col">
          <label>Relationship</label>
          <input type="text" name="nok_relationship">
        </div>
      </div>

      <h4>Reference 1 Data (Previous Employer/School)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <input type="text" name="ref1_surname">
        </div>
        <div class="col">
          <label>Other Names</label>
          <input type="text" name="ref1_other_names">
        </div>
        <div class="col">
          <label>Company</label>
          <input type="text" name="ref1_company">
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="ref1_address">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Phone Number</label>
          <input type="number" name="ref1_phone">
        </div>
        <div class="col">
          <label>Position</label>
          <input type="text" name="ref1_position">
        </div>
      </div>

      <h4>Reference 2 Data (Previous Employer/School)</h4>
      <div class="row">
        <div class="col">
          <label>Surname</label>
          <input type="text" name="ref2_surname">
        </div>
        <div class="col">
          <label>Other Names</label>
          <input type="text" name="ref2_other_names">
        </div>
        <div class="col">
          <label>Company</label>
          <input type="text" name="ref2_company">
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="ref2_address">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Phone Number</label>
          <input type="number" name="ref2_phone">
        </div>
        <div class="col">
          <label>Email Address</label>
          <input type="email" name="ref2_email">
        </div>
        <div class="col">
          <label>Position</label>
          <input type="text" name="ref2_position">
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update</button>
      </div>
    </form>
  </div>
</div>

<div class="main">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources</a> | <span>Employees</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px">
          Add Employee
        </button>
      </div>
    </div>
    <div class="row1">
      <div class="col1">
        <label>Filter by Name</label>
        <input type="text" id="filter-name" placeholder="Enter name..." />
      </div>
      <div class="col1">
        <label>Filter by Type</label>
        <select id="filter-type">
          <option value="">All Types</option>
          <option value="Full Staff">Full Staff</option>
          <option value="Contract">Contract</option>
          <option value="Probation">Probation</option>
          <option value="Suspended">Suspended</option>
        </select>
      </div>
    </div>


    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table>
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>Staff ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Position</th>
            <th>Department</th>
            <th>Joined Date</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          <?php include '../backend/human-resource/employees/fetch_employees.php'; ?>
        </tbody>
      </table>
    </div>
    <div class="pagination-controls">
      <div class="RPP">
        <label for="rowsPerPage">Rows per page:</label>
        <select id="rowsPerPage">
          <option value="25" selected>25</option>
          <option value="50">50</option>
          <option value="75">75</option>
          <option value="100">100</option>
        </select>
      </div>

      <div class="">
        <button id="prevPage">Previous</button>
        <span id="pageInfo">Page 1 of 1</span>
        <button id="nextPage">Next</button>
      </div>
    </div>

  </section>
</div>

<script>
  document.addEventListener('DOMContentLoaded', () => {
    const editModal = document.getElementById('edit');
    const editForm = editModal.querySelector('form');

    // Close modal
    editModal.querySelector('.close2').onclick = () => {
      editModal.style.display = 'none';
    };

  
document.querySelectorAll('.edit-btn').forEach(button => {
  button.onclick = async () => {
    const id = button.dataset.id;
    try {
      const res = await fetch(`../backend/human-resource/employees/get_employee.php?id=${id}`);
      if (!res.ok) throw new Error('Failed to fetch employee data');
      const data = await res.json();
      if (data.status !== 'success') throw new Error(data.message || 'Error fetching data');
      console.log('Fetched data:', data); // Debug the response

      // Populate form inputs
      const editForm = editModal.querySelector('form');
      editForm.querySelector('input[name="first_name"]').value = data.data.first_name || '';
      editForm.querySelector('input[name="last_name"]').value = data.data.last_name || '';
      editForm.querySelector('input[name="date_joined"]').value = data.data.date_joined || '';
      editForm.querySelector('input[name="position"]').value = data.data.position || '';
      editForm.querySelector('select[name="status"]').value = data.data.status || '';
      editForm.querySelector('select[name="department"]').value = data.data.department || '';
      editForm.querySelector('input[name="location"]').value = data.data.location || '';
      editForm.querySelector('select[name="marital_status"]').value = data.data.marital_status || '';
      editForm.querySelector('input[name="date_of_birth"]').value = data.data.date_of_birth || '';
      editForm.querySelector('input[name="phone"]').value = data.data.phone || '';
      editForm.querySelector('input[name="email"]').value = data.data.email || '';

      // Gender (radio buttons)
      if (data.data.gender) {
        const genderInput = editForm.querySelector(`input[name="gender"][value="${data.data.gender}"]`);
        if (genderInput) genderInput.checked = true;
      }

      editForm.querySelector('input[name="state_of_origin"]').value = data.data.state_of_origin || '';
      editForm.querySelector('input[name="nino"]').value = data.data.nino || '';
      editForm.querySelector('input[name="medical_condition"]').value = data.data.medical_condition || '';

      editForm.querySelector('input[name="bank_name"]').value = data.data.bank_name || '';
      editForm.querySelector('input[name="account_name"]').value = data.data.account_name || '';
      editForm.querySelector('input[name="account_number"]').value = data.data.account_number || '';

      // Family data
      editForm.querySelector('input[name="father_name"]').value = data.data.father_name || '';
      editForm.querySelector('input[name="father_occupation"]').value = data.data.father_occupation || '';
      editForm.querySelector('input[name="father_address"]').value = data.data.father_address || '';
      editForm.querySelector('input[name="father_phone"]').value = data.data.father_phone || '';

      editForm.querySelector('input[name="mother_name"]').value = data.data.mother_name || '';
      editForm.querySelector('input[name="mother_occupation"]').value = data.data.mother_occupation || '';
      editForm.querySelector('input[name="mother_address"]').value = data.data.mother_address || '';
      editForm.querySelector('input[name="mother_phone"]').value = data.data.mother_phone || '';

      editForm.querySelector('input[name="siblings_number"]').value = data.data.siblings_number || '';

      // Next of kin
      editForm.querySelector('input[name="nok_surname"]').value = data.data.nok_surname || '';
      editForm.querySelector('input[name="nok_other_names"]').value = data.data.nok_other_names || '';
      editForm.querySelector('input[name="nok_address"]').value = data.data.nok_address || '';
      editForm.querySelector('input[name="nok_phone"]').value = data.data.nok_phone || '';
      editForm.querySelector('input[name="nok_email"]').value = data.data.nok_email || '';
      editForm.querySelector('input[name="nok_relationship"]').value = data.data.nok_relationship || '';

      // Reference 1
      editForm.querySelector('input[name="ref1_surname"]').value = data.data.ref1_surname || '';
      editForm.querySelector('input[name="ref1_other_names"]').value = data.data.ref1_other_names || '';
      editForm.querySelector('input[name="ref1_company"]').value = data.data.ref1_company || '';
      editForm.querySelector('input[name="ref1_address"]').value = data.data.ref1_address || '';
      editForm.querySelector('input[name="ref1_phone"]').value = data.data.ref1_phone || '';
      editForm.querySelector('input[name="ref1_position"]').value = data.data.ref1_position || '';

      // Reference 2
      editForm.querySelector('input[name="ref2_surname"]').value = data.data.ref2_surname || '';
      editForm.querySelector('input[name="ref2_other_names"]').value = data.data.ref2_other_names || '';
      editForm.querySelector('input[name="ref2_company"]').value = data.data.ref2_company || '';
      editForm.querySelector('input[name="ref2_address"]').value = data.data.ref2_address || '';
      editForm.querySelector('input[name="ref2_phone"]').value = data.data.ref2_phone || '';
      editForm.querySelector('input[name="ref2_email"]').value = data.data.ref2_email || '';
      editForm.querySelector('input[name="ref2_position"]').value = data.data.ref2_position || '';

      // Store id in form dataset or hidden input
      if (!editForm.querySelector('input[name="id"]')) {
        const idInput = document.createElement('input');
        idInput.type = 'hidden';
        idInput.name = 'id';
        editForm.appendChild(idInput);
      }
      editForm.querySelector('input[name="id"]').value = id;

      editModal.style.display = 'block';
    } catch (error) {
      console.error('Error:', error.message);
      alert('Failed to load employee data');
    }
  };
});

    // Submit Edit form via AJAX
    editForm.onsubmit = async (e) => {
      e.preventDefault();

      // Collect form data as object
      const formData = new FormData(editForm);
      const data = {};
      formData.forEach((v, k) => data[k] = v);

      // Handle radios separately for gender
      const gender = editForm.querySelector('input[name="gender"]:checked');
      data.gender = gender ? gender.value : '';

      // Send update request
      const res = await fetch('../backend/human-resource/employees/update_employee.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
      const result = await res.json();

      if (result.success) {
        alert('Employee updated successfully');
        editModal.style.display = 'none';
        location.reload(); // refresh table to show updates
      } else {
        alert('Update failed');
      }
    };

    // Delete button handler
    document.querySelectorAll('.delete-btn').forEach(button => {
      button.onclick = async () => {
        if (!confirm('Are you sure you want to delete this employee?')) return;
        const id = button.dataset.id;

        const res = await fetch('../backend/human-resource/employees/delete_employee.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: `id=${encodeURIComponent(id)}`
        });
        const result = await res.json();

        if (result.success) {
          alert('Employee deleted');
          location.reload();
        } else {
          alert('Delete failed');
        }
      };
    });
  });
</script>
<script>
//   document.addEventListener('DOMContentLoaded', () => {
//     const viewModal = document.querySelector('.modal1');
//     const viewCloseBtn = document.querySelector('.close1');

//     // Close modal
//     viewCloseBtn.onclick = () => {
//       viewModal.style.display = 'none';
//     };

//     // Utility: Fill <p> by label text
//     const fillViewModal = (data) => {
     
//         console.log('data',data);
//           alert('red');
//       const fields = {
//         "Full Name": `${data.first_name || ''} ${data.last_name || ''}`,
//         "Gender": data.gender,
//         "Email": data.email,
//         "Marital Status": data.marital_status,
//         "Phone Number": data.phone,
//         "Date of Birth": data.dob,
//         "State Of Origin": data.state_of_origin,
//         "NINO": data.nino,
//         "Name On Account": data.account_name,
//         "Account Number": data.account_number,
//         "Branch": data.location,
//         "Staff ID": data.id,
//         "Title": data.position,
//         "Joining Data": data.date_joined,
//         "Department": data.department,
//         "Medical Condtion": data.medical_condition,
//         "Name Of Bank": data.bank_name,
//         "Full Staff": data.status,

//         // Family
//         "Father Name": data.father_name,
//         "Father Phone No.": data.father_phone,
//         "Father Occupation": data.father_occupation,
//         "Father Address": data.father_address,
//         "Mother Name": data.mother_name,
//         "Mother Phone Number": data.mother_phone,
//         "Mother Occupation": data.mother_occupation,
//         "Mother Address": data.mother_address,
//         "No. Of Siblings": data.siblings_number,

//         // Next of Kin
//         "Surname": data.next_of_kin_surname,
//         "Other Names": data.next_of_kin_other_names,
//         "Address": data.next_of_kin_address,
//         "Phone No.": data.next_of_kin_phone,
//         "Email Address": data.next_of_kin_email,
//         "Relationship": data.next_of_kin_relationship,

//         // Reference 1
//         "Company": data.ref1_company,
//         "Position": data.ref1_position,
//         "Phone Number": data.ref1_phone,
//         "Address": data.ref1_address,
//         "Other Names": data.ref1_other_names,
//         "Surname": data.ref1_surname,
//         "Email Address": data.ref1_email || '',

//         // Reference 2
//         "Company_2": data.ref2_company,
//         "Position_2": data.ref2_position,
//         "Phone Number_2": data.ref2_phone,
//         "Address_2": data.ref2_address,
//         "Other Names_2": data.ref2_other_names,
//         "Surname_2": data.ref2_surname,
//         "Email Address_2": data.ref2_email || ''
//       };

//       const rows = viewModal.querySelectorAll('label');
//       rows.forEach(label => {
//         const text = label.textContent.trim();
//         const p = label.parentElement.querySelector('p');

//         // Handle duplicate labels by label+index if needed
//         const value = fields[text] || fields[text + '_2'] || 'No data';
//         if (p) p.textContent = value || 'No data';
//       });
//     };

//     // View button click
//     document.querySelectorAll('.view-btn').forEach(button => {
//       button.onclick = async () => {
//         const id = button.dataset.id;
//         const res = await fetch(`../backend/human-resource/employees/get_employee.php?id=${id}`);
//         if (!res.ok) {
//           alert('Failed to fetch employee data.');
//           return;
//         }
//         const data = await res.json();
//         console.log('data',data);
//         fillViewModal(data);
//         viewModal.style.display = 'block';
//       };
//     });
//   });
document.addEventListener('DOMContentLoaded', () => {
  const viewModal = document.querySelector('.modal1');
  const viewCloseBtn = document.querySelector('.close1');

  // Close modal
  viewCloseBtn.onclick = () => {
    viewModal.style.display = 'none';
  };

  // Utility: Fill <p> by label text
  const fillViewModal = (data) => {
    console.log('View modal data:', data); // Debug the response
    const fields = {
      "Full Name": `${data.data.first_name || ''} ${data.data.last_name || ''}`,
      "Gender": data.data.gender || 'No data',
      "Email": data.data.email || 'No data',
      "Marital Status": data.data.marital_status || 'No data',
      "Phone Number": data.data.phone || 'No data',
      "Date of Birth": data.data.date_of_birth || 'No data',
      "State Of Origin": data.data.state_of_origin || 'No data',
      "NINO": data.data.nino || 'No data',
      "Name On Account": data.data.account_name || 'No data',
      "Account Number": data.data.account_number || 'No data',
      "Branch": data.data.location || 'No data',
      "Staff ID": data.data.id || 'No data',
      "Title": data.data.position || 'No data',
      "Joining Data": data.data.date_joined || 'No data',
      "Department": data.data.department || 'No data',
      "Medical Condtion": data.data.medical_condition || 'No data',
      "Name Of Bank": data.data.bank_name || 'No data',
      "Full Staff": data.data.status || 'No data',
      // Family
      "Father Name": data.data.father_name || 'No data',
      "Father Phone No.": data.data.father_phone || 'No data',
      "Father Occupation": data.data.father_occupation || 'No data',
      "Father Address": data.data.father_address || 'No data',
      "Mother Name": data.data.mother_name || 'No data',
      "Mother Phone Number": data.data.mother_phone || 'No data',
      "Mother Occupation": data.data.mother_occupation || 'No data',
      "Mother Address": data.data.mother_address || 'No data',
      "No. Of Siblings": data.data.siblings_number || 'No data',
      // Next of Kin
      "Surname": data.data.nok_surname || 'No data',
      "Other Names": data.data.nok_other_names || 'No data',
      "Address": data.data.nok_address || 'No data',
      "Phone No.": data.data.nok_phone || 'No data',
      "Email Address": data.data.nok_email || 'No data',
      "Relationship": data.data.nok_relationship || 'No data',
      // Reference 1
      "Surname_1": data.data.ref1_surname || 'No data',
      "Other Names_1": data.data.ref1_other_names || 'No data',
      "Company": data.data.ref1_company || 'No data',
      "Address_1": data.data.ref1_address || 'No data',
      "Phone Number": data.data.ref1_phone || 'No data',
      "Position": data.data.ref1_position || 'No data',
      "Email Address": data.data.ref1_email || 'No data',
      // Reference 2
      "Surname_2": data.data.ref2_surname || 'No data',
      "Other Names_2": data.data.ref2_other_names || 'No data',
      "Company_2": data.data.ref2_company || 'No data',
      "Address_2": data.data.ref2_address || 'No data',
      "Phone Number_2": data.data.ref2_phone || 'No data',
      "Position_2": data.data.ref2_position || 'No data',
      "Email Address_2": data.data.ref2_email || 'No data'
    };

    const rows = viewModal.querySelectorAll('.col');
    rows.forEach(col => {
      const label = col.querySelector('label');
      const p = col.querySelector('p');
      if (label && p) {
        const text = label.textContent.trim();
        // Handle duplicate labels by checking section context
        let value = 'No data';
        if (col.closest('h4')?.textContent.includes('Reference 2')) {
          value = fields[text + '_2'] || fields[text] || 'No data';
        } else if (col.closest('h4')?.textContent.includes('Reference 1')) {
          value = fields[text + '_1'] || fields[text] || 'No data';
        } else if (col.closest('h4')?.textContent.includes('Next Of Kin')) {
          value = fields[text] || 'No data';
        } else {
          value = fields[text] || 'No data';
        }
        p.textContent = value;
      }
    });
  };

  // View button click
  document.querySelectorAll('.view-btn').forEach(button => {
    button.onclick = async () => {
      const id = button.dataset.id;
      try {
        const res = await fetch(`../backend/human-resource/employees/get_employee.php?id=${id}`);
        if (!res.ok) throw new Error('Failed to fetch employee data');
        const data = await res.json();
        if (data.status !== 'success') throw new Error(data.message || 'Error fetching data');
        fillViewModal(data);
        viewModal.style.display = 'block';
      } catch (error) {
        console.error('Error:', error.message);
        alert('Failed to load employee data');
      }
    };
  });
});
</script>
<!--<script>-->
<!--  document.addEventListener('DOMContentLoaded', () => {-->
<!--    const filters = ['#filter-name', '#filter-month', '#filter-year', '#filter-type'];-->
<!--    filters.forEach(id => document.querySelector(id).addEventListener('input', applyFilters));-->
<!--    filters.forEach(id => document.querySelector(id).addEventListener('change', applyFilters));-->

<!--    async function applyFilters() {-->
<!--      const name = document.querySelector('#filter-name').value;-->
<!--      const month = document.querySelector('#filter-month').value;-->
<!--      const year = document.querySelector('#filter-year').value;-->
<!--      const type = document.querySelector('#filter-type').value;-->

<!--      const response = await fetch('../backend/human-resource/employees/filter_employees.php', {-->
<!--        method: 'POST',-->
<!--        headers: {-->
<!--          'Content-Type': 'application/json'-->
<!--        },-->
<!--        body: JSON.stringify({-->
<!--          name,-->
<!--          month,-->
<!--          year,-->
<!--          type-->
<!--        })-->
<!--      });-->

<!--      const rows = await response.text();-->
<!--      document.querySelector('.leads-table tbody').innerHTML = rows;-->
<!--    }-->
<!--  });-->
<!--</script>-->
// <script>
//   document.addEventListener('DOMContentLoaded', () => {
//     const tbody = document.querySelector("table tbody");
//     const rowsPerPageSelect = document.getElementById("rowsPerPage");
//     const prevPageBtn = document.getElementById("prevPage");
//     const nextPageBtn = document.getElementById("nextPage");
//     const pageInfoSpan = document.getElementById("pageInfo");

//     let currentPage = 1;
//     let rowsPerPage = parseInt(rowsPerPageSelect.value);

//     function fetchEmployees() {
//       const formData = new FormData();
//       formData.append('page', currentPage);
//       formData.append('rows_per_page', rowsPerPage);

//       fetch('../backend/human-resource/employees/fetch_employees.php', {
//           method: 'POST',
//           body: formData
//         })
//         .then(res => res.json())
//         .then(res => {
//           if (res.status === 'success') {
//             tbody.innerHTML = '';
//             res.data.forEach(emp => {
//               const tr = document.createElement('tr');
//               tr.innerHTML = `
//               <td>${emp.staff_id}</td>
//               <td>${emp.first_name}</td>
//               <td>${emp.last_name}</td>
//               <td>${emp.position}</td>
//               <td>${emp.department || '-'}</td>
//               <td>${emp.date_joined}</td>
//               <td><button class="view-btn" data-id="${emp.id}">View</button></td>
//               <td><button class="edit-btn" data-id="${emp.id}">Edit</button></td>
//               <td><button class="delete-btn" data-id="${emp.id}">Delete</button></td>
//             `;
//               tbody.appendChild(tr);
//             });

//             pageInfoSpan.textContent = `Page ${res.currentPage} of ${res.totalPages}`;
//             prevPageBtn.disabled = res.currentPage === 1;
//             nextPageBtn.disabled = res.currentPage === res.totalPages;

//             attachEventListeners(); // Reattach handlers after rebuild
//           }
//         });
//     }

//     rowsPerPageSelect.addEventListener("change", () => {
//       rowsPerPage = parseInt(rowsPerPageSelect.value);
//       currentPage = 1;
//       fetchEmployees();
//     });

//     prevPageBtn.addEventListener("click", () => {
//       if (currentPage > 1) {
//         currentPage--;
//         fetchEmployees();
//       }
//     });

//     nextPageBtn.addEventListener("click", () => {
//       currentPage++;
//       fetchEmployees();
//     });

//     function attachEventListeners() {
//       // Your view, edit, delete logic can be reattached here
//       // For example:
//       document.querySelectorAll('.edit-btn').forEach(button => {
//         button.onclick = () => {
//           // trigger modal & fill in logic
//         };
//       });

//       document.querySelectorAll('.delete-btn').forEach(button => {
//         button.onclick = async () => {
//           if (!confirm('Delete this employee?')) return;
//           const id = button.dataset.id;

//           const res = await fetch('../backend/human-resource/employees/delete_employee.php', {
//             method: 'POST',
//             headers: {
//               'Content-Type': 'application/x-www-form-urlencoded'
//             },
//             body: `id=${encodeURIComponent(id)}`
//           });
//           const result = await res.json();

//           if (result.success) {
//             alert('Deleted!');
//             fetchEmployees();
//           } else {
//             alert('Delete failed');
//           }
//         };
//       });
//     }

//     fetchEmployees(); // Initial load
//   });
// </script>

<style>
  colgroup col:nth-child(2) {
    width: 120px;
  }

  colgroup col:nth-child(3) {
    width: 120px;
  }

  colgroup col:nth-child(4) {
    width: 150px;
  }

  colgroup col:nth-child(5) {
    width: 150px;
  }
</style>
<?php include_once '../components/cashflow_footer.php'; ?>