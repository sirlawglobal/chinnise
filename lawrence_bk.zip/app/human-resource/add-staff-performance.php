<form method="POST" action="../../config/api.php" style="width: 100%;">
  <input type="hidden" name="createPerformance" value="Performance">
  <div class="row">
    <div class="col-md-7 col-7">
      <div class="d-flex">
        <div>
          <span class="client-data-title d-xl-none hide-for-mobile">Human Resources</span>
          <span class="client-data-title d-block d-md-none d-lg-none">H.Resources</span>
        </div>
        <!--<div>-->
        <!--  <div class="divider-sm"></div>-->
        <!--</div>-->
        <!--<div>-->
        <!--  <span class="client-data-title">Staff Performance List</span>-->
        <!--</div>-->
        <div>
          <div class="divider-sm"></div>
        </div>
        <div>
          <span class="company-list-title">Staff Performance</span>
        </div>
      </div>
    </div>
    <div class="col-md-5 col-5">
      <div style="text-align: right;">
        <button class="add-dept-btn" type="submit">Save</button>
      </div>
    </div>
  </div>
  <div class="row mt-3">
    <div class="col-md-12">
      <button onclick="history.back()" type="button" class="back-btn"><img src="../../assets/icons/back.png"
          alt="">&nbsp;Back</button>
    </div>
  </div>
  <div class="row mt-2">
    <div class="col-md-12">
      <p class="performance-title">PERFOMANCE APPRAISAL INTERVIEW FORM</p>
    </div>
    <hr>
    <div class="col-md-12" style="margin-top: -30px;">
      <div class="row">
        <div class="col-md-10">
          <div class="row mt-3">
            <div class="col-md-6">
              <div class="row mt-3">
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="form-label">Name of Employee*</label>
                    <input type="text" name="employee_name" class="form-input" required="">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="form-label">Review Period*</label>
                    <input type="text" name="review_period" class="form-input" required="">
                  </div>
                </div>
              </div>
              <div class="row mt-3">
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="form-label">Staff ID</label>
                    <input type="text" name="staff_id" class="form-input">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="form-label">Date*</label>
                    <input type="date" name="performance_date" class="form-input" required="">
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="row mt-3">
                <div class="col-md-12">
                  <div class="form-group">
                    <label class="form-label">Name of Supervisor/Head of Department</label><br>
                    <input type="text" name="supervisor_name" class="form-input" style="width: 100%;">
                  </div>
                </div>
                <div class="col-md-12 mt-3">
                  <div class="form-group">
                    <label class="form-label">Position of Supervisor/Head of Department</label><br>
                    <input type="text" name="supervisor_position" class="form-input" style="width: 100%;">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row mt-4">
            <div class="col-md-6">
              <p class="performance-note">Please provide a critical assessment of the performance of the employee within
                the review period using the following rating scale. Provide examples where applicable. Please use a
                separate sheet if required.</p>
            </div>
            <div class="col-md-6">
              <table class="table-bordered w-100">
                <thead>
                  <tr>
                    <th class="text-center performance-th">E</th>
                    <th class="text-center performance-th">VG</th>
                    <th class="text-center performance-th">G</th>
                    <th class="text-center performance-th">NI</th>
                    <th class="text-center performance-th">P</th>




                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="text-center performance-td">Excellent</td>
                    <td class="text-center performance-td">Very Good</td>
                    <td class="text-center performance-td">Good</td>
                    <td class="text-center performance-td"> Needs Improvement</td>
                    <td class="text-center performance-td"> Poor</td>




                  </tr>
                </tbody>
              </table>
            </div>
            <div class="col-md-12 ">
              <p class="performance-title">B. ASSESSMENT OF GOALS/OBJECTIVES SET DURING THE REVIEW PERIOD</p>
              <div style="overflow-x: scroll;">
                <table class="table-bordered table-width mt-3">
                  <thead>
                    <tr>
                      <th style="width: 400px;" class="performance-th"><b>Criteria</b></th>
                      <th class="performance-th text-center"><b>P(0)</b></th>
                      <th class="performance-th text-center"><b>NI(3)</b></th>
                      <th class="performance-th text-center"><b>G(6)</b></th>
                      <th class="performance-th text-center"><b>VG(9)</b></th>
                      <th class="performance-th text-center"><b>E(12)</b></th>
                      <th class="performance-th text-center"><b>Score</b></th>
                      <th class="performance-th text-center"><b>Comments</b></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="performance-td" style="text-align: left;">
                        Demonstrated Knowledge of duties &amp; Quality of Work
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="demonstrated_knowledge" value="P(0)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="demonstrated_knowledge" value="NI(3)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="demonstrated_knowledge" value="G(6)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="demonstrated_knowledge" value="VG(9)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="demonstrated_knowledge" value="E(12)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="text" id="demonstrated_knowledge_score" name="demonstrated_knowledge_score"
                          style="width: 50px;border: none;outline: none;" onkeyup="demonstratedScore(this)"
                          class="form-input">
                      </td>
                      <td class="performance-td text-center">
                        <input type="text" name="demonstrated_knowledge_comment"
                          style="width: 180px;border: none;outline: none;" class="form-input">
                      </td>
                    </tr>
                    <tr>
                      <td class="performance-td" style="text-align: left;">
                        Timeliness of Delivery
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="timeliness_of_delivery" value="P(0)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="timeliness_of_delivery" value="NI(3)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="timeliness_of_delivery" value="G(6)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="timeliness_of_delivery" value="VG(9)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="timeliness_of_delivery" value="E(12)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="text" id="timeliness_of_delivery_score" name="timeliness_of_delivery_score"
                          onkeyup="timelinesScore(this)" style="width: 50px;border: none;outline: none;"
                          class="form-input">
                      </td>
                      <td class="performance-td text-center">
                        <input type="text" name="timeliness_of_delivery_comment"
                          style="width: 180px;border: none;outline: none;" class="form-input">
                      </td>
                    </tr>
                    <tr>
                      <td class="performance-td" style="text-align: left;">
                        Impact of Achievement
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="impact_of_investment" value="P(0)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="impact_of_investment" value="NI(3)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="impact_of_investment" value="G(6)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="impact_of_investment" value="VG(9)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="impact_of_investment" value="E(12)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="text" id="impact_of_investment_score" name="impact_of_investment_score"
                          onkeyup="impactInvestment(this)" style="width: 50px;border: none;outline: none;"
                          class="form-input">
                      </td>
                      <td class="performance-td text-center">
                        <input type="text" name="impact_of_investment_comment"
                          style="width: 180px;border: none;outline: none;" class="form-input">
                      </td>
                    </tr>
                    <tr>
                      <td class="performance-td" style="text-align: left;">
                        Overall Achievement of Goals/Objectives
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="achievement_of_goals" value="P(0)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="achievement_of_goals" value="NI(3)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="achievement_of_goals" value="G(6)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="achievement_of_goals" value="VG(9)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="radio" name="achievement_of_goals" value="E(12)">
                      </td>
                      <td class="performance-td text-center">
                        <input type="text" id="achievement_of_goals_score" name="achievement_of_goals_score"
                          onkeyup="achievementGoal(this)" style="width: 50px;border: none;outline: none;"
                          class="form-input">
                      </td>
                      <td class="performance-td text-center">
                        <input type="text" name="achievement_of_goals_comment"
                          style="width: 180px;border: none;outline: none;" class="form-input">
                      </td>
                    </tr>
                    <tr>
                      <td class="performance-td" style="text-align: left;">
                        Going beyond the call of Duty
                      </td>
                      <td class="performance-td text-center" colspan="5">
                        Extra (6, 9, or 12) bonus points to be earned for going beyond the call of duty
                      </td>
                      <td class=" performance-td text-center">
                        <input type="text" id="bonus_point" name="bonus_point_score" onkeyup="bonusPoint(this)"
                          style="width: 50px;border: none;outline: none;" class="form-input">
                      </td>
                      <td class=" performance-td text-center">
                        <input type="text" name="bonus_point_comment" style="width: 180px;border: none;outline: none;"
                          class="form-input">
                      </td>
                    </tr>
                    <tr>
                      <td class="performance-td text-center"></td>
                      <td class="performance-td" style="text-align: right;" colspan="5">
                        <input type="hidden" id="total_score_input" name="total_score">
                        Total Score
                      </td>
                      <td class="performance-td text-center" style="text-align: center;">
                        <input type="hidden" id="total_score_input" name="total_score"><span
                          class="total-score">0</span>
                      </td>
                      <td class="performance-td text-center">
                        <input type="text" name="achievement_of_goals_comment" disabled=""
                          style="width: 180px;border: none;outline: none;" class="form-input">
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="col-md-12 mt-3">
              <p class="performance-title">C. Recommendations by Reviewer</p>
              <hr>
              <textarea name="recommendation_by_reviewer" class="form-input" placeholder="Enter your recommendations"
                style="height: 80px"></textarea>

            </div>
            <div class="col-md-12 mt-3">
              <p class="performance-title">D. Comments by Employee</p>
              <hr>
              <textarea name="employee_comments" class="form-input" placeholder="Enter your comments here"
                style="height: 80px"></textarea>
            </div>
            <div class="col-md-12 mt-3">
              <p class="performance-title">E. Development Plan</p>
              <table class="table-bordered mt-3" style="width: 100%;">
                <thead style="width: 100%;">
                  <tr>
                    <th class="performance-th"><b>Areas for Improvement</b></th>
                    <th class="performance-th"><b>Expected Outcome(s)</b></th>
                    <th class="performance-th"><b>Supervisor's Name</b></th>
                    <th class="performance-th"><b>Start Date</b></th>
                    <th class="performance-th"><b>End Date</b></th>
                    <th class="d-flex performance-th pt-2">
                      <img onclick="addRecommendedAreas()" src="../../assets/images/add.png" alt="">
                    </th>
                  </tr>
                </thead>
                <tbody id="recommendation-container"></tbody>
              </table>
            </div>
            <div class="col-md-12 mt-3">
              <p class="performance-title">F. KEY GOALS FOR NEXT REVIEW PERIOD </p>
              <table class="table-bordered mt-3" style="width: 100%;">
                <thead style="width: 100%;">
                  <tr>
                    <th class="performance-th"><b>Goal (s) Set and Agreed on with Employee</b></th>
                    <th class="performance-th"><b>Proposed Completion Period</b></th>
                    <th class="performance-th"><b>
                        <img onclick="addKeyGoals()" src="../../assets/images/add.png" alt="">
                      </b></th>
                  </tr>
                </thead>

                <tbody id="key-goals-container"></tbody>
              </table>
            </div>

          </div>
        </div>
      </div>
    </div>
    <div class="mt-5 mb-5">
      <button class="default-btn" type="submit">Save</button>
    </div>
  </div>
</form>