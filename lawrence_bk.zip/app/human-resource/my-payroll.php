<?php include_once '../components/header.php'; ?>

<div class="modal" style="display: none;">
  <div class="modal-content">
    <span class="close">×</span>
    <h2 class="con">Add New Payroll</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Staff ID</label>
          <select name="staff_id">
            <option value="">Select Staff ID</option>
          </select>

        </div>
        <div class="col">
          <label>Surname</label>
          <input type="text" name="surname">
        </div>
        <div class="col">
          <label>First Name</label>
          <input type="text" name="first_name">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Basic Salary</label>
          <input type="text" name="basic_salary">
        </div>
        <div class="col">
          <label>Attendance Bonus</label>
          <input type="text" name="attendance_bonus">
        </div>
        <div class="col">
          <label>Monythly Bonus</label>
          <input type="text" name="monthly_bonus">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Deductions</label>
          <input type="text" name="deductions">
        </div>
        <div class="col">
          <label>PAYE</label>
          <input type="text" name="paye">
        </div>
        <div class="col">
          <label>Pension</label>
          <input type="text" name="pension">
        </div>
      </div>
      <div class="row">
        
        <div class="col">
          <label>Net Salary</label>
          <input type="text" name="net_salary">
        </div>
        <div class="col">
          <label>Status</label>
          <select name="status">
            <option value="">Select Status</option>
            <option value="Pending">Pending</option>
            <option value="paid">Paid</option>
            <option value="unpaid">Unpaid</option>
          </select>
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>
<div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">View Payroll</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Staff ID</label>
          <input type="text" name="staff_id">
        </div>
        <div class="col">
          <label>Surname</label>
          <input type="text" name="surname">
        </div>
        <div class="col">
          <label>First Name</label>
          <input type="text" name="first_name">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Basic Salary</label>
          <input type="text" name="basic_salary">
        </div>
        <div class="col">
          <label>Attendance Bonus</label>
          <input type="text" name="attendance_bonus">
        </div>
        <div class="col">
          <label>Monythly Bonus</label>
          <input type="text" name="monthly_bonus">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Deductions</label>
          <input type="text" name="deductions">
        </div>
        <div class="col">
          <label>PAYE</label>
          <input type="text" name="paye">
        </div>
        <div class="col">
          <label>Pension</label>
          <input type="text" name="pension">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Net Salary</label>
          <input type="text" name="net_salary">
        </div>
        <div class="col">
          <label>Status</label>
          <select name="status">
            <option value="">Select Status</option>
            <option value="paid">Paid</option>
            <option value="unpaid">Unpaid</option>
          </select>
        </div>
      </div>
    </form>
  </div>
</div>
<div class="modal2" id="edit">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Payroll</h2>
    <form>
      <input type="hidden" name="id" class="edit-payroll-id">
      <div class="row">
        <div class="col">
          <label>Staff ID</label>
          <input type="text" name="staff_id" readonly disabled>
        </div>
        <div class="col">
          <label>Surname</label>
          <input type="text" name="surname">
        </div>
        <div class="col">
          <label>First Name</label>
          <input type="text" name="first_name">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Basic Salary</label>
          <input type="text" name="basic_salary">
        </div>
        <div class="col">
          <label>Attendance Bonus</label>
          <input type="text" name="attendance_bonus">
        </div>
        <div class="col">
          <label>Monythly Bonus</label>
          <input type="text" name="monthly_bonus">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Deductions</label>
          <input type="text" name="deductions">
        </div>
        <div class="col">
          <label>PAYE</label>
          <input type="text" name="paye">
        </div>
        <div class="col">
          <label>Pension</label>
          <input type="text" name="pension">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Net Salary</label>
          <input type="text" name="net_salary">
        </div>
        <div class="col">
          <label>Status</label>
          <select name="status">
            <option value="">Select Status</option>
            <option value="paid">Paid</option>
            <option value="unpaid">Unpaid</option>
          </select>
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>

<div class="main">
  <?php include_once '../components/common_header.php'; ?>


  <!-- Your page content goes here -->
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources</a> | <span>Payroll</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px">
          Add Payroll
        </button>
      </div>
    </div>
    <header id="payroll-header">
      <div class="tabs">
        <!-- <button class="tab-btn" data-tab="welcome" onclick="location.href='./payroll'">Welcome</button> -->
        <button class="tab-btn active" onclick="location.href='./my-payroll'" data-tab="payroll">Payroll</button>
        <!-- <button class="tab-btn" onclick="location.href='./deductions'" data-tab="deductions">Deductions</button> -->
        <!-- <button class="tab-btn" onclick="location.href='./monthly-bonus'" data-tab="bonus">Monthly Bonus</button> -->
        <!-- <button class="tab-btn" onclick="location.href='./pay-grade'" data-tab="paygrade">Pay Grade</button> -->
        <button class="tab-btn" onclick="location.href='./payment-history'" data-tab="history">Payment History</button>
      </div>
    </header>
    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table>
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>Staff ID </th>
            <th>Surname </th>
            <th>First Name </th>
            <th>Basic Salary </th>
            <!-- <th>Attendance Bonus </th> -->
            <th>Monythly Bonus </th>
            <th>Deductions </th>
            <!-- <th>PAYE </th>
            <th>Pension </th>
            <th>Net Salary </th> -->
            <th>Status</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody id="payroll-body">
          <!-- Fetched rows will be injected here -->
        </tbody>

      </table>
    </div>
  </section>
</div>
<script>
  document.addEventListener("DOMContentLoaded", () => {
    fetch('../backend/human-resource/payroll/fetch_payrolls.php')
      .then(res => res.json())
      .then(data => {
  const tbody = document.getElementById('payroll-body');
  tbody.innerHTML = '';

  if (data.error) {
    tbody.innerHTML = `<tr><td colspan="14">Error: ${data.error}</td></tr>`;
    return;
  }

  data.forEach(row => {
    tbody.innerHTML += `
    <tr 
      data-id="${row.id}"
      data-staff_id="${row.staff_id}"
      data-surname="${row.surname}"
      data-first_name="${row.first_name}"
      data-basic_salary="${row.basic_salary}"
      data-attendance_bonus="${row.attendance_bonus}"
      data-monthly_bonus="${row.monthly_bonus}"
      data-deductions="${row.deductions}"
      data-paye="${row.paye}"
      data-pension="${row.pension}"
      data-net_salary="${row.net_salary}"
      data-status="${row.status}">
    
      <td>${row.staff_id}</td>
      <td>${row.surname}</td>
      <td>${row.first_name}</td>
      <td>${parseFloat(row.basic_salary).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
      <td>${parseFloat(row.monthly_bonus).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
      <td>${parseFloat(row.deductions).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
      <td>${row.status}</td>
      <td><i class="view-icon"><img src="../assets/eye-open.png" /></i></td>
      <td><i class="edit-icon"><img src="../assets/edit.svg"></i></td>
      <td><i class="delete-icon"><img src="../assets/Delete.svg"></i></td>
    </tr>`;
  });
})
      .catch(err => {
        document.getElementById('payroll-body').innerHTML = `<tr><td colspan="14">Failed to load data.</td></tr>`;
        console.error(err);
      });
  });
</script>


<script>
  document.addEventListener('DOMContentLoaded', function () {
    const staffSelect = document.querySelector('select[name="staff_id"]');
    const firstNameInput = document.querySelector('input[name="first_name"]');
    const surnameInput = document.querySelector('input[name="surname"]');

    // Populate staff ID dropdown
    fetch('../backend/human-resource/payroll/fetch_staff_ids.php')
      .then(res => res.json())
      .then(data => {
        data.forEach(staff => {
          console.log(staff);

          const option = document.createElement('option');
          option.value = staff.staff_id;
          option.textContent = staff.staff_id;
          staffSelect.appendChild(option);
        });
      });

    // On staff ID change, auto-fill names
    staffSelect.addEventListener('change', function () {
      const staffId = this.value;
      fetch(`../backend/human-resource/payroll/get_staff_details.php?staff_id=${staffId}`)
        .then(res => res.json())
        .then(data => {
          firstNameInput.value = data.first_name || '';
          surnameInput.value = data.surname || '';
        });
    });

    // Submit payroll form
    document.querySelector('.modal form').addEventListener('submit', function (e) {
      e.preventDefault();
      const formData = new FormData(this);
      fetch('../backend/human-resource/payroll/add_payroll.php', {
        method: 'POST',
        body: formData
      })
        .then(res => res.json())
        .then(resp => {
          if (resp.success) {
            alert('Payroll saved!');
            location.reload();
          }
        });
    });
  });
</script>
<script>
  function fillForm(modalSelector, rowData, readOnly = true) {
    const modal = document.querySelector(modalSelector);
    [...modal.querySelectorAll('input, select')].forEach(input => {
      const key = input.name;
      if (rowData[key] !== undefined) {
        input.value = rowData[key];
      }
      input.readOnly = readOnly;
      if (input.tagName === 'SELECT') {
        input.disabled = readOnly;
      }
    });
  }

  document.addEventListener('click', e => {
    const tr = e.target.closest('tr');
    if (!tr) return;

    const data = Object.fromEntries(Object.entries(tr.dataset));

    if (e.target.closest('.view-icon')) {
      fillForm('.modal1 form', data, true);
      document.querySelector('.modal1').style.display = 'block';
    }

    if (e.target.closest('.edit-icon')) {
      fillForm('.modal2 form', data, false);
      document.querySelector('.modal2').style.display = 'block';
    }

    if (e.target.closest('.delete-icon')) {
      if (!confirm('Delete this payroll?')) return;
      fetch(`../backend/human-resource/payroll/delete_payroll.php?id=${data.id}`, { method: 'GET' })
        .then(res => res.text())
        .then(() => tr.remove())
        .catch(() => alert('Delete failed.'));
    }
  });

  document.querySelector('.close1').onclick = () => document.querySelector('.modal1').style.display = 'none';
  document.querySelector('.close2').onclick = () => document.querySelector('.modal2').style.display = 'none';

  document.querySelector('.modal2 form').addEventListener('submit', e => {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);

    // Debug what's being sent
    console.log([...formData.entries()]);

    fetch('../backend/human-resource/payroll/update_payroll.php', {
      method: 'POST',
      body: formData
    })
      .then(res => res.json())
      .then(resp => {
        if (resp.success) {
          alert('Updated!');
          location.reload();
        } else {
          alert('Error: ' + (resp.error || 'Unknown error'));
        }
      })
      .catch(err => {
        alert('Request failed: ' + err.message);
      });
  });
</script>
<script>

</script>
<?php include_once '../components/cashflow_footer.php'; ?>