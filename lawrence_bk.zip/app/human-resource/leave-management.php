<?php include_once '../components/header.php'; ?>


<div class="modal" style="display: none;">
  <div class="modal-content">
    <span class="close">×</span>
    <h2 class="con">Add Leave</h2>
    <form action="../backend/human-resource/leave-management/submit_leave.php" method="POST">
      <div class="row">
        
        <div class="col">
          <label>Staff ID</label>
          <select name="staff_id" id="staff_id_dropdown">
            <option value="">Select Staff ID</option>
            <?php
            // PHP to populate the dropdown from your database
            require_once '../settings/connection.php'; // Adjust path if necessary

            try {
                $stmt = $pdo->query("SELECT id as staff_id, first_name as employee_name FROM employees");
                $employees_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($employees_data as $employee) {
                    echo "<option value='" . htmlspecialchars($employee['staff_id']) . "' data-name='" . htmlspecialchars($employee['employee_name']) . "'>" . htmlspecialchars($employee['staff_id']) . "</option>";
                }
            } catch (PDOException $e) {
                // Log the error or display a message
                echo "<option value=''>Error loading IDs</option>";
                // In a real application, you might want to log $e->getMessage()
            }
            ?>
          </select>
        </div>
        <div class="col">
          <label>Request From</label>
          <input type="text" name="employee_name" id="employee_name" placeholder="Enter Employee Name">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Leave Type*</label>
          <select name="leave_type">
            <option value="">Select Leave Type</option>
            <option value="sick">Sick Leave</option>
            <option value="annual">Study Leave</option>
            <option value="maternity">Maternity Leave</option>
            <option value="paternity">Paternity Leave</option>
            <option value="bereavement">Bereavement Leave</option>
            <option value="unpaid">Unpaid Leave</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div class="col">
          <label>Purpose</label>
          <input type="text" name="purpose" placeholder="Enter Purpose of Leave">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Description</label>
          <textarea placeholder="Enter Description" name="description"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Start Date</label>
          <input type="date" class="form-input" name="start_date" />
        </div>
        <div class="col">
          <label>Duration</label>
          <input type="text" name="duration" placeholder="Enter Duration">
        </div>
        <div class="col">
          <label>Status*</label>
          <select name="status">
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Declined</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Approved by</label>
          <input type="text" name="approved_by">
        </div>
        <div class="col">
          <label>Gender*</label>
          <select name="gender">
            <option value="">
              Select Gender
            </option>
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>
        </div>
        <div class="col">
          <label>Request Date</label>
          <input type="date" class="form-input" name="request_date" />
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>
<div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">View Leave</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Request From</label>
          <input type="text" placeholder="Enter Employee Name" id="view_employee_name" name="employee_name">
        </div>
        <div class="col">
          <label>Staff ID</label>
          <input type="text" id="view_staff_id" name="staff_id" placeholder="Enter Staff ID">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Leave Type*</label>
          <select id="view_leave_type" name="leave_type">
            <option value="">Select Leave Type</option>
            <option value="sick">Sick Leave</option>
            <option value="study">Study Leave</option>
            <option value="maternity">Maternity Leave</option>
            <option value="paternity">Paternity Leave</option>
            <option value="bereavement">Bereavement Leave</option>
            <option value="unpaid">Unpaid Leave</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div class="col">
          <label>Purpose</label>
          <input type="text" placeholder="Enter Purpose of Leave" id="view_purpose" name="purpose">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Description</label>
          <textarea placeholder="Enter Description" id="view_description" name="description"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Start Date</label>
          <input type="date" class="form-input" id="view_start_date" name="start_date" />
        </div>
        <div class="col">
          <label>Duration</label>
          <input type="text" placeholder="Enter Duration" id="view_duration" name="duration">
        </div>
        <div class="col">
          <label>Status*</label>
          <select id="view_status" name="status">
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Declined</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Approved by</label>
          <input type="text" id="view_approved_by" name="approved_by">
        </div>
        <div class="col">
          <label>Gender*</label>
          <select id="view_gender" name="gender">
            <option value="">
              Select Gender
            </option>
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>
        </div>
        <div class="col">
          <label>Request Date</label>
          <input type="date" class="form-input" id="view_request_date" name="request_date" />
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update</button>
      </div>
    </form>
  </div>
</div>
<div class="modal2" id="edit">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Leave</h2>
    <form method="POST" action="../backend/human-resource/leave-management/update_leave.php">
      <input type="hidden" name="id" id="edit_id">
      <div class="row">
        <div class="col">
          <label>Request From</label>
          <input type="text" placeholder="Enter Employee Name" id="edit_employee_name" name="employee_name">
        </div>
        <div class="col">
          <label>Staff ID</label>
          <input type="text" id="edit_staff_id" name="staff_id" placeholder="Enter Staff ID">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Leave Type*</label>
          <select id="edit_leave_type" name="leave_type">
            <option value="">Select Leave Type</option>
            <option value="sick">Sick Leave</option>
            <option value="study">Study Leave</option>
            <option value="maternity">Maternity Leave</option>
            <option value="paternity">Paternity Leave</option>
            <option value="bereavement">Bereavement Leave</option>
            <option value="unpaid">Unpaid Leave</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div class="col">
          <label>Purpose</label>
          <input type="text" placeholder="Enter Purpose of Leave" id="edit_purpose" name="purpose">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Description</label>
          <textarea placeholder="Enter Description" id="edit_description" name="description"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Start Date</label>
          <input type="date" class="form-input" id="edit_start_date" name="start_date" />
        </div>
        <div class="col">
          <label>Duration</label>
          <input type="text" placeholder="Enter Duration" id="edit_duration" name="duration">
        </div>
        <div class="col">
          <label>Status*</label>
          <select id="edit_status" name="status">
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Declined</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Approved by</label>
          <input type="text" id="edit_approved_by" name="approved_by">
        </div>
        <div class="col">
          <label>Gender*</label>
          <select id="edit_gender" name="gender">
            <option value="">
              Select Gender
            </option>
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>
        </div>
        <div class="col">
          <label>Request Date</label>
          <input type="date" class="form-input" id="edit_request_date" name="request_date" />
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update</button>
      </div>
    </form>
  </div>
</div>

<div class="main">
  <?php include_once '../components/common_header.php'; ?>


  <!-- Your page content goes here -->
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources | Management</a> | <span>Request</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px">
          Request Now
        </button>
      </div>
    </div>
    <div class="row1" style="margin-bottom: 1rem;">
      <div class="col1">
        <label>Filter by Name</label>
        <input type="text" id="filter_name" placeholder="Enter employee name" />
      </div>
      <div class="col1">
        <label>Filter by Month</label>
        <select id="filter_month">
          <option value="">All Months</option>
          <option value="01">January</option>
          <option value="02">February</option>
          <option value="03">March</option>
          <option value="04">April</option>
          <option value="05">May</option>
          <option value="06">June</option>
          <option value="07">July</option>
          <option value="08">August</option>
          <option value="09">September</option>
          <option value="10">October</option>
          <option value="11">November</option>
          <option value="12">December</option>
        </select>
      </div>
      <div class="col1">
        <label>Filter by Year</label>
        <select id="filter_year">
          <option value="">All Years</option>
          <?php for ($year = date("Y"); $year >= 2020; $year--): ?>
            <option value="<?= $year ?>"><?= $year ?></option>
          <?php endfor; ?>
        </select>
      </div>
      <div class="col1">
        <label>Filter by Type</label>
        <select id="filter_type">
          <option value="">All Types</option>
          <option value="sick">Sick Leave</option>
          <option value="annual">Study Leave</option>
          <option value="maternity">Maternity Leave</option>
          <option value="paternity">Paternity Leave</option>
          <option value="bereavement">Bereavement Leave</option>
          <option value="unpaid">Unpaid Leave</option>
          <option value="other">Other</option>
        </select>
      </div>
    </div>

    <div>
      <table>
        <colgroup>
        <col>
        <col>
        <col>
        <col>
        <col>
        <col>
        <col>
        <col>
        <col>
        <col>
      </colgroup>
        <thead>
          <tr>
            <th>Staff ID</th>
            <th>Employee name</th>
            <th>Leave Type</th>
            <th>Purpose</th>
            <th>Duration</th>
            <th>Request Date</th>
            <th>Status</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          <?php include '../backend/human-resource/leave-management/fetch_leaves.php'; ?>
        </tbody>

      </table>
    </div>
  </section>
</div>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    // View
    document.querySelectorAll(".view-icon").forEach(function (icon) {
      icon.addEventListener("click", function () {
        const id = this.dataset.id;
        fetch(`../backend/human-resource/leave-management/get_leave.php?id=${id}`)
          .then(res => res.json())
          .then(data => {
            // Populate view modal
            document.getElementById("view_employee_name").value = data.employee_name;
            document.getElementById("view_staff_id").value = data.staff_id;
            document.getElementById("view_leave_type").value = data.leave_type;
            document.getElementById("view_purpose").value = data.purpose;
            document.getElementById("view_description").value = data.description;
            document.getElementById("view_start_date").value = data.start_date;
            document.getElementById("view_duration").value = data.duration;
            document.getElementById("view_status").value = data.status;
            document.getElementById("view_approved_by").value = data.approved_by;
            document.getElementById("view_gender").value = data.gender;
            document.getElementById("view_request_date").value = data.request_date;

            document.querySelector(".modal1").style.display = "block";
          });
      });
    });

    // Edit
    document.querySelectorAll(".edit-icon").forEach(function (icon) {
      icon.addEventListener("click", function () {
        const id = this.dataset.id;
        fetch(`../backend/human-resource/leave-management/get_leave.php?id=${id}`)
          .then(res => res.json())
          .then(data => {
            document.getElementById("edit_id").value = id; // hidden field
            document.getElementById("edit_employee_name").value = data.employee_name;
            document.getElementById("edit_staff_id").value = data.staff_id;
            document.getElementById("edit_leave_type").value = data.leave_type;
            document.getElementById("edit_purpose").value = data.purpose;
            document.getElementById("edit_description").value = data.description;
            document.getElementById("edit_start_date").value = data.start_date;
            document.getElementById("edit_duration").value = data.duration;
            document.getElementById("edit_status").value = data.status;
            document.getElementById("edit_approved_by").value = data.approved_by;
            document.getElementById("edit_gender").value = data.gender;
            document.getElementById("edit_request_date").value = data.request_date;

            document.querySelector(".modal2").style.display = "block";
          });
      });
    });

    // Delete
    document.querySelectorAll(".delete-icon").forEach(function (icon) {
      icon.addEventListener("click", function () {
        const id = this.dataset.id;
        if (confirm("Are you sure you want to delete this leave request?")) {
          fetch(`../backend/human-resource/leave-management/delete_leave.php?id=${id}`, { method: "POST" })
            .then(res => res.text())
            .then(msg => {
              alert(msg);
              location.reload();
            });
        }
      });
    });

    // Close modals
    document.querySelector(".close1").onclick = () => document.querySelector(".modal1").style.display = "none";
    document.querySelector(".close2").onclick = () => document.querySelector(".modal2").style.display = "none";
  });
</script>
<script>
  function fetchFilteredData() {
    const name = document.getElementById("filter_name").value;
    const month = document.getElementById("filter_month").value;
    const year = document.getElementById("filter_year").value;
    const type = document.getElementById("filter_type").value;

    const params = new URLSearchParams({ name, month, year, type });

    fetch("../backend/human-resource/leave-management/filter_leaves.php?" + params.toString())
      .then(res => res.text())
      .then(data => {
        document.querySelector(".leads-table tbody").innerHTML = data;
      });
  }

  // Trigger filter on input/select change
  ["filter_name", "filter_month", "filter_year", "filter_type"].forEach(id => {
    document.getElementById(id).addEventListener("change", fetchFilteredData);
    document.getElementById(id).addEventListener("input", fetchFilteredData);
  });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const staffIdDropdown = document.getElementById('staff_id_dropdown');
        const employeeNameInput = document.getElementById('employee_name');

        staffIdDropdown.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            // Get the employee name from the data-name attribute
            const employeeName = selectedOption.getAttribute('data-name');

            if (employeeName) {
                employeeNameInput.value = employeeName;
            } else {
                employeeNameInput.value = ''; // Clear if no name found (e.g., "Select Staff ID" option)
            }
        });
    });
</script>
<?php include_once '../components/cashflow_footer.php'; ?>