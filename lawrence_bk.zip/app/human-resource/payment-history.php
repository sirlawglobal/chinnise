<?php include_once '../components/header.php'; ?>

<div class="main">
  <?php include_once '../components/common_header.php'; ?>


  <!-- Your page content goes here -->
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources</a> | <span>Payment History</span>
        </div>
      </div>
      <div class="right">
        <!-- <button class="add-new-button" style="border-radius: 15px">
          Add Payment
        </button> -->
      </div>
    </div>
    <div class="controls-container">
      <div class="filter-box">
        <span class="search-icon">
        </span>
        <input type="text" placeholder="Filter">
      </div>
      <div class="dropdown">
        <select>
          <option value="">Year</option>
          <option value="2025">2025</option>
          <option value="2024">2024</option>
          <option value="2023">2023</option>
        </select>
      </div>
      <div class="dropdown">
        <select>
          <option value="">Month</option>
          <option value="january">January</option>
          <option value="february">February</option>
          <option value="march">March</option>
          <option value="april">April</option>
          <option value="may">May</option>
          <option value="june">June</option>
          <option value="july">July</option>
          <option value="august">August</option>
          <option value="september">September</option>
          <option value="october">October</option>
          <option value="november">November</option>
          <option value="december">December</option>
        </select>
      </div>
    </div>
    <header id="payroll-header">
      <div class="tabs">
        <!-- <button class="tab-btn" data-tab="welcome" onclick="location.href='./payroll'">Welcome</button> -->
        <button class="tab-btn" onclick="location.href='./my-payroll'" data-tab="payroll">Payroll</button>
        <!-- <button class="tab-btn" onclick="location.href='./deductions'" data-tab="deductions">Deductions</button> -->
        <!-- <button class="tab-btn" onclick="location.href='./monthly-bonus'" data-tab="bonus">Monthly Bonus</button> -->
        <!-- <button class="tab-btn" onclick="location.href='./pay-grade'" data-tab="paygrade">Pay Grade</button> -->
        <button class="tab-btn active" onclick="location.href='./payment-history'" data-tab="history">Payment
          History</button>
      </div>
    </header>
    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table>
        <colgroup>
          <col><col><col><col><col><col><col>
        </colgroup>
        <thead>
          <tr>
            <th>Staff ID </th>
            <th>Surname </th>
            <th>First Name </th>
            <th>Basic Salary </th>
            <th>Monythly Bonus </th>
            <th>Deductions </th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody id="payment-history-body">
  <!-- Dynamic content here -->
</tbody>

      </table>
    </div>
  </section>
</div>
<script>
  const searchInput = document.querySelector('.filter-box input');
  const yearSelect = document.querySelectorAll('.dropdown select')[0];
  const monthSelect = document.querySelectorAll('.dropdown select')[1];
  const tbody = document.getElementById('payment-history-body');

  function fetchAndRenderData() {
    const year = yearSelect.value;
    const month = monthSelect.value;
    const search = searchInput.value;

    const params = new URLSearchParams({ year, month, search });

    fetch(`../backend/human-resource/payroll/fetch_all_payrolls.php?${params}`)
      .then(res => res.json())
      .then(data => {
        if (data.length === 0) {
          tbody.innerHTML = '<tr><td colspan="11">No results found.</td></tr>';
          return;
        }

        tbody.innerHTML = data.map(row => `
          <tr>
            <td>${row.staff_id}</td>
            <td>${row.surname}</td>
            <td>${row.first_name}</td>
            <td>${format(row.basic_salary)}</td>
            <td>${format(row.monthly_bonus)}</td>
            <td>${format(row.deductions)}</td>
            <td>${row.status}</td>
          </tr>
        `).join('');
      })
      .catch(err => {
        tbody.innerHTML = `<tr><td colspan="11">Error loading data</td></tr>`;
      });
  }

  function format(value) {
    return Number(value).toLocaleString(undefined, { minimumFractionDigits: 2 });
  }

  // Trigger fetch on input change
  [searchInput, yearSelect, monthSelect].forEach(el =>
    el.addEventListener('input', fetchAndRenderData)
  );

  // Initial load
  fetchAndRenderData();
</script>

<?php include_once '../components/cashflow_footer.php'; ?>
