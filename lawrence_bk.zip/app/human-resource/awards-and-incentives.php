<?php include_once '../components/header.php'; ?>

<div class="modal" style="display: none;">
  <div class="modal-content">
    <span class="close">×</span>
    <h2 class="con">Add New Award</h2>
    <form id="addAwardForm">
           <div class="row">
        <div class="col">
          <label>Staff ID</label>
          <select name="staff_id" id="award_staff_id_dropdown" required>
            <option value="">Select Staff ID</option>
            <?php
            // PHP to populate the Staff ID dropdown
            // Ensure this path is correct relative to the file containing this HTML
            require_once '../settings/connection.php'; 

            try {
                $stmt = $pdo->query("SELECT id as staff_id, first_name, last_name FROM employees ORDER BY first_name ASC, last_name ASC");
                $employees_for_dropdown = $stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($employees_for_dropdown as $employee) {
                    echo "<option value='" . htmlspecialchars($employee['staff_id']) . "' ";
                    echo "data-first-name='" . htmlspecialchars($employee['first_name']) . "' ";
                    echo "data-last-name='" . htmlspecialchars($employee['last_name']) . "'>";
                    echo htmlspecialchars($employee['staff_id']) . "</option>";
                }
            } catch (PDOException $e) {
                error_log("Error loading employees for dropdown: " . $e->getMessage()); // Log error for debugging
                echo "<option value=''>Error loading IDs</option>";
            }
            ?>
          </select>
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>First Name</label>
          <input type="text" name="first_name" id="award_first_name" required readonly>
        </div>
        <div class="col">
          <label>Last Name</label>
          <input type="text" name="last_name" id="award_last_name" required readonly>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Award Name</label>
          <select name="award_name" required>
            <option value="">Select Award</option>
            <option value="Time Management">Time Management</option>
            <option value="Staff of the month">Staff of the month</option>
            <option value="Staff of the year">Staff of the year</option>
            <option value="Mentorship">Mentorship</option>
            <option value="Top performer">Top performer</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Award Description</label>
          <input type="text" name="award_description" required>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Gift Item</label>
          <input type="text" name="gift_item" required>
        </div>
        <div class="col">
          <label>Date</label>
          <input type="date" name="award_date" required>
        </div>
      </div>

 
      <div class="row">
        <div class="col">
          <label>Awarded By</label>
          <input type="text" name="awarded_by" required>
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>
<div class="modal2" id="edit">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Award</h2>
    <form id="editAwardForm">
      <input type="hidden" name="id">
      <div class="row">
        <div class="col">
          <label>Award Name</label>
          <input type="text" name="award_name" required>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Award Description</label>
          <input type="text" name="award_description" required>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Gift Item</label>
          <input type="text" name="gift_item" required>
        </div>
        <div class="col">
          <label>Date</label>
          <input type="date" name="award_date" required>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>First Name</label>
          <input type="text" name="first_name" required>
        </div>
        <div class="col">
          <label>Last Name</label>
          <input type="text" name="last_name" required>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Awarded By</label>
          <input type="text" name="awarded_by" required>
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update</button>
      </div>
    </form>
  </div>
</div>
<div class="main">
  <?php include_once '../components/common_header.php'; ?>


  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources</a> | <span>Welcome</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px">
          Add New Award
        </button>
      </div>
    </div>
    <header id="payroll-header">
      <div class="tabs">
        <button class="tab-btn active" data-tab="welcome" onclick="location.href='./awards-and-incentives'">Welcome</button>
        <button class="tab-btn" onclick="location.href='./time-management'" data-tab="payroll">Time
          Management</button>
        <button class="tab-btn" onclick="location.href='./staff-of-the-month'" data-tab="deductions">Staff of The
          Month</button>
        <button class="tab-btn" onclick="location.href='./staff-of-the-year'" data-tab="bonus">Staff of the
          Year</button>
        <button class="tab-btn" onclick="location.href='./mentorship'" data-tab="paygrade">Mentorship</button>
        <button class="tab-btn" onclick="location.href='./top-performer'" data-tab="history">Top performer</button>
      </div>
    </header>
    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table>
        <colgroup>
            <col>
            <col>
            <col>
            <col>
            <col><col><col><col><col>
        </colgroup>
        <thead>
          <tr>
            <th>Date</th>
            <th>First Name</th>
            <th>Surname</th>
            <th>Award Name</th>
            <th>Award Description</th>
            <th>Gift Item</th>
            <th>Awarded By</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody id="awards-table-body">
        </tbody>
      </table>
    </div>
  </section>
</div>
<script>
  // Global function to load awards
  function loadAwards() {
    fetch('../backend/human-resource/time-management/welcome.php')
      .then(res => res.json())
      .then(data => {
        let tbody = document.getElementById('awards-table-body'); // Use an ID for the tbody
        tbody.innerHTML = ''; // Clear existing content

        if (data.error) {
          tbody.innerHTML = `<tr><td colspan="9" style="color: red;">Error: ${data.error}</td></tr>`;
          return;
        }

        data.forEach(row => {
          const awardDate = new Date(row.award_date);

          // Get day, month, and year
          const day = String(awardDate.getDate()).padStart(2, '0');
          const month = String(awardDate.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
          const year = awardDate.getFullYear();

          // Format as dd-mm-yyyy
          const formattedDate = `${day}-${month}-${year}`;

          // Truncate strings to 20 characters if they are longer
          const truncatedAwardName = row.award_name.length > 20 ? row.award_name.substring(0, 17) + '...' : row.award_name;
          const truncatedAwardDescription = row.award_description.length > 20 ? row.award_description.substring(0, 17) + '...' : row.award_description;
          const truncatedGiftItem = row.gift_item.length > 20 ? row.gift_item.substring(0, 17) + '...' : row.gift_item;
          const truncatedAwardedBy = row.awarded_by.length > 20 ? row.awarded_by.substring(0, 17) + '...' : row.awarded_by;


          tbody.innerHTML += `
        <tr data-id="${row.id}">
            <td>${formattedDate}</td>
            <td>${row.first_name}</td>
            <td>${row.last_name}</td>
            <td>${truncatedAwardName}</td>
            <td>${truncatedAwardDescription}</td>
            <td>${truncatedGiftItem}</td>
            <td>${truncatedAwardedBy}</td>
            <td><i class="edit-icon"><img src="../assets/edit.svg" /></i></td>
            <td><i class="delete-icon"><img src="../assets/Delete.svg" /></i></td>
        </tr>`;
        });
      })
      .catch(err => {
        console.error('Error fetching awards:', err);
        document.getElementById('awards-table-body').innerHTML = `<tr><td colspan="9" style="color: red;">Failed to load awards.</td></tr>`;
      });
  }

  // Load awards when the page loads
  document.addEventListener('DOMContentLoaded', loadAwards);

  // Modal opening/closing
  document.querySelector('.add-new-button').addEventListener('click', function() {
    document.querySelector('.modal').style.display = 'block';
  });

  document.querySelector('.close').addEventListener('click', function() {
    document.querySelector('.modal').style.display = 'none';
  });

  document.querySelector('.close2').addEventListener('click', function() {
    document.getElementById('edit').style.display = 'none';
  });
</script>

<script>
  // Handle Add Award form submission
  document.getElementById("addAwardForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form); // Use FormData for easier handling

    fetch("../backend/human-resource/time-management/add_award.php", {
        method: "POST",
        body: formData, // FormData automatically sets Content-Type
      })
      .then((res) => res.json())
      .then((response) => {
        alert(response.message);
        if (response.success) { // Assuming your backend sends a 'success' field
          form.reset();
          document.querySelector(".modal").style.display = "none";
          loadAwards(); // Reload awards list after successful addition
        }
      })
      .catch((err) => {
        console.error("Error adding award:", err);
        alert("Something went wrong adding the award.");
      });
  });

  // Event delegation for Edit and Delete icons
  document.addEventListener('click', function(e) {
    const editIcon = e.target.closest('.edit-icon');
    const deleteIcon = e.target.closest('.delete-icon');

    if (editIcon) {
      const row = editIcon.closest('tr');
      const cells = row.querySelectorAll('td');
      const awardId = row.dataset.id; // Get ID from data-id attribute

      const form = document.getElementById("editAwardForm");

      form.id.value = awardId; // Set the hidden ID field
      form.award_name.value = cells[3].innerText;
      form.award_description.value = cells[4].innerText;
      form.gift_item.value = cells[5].innerText;
      form.award_date.value = cells[0].innerText;
      form.first_name.value = cells[1].innerText;
      form.last_name.value = cells[2].innerText;
      form.awarded_by.value = cells[6].innerText;

      document.getElementById("edit").style.display = "block";

    } else if (deleteIcon) {
      const row = deleteIcon.closest('tr');
      const awardId = row.dataset.id;

      if (confirm("Are you sure you want to delete this award?")) {
        fetch("../backend/human-resource/time-management/delete_award.php", {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              id: awardId
            }),
          })
          .then(res => res.json())
          .then(response => {
            alert(response.message);
            if (response.success) {
              loadAwards(); // Reload awards list after successful deletion
              location.reload();
            }
          })
          .catch(err => {
            console.error("Error deleting award:", err);
            alert("Delete failed.");
          });
      }
    }
  });

  // Handle Edit Award form submission
  document.getElementById("editAwardForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form); // Use FormData for easier handling

    // Optional: Log form data to console for debugging
    // console.log(Object.fromEntries(formData.entries()));

    fetch("../backend/human-resource/time-management/update_award.php", {
        method: "POST",
        body: formData, // FormData automatically sets Content-Type
      })
      .then(res => res.json())
      .then(response => {
        alert(response.message);
        if (response.success) {
          document.getElementById("edit").style.display = "none";
          loadAwards(); // Reload awards list after successful update
        }
      })
      .catch(err => {
        console.error("Error updating award:", err);
        alert("Update failed.");
      });
  });
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const staffIdDropdown = document.getElementById('award_staff_id_dropdown');
    const firstNameInput = document.getElementById('award_first_name');
    const lastNameInput = document.getElementById('award_last_name');

    if (staffIdDropdown && firstNameInput && lastNameInput) {
        staffIdDropdown.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const firstName = selectedOption.getAttribute('data-first-name');
            const lastName = selectedOption.getAttribute('data-last-name');

            if (firstName !== null) { // Check if data-first-name exists (not null)
                firstNameInput.value = firstName;
            } else {
                firstNameInput.value = '';
            }

            if (lastName !== null) { // Check if data-last-name exists (not null)
                lastNameInput.value = lastName;
            } else {
                lastNameInput.value = '';
            }
        });
    }
});
</script>
<style>
    colgroup col:nth-child(1) {
    width: 100px;
  }

  colgroup col:nth-child(2) {
    width: 150px;
  }

  colgroup col:nth-child(3) {
    width: 150px;
  }

  colgroup col:nth-child(4) {
    width: 150px;
  }

  colgroup col:nth-child(5) {
    width: 120px;
  }

  colgroup col:nth-child(6) {
    width: 100px;
  }

  colgroup col:nth-child(7) {
    width: 100px;
  }

  colgroup col:nth-child(8) {
    width: 50px;
  }

  colgroup col:nth-child(9) {
    width: 60px;
  }
</style>
<?php include_once '../components/cashflow_footer.php'; ?>