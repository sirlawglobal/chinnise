<?php include_once '../components/header.php'; ?>
<!-- CREATE MODAL -->
<div class="modal" style="display: none;">
  <div class="modal-content">
    <span class="close">×</span>
    <h2 class="con">Create New Training</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Date</label>
          <input type="date" class="form-input" name="training_date" />
        </div>
        <div class="col">
          <label>Course Name</label>
          <input type="text" name="course_name">
        </div>
      </div>
      <div class="row">
        
        <div class="col">
          <label>Description</label>
          <textarea name="description" id=""></textarea>
          <!-- <input type="text" name="description"> -->
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Type of Training</label>
          <select name="training_type">
            <option value="">Select Training Type</option>
            <option value="general">General</option>
            <option value="technical">Technical</option>
            <option value="specific">Specific</option>
          </select>
        </div>
        <div class="col">
          <label>Duration</label>
          <input type="text" name="duration">
        </div>
      </div>
      <div class="row">
        
        <div class="col">
          <label>Time</label>
          <input type="time" class="form-input" name="training_time" />
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>

<!-- VIEW MODAL (Read-only) -->
<div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">View Training</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Date</label>
          <input type="date" readonly value="2025-04-12" class="form-input" name="training_date" />
        </div>
        <div class="col">
          <label>Course Id</label>
          <input type="text" name="id" readonly value="New Staff Training" aria-readonly="true">
        </div>
      </div>
      <div class="row">
         <div class="col">
          <label>Course Name</label>
          <input type="text" name="course_name" readonly value="New Staff Training">
        </div>

        <div class="col">
          <label>Description</label>
          <input type="text" name="description" readonly value="General Training for new staff">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Type of Training</label>
          <input type="text" name="training_type" readonly value="General">
        </div>
        <div class="col">
          <label>Duration</label>
          <input type="text" name="duration" readonly value="5 hours">
        </div>
      </div>
      <div class="row">
        
        <div class="col">
          <label>Time</label>
          <input type="time" readonly value="10:00 AM" class="form-input" name="training_time" />
        </div>
      </div>
    </form>
  </div>
</div>

<!-- EDIT MODAL -->
<div class="modal2" id="edit">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Training</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Date</label>
          <input type="date" readonly value="2025-04-12" class="form-input" name="training_date" />
        </div>
        <div class="col">
          <label>Course Id</label>
          <input type="text" name="id" readonly value="New Staff Training" aria-readonly="true">
        </div>
      </div>
      <div class="row">
         <div class="col">
          <label>Course Name</label>
          <input type="text" name="course_name" readonly value="New Staff Training">
        </div>

        <div class="col">
          <label>Description</label>
          <input type="text" name="description" readonly value="General Training for new staff">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Type of Training</label>
          <input type="text" name="training_type" readonly value="General">
        </div>
        <div class="col">
          <label>Duration</label>
          <input type="text" name="duration" readonly value="5 hours">
        </div>
      </div>
      <div class="row">
        
        <div class="col">
          <label>Time</label>
          <input type="time" readonly value="10:00 AM" class="form-input" name="training_time" />
        </div>
      </div>
    </form>
  </div>
</div>


<div class="main">
  <?php include_once '../components/common_header.php'; ?>

  <!-- Your page content goes here -->
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources</a> | <span>Training</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px">
          Add New Training
        </button>
      </div>
    </div>
    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table>
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>Course Id</th>
            <th>New Staff Training</th>
            <th>Course Name</th>
            <th>Description</th>
            <th>Training Type</th>
            <th>Date</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>New staff Training</td>
            <td></td>
            <td>General</td>
            <td>5 hours</td>
            <td></td>
            <td>
              <i class="view-icon"><img src="../assets/eye-open.png" />
              </i>
            </td>
            <td>
              <i class="edit-icon">
                <img src="../assets/edit.svg" />
              </i>
            </td>
            <td>
              <i class="delete-icon">
                <img src="../assets/Delete.svg" /></i>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</div>
<script>
  document.addEventListener('DOMContentLoaded', init);

  function init() {
    loadTrainings();
    setupModals();
  }

  function loadTrainings() {
    fetch('../backend/human-resource/training/fetch_trainings.php')
      .then(r => r.json())
      .then(data => {
        const tbody = document.querySelector('table tbody');
        tbody.innerHTML = '';
        data.forEach(t => {
    const trainingDate = new Date(t.training_date);

    // Get day, month, and year
    const day = String(trainingDate.getDate()).padStart(2, '0');
    const month = String(trainingDate.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
    const year = trainingDate.getFullYear();

    // Format as dd-mm-yyyy
    const formattedDate = `${day}-${month}-${year}`;

    // Helper function to truncate text
    const truncate = (text, maxLength) => {
        if (text === null || text === undefined) {
            return ''; // Handle null or undefined values gracefully
        }
        text = String(text); // Ensure it's a string
        if (text.length > maxLength) {
            return text.substring(0, maxLength - 3) + '...'; // Leave space for "..."
        }
        return text;
    };

    // Apply truncation to desired fields
    const truncatedCourseName = truncate(t.course_name, 10);
    const truncatedDescription = truncate(t.description, 20);

    tbody.innerHTML += `
        <tr data-id="${t.id}">
            <td>C1000${t.id}</td>
            <td>${t.course_name}</td>
            <td>${truncatedDescription}</td>
            <td>${t.training_type}</td>
            <td>${t.duration}</td>
            <td>${formattedDate}</td>
            <td><i class="view-icon"><img src="../assets/eye-open.png" alt="View" /></i></td>
            <td><i class="edit-icon"><img src="../assets/edit.svg" alt="Edit" /></i></td>
            <td><i class="delete-icon"><img src="../assets/Delete.svg" alt="Delete" /></i></td>
        </tr>`;
        });
        attachRowActions();
      });
  }

  function setupModals() {
    // Add Modal Show
    document.querySelector('.add-new-button').onclick = () =>
      document.querySelector('.modal').style.display = 'block';

    document.querySelector('.modal .close').onclick = () =>
      document.querySelector('.modal').style.display = 'none';

    document.querySelector('.modal form').onsubmit = e => {
      e.preventDefault();
      const f = e.target;
      const data = {
        course_name: f.course_name.value,
        description: f.description.value,
        training_type: f.training_type.value,
        duration: f.duration.value,
        training_date: f.training_date.value,
        training_time: f.training_time.value
      };
      fetch('../backend/human-resource/training/add_training.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }).then(_ => {
        f.reset(); document.querySelector('.modal').style.display = 'none';
        loadTrainings();
      });
    };
  }

  function attachRowActions() {
    document.querySelectorAll('.view-icon').forEach(el => {
      el.onclick = () => openView(el.closest('tr').dataset.id);
    });
    document.querySelectorAll('.edit-icon').forEach(el => {
      el.onclick = () => openEdit(el.closest('tr').dataset.id);
    });
    document.querySelectorAll('.delete-icon').forEach(el => {
      el.onclick = () => {
        if (confirm('Delete?')) {
          fetch('../backend/human-resource/training/delete_training.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: el.closest('tr').dataset.id })
          }).then(_ => loadTrainings());
        }
      };
    });
  }

  function openView(id) {
    fetch(`../backend/human-resource/training/view_training.php?id=${id}`)
      .then(r => r.json())
      .then(d => {
        const m = document.querySelector('.modal1');

        // Dynamically set the ID field if it exists
        const trainingIdField = m.querySelector('[readonly][value][name="id"]'); // Assuming you have an input field named "training_id" to display "C1000 + id"
        if (trainingIdField) {
            trainingIdField.value = `C1000${d.id}`; // Concatenate "C1000" with the actual ID from data
        }

        // Loop through other fields as before
        ['course_name', 'description', 'training_type', 'duration', 'training_date', 'training_time'].forEach(n => {
          const field = m.querySelector(`[readonly][value][name="${n}"]`);
          if (field) { // Check if the field exists before trying to set its value
            field.value = d[n];
          }
        });

        m.style.display = 'block';
        m.querySelector('.close1').onclick = () => m.style.display = 'none';
      });
  }

  function openEdit(id) {
    fetch(`../backend/human-resource/training/view_training.php?id=${id}`)
      .then(r => r.json())
      .then(d => {
        const m = document.getElementById('edit');
        const f = m.querySelector('form');
        f.innerHTML = `
        <input type="hidden" name="id" value="${d.id}">
        <label>Course Id</label><input name="id" value="C1000${d.id}">
        <label>Course Name</label><input name="course_name" value="${d.course_name}">
        <label>Description</label><input name="description" value="${d.description}">
        <label>Type</label><input name="training_type" value="${d.training_type}">
        <label>Duration</label><input name="duration" value="${d.duration}">
        <label>Date</label><input type="date" name="training_date" value="${d.training_date}">
        <label>Time</label><input type="time" name="training_time" value="${d.training_time}">
        <button type="submit">Save</button>`;
        m.style.display = 'block';
        m.querySelector('.close2').onclick = () => m.style.display = 'none';

        f.onsubmit = e => {
          e.preventDefault();
          const fd = Object.fromEntries(new FormData(f).entries());
          fetch('../backend/human-resource/training/edit_training.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(fd)
          }).then(_ => {
            m.style.display = 'none';
            loadTrainings();
          });
        }
      });
  }
</script>
<style>
    colgroup col:nth-child(9) {
    width: 65px;
  }
</style>
<?php include_once '../components/cashflow_footer.php'; ?>