<?php include_once '../components/header.php'; ?>

<div class="modal" style="display: none;">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con">Add New Onboarding Record</h2>
    <form id="onboardingForm" method="post" enctype="multipart/form-data">
      <div class="row">
        <div class="col">
          <label for="staff_id">Staff ID</label>
          <select id="staff_id" name="staff_id">
            <option value="">Select Staff ID</option>
            <!-- Options will be dynamically populated -->
          </select>

        </div>
        <div class="col">
          <label for="staff_name">Staff Name</label>
          <input type="text" id="staff_name" name="staff_name">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label for="dept_name">Department Name</label>
          <input type="text" id="dept_name" name="dept_name">
        </div>
        <div class="col">
          <label for="hr_name">HR Name</label>
          <input type="text" id="hr_name" name="hr_name">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label for="start_date">Start Date</label>
          <input type="date" id="start_date" name="start_date">
        </div>
      </div>

      <h3>Document Checks</h3>
      <div class="row">
        <div class="col">
          <label for="offer_letter">Offer Letter</label>
          <select id="offer_letter" name="offer_letter">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="contract">Contract</label>
          <select id="contract" name="contract">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="employee_data_sheet">Employee Data Sheet</label>
          <select id="employee_data_sheet" name="employee_data_sheet">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="references_check">References Check</label>
          <select id="references_check" name="references_check">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="nda">NDA</label>
          <select id="nda" name="nda">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>

      <h3>IT Assets</h3>
      <div class="row">
        <div class="col">
          <label for="laptop">Laptop</label>
          <select id="laptop" name="laptop">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="headset">Headset</label>
          <select id="headset" name="headset">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="mouse">Mouse</label>
          <select id="mouse" name="mouse">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>

      <h3>System Logins</h3>
      <div class="row">
        <div class="col">
          <label for="domain_login">Domain Login</label>
          <select id="domain_login" name="domain_login">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="skype_logins">Skype Logins</label>
          <select id="skype_logins" name="skype_logins">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="other_logins">Other Logins</label>
          <textarea id="other_logins" name="other_logins" rows="3"></textarea>
        </div>
      </div>

      <h3>Company Orientation</h3>
      <div class="row">
        <div class="col">
          <label for="company_overview">Company Overview</label>
          <select id="company_overview" name="company_overview">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="company_culture">Company Culture</label>
          <select id="company_culture" name="company_culture">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="tour_premises">Tour Premises</label>
          <select id="tour_premises" name="tour_premises">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="staff_intro">Staff Introduction</label>
          <select id="staff_intro" name="staff_intro">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="peer_mentor">Peer Mentor Assigned</label>
          <select id="peer_mentor" name="peer_mentor">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>

      <h3>Responsibilities & Feedback</h3>
      <div class="row">
        <div class="col">
          <label for="responsibilities_discussed">Responsibilities Discussed</label>
          <select id="responsibilities_discussed" name="responsibilities_discussed">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="feedback_comment">Feedback / Comment</label>
          <textarea id="feedback_comment" name="feedback_comment" rows="3"></textarea>
        </div>
      </div>

      <h3>Week 1 (Initial) Observations</h3>
      <div class="row">
        <div class="col">
          <label for="time_keeping">Time Keeping</label>
          <textarea id="time_keeping" name="time_keeping" rows="3"></textarea>
        </div>
        <div class="col">
          <label for="behaviour_integration">Behaviour & Integration</label>
          <textarea id="behaviour_integration" name="behaviour_integration" rows="3"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="initial_skills">Initial Skills</label>
          <textarea id="initial_skills" name="initial_skills" rows="3"></textarea>
        </div>
      </div>

      <h3>14-Day Review (Skills Development)</h3>
      <div class="row">
        <div class="col">
          <label for="skills_14_learning">Learning</label>
          <textarea id="skills_14_learning" name="skills_14_learning" rows="3"></textarea>
        </div>
        <div class="col">
          <label for="skills_14_instructions">Instructions Given</label>
          <textarea id="skills_14_instructions" name="skills_14_instructions" rows="3"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="skills_14_review">Review</label>
          <textarea id="skills_14_review" name="skills_14_review" rows="3"></textarea>
        </div>
      </div>

      <h3>30-Day Review (Skills Development)</h3>
      <div class="row">
        <div class="col">
          <label for="skills_30_learning">Learning</label>
          <textarea id="skills_30_learning" name="skills_30_learning" rows="3"></textarea>
        </div>
        <div class="col">
          <label for="skills_30_instructions">Instructions Given</label>
          <textarea id="skills_30_instructions" name="skills_30_instructions" rows="3"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="skills_30_review">Review</label>
          <textarea id="skills_30_review" name="skills_30_review" rows="3"></textarea>
        </div>
      </div>

      <h3>60-Day Review (Skills Development)</h3>
      <div class="row">
        <div class="col">
          <label for="skills_60_learning">Learning</label>
          <textarea id="skills_60_learning" name="skills_60_learning" rows="3"></textarea>
        </div>
        <div class="col">
          <label for="skills_60_instructions">Instructions Given</label>
          <textarea id="skills_60_instructions" name="skills_60_instructions" rows="3"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="skills_60_review">Review</label>
          <textarea id="skills_60_review" name="skills_60_review" rows="3"></textarea>
        </div>
      </div>

      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save Onboarding</button>
      </div>
    </form>
  </div>
</div>

<div class="modal1">
  <div class="modal-content" style="max-width: 800px; position: static; margin: 0 auto;">
    <span class="close1">&times;</span>
    <h2 class="con">View Onboarding</h2>
    <form>
      <div class="row">
        <div class="col">
          <label for="staff_id">Staff ID</label>
          <input type="text" id="staff_id" name="staff_id">

        </div>
        <div class="col">
          <label for="staff_name">Staff Name</label>
          <input type="text" id="staff_name" name="staff_name">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label for="dept_name">Department Name</label>
          <input type="text" id="dept_name" name="dept_name">
        </div>
        <div class="col">
          <label for="hr_name">HR Name</label>
          <input type="text" id="hr_name" name="hr_name">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label for="start_date">Start Date</label>
          <input type="date" id="start_date" name="start_date">
        </div>
      </div>

      <h3>Document Checks</h3>
      <div class="row">
        <div class="col">
          <label for="offer_letter">Offer Letter</label>
          <select id="offer_letter" name="offer_letter">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="contract">Contract</label>
          <select id="contract" name="contract">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="employee_data_sheet">Employee Data Sheet</label>
          <select id="employee_data_sheet" name="employee_data_sheet">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="references_check">References Check</label>
          <select id="references_check" name="references_check">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="nda">NDA</label>
          <select id="nda" name="nda">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>

      <h3>IT Assets</h3>
      <div class="row">
        <div class="col">
          <label for="laptop">Laptop</label>
          <select id="laptop" name="laptop">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="headset">Headset</label>
          <select id="headset" name="headset">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="mouse">Mouse</label>
          <select id="mouse" name="mouse">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>

      <h3>System Logins</h3>
      <div class="row">
        <div class="col">
          <label for="domain_login">Domain Login</label>
          <select id="domain_login" name="domain_login">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="skype_logins">Skype Logins</label>
          <select id="skype_logins" name="skype_logins">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="other_logins">Other Logins</label>
          <textarea id="other_logins" name="other_logins" rows="3"></textarea>
        </div>
      </div>

      <h3>Company Orientation</h3>
      <div class="row">
        <div class="col">
          <label for="company_overview">Company Overview</label>
          <select id="company_overview" name="company_overview">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="company_culture">Company Culture</label>
          <select id="company_culture" name="company_culture">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="tour_premises">Tour Premises</label>
          <select id="tour_premises" name="tour_premises">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="staff_intro">Staff Introduction</label>
          <select id="staff_intro" name="staff_intro">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="peer_mentor">Peer Mentor Assigned</label>
          <select id="peer_mentor" name="peer_mentor">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>

      <h3>Responsibilities & Feedback</h3>
      <div class="row">
        <div class="col">
          <label for="responsibilities_discussed">Responsibilities Discussed</label>
          <select id="responsibilities_discussed" name="responsibilities_discussed">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="feedback_comment">Feedback / Comment</label>
          <textarea id="feedback_comment" name="feedback_comment" rows="3"></textarea>
        </div>
      </div>

      <h3>Week 1 (Initial) Observations</h3>
      <div class="row">
        <div class="col">
          <label for="time_keeping">Time Keeping</label>
          <textarea id="time_keeping" name="time_keeping" rows="3"></textarea>
        </div>
        <div class="col">
          <label for="behaviour_integration">Behaviour & Integration</label>
          <textarea id="behaviour_integration" name="behaviour_integration" rows="3"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="initial_skills">Initial Skills</label>
          <textarea id="initial_skills" name="initial_skills" rows="3"></textarea>
        </div>
      </div>

      <h3>14-Day Review (Skills Development)</h3>
      <div class="row">
        <div class="col">
          <label for="skills_14_learning">Learning</label>
          <textarea id="skills_14_learning" name="skills_14_learning" rows="3"></textarea>
        </div>
        <div class="col">
          <label for="skills_14_instructions">Instructions Given</label>
          <textarea id="skills_14_instructions" name="skills_14_instructions" rows="3"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="skills_14_review">Review</label>
          <textarea id="skills_14_review" name="skills_14_review" rows="3"></textarea>
        </div>
      </div>

      <h3>30-Day Review (Skills Development)</h3>
      <div class="row">
        <div class="col">
          <label for="skills_30_learning">Learning</label>
          <textarea id="skills_30_learning" name="skills_30_learning" rows="3"></textarea>
        </div>
        <div class="col">
          <label for="skills_30_instructions">Instructions Given</label>
          <textarea id="skills_30_instructions" name="skills_30_instructions" rows="3"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="skills_30_review">Review</label>
          <textarea id="skills_30_review" name="skills_30_review" rows="3"></textarea>
        </div>
      </div>

      <h3>60-Day Review (Skills Development)</h3>
      <div class="row">
        <div class="col">
          <label for="skills_60_learning">Learning</label>
          <textarea id="skills_60_learning" name="skills_60_learning" rows="3"></textarea>
        </div>
        <div class="col">
          <label for="skills_60_instructions">Instructions Given</label>
          <textarea id="skills_60_instructions" name="skills_60_instructions" rows="3"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="skills_60_review">Review</label>
          <textarea id="skills_60_review" name="skills_60_review" rows="3"></textarea>
        </div>
      </div>
    </form>
  </div>
</div>
<div class="modal2" id="edit">
  <div class="modal-content" style="max-width: 800px; position: static; margin: 0 auto;">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Onboarding</h2>
    <form id="editOnboardingForm">
      <input type="hidden" id="edit_id" name="id"> 
      <div class="row">
        <div class="col">
          <label for="staff_id">Staff ID</label>
          <input type="text" id="edit_staff_id" name="staff_id">

        </div>
        <div class="col">
          <label for="staff_name">Staff Name</label>
          <input type="text" id="edit_staff_name" name="staff_name">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label for="dept_name">Department Name</label>
          <input type="text" id="edit_dept_name" name="dept_name">
        </div>
        <div class="col">
          <label for="hr_name">HR Name</label>
          <input type="text" id="edit_hr_name" name="hr_name">
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label for="start_date">Start Date</label>
          <input type="date" id="edit_start_date" name="start_date">
        </div>
      </div>

      <h3>Document Checks</h3>
      <div class="row">
        <div class="col">
          <label for="offer_letter">Offer Letter</label>
          <select id="edit_offer_letter" name="offer_letter">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="contract">Contract</label>
          <select id="edit_contract" name="contract">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="employee_data_sheet">Employee Data Sheet</label>
          <select id="edit_employee_data_sheet" name="employee_data_sheet">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="references_check">References Check</label>
          <select id="edit_references_check" name="references_check">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="nda">NDA</label>
          <select id="edit_nda" name="nda">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>

      <h3>IT Assets</h3>
      <div class="row">
        <div class="col">
          <label for="laptop">Laptop</label>
          <select id="edit_laptop" name="laptop">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="headset">Headset</label>
          <select id="edit_headset" name="headset">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="mouse">Mouse</label>
          <select id="edit_mouse" name="mouse">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>

      <h3>System Logins</h3>
      <div class="row">
        <div class="col">
          <label for="domain_login">Domain Login</label>
          <select id="edit_domain_login" name="domain_login">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="skype_logins">Skype Logins</label>
          <select id="edit_skype_logins" name="skype_logins">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="other_logins">Other Logins</label>
          <textarea id="edit_other_logins" name="other_logins" rows="3"></textarea>
        </div>
      </div>

      <h3>Company Orientation</h3>
      <div class="row">
        <div class="col">
          <label for="company_overview">Company Overview</label>
          <select id="edit_company_overview" name="company_overview">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="company_culture">Company Culture</label>
          <select id="edit_company_culture" name="company_culture">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="tour_premises">Tour Premises</label>
          <select id="edit_tour_premises" name="tour_premises">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="staff_intro">Staff Introduction</label>
          <select id="edit_staff_intro" name="staff_intro">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="peer_mentor">Peer Mentor Assigned</label>
          <select id="edit_peer_mentor" name="peer_mentor">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
      </div>

      <h3>Responsibilities & Feedback</h3>
      <div class="row">
        <div class="col">
          <label for="responsibilities_discussed">Responsibilities Discussed</label>
          <select id="edit_responsibilities_discussed" name="responsibilities_discussed">
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div class="col">
          <label for="feedback_comment">Feedback / Comment</label>
          <textarea id="edit_feedback_comment" name="feedback_comment" rows="3"></textarea>
        </div>
      </div>

      <h3>Week 1 (Initial) Observations</h3>
      <div class="row">
        <div class="col">
          <label for="time_keeping">Time Keeping</label>
          <textarea id="edit_time_keeping" name="time_keeping" rows="3"></textarea>
        </div>
        <div class="col">
          <label for="behaviour_integration">Behaviour & Integration</label>
          <textarea id="edit_behaviour_integration" name="behaviour_integration" rows="3"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="initial_skills">Initial Skills</label>
          <textarea id="edit_initial_skills" name="initial_skills" rows="3"></textarea>
        </div>
      </div>

      <h3>14-Day Review (Skills Development)</h3>
      <div class="row">
        <div class="col">
          <label for="skills_14_learning">Learning</label>
          <textarea id="edit_skills_14_learning" name="skills_14_learning" rows="3"></textarea>
        </div>
        <div class="col">
          <label for="skills_14_instructions">Instructions Given</label>
          <textarea id="edit_skills_14_instructions" name="skills_14_instructions" rows="3"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="skills_14_review">Review</label>
          <textarea id="edit_skills_14_review" name="skills_14_review" rows="3"></textarea>
        </div>
      </div>

      <h3>30-Day Review (Skills Development)</h3>
      <div class="row">
        <div class="col">
          <label for="skills_30_learning">Learning</label>
          <textarea id="edit_skills_30_learning" name="skills_30_learning" rows="3"></textarea>
        </div>
        <div class="col">
          <label for="skills_30_instructions">Instructions Given</label>
          <textarea id="edit_skills_30_instructions" name="skills_30_instructions" rows="3"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="skills_30_review">Review</label>
          <textarea id="edit_skills_30_review" name="skills_30_review" rows="3"></textarea>
        </div>
      </div>

      <h3>60-Day Review (Skills Development)</h3>
      <div class="row">
        <div class="col">
          <label for="skills_60_learning">Learning</label>
          <textarea id="edit_skills_60_learning" name="skills_60_learning" rows="3"></textarea>
        </div>
        <div class="col">
          <label for="skills_60_instructions">Instructions Given</label>
          <textarea id="edit_skills_60_instructions" name="skills_60_instructions" rows="3"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label for="skills_60_review">Review</label>
          <textarea id="edit_skills_60_review" name="skills_60_review" rows="3"></textarea>
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update Onboarding</button>
      </div>
    </form>
  </div>
</div>

<div class="main">
  <?php include_once '../components/common_header.php'; ?>

  <!-- Your page content goes here -->
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources</a> | <span>Onboarding</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px">
          Add New
        </button>
      </div>
    </div>
   <?php
    require '../settings/connection.php'; // Ensure this path is correct for your setup

    try {
        // We are still selecting all columns, as per your request
        $stmt = $pdo->query("SELECT * FROM onboarding ORDER BY id DESC");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        die("Error fetching data: " . $e->getMessage()); // It's better to log this error and show a user-friendly message
    }
?>

<div style="overflow: auto; padding: 0.7rem; height: 80%">
  <table>
    <colgroup>
      <col>
      <col>
      <col><col><col><col><col><col><col>
    </colgroup>
    <thead>
      <tr>
        <th>Staff Id</th>
        <th>First Name</th>
        <th>Surname</th>
        <th>Dept. Name</th>
        <th>HR. Name</th>
        <th>Start Date</th>
        <th>View</th>
        <th>Edit</th>
        <th>Delete</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $row): ?>
        <?php
        $firstName = '';
        $lastName = '';

        // Safely get the staff_name, ensure it's a string and not null
        $fullName = isset($row['staff_name']) ? (string)$row['staff_name'] : '';
        
        // Split the full name by the first space encountered
        $nameParts = explode(' ', $fullName, 2); 
        
        if (count($nameParts) > 1) {
            $firstName = $nameParts[0];
            $lastName = $nameParts[1];
        } else {
            // If there's only one part (no space), assume it's the first name
            $firstName = $fullName;
            $lastName = ''; // Or set to a default like 'N/A' if you prefer
        }
        ?>
        <tr>
          <td><?= htmlspecialchars($row['staff_id']) ?></td>
          <td><?= htmlspecialchars($firstName) ?></td>
          <td><?= htmlspecialchars($lastName) ?></td>
          <td><?= htmlspecialchars($row['dept_name']) ?></td>
          <td><?= htmlspecialchars($row['hr_name']) ?></td>
          <td><?= date('d-m-Y', strtotime($row['start_date'])) ?></td>
          <td>
            <i class="view-icon" data-id="<?= htmlspecialchars($row['id']) ?>">
              <img src="../assets/eye-open.png" alt="View" />
            </i>
          </td>
          <td>
            <i class="edit-icon" data-id="<?= htmlspecialchars($row['id']) ?>">
              <img src="../assets/edit.svg" alt="Edit" />
            </i>
          </td>
          <td>
            <i class="delete-icon" data-id="<?= htmlspecialchars($row['id']) ?>">
              <img src="../assets/Delete.svg" alt="Delete" />
            </i>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
  </section>
</div>


<script>
  document.addEventListener("DOMContentLoaded", function () {
    const staffIdSelect = document.getElementById("staff_id");
    const staffNameInput = document.getElementById("staff_name");
    const deptNameInput = document.getElementById("dept_name");

    // Fetch and populate employee dropdown
    fetch("../backend/human-resource/onboarding/get_employees.php")
      .then(response => response.json())
      .then(data => {
        if (Array.isArray(data)) {
          data.forEach(emp => {
            const option = document.createElement("option");
            option.value = emp.id;
            option.textContent = emp.id;
            option.dataset.firstname = emp.first_name;
            option.dataset.lastname = emp.last_name;
            option.dataset.department = emp.department;
            staffIdSelect.appendChild(option);
          });
        } else {
          console.error("Unexpected data:", data);
        }
      });

    // Auto-fill on selection
    staffIdSelect.addEventListener("change", function () {
      const selected = staffIdSelect.options[staffIdSelect.selectedIndex];
      if (selected.value) {
        staffNameInput.value = `${selected.dataset.firstname} ${selected.dataset.lastname}`;
        deptNameInput.value = selected.dataset.department;
      } else {
        staffNameInput.value = '';
        deptNameInput.value = '';
      }
    });

    // Handle form submission
    const onboardingForm = document.getElementById("onboardingForm");
    onboardingForm.addEventListener("submit", function (e) {
      e.preventDefault(); // Prevent default form submission

      // Collect form data
      const formData = new FormData(onboardingForm);

      // Send data via AJAX
      fetch('../backend/human-resource/onboarding/submit_onboarding.php', {
        method: 'POST',
        body: formData
      })
        .then(response => response.text())
        .then(data => {
          alert(data); // Show success message
          onboardingForm.reset(); // Reset form
          // Optionally close the modal here
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Error saving data');
        });
    });
  });
</script>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const modal = document.querySelector(".modal1");
    const closeBtn = modal.querySelector(".close1");

    // Handle open
    document.querySelectorAll(".view-icon").forEach(icon => {
      icon.addEventListener("click", function () {
        const id = this.getAttribute("data-id");

        fetch("../backend/human-resource/onboarding/get_onboarding.php?id=" + id)
          .then(response => response.json())
          .then(data => {
            if (data) {
              const inputs = modal.querySelectorAll("input, select, textarea");
              inputs.forEach(input => {
                const name = input.name || input.previousElementSibling?.textContent?.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/_+$/, '');
                if (name && data[name] !== undefined) {
                  input.value = data[name];
                }
              });
              modal.style.display = "block";
            }
          });
      });
    });

    // Handle close
    closeBtn.onclick = () => (modal.style.display = "none");

    window.onclick = e => {
      if (e.target === modal) modal.style.display = "none";
    };
  });
</script>

<script>
  // Edit functionality
  document.addEventListener("DOMContentLoaded", function () {
    const editModal = document.getElementById("edit");
    const closeEditBtn = editModal.querySelector(".close2");

    // Handle edit open
    document.querySelectorAll(".edit-icon").forEach(icon => {
      icon.addEventListener("click", function () {
        const id = this.getAttribute("data-id");

        fetch("../backend/human-resource/onboarding/get_onboarding.php?id=" + id)
          .then(response => response.json())
          .then(data => {
            if (data) {
              // Populate the edit form
              document.getElementById("edit_id").value = data.id;
              document.getElementById("edit_staff_id").value = data.staff_id;
              document.getElementById("edit_staff_name").value = data.staff_name;
              document.getElementById("edit_dept_name").value = data.dept_name;
              document.getElementById("edit_hr_name").value = data.hr_name;
              document.getElementById("edit_start_date").value = data.start_date;

              // Populate all other fields similarly...

              editModal.style.display = "block";
            }
          });
      });
    });

    // Handle edit close
    closeEditBtn.onclick = () => (editModal.style.display = "none");

    // Handle edit form submission
    const editForm = document.getElementById("editOnboardingForm");
    editForm.addEventListener("submit", function (e) {
      e.preventDefault();

      const formData = new FormData(editForm);

      fetch('../backend/human-resource/onboarding/update_onboarding.php', {
        method: 'POST',
        body: formData
      })
        .then(response => response.text())
        .then(data => {
          alert(data);
          editModal.style.display = "none";
          location.reload(); // Refresh the page to see changes
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Error updating data');
        });
    });

    // Delete functionality
    document.querySelectorAll(".delete-icon").forEach(icon => {
      icon.addEventListener("click", function () {
        if (confirm("Are you sure you want to delete this onboarding record?")) {
          const id = this.getAttribute("data-id");

          fetch('../backend/human-resource/onboarding/delete_onboarding.php', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id=' + id
          })
            .then(response => response.text())
            .then(data => {
              alert(data);
              location.reload(); // Refresh the page to see changes
            })
            .catch(error => {
              console.error('Error:', error);
              alert('Error deleting data');
            });
        }
      });
    });
  });
</script>
<style>

  colgroup col:nth-child(1) {
    width: 80px;
  }

  colgroup col:nth-child(2) {
    width: 150px;
  }

  colgroup col:nth-child(3) {
    width: 120px;
  }

  colgroup col:nth-child(4) {
    width: 200px;
  }

  colgroup col:nth-child(5) {
    width: px;
  }

  colgroup col:nth-child(6) {
    width: 120px;
  }

  colgroup col:nth-child(7) {
    width: 60px;
  }

  colgroup col:nth-child(8) {
    width: 60px;
  }

  colgroup col:nth-child(9) {
    width: 60px;
  }
</style>
<?php include_once '../components/cashflow_footer.php'; ?>