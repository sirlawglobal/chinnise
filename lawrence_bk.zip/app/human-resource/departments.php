<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
  header("Location: auth/login.php");
  exit;
}
?>

<?php include_once '../components/header.php'; ?>

<!-- Toast Container -->
<div id="toast-container"></div>

<!-- Add Department Modal -->
<div class="modal" id="addModal" style="display: none;">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con">Add Department</h2>
    <form id="addForm">
      <div class="row">
        <div class="col">
          <label>Department Name</label>
          <input type="text" name="dept_name" id="add_dept_name" required>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Head Of Department</label>
          <input type="text" name="dept_head" id="add_dept_head" required>
        </div>
        <div class="col">
          <label>No. Of Staff In Department</label>
          <input type="number" name="staff_count" id="add_staff_count" min="0" required>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Dept Managed by</label>
          <input type="text" name="admin_dept" id="add_admin_dept" required>
        </div>
        <div class="col">
          <label>Location</label>
          <input type="text" name="location" id="add_location" required>
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>

<!-- View Department Modal -->
<div class="modal" id="viewModal" style="display: none;">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con">View Department</h2>
    <form id="viewForm">
      <div class="row">
        <div class="col">
          <label>Department Name</label>
          <input type="text" name="dept_name" readonly>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Head Of Department</label>
          <input type="text" name="dept_head" readonly>
        </div>
        <div class="col">
          <label>No. Of Staff In Department</label>
          <input type="text" name="staff_count" readonly>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Dept Managed by</label>
          <input type="text" name="admin_dept" readonly>
        </div>
        <div class="col">
          <label>Location</label>
          <input type="text" name="location" readonly>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Edit Department Modal -->
<div class="modal" id="editModal" style="display: none;">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con">Edit Department</h2>
    <form id="editForm">
      <input type="hidden" name="id">
      <div class="row">
        <div class="col">
          <label>Department Name</label>
          <input type="text" name="dept_name" required>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Head Of Department</label>
          <input type="text" name="dept_head" required>
        </div>
        <div class="col">
          <label>No. Of Staff In Department</label>
          <input type="number" name="staff_count" min="0" required>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Dept Managed by</label>
          <input type="text" name="admin_dept" required>
        </div>
        <div class="col">
          <label>Location</label>
          <input type="text" name="location" required>
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal" id="deleteModal" style="display: none;">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con">Confirm Deletion</h2>
    <!--<p>Are you sure you want to delete this department?</p>-->
    <div class="button-container" style='justify-content:center'>
      <button id="confirmDeleteBtn" class="save-btn large-btn">Confirm</button>
      <button id="cancelDeleteBtn" class="cancel-btn large-btn">Cancel</button>
    </div>
  </div>
</div>

<div class="main">
  <?php include_once '../components/common_header.php'; ?>
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources</a> | <span>Departments</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" id="addDepartmentBtn" style="border-radius: 15px">
          Add Department
        </button>
      </div>
    </div>
    <div>
      <table id="departmentsTable">
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>DEPT NO</th>
            <th>DEPTNAME</th>
            <th>DEPTHEAD</th>
            <th>NUMBER OF STAFFS</th>
            <th>Dept Managed by</th>
            <th>LOCATION</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
    </div>
    <div class="pagination-controls">
      <div class="RPP">
        <label for="rowsPerPage">Rows per page:</label>
        <select id="rowsPerPage">
          <option value="25" selected>25</option>
          <option value="50">50</option>
          <option value="75">75</option>
          <option value="100">100</option>
        </select>
      </div>
      <div>
        <button id="prevPage">Previous</button>
        <span id="pageInfo">Page 1 of 1</span>
        <button id="nextPage">Next</button>
      </div>
    </div>
  </section>
</div>

<style>
  .modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 1000;
    justify-content: center;
    align-items: center;
  }
  .modal-content {
    background: white;
    padding: 20px;
    border-radius: 8px;
    max-width: 600px;
    width: 90%;
  }
  .close {
    float: right;
    font-size: 24px;
    cursor: pointer;
  }
  table {
    border-collapse: collapse;
    width: 100%;
    table-layout: fixed;
  }
  th, td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
  }
  colgroup col:nth-child(2) {
    width: 200px;
  }
  colgroup col:nth-child(4) {
    width: 150px;
  }
  colgroup col:nth-child(7),
  colgroup col:nth-child(8),
  colgroup col:nth-child(9) {
    width: 60px;
  }
  #toast-container {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 2000;
  }
  .toast {
    padding: 15px;
    margin-bottom: 10px;
    border-radius: 4px;
    color: white;
    min-width: 200px;
    max-width: 300px;
    opacity: 0;
    transition: opacity 0.3s ease-in-out;
  }
  .toast.success {
    background-color: #28a745;
  }
  .toast.error {
    background-color: #dc3545;
  }
  .toast.show {
    opacity: 1;
  }
  .cancel-btn {
    background-color: #6c757d;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
    margin-left: 10px;
  }
  .cancel-btn:hover {
    background-color: #5a6268;
  }
</style>

<script>
  // Toast notification function
  function showToast(message, type = 'success') {
    const toastContainer = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    toastContainer.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 100);
    
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  document.addEventListener('DOMContentLoaded', () => {
    const addModal = document.getElementById('addModal');
    const viewModal = document.getElementById('viewModal');
    const editModal = document.getElementById('editModal');
    const deleteModal = document.getElementById('deleteModal');
    const addForm = document.getElementById('addForm');
    const viewForm = document.getElementById('viewForm');
    const editForm = document.getElementById('editForm');
    const addDepartmentBtn = document.getElementById('addDepartmentBtn');
    const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
    const cancelDeleteBtn = document.getElementById('cancelDeleteBtn');
    const tbody = document.querySelector('#departmentsTable tbody');
    const rowsPerPageSelect = document.getElementById('rowsPerPage');
    const prevPageBtn = document.getElementById('prevPage');
    const nextPageBtn = document.getElementById('nextPage');
    const pageInfoSpan = document.getElementById('pageInfo');
    let currentPage = 1;
    let rowsPerPage = parseInt(rowsPerPageSelect.value);
    let deleteDepartmentId = null;

    // Modal close handlers
    document.querySelectorAll('.close').forEach(closeBtn => {
      closeBtn.addEventListener('click', () => {
        closeBtn.closest('.modal').style.display = 'none';
      });
    });

    // Open add modal
    addDepartmentBtn.addEventListener('click', () => {
      addForm.reset();
      addModal.style.display = 'block';
    });

    // Cancel delete
    cancelDeleteBtn.addEventListener('click', () => {
      deleteModal.style.display = 'none';
      deleteDepartmentId = null;
    });

    // Confirm delete
    confirmDeleteBtn.addEventListener('click', () => {
      if (deleteDepartmentId) {
        const formData = new FormData();
        formData.append('id', deleteDepartmentId);
        fetch('../backend/human-resource/departments/delete_department.php', {
          method: 'POST',
          body: formData
        })
          .then(res => res.json())
          .then(resp => {
            if (resp.status === 'success') {
              showToast(resp.message || 'Department deleted successfully!', 'success');
              fetchDepartments();
            } else {
              showToast(resp.message || 'Failed to delete department.', 'error');
            }
            deleteModal.style.display = 'none';
            deleteDepartmentId = null;
          })
          .catch(err => {
            console.error('Delete error:', err);
            showToast('An error occurred while deleting the department.', 'error');
            deleteModal.style.display = 'none';
            deleteDepartmentId = null;
          });
      }
    });

    // Fetch departments with pagination
    function fetchDepartments() {
      const formData = new FormData();
      formData.append('page', currentPage);
      formData.append('rows_per_page', rowsPerPage);

      fetch('../backend/human-resource/departments/get_departments.php', {
        method: 'POST',
        body: formData
      })
        .then(res => res.json())
        .then(res => {
          if (res.status === 'success') {
            tbody.innerHTML = '';
            res.data.forEach(dep => {
              const tr = document.createElement('tr');
              tr.innerHTML = `
                <td>100${dep.id}</td>
                <td>${dep.dept_name}</td>
                <td>${dep.dept_head}</td>
                <td>${dep.staff_count}</td>
                <td>${dep.admin_dept}</td>
                <td>${dep.location}</td>
                <td><i class="view-icon" data-id="${dep.id}"><img src="../assets/eye-open.png"></i></td>
                <td><i class="edit-icon" data-id="${dep.id}"><img src="../assets/edit.svg"></i></td>
                <td><i class="delete-icon" data-id="${dep.id}"><img src="../assets/Delete.svg"></i></td>
              `;
              tbody.appendChild(tr);
            });

            pageInfoSpan.textContent = `Page ${res.currentPage} of ${res.totalPages}`;
            prevPageBtn.disabled = res.currentPage === 1;
            nextPageBtn.disabled = res.currentPage === res.totalPages;
          } else {
            showToast(res.message || 'Failed to load departments.', 'error');
          }
        })
        .catch(err => {
          console.error('Fetch error:', err);
          showToast('An error occurred while fetching departments.', 'error');
        });
    }

    // AJAX form submission
    function ajaxSubmit(form, url, successMessage) {
      form.addEventListener('submit', e => {
        e.preventDefault();
        const formData = new FormData(form);
        fetch(url, {
          method: 'POST',
          body: formData
        })
          .then(res => res.json())
          .then(resp => {
            if (resp.status === 'success') {
              showToast(successMessage, 'success');
              form.closest('.modal').style.display = 'none';
              fetchDepartments();
            } else {
              showToast(resp.message || 'Operation failed.', 'error');
            }
          })
          .catch(err => {
            console.error('Submit error:', err);
            showToast('An error occurred during the operation.', 'error');
          });
      });
    }

    // CRUD operations
    ajaxSubmit(addForm, '../backend/human-resource/departments/create_department.php', 'Department added successfully!');
    ajaxSubmit(editForm, '../backend/human-resource/departments/update_department.php', 'Department updated successfully!');

    // Table button clicks
    tbody.addEventListener('click', e => {
      const el = e.target.closest('i');
      if (!el) return;

      const id = el.dataset.id;
      if (el.classList.contains('delete-icon')) {
        deleteDepartmentId = id;
        deleteModal.style.display = 'block';
      } else if (el.classList.contains('view-icon')) {
        fetch('../backend/human-resource/departments/get_departments.php')
          .then(res => res.json())
          .then(res => {
            if (res.status === 'success') {
              const dep = res.data.find(x => x.id == id);
              if (!dep) {
                showToast('Department not found.', 'error');
                return;
              }
              ['dept_name', 'dept_head', 'staff_count', 'admin_dept', 'location']
                .forEach(f => viewForm[f].value = dep[f] || '');
              viewModal.style.display = 'block';
            } else {
              showToast(res.message || 'Failed to load department.', 'error');
            }
          })
          .catch(err => {
            console.error('View error:', err);
            showToast('An error occurred while viewing the department.', 'error');
          });
      } else if (el.classList.contains('edit-icon')) {
        fetch('../backend/human-resource/departments/get_departments.php')
          .then(res => res.json())
          .then(res => {
            if (res.status === 'success') {
              const dep = res.data.find(x => x.id == id);
              if (!dep) {
                showToast('Department not found.', 'error');
                return;
              }
              editForm['id'].value = dep.id;
              ['dept_name', 'dept_head', 'staff_count', 'admin_dept', 'location']
                .forEach(f => editForm[f].value = dep[f] || '');
              editModal.style.display = 'block';
            } else {
              showToast(res.message || 'Failed to load department.', 'error');
            }
          })
          .catch(err => {
            console.error('Edit error:', err);
            showToast('An error occurred while editing the department.', 'error');
          });
      }
    });

    // Pagination controls
    rowsPerPageSelect.addEventListener('change', () => {
      rowsPerPage = parseInt(rowsPerPageSelect.value);
      currentPage = 1;
      fetchDepartments();
    });

    prevPageBtn.addEventListener('click', () => {
      if (currentPage > 1) {
        currentPage--;
        fetchDepartments();
      }
    });

    nextPageBtn.addEventListener('click', () => {
      currentPage++;
      fetchDepartments();
    });

    // Initial load
    fetchDepartments();
  });
</script>

<?php include_once '../components/cashflow_footer.php'; ?>