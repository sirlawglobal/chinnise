<?php include_once '../components/header.php'; ?>

<div class="modal" style="display: none;">
  <div class="modal-content">
    <span class="close">×</span>
    <h2 class="con">Add Pay Grade</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Level*</label>
          <input type="text">
        </div>
        <div class="col">
          <label>Pay Grade Name*</label>
          <input type="text">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Gross Salary*</label>
          <input type="text">
        </div>
        <div class="col">
          <label>PAYE</label>
          <input type="text">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Pension*</label>
          <input type="text">
        </div>
        <div class="col">
          <label>Overtime Rate</label>
          <input type="text">
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>

<div class="modal2" id="edit">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Pay Grade</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Level*</label>
          <input type="text" value="1" placeholder="Enter level">
        </div>
        <div class="col">
          <label>Pay Grade Name*</label>
          <input type="text" value="Junior Developer" placeholder="Enter pay grade name">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Gross Salary*</label>
          <input type="text" value="1000.00" placeholder="Enter gross salary">
        </div>
        <div class="col">
          <label>PAYE</label>
          <input type="text" value="100.00" placeholder="Enter PAYE">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Pension*</label>
          <input type="text" value="50.00" placeholder="Enter pension">
        </div>
        <div class="col">
          <label>Overtime Rate</label>
          <input type="text" value="20.00" placeholder="Enter overtime rate">
        </div>
      </div>

      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update</button>
      </div>
    </form>
  </div>
</div>

<div class="main">
  <?php include_once '../components/common_header.php'; ?>


  <!-- Your page content goes here -->
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources</a> | <span>Pay Grade</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px">
          Add Pay Grade
        </button>
      </div>
    </div>
    <header id="payroll-header">
      <div class="tabs">
        <!-- <button class="tab-btn" data-tab="welcome" onclick="location.href='./payroll'">Welcome</button> -->
        <button class="tab-btn" onclick="location.href='./my-payroll'" data-tab="payroll">Payroll</button>
        <!-- <button class="tab-btn" onclick="location.href='./deductions'" data-tab="deductions">Deductions</button> -->
        <!-- <button class="tab-btn" onclick="location.href='./monthly-bonus'" data-tab="bonus">Monthly Bonus</button> -->
        <button class="tab-btn active" onclick="location.href='./pay-grade'" data-tab="paygrade">Pay Grade</button>
        <button class="tab-btn" onclick="location.href='./payment-history'" data-tab="history">Payment History</button>
      </div>
    </header>
    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table class="leads-table">
        <thead>
          <tr>
            <th>Level</th>
            <th>Grade</th>
            <th>Name</th>
            <th>Grade</th>
            <th>Salary</th>
            <th>PAYE</th>
            <th>Pension</th>
            <th>Overtime Rate</th>
            <th>Options</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>Some Pay Grade</td>
            <td>Junior Developer</td>
            <td>1,000.00</td>
            <td>100.00</td>
            <td>50.00</td>
            <td>20.00</td>
            <td>100.00</td>
            <td>
              <i class="edit-icon">
                <img src="../assets/edit.svg" />
              </i>
              <i class="delete-icon">
                <img src="../assets/Delete.svg" /></i>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</div>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const modal = document.querySelector(".modal");
    const modal2 = document.querySelector(".modal2");
    const close = document.querySelector(".close");
    const close2 = document.querySelector(".close2");
    const addBtn = document.querySelector(".add-new-button");
    const saveBtn = document.querySelector(".modal .save-btn");
    const updateBtn = document.querySelector(".modal2 .save-btn");
    const tableBody = document.querySelector(".leads-table tbody");

    let editingId = null;

    // Show Add Modal
    addBtn.addEventListener("click", () => {
      modal.style.display = "block";
      modal.querySelectorAll("input").forEach(input => input.value = "");
    });

    // Close modals
    close.onclick = () => modal.style.display = "none";
    close2.onclick = () => modal2.style.display = "none";

    // Fetch & Display
    function fetchGrades() {
      fetch("../backend/human-resource/pay-grade/fetch_pay_grades.php")
        .then(res => res.json())
        .then(data => {
          tableBody.innerHTML = "";
          data.forEach(item => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
            <td>${item.level}</td>
            <td>${item.pay_grade_name}</td>
            <td>${item.pay_grade_name}</td>
            <td>${parseFloat(item.gross_salary).toFixed(2)}</td>
            <td>${parseFloat(item.paye).toFixed(2)}</td>
            <td>${parseFloat(item.pension).toFixed(2)}</td>
            <td>${parseFloat(item.overtime_rate).toFixed(2)}</td>
            <td>${parseFloat(item.overtime_rate).toFixed(2)}</td>
            <td>
              <i class="edit-icon" data-id="${item.id}">
                <img src="../assets/edit.svg" />
              </i>
              <i class="delete-icon" data-id="${item.id}">
                <img src="../assets/Delete.svg" />
              </i>
            </td>
          `;
            tableBody.appendChild(tr);
          });
        });
    }

    fetchGrades(); // Initial fetch

    // Add new
    saveBtn.addEventListener("click", function (e) {
      e.preventDefault();
      const inputs = modal.querySelectorAll("input");
      const data = {
        level: inputs[0].value,
        pay_grade_name: inputs[1].value,
        gross_salary: inputs[2].value,
        paye: inputs[3].value,
        pension: inputs[4].value,
        overtime_rate: inputs[5].value
      };

      fetch("../backend/human-resource/pay-grade/add_pay_grade.php", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }).then(res => res.json())
        .then(res => {
          if (res.success) {
            modal.style.display = "none";
            fetchGrades();
          }
        });
    });

    // Edit
    tableBody.addEventListener("click", function (e) {
      if (e.target.closest(".edit-icon")) {
        const id = e.target.closest(".edit-icon").dataset.id;
        fetch("../backend/human-resource/pay-grade/fetch_pay_grades.php")
          .then(res => res.json())
          .then(data => {
            const grade = data.find(row => row.id === parseInt(id));
            if (!grade) {
              console.error("Grade not found for ID:", id);
              return;
            }

            const inputs = modal2.querySelectorAll("input");
            inputs[0].value = grade.level;
            inputs[1].value = grade.pay_grade_name;
            inputs[2].value = grade.gross_salary;
            inputs[3].value = grade.paye;
            inputs[4].value = grade.pension;
            inputs[5].value = grade.overtime_rate;
            editingId = id;
            modal2.style.display = "block";
          });
      }

    });

    updateBtn.addEventListener("click", function (e) {
      e.preventDefault();
      const inputs = modal2.querySelectorAll("input");
      const data = {
        id: editingId,
        level: inputs[0].value,
        pay_grade_name: inputs[1].value,
        gross_salary: inputs[2].value,
        paye: inputs[3].value,
        pension: inputs[4].value,
        overtime_rate: inputs[5].value
      };

      fetch("../backend/human-resource/pay-grade/update_pay_grade.php", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }).then(res => res.json())
        .then(res => {
          if (res.success) {
            modal2.style.display = "none";
            fetchGrades();
          }
        });
    });

    // Delete
    tableBody.addEventListener("click", function (e) {
      if (e.target.closest(".delete-icon")) {
        const id = e.target.closest(".delete-icon").dataset.id;
        if (confirm("Are you sure you want to delete this Pay Grade?")) {
          fetch("../backend/human-resource/pay-grade/delete_pay_grade.php", {
            method: "POST",
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
          }).then(res => res.json())
            .then(res => {
              if (res.success) {
                fetchGrades();
              }
            });
        }
      }
    });
  });
</script>

<?php include_once '../components/cashflow_footer.php'; ?>