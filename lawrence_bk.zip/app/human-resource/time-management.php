<?php include_once '../components/header.php'; ?>

<div class="main">
  <?php include_once '../components/common_header.php'; ?>


  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources</a> | <span>Time Management</span>
        </div>
      </div>
    </div>
    <header id="payroll-header">
      <div class="tabs">
        <button class="tab-btn" data-tab="welcome" onclick="location.href='./awards-and-incentives'">Welcome</button>
        <button class="tab-btn active" onclick="location.href='./time-management'" data-tab="payroll">Time
          Management</button>
        <button class="tab-btn" onclick="location.href='./staff-of-the-month'" data-tab="deductions">Staff of The
          Month</button>
        <button class="tab-btn" onclick="location.href='./staff-of-the-year'" data-tab="bonus">Staff of the
          Year</button>
        <button class="tab-btn" onclick="location.href='./mentorship'" data-tab="paygrade">Mentorship</button>
        <button class="tab-btn" onclick="location.href='./top-performer'" data-tab="history">Top performer</button>
      </div>
    </header>
    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table class="leads-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>First Name</th>
            <th>Surname</th>
            <th>Award Name</th>
            <th>Award Description</th>
            <th>Gift Item</th>
            <th>Awarded By</th>
          </tr>
        </thead>
        <tbody id="awards-table-body">
        </tbody>
      </table>
    </div>
  </section>
</div>
<script>
  // Global function to load awards
  function loadAwards() {
    fetch('../backend/human-resource/time-management/fetch_awards.php')
      .then(res => res.json())
      .then(data => {
        let tbody = document.getElementById('awards-table-body'); // Use an ID for the tbody
        tbody.innerHTML = ''; // Clear existing content

        if (data.error) {
          tbody.innerHTML = `<tr><td colspan="9" style="color: red;">Error: ${data.error}</td></tr>`;
          return;
        }

        data.forEach(row => {
          const awardDate = new Date(row.award_date);

          // Get day, month, and year
          const day = String(awardDate.getDate()).padStart(2, '0');
          const month = String(awardDate.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
          const year = awardDate.getFullYear();

          // Format as dd-mm-yyyy
          const formattedDate = `${day}-${month}-${year}`;

          // Truncate strings to 20 characters if they are longer, adding "..."
          const truncate = (text, maxLength) => {
            if (text === null || text === undefined) {
              return ''; // Handle null or undefined values gracefully
            }
            text = String(text); // Ensure it's a string
            if (text.length > maxLength) {
              return text.substring(0, maxLength - 3) + '...';
            }
            return text;
          };

          const truncatedAwardName = truncate(row.award_name, 20);
          const truncatedAwardDescription = truncate(row.award_description, 20);
          const truncatedGiftItem = truncate(row.gift_item, 20);
          const truncatedAwardedBy = truncate(row.awarded_by, 20);

          tbody.innerHTML += `
        <tr data-id="${row.id}">
            <td>${formattedDate}</td>
            <td>${row.first_name}</td>
            <td>${row.last_name}</td>
            <td>${truncatedAwardName}</td>
            <td>${truncatedAwardDescription}</td>
            <td>${truncatedGiftItem}</td>
            <td>${truncatedAwardedBy}</td>
        </tr>`;
        });
      })
      .catch(err => {
        console.error('Error fetching awards:', err);
        document.getElementById('awards-table-body').innerHTML = `<tr><td colspan="9" style="color: red;">Failed to load awards.</td></tr>`;
      });
  }

  // Load awards when the page loads
  document.addEventListener('DOMContentLoaded', loadAwards);

  // Modal opening/closing
  document.querySelector('.add-new-button').addEventListener('click', function() {
    document.querySelector('.modal').style.display = 'block';
  });

  document.querySelector('.close').addEventListener('click', function() {
    document.querySelector('.modal').style.display = 'none';
  });

  document.querySelector('.close2').addEventListener('click', function() {
    document.getElementById('edit').style.display = 'none';
  });
</script>

<script>
  // Handle Add Award form submission
  document.getElementById("addAwardForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form); // Use FormData for easier handling

    fetch("../backend/human-resource/time-management/add_award.php", {
        method: "POST",
        body: formData, // FormData automatically sets Content-Type
      })
      .then((res) => res.json())
      .then((response) => {
        alert(response.message);
        if (response.success) { // Assuming your backend sends a 'success' field
          form.reset();
          document.querySelector(".modal").style.display = "none";
          loadAwards(); // Reload awards list after successful addition
        }
      })
      .catch((err) => {
        console.error("Error adding award:", err);
        alert("Something went wrong adding the award.");
      });
  });

  // Event delegation for Edit and Delete icons
  document.addEventListener('click', function(e) {
    const editIcon = e.target.closest('.edit-icon');
    const deleteIcon = e.target.closest('.delete-icon');

    if (editIcon) {
      const row = editIcon.closest('tr');
      const cells = row.querySelectorAll('td');
      const awardId = row.dataset.id; // Get ID from data-id attribute

      const form = document.getElementById("editAwardForm");

      form.id.value = awardId; // Set the hidden ID field
      form.award_name.value = cells[3].innerText;
      form.award_description.value = cells[4].innerText;
      form.gift_item.value = cells[5].innerText;
      form.award_date.value = cells[0].innerText;
      form.first_name.value = cells[1].innerText;
      form.last_name.value = cells[2].innerText;
      form.awarded_by.value = cells[6].innerText;

      document.getElementById("edit").style.display = "block";

    } else if (deleteIcon) {
      const row = deleteIcon.closest('tr');
      const awardId = row.dataset.id;

      if (confirm("Are you sure you want to delete this award?")) {
        fetch("../backend/human-resource/time-management/delete_award.php", {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              id: awardId
            }),
          })
          .then(res => res.json())
          .then(response => {
            alert(response.message);
            if (response.success) {
              loadAwards(); // Reload awards list after successful deletion
              location.reload();
            }
          })
          .catch(err => {
            console.error("Error deleting award:", err);
            alert("Delete failed.");
          });
      }
    }
  });

  // Handle Edit Award form submission
  document.getElementById("editAwardForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form); // Use FormData for easier handling

    // Optional: Log form data to console for debugging
    // console.log(Object.fromEntries(formData.entries()));

    fetch("../backend/human-resource/time-management/update_award.php", {
        method: "POST",
        body: formData, // FormData automatically sets Content-Type
      })
      .then(res => res.json())
      .then(response => {
        alert(response.message);
        if (response.success) {
          document.getElementById("edit").style.display = "none";
          loadAwards(); // Reload awards list after successful update
        }
      })
      .catch(err => {
        console.error("Error updating award:", err);
        alert("Update failed.");
      });
  });
</script>

<?php include_once '../components/cashflow_footer.php'; ?>