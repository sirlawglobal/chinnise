<?php include_once '../components/header.php'; ?>
<div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">View Client</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Company Name</label>
          <input type="text" readonly value="BrightMind Solutions" />
        </div>
        <div class="col">
          <label>Contact Title</label>
          <input type="text" readonly value="Mr." />
        </div>
        <div class="col">
          <label>Contact Firstname</label>
          <input type="text" readonly value="Simran" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Contact Lastname</label>
          <input type="text" readonly value="Mehra" />
        </div>
        <div class="col">
          <label>Email</label>
          <input
            type="email"
            readonly
            placeholder="Enter email"
            value="simran.mehra@email.com" />
        </div>
        <div class="col">
          <label>Company Category</label>
          <input
            type="text"
            readonly
            placeholder="Enter category"
            value="IT" />
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Position</label>
          <input type="text" readonly value="Product Manager" />
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" readonly value="45 Maple Blvd, Bengaluru" />
        </div>
        <div class="col">
          <label>Source</label>
          <input type="text" readonly value="Imported" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Modified Date</label>
          <input
            type="date"
            readonly
            value="2025-04-12"
            class="form-input"
            name="modified_date" />
        </div>
        <div class="col">
          <label>Phone Number</label>
          <input type="tel" readonly value="9834567890" />
        </div>
        <div class="col">
          <label>Status</label>
          <select>
            <option>New</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="card">
          <div class="card-header">
            <h3>Notes</h3>
          </div>
          <div class="card-body">
            <div class="card-item">
              <small class="card-s">Admin Admin - April 13, 2025</small>
              <p class="card-p">Hello Engr. Simran</p>
            </div>
            <div class="card-item">
              <small class="card-s">Admin Admin - April 13, 2025</small>
              <p class="card-p">Hello Engr. Simran</p>
            </div>
          </div>
        </div>
      </div>

      <button type="submit" class="save-btn">Save</button>
    </form>
  </div>
</div>
<!-- Main content -->
<div class="main">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <?php
  // Make sure the path to your connection file is correct!
  require_once '../settings/connection.php'; // Adjust 'db_connect.php' to your actual file name and path

  try {
    // Query to get total employees, men, and women
    $stmt = $pdo->query("SELECT
                            COUNT(*) AS total_employees,
                            COUNT(CASE WHEN gender = 'Male' THEN 1 END) AS men_count,
                            COUNT(CASE WHEN gender = 'Female' THEN 1 END) AS women_count
                         FROM employees");

    $employee_data = $stmt->fetch();

    $total_employees = $employee_data['total_employees'];
    $men_count       = $employee_data['men_count'];
    $women_count     = $employee_data['women_count'];
  } catch (\PDOException $e) {
    // Handle database query errors gracefully
    error_log("Employee data query error: " . $e->getMessage());
    $total_employees = 'N/A'; // Default values in case of error
    $men_count       = 'N/A';
    $women_count     = 'N/A';
    // Optionally, display a user-friendly error message on the page
    // echo "<p>Error fetching employee data. Please try again later.</p>";
  }

  $stmt8 = $pdo->query("SELECT COUNT(*) FROM leave_requests");
  $leave = $stmt8->fetchColumn();

  $stmt9 = $pdo->query("SELECT COUNT(*) FROM leave_requests WHERE gender = 'male'");
  $leave_male = $stmt9->fetchColumn();

  $stmt10 = $pdo->query("SELECT COUNT(*) FROM leave_requests WHERE gender = 'female'");
  $leave_female = $stmt10->fetchColumn();
  ?>
  <section class="content">
    <h3 style="padding: 1rem">Human Resource</h3>
    <div class="box1">
      <div class="employee-box">
        <div class="box2" style="width: 50%">
          <h4 class="box2-title">Employees</h4>
          <div class="box2__value box2__value--green"><?php echo htmlspecialchars($total_employees); ?></div>
          <div class="box2-split">
            <div class="box2-split-item">
              <div class="box2-split-number"><?php echo htmlspecialchars($men_count); ?></div>
              <div class="box2-split-label">Men</div>
            </div>
            <div class="box2-split-divider"></div>

            <div class="box2-split-item">
              <div class="box2-split-number"><?php echo htmlspecialchars($women_count); ?></div>
              <div class="box2-split-label">Women</div>
            </div>
          </div>
        </div>
        <div class="box2" style="width: 50%">
          <h4 class="box2-title">Leave Taken</h4>
          <div class="box2__value box2__value--green"><?php echo htmlspecialchars($leave); ?></div>
          <div class="box2-split">
            <div class="box2-split-item">
              <div class="box2-split-number"><?php echo htmlspecialchars($leave_male); ?></div>
              <div class="box2-split-label">Men</div>
            </div>
            <div class="box2-split-divider"></div>

            <div class="box2-split-item">
              <div class="box2-split-number"><?php echo htmlspecialchars($leave_female); ?></div>
              <div class="box2-split-label">Women</div>
            </div>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-header">
          <h2>Attendance Statistics</h2>
          <div class="header-right">
            <div class="legend">
              <span><span class="dot pink"></span>Over time</span>
              <span><span class="dot red"></span>Late</span>
              <span><span class="dot yellow"></span>Absent</span>
              <span><span class="dot blue"></span>Early</span>
            </div>
            <div class="icons">
              <span class="icon">⤢</span>
              <span class="icon">⬇</span>
            </div>
          </div>
        </div>
        <div class="attendance-content">
          <div class="y-axis-label">Number of Days</div>
          <div class="chart-area">
            <!-- Placeholder for chart -->
          </div>
          <div class="badge">THIS YEAR</div>
        </div>
      </div>
    </div>
<div class="box1" style="grid-template-columns: 56% 43%">
    <div class="box2" style="height: 100%; padding: 0">
        <h4>Trainings</h4>
        <div
            style="overflow: auto; padding: 0.7rem; height: 80%; width: 100%">
            <table class="leads-table">
                <thead>
                    <tr>
                        <th>Events</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Assuming connection.php is correctly configured and $pdo is available
                    include_once '../settings/connection.php'; 

                    try {
                        // Select course_name and date from the trainings table
                        // Order by date to show upcoming events first
                        // You might want to add a WHERE clause here to only show future events, e.g., WHERE date >= CURDATE()
                        $stmt = $pdo->query("SELECT course_name, training_date as date FROM trainings ORDER BY date ASC LIMIT 10"); // Limit to 10 for display

                        // Check if any rows were returned
                        if ($stmt->rowCount() > 0) {
                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                $eventName = htmlspecialchars($row['course_name']);
                                
                                // Format the date as "DD Month YYYY" (e.g., "30 June 2024")
                                $eventDate = date("j F Y", strtotime($row['date']));

                                echo "<tr>
                                        <td>{$eventName}</td>
                                        <td>{$eventDate}</td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='2'>No upcoming events found.</td></tr>";
                        }
                    } catch (PDOException $e) {
                        echo "<tr><td colspan='2'>Error fetching events: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="box2" style="height: 100%">
        <div id="calendar" style="overflow-y: auto;width:100%"></div>
    </div>
</div>
  </section>
</div>
<script src="../fullcalendar.min.js"></script>
<script src="../cals.js"></script>
<?php include_once '../components/cashflow_footer.php'; ?>