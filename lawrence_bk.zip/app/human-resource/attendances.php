<?php
include_once '../settings/connection.php'; // Sets up $pdo

try {
  $stmt = $pdo->prepare("
        SELECT 
            t.date, 
            t.staff_id, 
            s.firstname, 
            s.lastname, 
            t.time_in, 
            t.time_out, 
            t.note, 
            t.type
        FROM timesheet t
        LEFT JOIN staffs s ON t.staff_id = s.id
        ORDER BY t.date DESC
    ");
  $stmt->execute();
  $timesheetRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  die("Error fetching timesheet data: " . $e->getMessage());
}
?>


<?php include_once '../components/header.php'; ?>

<div class="main">
  <?php include_once '../components/common_header.php'; ?>

  <!-- Your page content goes here -->
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources | Attendance</a> | <span>Daily</span>
        </div>
      </div>
    </div>

    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table>
        <colgroup>
        <col>
        <col>
        <col>
        <col>
        <col>
        <col>
      </colgroup>
        <thead>
          <tr>
            <th>Date</th>
            <th>Staff ID</th>
            <th>Employee Name</th>
            <th>Time in</th>
            <th>Time out</th>
            <th>Note</th>
            <!-- <th>Late</th> -->
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($timesheetRows)): ?>
            <?php foreach ($timesheetRows as $row): ?>
              <tr>
                <td><?= date('d-m-Y', strtotime($row['date'])) ?></td>
                <td><?= htmlspecialchars($row['staff_id']) ?></td>
                <td><?= htmlspecialchars($row['firstname'] . ' ' . $row['lastname']) ?></td>
                <td><?= htmlspecialchars($row['time_in']) ?></td>
                <td><?= htmlspecialchars($row['time_out']) ?></td>
                <td><?= nl2br(htmlspecialchars($row['note'])) ?></td>
                <td><?= htmlspecialchars($row['type'] === 'OT' ? 'Overtime' : 'Normal Time') ?></td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="7">No records found.</td>
            </tr>
          <?php endif; ?>
        </tbody>

      </table>
    </div>
  </section>
</div>
<style>
  colgroup col:nth-child(1) {
    width: 120px;
  }

  colgroup col:nth-child(2) {
    width: 80px;
  }

  colgroup col:nth-child(3) {
    width: 200px;
  }

  colgroup col:nth-child(4) {
    width: 150px;
  }

  colgroup col:nth-child(5) {
    width: 180px;
  }

  colgroup col:nth-child(6) {
    width: 150px;
  }
</style>
<?php include_once '../components/cashflow_footer.php'; ?>