<?php include_once '../../components/header.php'; ?>
<div class="main">
  <?php include_once '../../components/common_header.php'; ?>
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="../attendance-report">Attendance</a> | <span>Leave Report</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px" onclick="window.print()">
          Print Report
        </button>
      </div>
    </div>

    <!-- Auto-Submit Filter Form -->
    <form method="GET" id="filterForm" class="row1" style="gap: 1rem;">
      <div class="col1">
        <label>Start Date:</label>
        <input type="date" name="start_date" value="<?= htmlspecialchars($_GET['start_date'] ?? '') ?>" />
      </div>
      <div class="col1">
        <label>End Date:</label>
        <input type="date" name="end_date" value="<?= htmlspecialchars($_GET['end_date'] ?? '') ?>" />
      </div>
      <div class="col1">
        <label>Employee:</label>
        <select name="employee">
          <option value="">All</option>
          <?php
          require_once '../../settings/connection.php';
          $stmtEmp = $pdo->query("SELECT DISTINCT employee_name FROM leave_requests ORDER BY employee_name");
          while ($row = $stmtEmp->fetch(PDO::FETCH_ASSOC)) {
            $selected = ($_GET['employee'] ?? '') === $row['employee_name'] ? 'selected' : '';
            echo "<option value=\"" . htmlspecialchars($row['employee_name']) . "\" $selected>" . htmlspecialchars($row['employee_name']) . "</option>";
          }
          ?>
        </select>
      </div>
    </form>

    <!-- Table Section -->
    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table class="leads-table">
        <thead>
          <tr>
            <th>Employee</th>
            <th>Leave Type</th>
            <th>Start Date</th>
            <th>Leave Days</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $totalLeaveDays = 0;

          // Build dynamic WHERE clause
          $conditions = [];
          $params = [];

          if (!empty($_GET['start_date'])) {
            $conditions[] = "start_date >= :start_date";
            $params[':start_date'] = $_GET['start_date'];
          }
          if (!empty($_GET['end_date'])) {
            $conditions[] = "start_date <= :end_date";
            $params[':end_date'] = $_GET['end_date'];
          }
          if (!empty($_GET['employee'])) {
            $conditions[] = "employee_name = :employee";
            $params[':employee'] = $_GET['employee'];
          }

          $whereSQL = $conditions ? "WHERE " . implode(" AND ", $conditions) : "";

          try {
            $stmt = $pdo->prepare("SELECT employee_name, leave_type, start_date, duration FROM leave_requests $whereSQL ORDER BY start_date DESC");
            $stmt->execute($params);
            $leaveRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($leaveRequests) {
              foreach ($leaveRequests as $request) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($request['employee_name']) . "</td>";
                echo "<td>" . htmlspecialchars($request['leave_type']) . "</td>";
                echo "<td>" . date('d-m-Y', strtotime($request['start_date'])) . "</td>";
                echo "<td>" . htmlspecialchars($request['duration']) . "</td>";
                echo "</tr>";
                $totalLeaveDays += (int) $request['duration'];
              }
            } else {
              echo "<tr><td colspan='4'>No leave requests found for selected filters.</td></tr>";
            }
          } catch (PDOException $e) {
            echo "<tr><td colspan='4' style='color: red;'>Error: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
          }
          ?>
        </tbody>
        <tfoot>
          <tr>
            <td colspan="3" style="font-weight: bold;">Total Leave Days:</td>
            <td><?= $totalLeaveDays ?></td>
          </tr>
        </tfoot>
      </table>
    </div>
  </section>
</div>
<?php include_once '../../components/cashflow_footer.php'; ?>

<!-- Auto-submit script -->
<script>
  const form = document.getElementById('filterForm');
  const inputs = form.querySelectorAll('input, select');

  inputs.forEach(input => {
    input.addEventListener('change', () => {
      form.submit();
    });
  });
</script>
