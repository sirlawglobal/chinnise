<?php
include_once '../../settings/connection.php'; // $pdo is set

// Fetch staff
$staffStmt = $pdo->query("SELECT id, firstname, lastname FROM staffs ORDER BY firstname");
$staffs = $staffStmt->fetchAll(PDO::FETCH_ASSOC);

// Get selected month
$selectedMonth = $_GET['month'] ?? date('Y-m');

// Prepare attendance summary
$attendanceData = [];

// Get working days in selected month
function getWorkingDays($month) {
    $start = new DateTime("$month-01");
    $end = clone $start;
    $end->modify('last day of this month');
    $workingDays = 0;
    while ($start <= $end) {
        if (!in_array($start->format('N'), [6, 7])) { // 6=Saturday, 7=Sunday
            $workingDays++;
        }
        $start->modify('+1 day');
    }
    return $workingDays;
}

$workingDays = getWorkingDays($selectedMonth);

// Fetch attendance
$sql = "
    SELECT staff_id, DATE(date) as date
    FROM timesheet
    WHERE DATE_FORMAT(date, '%Y-%m') = :month
    GROUP BY staff_id, DATE(date)
";
$stmt = $pdo->prepare($sql);
$stmt->execute(['month' => $selectedMonth]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Process attendance
foreach ($rows as $row) {
    $sid = $row['staff_id'];
    if (!isset($attendanceData[$sid])) {
        $attendanceData[$sid] = [];
    }
    $attendanceData[$sid][$row['date']] = true; // Unique dates
}

?>
<?php include_once '../../components/header.php'; ?>

<script>
  function printReport() {
    window.print();
  }

  document.addEventListener('DOMContentLoaded', function () {
    const monthInput = document.querySelector('input[name="month"]');
    if (monthInput) {
      monthInput.addEventListener('change', () => {
        document.getElementById('filterForm').submit();
      });
    }
  });
</script>

<div class="main">
  <?php include_once '../../components/common_header.php'; ?>
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="../attendance-report">Attendance</a> | <span>Monthly Attendance Summary Report</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px" onclick="printReport()">Print Report</button>
      </div>
    </div>

    <!-- Filter -->
    <form method="GET" id="filterForm" class="row1">
      <div class="col1">
        <label>Month:</label>
        <input type="month" name="month" value="<?= htmlspecialchars($selectedMonth) ?>">
      </div>
    </form>

    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table>
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>Month</th>
            <th>Employee Name</th>
            <th>Total Working Days</th>
            <th>Total Attendance</th>
            <th>Total Absences</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($staffs as $staff): 
              $sid = $staff['id'];
              $fullname = htmlspecialchars($staff['firstname'] . ' ' . $staff['lastname']);
              $attendanceCount = isset($attendanceData[$sid]) ? count($attendanceData[$sid]) : 0;
              $absences = $workingDays - $attendanceCount;
          ?>
            <tr>
              <td><?= date('m-Y', strtotime($selectedMonth)) ?></td>
              <td><?= $fullname ?></td>
              <td><?= $workingDays ?></td>
              <td><?= $attendanceCount ?></td>
              <td><?= $absences ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>
</div>
<style>
  colgroup col:nth-child(1) {
    width: 100px;
  }

  colgroup col:nth-child(2) {
    width: 150px;
  }

  colgroup col:nth-child(3) {
    width: 100px;
  }

  colgroup col:nth-child(4) {
    width: 100px;
  }

  colgroup col:nth-child(5) {
    width: 100px;
  }
</style>
<?php include_once '../../components/cashflow_footer.php'; ?>
