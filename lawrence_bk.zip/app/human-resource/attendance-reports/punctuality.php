<?php include_once '../../components/header.php'; ?>
<?php include_once '../../settings/connection.php'; ?>
<div class="main">
  <?php include_once '../../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="../attendance-report">Attendance</a> | <span>Punctuality Report</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px">
          Print Report
        </button>
      </div>
    </div>
    <div class="row1">
      <div class="col1">
        <label>Start Date:</label>
        <input type="date" id="startDate" />
      </div>
      <div class="col1">
        <label>End Date:</label>
        <input type="date" id="endDate" />
      </div>
      <div class="col1">
        <label>Employee:</label>
        <select id="employeeSelect">
          <option value="all">All</option>
          <?php
          // Populate employee list
          $employees = $pdo->query("SELECT id, CONCAT(firstname, ' ', lastname) AS name FROM staffs")->fetchAll();
          foreach ($employees as $emp) {
            echo "<option value='{$emp['id']}'>{$emp['name']}</option>";
          }
          ?>
        </select>
      </div>
    </div>


    <?php
    include_once '../../settings/connection.php';

    $start = $_GET['start'] ?? null;
    $end = $_GET['end'] ?? null;
    $employee = $_GET['employee'] ?? null;

    $conditions = [];
    $params = [];

    if ($start) {
      $conditions[] = 't.date >= :start';
      $params[':start'] = $start;
    }
    if ($end) {
      $conditions[] = 't.date <= :end';
      $params[':end'] = $end;
    }
    if ($employee && $employee !== 'all') {
      $conditions[] = 's.id = :employee';
      $params[':employee'] = $employee;
    }

    $where = count($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

    $sql = "
    SELECT 
        t.date,
        s.staff_id,
        CONCAT(s.firstname, ' ', s.lastname) AS employee_name,
        t.time_in,
        t.time_out,
        t.note,
        t.type
    FROM timesheet t
    JOIN staffs s ON t.staff_id = s.id
    $where
    ORDER BY t.date DESC
";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $timesheets = $stmt->fetchAll();

    // Count total late arrivals
    $totalLate = 0;
    foreach ($timesheets as $row) {
      if ($row['time_in'] > '09:00:00' && $row['type'] === 'NT') {
        $totalLate++;
      }
    }

    ?>

    <div class="over-table">
      <table class="leads-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Staff ID</th>
            <th>Employee Name</th>
            <th>Time In</th>
            <th>Time Out</th>
            <th>Note</th>
            <th>Late</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($timesheets as $row): ?>
            <tr>
              <td><?= date('d-m-Y', strtotime($row['date'])) ?></td>
              <td><?= htmlspecialchars($row['staff_id']) ?></td>
              <td><?= htmlspecialchars($row['employee_name']) ?></td>
              <td><?= htmlspecialchars($row['time_in']) ?></td>
              <td><?= htmlspecialchars($row['time_out'] ?? '-') ?></td>
              <td><?= htmlspecialchars($row['note']) ?></td>
              <td>
                <?= ($row['time_in'] > '09:00:00' && $row['type'] === 'NT') ? 'Yes' : 'No' ?>
              </td>
              <td><?= $row['type'] === 'OT' ? 'Overtime' : 'NT' ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr>
            <td colspan="7" style="font-weight: bold;">Total Late Arrivals</td>
            <td class="total-count"><?= $totalLate ?></td>
          </tr>
        </tfoot>

        <tfoot>
          <tr>
            <td colspan="7" style="font-weight: bold;">Total Late Arrivals</td>
            <td class="total-count">2</td>
          </tr>
        </tfoot>
      </table>
    </div>
  </section>
</div>
<script>
  function filterData() {
    const start = document.getElementById('startDate').value;
    const end = document.getElementById('endDate').value;
    const employee = document.getElementById('employeeSelect').value;

    const params = new URLSearchParams();
    if (start) params.append('start', start);
    if (end) params.append('end', end);
    if (employee !== 'all') params.append('employee', employee);

    window.location.href = '?' + params.toString();
  }

  // Auto-trigger filter on change
  document.getElementById('startDate').addEventListener('change', filterData);
  document.getElementById('endDate').addEventListener('change', filterData);
  document.getElementById('employeeSelect').addEventListener('change', filterData);
</script>

<script>
  document.querySelector('.add-new-button').addEventListener('click', () => {
    window.print();
  });
</script>

<?php include_once '../../components/cashflow_footer.php'; ?>