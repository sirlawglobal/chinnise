<?php include_once '../../components/header.php'; ?>

<?php
// Hardcoded list of UK holidays and special events (add more if needed)
$events = [
  ['date' => '01-01', 'name' => 'New Year’s Day', 'type' => 'Holiday', 'description' => 'Celebration of the New Year'],
  ['date' => '02-14', 'name' => 'Valentine’s Day', 'type' => 'Special Event', 'description' => 'Day for celebrating love and affection'],
  ['date' => '03-17', 'name' => 'St. Patrick’s Day', 'type' => 'Special Event', 'description' => 'Irish cultural celebration'],
  ['date' => '04-22', 'name' => 'Earth Day', 'type' => 'Special Event', 'description' => 'Support for environmental protection'],
  ['date' => '05-06', 'name' => 'Early May Bank Holiday', 'type' => 'Holiday', 'description' => 'UK national bank holiday'],
  ['date' => '12-25', 'name' => 'Christmas Day', 'type' => 'Holiday', 'description' => 'Celebration of Christ'],
  ['date' => '12-26', 'name' => 'Boxing Day', 'type' => 'Holiday', 'description' => 'Day after Christmas in the UK'],
];

// Handle filters
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$filterType = $_GET['type'] ?? 'All';

// Convert filters to MM-DD for comparison
$filteredEvents = array_filter($events, function ($event) use ($startDate, $endDate, $filterType) {
  $eventMMDD = $event['date'];

  if ($startDate && $endDate) {
    $start = date('m-d', strtotime($startDate));
    $end = date('m-d', strtotime($endDate));
    if ($eventMMDD < $start || $eventMMDD > $end)
      return false;
  }

  if ($filterType !== 'All' && $event['type'] !== $filterType)
    return false;

  return true;
});
?>

<div class="main">
  <?php include_once '../../components/common_header.php'; ?>
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="../attendance-report">Attendance</a> |
          <span>Holiday and Special Events Report</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px" onclick="window.print()">
          Print Report
        </button>
      </div>
    </div>

    <!-- Filters -->
    <form method="GET" style="margin-bottom: 1rem;" class="row1" id="filter-form">
      
      <div class="col1">
        <label>Event Type:</label>
        <select name="type" onchange="document.getElementById('filter-form').submit()">
          <option <?= $filterType == 'All' ? 'selected' : '' ?>>All</option>
          <option <?= $filterType == 'Holiday' ? 'selected' : '' ?>>Holiday</option>
          <option <?= $filterType == 'Special Event' ? 'selected' : '' ?>>Special Event</option>
        </select>
      </div>
    </form>


    <!-- Table -->
    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table class="leads-table">
        <thead>
          <tr>
            <th>Month</th>
            <th>Date</th>
            <th>Event Name</th>
            <th>Type</th>
            <th>Description</th>
          </tr>
        </thead>
        <tbody>
          <?php if (count($filteredEvents) > 0): ?>
            <?php foreach ($filteredEvents as $event): ?>
              <?php
              $parts = explode('-', $event['date']);
              $month = date("F", mktime(0, 0, 0, $parts[0], 10));
              ?>
              <tr>
                <td><?= $month ?></td>
                <td><?= $parts[1] ?></td>
                <td><?= htmlspecialchars($event['name']) ?></td>
                <td><?= $event['type'] ?></td>
                <td><?= htmlspecialchars($event['description']) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="5">No matching events found.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </section>
</div>

<?php include_once '../../components/cashflow_footer.php'; ?>