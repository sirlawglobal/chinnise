<?php
include_once '../../components/header.php';
include_once '../../settings/connection.php';

// Initialize variables for filtering
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$staffIdFilter = $_GET['staff'] ?? 'All'; // Changed from employee to staff for consistency

// Build the SQL query
$sql = "SELECT
            t.date,
            s.firstname AS staff_firstname,  -- Fetching firstname from staff table
            -- d.name AS department_name,
            t.time_in,
            t.time_out
        FROM
            timesheet t
        JOIN
            staffs s ON t.staff_id = s.id        -- Join with staff table using staff_id
        WHERE
            t.type = 'OT'"; // Filter for Overtime

// Add date range filters if provided
if (!empty($startDate)) {
    $sql .= " AND t.date >= :start_date";
}
if (!empty($endDate)) {
    $sql .= " AND t.date <= :end_date";
}
// Add staff filter if not 'All'
if ($staffIdFilter !== 'All') {
    $sql .= " AND t.staff_id = :staff_id_filter"; // Use staff_id for filtering
}

$sql .= " ORDER BY t.date DESC, s.firstname ASC"; // Order by first name

try {
    $stmt = $pdo->prepare($sql); // Assuming $pdo is your PDO database connection object

    // Bind parameters
    if (!empty($startDate)) {
        $stmt->bindParam(':start_date', $startDate);
    }
    if (!empty($endDate)) {
        $stmt->bindParam(':end_date', $endDate);
    }
    if ($staffIdFilter !== 'All') {
        $stmt->bindParam(':staff_id_filter', $staffIdFilter); // Bind the staff ID filter
    }

    $stmt->execute();
    $overtimeRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch staff for the dropdown
    // Make sure your staff table has an 'id' (or staff_id) and 'firstname'
    $staffSql = "SELECT id, firstname FROM staffs";
    $staffStmt = $pdo->query($staffSql);
    $staffMembers = $staffStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Handle database errors
    echo "Error: " . $e->getMessage();
    $overtimeRecords = []; // Ensure $overtimeRecords is an empty array on error
    $staffMembers = [];
}
?>

<div class="main">
    <?php include_once '../../components/common_header.php'; ?>
    <section class="content">
        <div class="top flex">
            <div class="left">
                <div class="breadcrumb">
                    <a href="../attendance-report">Attendance</a> | <span>Overtime Report</span>
                </div>
            </div>
            <div class="right">
                <button class="add-new-button" style="border-radius: 15px" onclick="printReport()">
                    Print Report
                </button>
            </div>
        </div>
        <div class="row1">
            <div class="col1">
                <label>Start Date:</label>
                <input type="date" id="startDate" value="<?php echo htmlspecialchars($startDate); ?>" />
            </div>
            <div class="col1">
                <label>End Date:</label>
                <input type="date" id="endDate" value="<?php echo htmlspecialchars($endDate); ?>" />
            </div>
            <div class="col1">
                <label>Staff:</label> <select id="staffFilter">
                    <option value="All" <?php echo ($staffIdFilter === 'All') ? 'selected' : ''; ?>>All</option>
                    <?php foreach ($staffMembers as $staff) : ?>
                        <option value="<?php echo htmlspecialchars($staff['id']); ?>" <?php echo ($staffIdFilter == $staff['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($staff['firstname']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <!-- <div class="col1">
                <button class="add-new-button" style="border-radius: 15px" onclick="applyFilters()">Apply Filter</button>
            </div> -->
        </div>

        <div style="overflow: auto; padding: 0.7rem; height: 80%">
            <table>
                <colgroup>
                    <col>
                    <col>
                    <col>
                </colgroup>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Staff Name</th>
                        <!-- <th>Department</th> -->
                        <th>Overtime Hours</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $totalOvertimeSeconds = 0; // Initialize total overtime in seconds
                    if (!empty($overtimeRecords)) {
                        foreach ($overtimeRecords as $record) {
                            $timeIn = new DateTime($record['time_in']);
                            $timeOut = new DateTime($record['time_out']);
                            $interval = $timeIn->diff($timeOut);

                            $hours = $interval->h;
                            $minutes = $interval->i;
                            $seconds = $interval->s;

                            // Calculate total seconds for the record
                            $recordTotalSeconds = ($hours * 3600) + ($minutes * 60) + $seconds;
                            $totalOvertimeSeconds += $recordTotalSeconds;

                            // Format for display (HH:MM:SS)
                            $overtimeFormatted = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
                    ?>
                            <tr>
                                <td><?= date('d-m-Y', strtotime($record['date'])) ?></td>
                                <td><?php echo htmlspecialchars($record['staff_firstname']); ?></td>
                                <!-- <td><?php echo htmlspecialchars($record['department_name']); ?></td> -->
                                <td><?php echo htmlspecialchars($overtimeFormatted); ?></td>
                            </tr>
                    <?php
                        }
                    } else {
                        echo '<tr><td colspan="4" style="text-align: center;">No overtime records found.</td></tr>';
                    }
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="2" style="font-weight: bold;">Total Overtime Hours:</td>
                        <td>
                            <?php
                            // Convert total seconds back to HH:MM:SS
                            $totalHours = floor($totalOvertimeSeconds / 3600);
                            $totalMinutes = floor(($totalOvertimeSeconds % 3600) / 60);
                            $totalSecondsRemainder = $totalOvertimeSeconds % 60;
                            echo sprintf('%02d:%02d:%02d', $totalHours, $totalMinutes, $totalSecondsRemainder);
                            ?>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </section>
</div>

<?php include_once '../../components/cashflow_footer.php'; ?>

<script>
    function applyFilters() {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        const staffId = document.getElementById('staffFilter').value; // Changed ID to staffFilter

        // Construct the URL with query parameters
        let url = window.location.pathname + '?';
        if (startDate) {
            url += `start_date=${startDate}&`;
        }
        if (endDate) {
            url += `end_date=${endDate}&`;
        }
        if (staffId !== 'All') { // Use staffId
            url += `staff=${staffId}&`; // Use 'staff' as the URL parameter name
        }
        // Remove trailing '&' if present
        if (url.endsWith('&')) {
            url = url.slice(0, -1);
        }

        window.location.href = url; // Redirect to apply filters
    }

    function printReport() {
        const contentToPrint = document.querySelector('.content').outerHTML;
        const originalBody = document.body.innerHTML;

        const printWindow = window.open('', '_blank');
        printWindow.document.write('<html><head><title>Overtime Report</title>');
        printWindow.document.write('<link rel="stylesheet" href="../../assets/css/style.css" type="text/css" />');
        printWindow.document.write('<style>');
        printWindow.document.write(`
            @media print {
                .top, .row1, .breadcrumb, .add-new-button {
                    display: none !important;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    border: 1px solid #ccc;
                    padding: 8px;
                    text-align: left;
                }
                tfoot td {
                    font-weight: bold;
                }
            }
        `);
        printWindow.document.write('</style>');
        printWindow.document.write('</head><body>');
        printWindow.document.write('<h2 style="text-align: center;">Overtime Report</h2>');
        printWindow.document.write(contentToPrint);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    }
</script>
<style>
    colgroup col:nth-child(1) {
        width: 100px;
    }

    colgroup col:nth-child(2) {
        width: 150px;
    }

    colgroup col:nth-child(3) {
        width: 100px;
    }
</style>