<?php
include_once '../../settings/connection.php'; // Sets up $pdo

try {
  //--- Load all staff for filter dropdown
  $staffStmt = $pdo->query("SELECT id, firstname, lastname FROM staffs ORDER BY firstname");
  $staffs = $staffStmt->fetchAll(PDO::FETCH_ASSOC);

  //--- Build filters from GET params
  $where = [];
  $params = [];

  if (!empty($_GET['start_date'])) {
    $where[] = 't.date >= :start_date';
    $params['start_date'] = $_GET['start_date'];
  }
  if (!empty($_GET['end_date'])) {
    $where[] = 't.date <= :end_date';
    $params['end_date'] = $_GET['end_date'];
  }
  if (!empty($_GET['employee']) && $_GET['employee'] !== 'all') {
    $where[] = 't.staff_id = :employee';
    $params['employee'] = $_GET['employee'];
  }

  //--- Build SQL
  $sql = "
        SELECT
            t.date,
            t.staff_id,
            s.firstname,
            s.lastname,
            t.time_in,
            t.time_out,
            t.note,
            t.type
        FROM timesheet t
        LEFT JOIN staffs s ON t.staff_id = s.id
    ";
  if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
  }
  $sql .= " ORDER BY t.date DESC";

  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $timesheetRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  die("Error fetching timesheet data: " . $e->getMessage());
}
?>
<?php include_once '../../components/header.php'; ?>

<!-- Print script -->
<script>
  function printReport() {
    window.print();
  }
</script>

<div class="main">
  <?php include_once '../../components/common_header.php'; ?>
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="../attendance-report">Attendance</a> | <span>Daily Attendance Report</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px" onclick="printReport()">
          Print Report
        </button>
      </div>
    </div>

    <!-- FILTER FORM -->
    <form method="GET" class="row1">
      <div class="col1">
        <label>Start Date:</label>
        <input type="date" name="start_date" value="<?= htmlspecialchars($_GET['start_date'] ?? '') ?>">
      </div>
      <div class="col1">
        <label>End Date:</label>
        <input type="date" name="end_date" value="<?= htmlspecialchars($_GET['end_date'] ?? '') ?>">
      </div>
      <div class="col1">
        <label>Employee:</label>
        <select name="employee">
          <option value="all">All</option>
          <?php foreach ($staffs as $staff):
            $id = $staff['id'];
            $name = htmlspecialchars($staff['firstname'] . ' ' . $staff['lastname']);
          ?>
            <option value="<?= $id ?>" <?= (($_GET['employee'] ?? '') == $id) ? 'selected' : '' ?>>
              <?= $name ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    </form>

    <!-- TABLE -->
    <div style="overflow:auto; padding:0.7rem; max-height:80vh;">
      <table>
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>Date</th>
            <th>Staff ID</th>
            <th>Employee Name</th>
            <th>Time in</th>
            <th>Time out</th>
            <th>Note</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($timesheetRows): ?>
            <?php foreach ($timesheetRows as $row): ?>
              <tr>
                <td><?= date('d-m-Y', strtotime($row['date'])) ?></td>
                <td><?= htmlspecialchars($row['staff_id']) ?></td>
                <td><?= htmlspecialchars($row['firstname'] . ' ' . $row['lastname']) ?></td>
                <td><?= htmlspecialchars($row['time_in']) ?></td>
                <td><?= htmlspecialchars($row['time_out']) ?></td>
                <td><?= nl2br(htmlspecialchars($row['note'])) ?></td>
                <td><?= htmlspecialchars($row['type'] === 'OT' ? 'Overtime' : 'Normal Time') ?></td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="8">No records found.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </section>
</div>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const filterForm = document.querySelector('form');

    filterForm.querySelectorAll('input, select').forEach(input => {
      input.addEventListener('change', function() {
        filterForm.submit();
      });
    });
  });
</script>
<style>
  colgroup col:nth-child(1) {
    width: 100px;
  }

  colgroup col:nth-child(2) {
    width: 80px;
  }

  colgroup col:nth-child(3) {
    width: 180px;
  }

  colgroup col:nth-child(4) {
    width: 100px;
  }

  colgroup col:nth-child(5) {
    width: 100px;
  }

  colgroup col:nth-child(6) {
    width: 150px;
  }

  colgroup col:nth-child(7) {
    width: 150px;
  }
</style>
<?php include_once '../../components/cashflow_footer.php'; ?>