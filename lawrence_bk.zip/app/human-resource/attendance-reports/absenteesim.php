<?php
include_once '../../components/header.php';
include_once '../../settings/connection.php'; // Your PDO connection file

// Fetch employee list for dropdown
$empStmt = $pdo->query("SELECT id, first_name FROM employees");
$employees = $empStmt->fetchAll(PDO::FETCH_ASSOC);

// Handle filters
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$employee_id = $_GET['employee_id'] ?? '';

// Build base query
$sql = "SELECT lr.start_date as date, lr.description, lr.status, lr.purpose, lr.employee_name
        FROM leave_requests lr
        WHERE 1";
$params = [];

if (!empty($start_date)) {
    $sql .= " AND lr.date >= :start_date";
    $params['start_date'] = $start_date;
}
if (!empty($end_date)) {
    $sql .= " AND lr.date <= :end_date";
    $params['end_date'] = $end_date;
}
if (!empty($employee_id)) {
    $sql .= " AND e.id = :employee_id";
    $params['employee_id'] = $employee_id;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$leave_records = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="main">
  <?php include_once '../../components/common_header.php'; ?>
  <section class="content">
    <form method="GET">
      <div class="top flex">
        <div class="left">
          <div class="breadcrumb">
            <a href="../attendance-report">Attendance</a> | <span>Absenteeism Report</span>
          </div>
        </div>
        <div class="right">
          <button type="button" class="add-new-button" onclick="window.print();" style="border-radius: 15px">Print Report</button>
        </div>
      </div>

      <!-- <div class="row1">
        <div class="col1">
          <label>Start Date:</label>
          <input type="date" name="start_date" value="<?= htmlspecialchars($start_date) ?>" />
        </div>
        <div class="col1">
          <label>End Date:</label>
          <input type="date" name="end_date" value="<?= htmlspecialchars($end_date) ?>">
        </div>
        <div class="col1">
          <label>Employee:</label>
          <select name="employee_id">
            <option value="">All Employees</option>
            <?php foreach ($employees as $emp): ?>
              <option value="<?= $emp['id'] ?>" <?= $emp['id'] == $employee_id ? 'selected' : '' ?>>
                <?= htmlspecialchars($emp['first_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col1">
          <button type="submit">Filter</button>
        </div>
      </div> -->
    </form>

    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table>
        <colgroup>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>Date</th>
            <th>Employee</th>
            <th>Reason</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($leave_records)): ?>
            <?php foreach ($leave_records as $row): ?>
              <tr>
                <td><?= date('d-m-Y', strtotime($row['date'])) ?></td>
                <td><?= htmlspecialchars($row['employee_name']) ?></td>

                <td><?= htmlspecialchars($row['purpose']) ?></td>
                <td><?= htmlspecialchars($row['status']) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="5">No leave records found.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </section>
</div>
<style>
  colgroup col:nth-child(1) {
    width: 100px;
  }

  colgroup col:nth-child(2) {
    width: 150px;
  }

  colgroup col:nth-child(3) {
    width: 100px;
  }

  colgroup col:nth-child(4) {
    width: 100px;
  }

  colgroup col:nth-child(5) {
    width: 100px;
  }
</style>
<?php include_once '../../components/cashflow_footer.php'; ?>
