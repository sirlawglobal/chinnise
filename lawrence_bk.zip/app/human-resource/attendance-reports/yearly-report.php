<?php
include_once '../../components/header.php';
include_once '../../settings/connection.php'; // your PDO connection

$currentYear = isset($_GET['year']) ? $_GET['year'] : date("Y");
$staff_id = 1; // Replace with dynamic ID as needed

// Get employee_name for leave_requests matching
$stmt = $pdo->prepare("SELECT firstname as employee_name FROM staffs WHERE id = ?");
$stmt->execute([$staff_id]);
$employee_name = $stmt->fetchColumn();

// Get available years from timesheet table
$yearStmt = $pdo->query("SELECT DISTINCT YEAR(date) as year FROM timesheet ORDER BY year DESC");
$years = $yearStmt->fetchAll(PDO::FETCH_ASSOC);

// Init
$reportData = [];
$yearlyTotals = ['hours' => 0, 'overtime' => 0, 'leave' => 0];

for ($month = 1; $month <= 12; $month++) {
    // NT hours
    $stmt = $pdo->prepare("
        SELECT TIME_TO_SEC(TIMEDIFF(time_out, time_in))/3600 AS hours
        FROM timesheet
        WHERE staff_id = ? AND type = 'NT' AND MONTH(date) = ? AND YEAR(date) = ?
    ");
    $stmt->execute([$staff_id, $month, $currentYear]);
    $ntTotal = array_sum(array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'hours'));

    // OT hours
    $stmt = $pdo->prepare("
        SELECT TIME_TO_SEC(TIMEDIFF(time_out, time_in))/3600 AS hours
        FROM timesheet
        WHERE staff_id = ? AND type = 'OT' AND MONTH(date) = ? AND YEAR(date) = ?
    ");
    $stmt->execute([$staff_id, $month, $currentYear]);
    $otTotal = array_sum(array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'hours'));

    // Leave days
    $stmt = $pdo->prepare("
        SELECT SUM(duration) as leave_days
        FROM leave_requests
        WHERE employee_name = ? AND MONTH(start_date) = ? AND YEAR(start_date) = ? AND status = 'approved'
    ");
    $stmt->execute([$employee_name, $month, $currentYear]);
    $leaveDays = $stmt->fetchColumn() ?? 0;

    $reportData[] = [
        'month' => date('F', mktime(0, 0, 0, $month, 1)),
        'hours' => round($ntTotal, 2),
        'overtime' => round($otTotal, 2),
        'leave' => (int)$leaveDays,
    ];

    $yearlyTotals['hours'] += $ntTotal;
    $yearlyTotals['overtime'] += $otTotal;
    $yearlyTotals['leave'] += $leaveDays;
}
?>

<div class="main">
  <?php include_once '../../components/common_header.php'; ?>
  <section class="content">
    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="../attendance-report">Attendance</a> | <span>Yearly Report</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px" onclick="window.print()">Print Report</button>
      </div>
    </div>

    <div class="row1">
      <div class="col1">
        <label>Years:</label>
        <select onchange="window.location.href='?year=' + this.value">
          <option value="">All Years</option>
          <?php foreach ($years as $y): ?>
            <option value="<?= $y['year'] ?>" <?= ($y['year'] == $currentYear) ? 'selected' : '' ?>>
              <?= $y['year'] ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table class="leads-table">
        <thead>
          <tr>
            <th>Month</th>
            <th>Total Hours Worked</th>
            <th>Total Overtime</th>
            <th>Total Leave Days</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($reportData as $row): ?>
            <tr>
              <td><?= $row['month'] ?></td>
              <td><?= $row['hours'] ?></td>
              <td><?= $row['overtime'] ?></td>
              <td><?= $row['leave'] ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr>
            <td><strong>Yearly Totals</strong></td>
            <td><?= round($yearlyTotals['hours'], 2) ?></td>
            <td><?= round($yearlyTotals['overtime'], 2) ?></td>
            <td><?= (int)$yearlyTotals['leave'] ?></td>
          </tr>
        </tfoot>
      </table>
    </div>
  </section>
</div>

<?php include_once '../../components/cashflow_footer.php'; ?>
