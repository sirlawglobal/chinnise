<?php include_once '../components/header.php'; ?>


<div class="modal staff-performance" style="display: none;">
  <div class="modal-content" style="width: 90%; max-width: 1200px; position: static; margin: auto;">
    <span class="close">×</span>
    <h2 class="con">Add Performance Appraisal Interview Form</h2>
    <form method="POST" style="width: 100%;" action="../backend/human-resource/performance/add_performance.php">
      <input type="hidden" name="createPerformance" value="Performance">
      <div class="row">
        <div class="col">
          <label class="form-label">Name of Employee*</label>
          <input type="text" name="employee_name" class="form-input" required="">
        </div>
        <div class="col">
          <label class="form-label">Review Period*</label>
          <input type="text" name="review_period" class="form-input" required="">
        </div>
        <div class="col">
          <label class="form-label">Name of Supervisor/Head of Department</label>
          <input type="text" name="supervisor_name" class="form-input" style="width: 100%;">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label class="form-label">Staff ID</label>
          <input type="text" name="staff_id" class="form-input">
        </div>
        <div class="col">
          <label class="form-label">Date*</label>
          <input type="date" name="performance_date" class="form-input" required="">
        </div>
        <div class="col">
          <div class="form-group">
            <label class="form-label">Position of Supervisor/Head of Department</label>
            <input type="text" name="supervisor_position" class="form-input" style="width: 100%;">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p class="performance-note">Please provide a critical assessment of the performance of the employee
            within the review period using the following rating scale. Provide examples where applicable. Please
            use a separate sheet if required.</p>
        </div>
        <div class="col" style="flex: 1;">
          <table>
            <thead>
              <tr>
                <th class="text-center performance-th">E</th>
                <th class="text-center performance-th">VG</th>
                <th class="text-center performance-th">G</th>
                <th class="text-center performance-th">NI</th>
                <th class="text-center performance-th">P</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="text-center performance-td">Excellent</td>
                <td class="text-center performance-td">Very Good</td>
                <td class="text-center performance-td">Good</td>
                <td class="text-center performance-td"> Needs Improvement</td>
                <td class="text-center performance-td"> Poor</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="col">
        <div class="col-md-12 ">
          <p class="performance-title">B. ASSESSMENT OF GOALS/OBJECTIVES SET DURING THE REVIEW PERIOD</p>
          <div style="overflow-x: scroll;">
            <table class="table-bordered table-width mt-3">
              <thead>
                <tr>
                  <th style="width: 400px;" class="performance-th"><b>Criteria</b></th>
                  <th class="performance-th text-center"><b>P(0)</b></th>
                  <th class="performance-th text-center"><b>NI(3)</b></th>
                  <th class="performance-th text-center"><b>G(6)</b></th>
                  <th class="performance-th text-center"><b>VG(9)</b></th>
                  <th class="performance-th text-center"><b>E(12)</b></th>
                  <th class="performance-th text-center"><b>Score</b></th>
                  <th class="performance-th text-center"><b>Comments</b></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Demonstrated Knowledge of duties &amp; Quality of Work
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="P(0)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="NI(3)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="G(6)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="VG(9)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="E(12)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" id="demonstrated_knowledge_score" name="demonstrated_knowledge_score"
                      style="width: 50px;border: none;outline: none;" onkeyup="demonstratedScore(this)"
                      class="form-input">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="demonstrated_knowledge_comment"
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Timeliness of Delivery
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="P(0)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="NI(3)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="G(6)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="VG(9)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="E(12)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" id="timeliness_of_delivery_score" name="timeliness_of_delivery_score"
                      onkeyup="timelinesScore(this)" style="width: 50px;border: none;outline: none;" class="form-input">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="timeliness_of_delivery_comment"
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Impact of Achievement
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="P(0)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="NI(3)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="G(6)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="VG(9)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="E(12)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" id="impact_of_investment_score" name="impact_of_investment_score"
                      onkeyup="impactInvestment(this)" style="width: 50px;border: none;outline: none;"
                      class="form-input">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="impact_of_investment_comment"
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Overall Achievement of Goals/Objectives
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="P(0)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="NI(3)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="G(6)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="VG(9)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="E(12)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" id="achievement_of_goals_score" name="achievement_of_goals_score"
                      onkeyup="achievementGoal(this)" style="width: 50px;border: none;outline: none;"
                      class="form-input">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="achievement_of_goals_comment"
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Going beyond the call of Duty
                  </td>
                  <td class="performance-td text-center" colspan="5">
                    Extra (6, 9, or 12) bonus points to be earned for going beyond the call of duty
                  </td>
                  <td class=" performance-td text-center">
                    <input type="text" id="bonus_point" name="bonus_point_score" onkeyup="bonusPoint(this)"
                      style="width: 50px;border: none;outline: none;" class="form-input">
                  </td>
                  <td class=" performance-td text-center">
                    <input type="text" name="bonus_point_comment" style="width: 180px;border: none;outline: none;"
                      class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td text-center"></td>
                  <td class="performance-td" style="text-align: right;" colspan="5">
                    <input type="hidden" id="total_score_input" name="total_score">
                    Total Score
                  </td>
                  <td class="performance-td text-center" style="text-align: center;">
                    <input type="hidden" id="total_score_input" name="total_score"><span class="total-score">0</span>
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="achievement_of_goals_comment" disabled=""
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="col-md-12 mt-3">
          <p class="performance-title">C. Recommendations by Reviewer</p>
          <hr>
          <textarea name="recommendation_by_reviewer" class="form-input" placeholder="Enter your recommendations"
            style="height: 80px"></textarea>

        </div>
        <div class="col-md-12 mt-3">
          <p class="performance-title">D. Comments by Employee</p>
          <hr>
          <textarea name="employee_comments" class="form-input" placeholder="Enter your comments here"
            style="height: 80px"></textarea>
        </div>
        <div class="col-md-12 mt-3">
          <p class="performance-title">E. Development Plan</p>
          <table class="table-bordered mt-3" style="width: 100%;">
            <thead style="width: 100%;">
              <tr>
                <th class="performance-th"><b>Areas for Improvement</b></th>
                <th class="performance-th"><b>Expected Outcome(s)</b></th>
                <th class="performance-th"><b>Supervisor's Name</b></th>
                <th class="performance-th"><b>Start Date</b></th>
                <th class="performance-th"><b>End Date</b></th>
                <th class="d-flex performance-th pt-2">
                  <img onclick="addRecommendedAreas()" src="../../assets/images/add.png" alt="">
                </th>
              </tr>
            </thead>
            <tbody id="recommendation-container"></tbody>
          </table>
        </div>
        <div class="col-md-12 mt-3">
          <p class="performance-title">F. KEY GOALS FOR NEXT REVIEW PERIOD </p>
          <table class="table-bordered mt-3" style="width: 100%;">
            <thead style="width: 100%;">
              <tr>
                <th class="performance-th"><b>Goal (s) Set and Agreed on with Employee</b></th>
                <th class="performance-th"><b>Proposed Completion Period</b></th>
                <th class="performance-th"><b>
                    <img onclick="addKeyGoals()" src="../../assets/images/add.png" alt="">
                  </b></th>
              </tr>
            </thead>

            <tbody id="key-goals-container"></tbody>
          </table>
        </div>

      </div>
      <button type="submit" class="save-btn">Save</button>
    </form>
  </div>
</div>

<div class="modal1 staff-performance">
  <div class="modal-content" style="width: 90%; max-width: 1200px; position: static; margin: auto;">
    <span class="close1">&times;</span>
    <h2 class="con">View Performance Appraisal Interview Form</h2>
    <form method="POST" style="width: 100%;">
      <input type="hidden" name="createPerformance" value="Performance">
      <div class="row">
        <div class="col">
          <label class="form-label">Name of Employee*</label>
          <input type="text" name="employee_name" class="form-input" required="">
        </div>
        <div class="col">
          <label class="form-label">Review Period*</label>
          <input type="text" name="review_period" class="form-input" required="">
        </div>
        <div class="col">
          <label class="form-label">Name of Supervisor/Head of Department</label>
          <input type="text" name="supervisor_name" class="form-input" style="width: 100%;">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label class="form-label">Staff ID</label>
          <input type="text" name="staff_id" class="form-input">
        </div>
        <div class="col">
          <label class="form-label">Date*</label>
          <input type="date" name="performance_date" class="form-input" required="">
        </div>
        <div class="col">
          <div class="form-group">
            <label class="form-label">Position of Supervisor/Head of Department</label>
            <input type="text" name="supervisor_position" class="form-input" style="width: 100%;">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p class="performance-note">Please provide a critical assessment of the performance of the employee
            within the review period using the following rating scale. Provide examples where applicable. Please
            use a separate sheet if required.</p>
        </div>
        <div class="col" style="flex: 1;">
          <table>
            <thead>
              <tr>
                <th class="text-center performance-th">E</th>
                <th class="text-center performance-th">VG</th>
                <th class="text-center performance-th">G</th>
                <th class="text-center performance-th">NI</th>
                <th class="text-center performance-th">P</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="text-center performance-td">Excellent</td>
                <td class="text-center performance-td">Very Good</td>
                <td class="text-center performance-td">Good</td>
                <td class="text-center performance-td"> Needs Improvement</td>
                <td class="text-center performance-td"> Poor</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="col">
        <div class="col-md-12 ">
          <p class="performance-title">B. ASSESSMENT OF GOALS/OBJECTIVES SET DURING THE REVIEW PERIOD</p>
          <div style="overflow-x: scroll;">
            <table class="table-bordered table-width mt-3">
              <thead>
                <tr>
                  <th style="width: 400px;" class="performance-th"><b>Criteria</b></th>
                  <th class="performance-th text-center"><b>P(0)</b></th>
                  <th class="performance-th text-center"><b>NI(3)</b></th>
                  <th class="performance-th text-center"><b>G(6)</b></th>
                  <th class="performance-th text-center"><b>VG(9)</b></th>
                  <th class="performance-th text-center"><b>E(12)</b></th>
                  <th class="performance-th text-center"><b>Score</b></th>
                  <th class="performance-th text-center"><b>Comments</b></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Demonstrated Knowledge of duties &amp; Quality of Work
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="P(0)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="NI(3)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="G(6)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="VG(9)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="E(12)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" id="demonstrated_knowledge_score" name="demonstrated_knowledge_score"
                      style="width: 50px;border: none;outline: none;" onkeyup="demonstratedScore(this)"
                      class="form-input">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="demonstrated_knowledge_comment"
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Timeliness of Delivery
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="P(0)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="NI(3)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="G(6)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="VG(9)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="E(12)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" id="timeliness_of_delivery_score" name="timeliness_of_delivery_score"
                      onkeyup="timelinesScore(this)" style="width: 50px;border: none;outline: none;" class="form-input">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="timeliness_of_delivery_comment"
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Impact of Achievement
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="P(0)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="NI(3)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="G(6)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="VG(9)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="E(12)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" id="impact_of_investment_score" name="impact_of_investment_score"
                      onkeyup="impactInvestment(this)" style="width: 50px;border: none;outline: none;"
                      class="form-input">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="impact_of_investment_comment"
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Overall Achievement of Goals/Objectives
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="P(0)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="NI(3)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="G(6)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="VG(9)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="E(12)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" id="achievement_of_goals_score" name="achievement_of_goals_score"
                      onkeyup="achievementGoal(this)" style="width: 50px;border: none;outline: none;"
                      class="form-input">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="achievement_of_goals_comment"
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Going beyond the call of Duty
                  </td>
                  <td class="performance-td text-center" colspan="5">
                    Extra (6, 9, or 12) bonus points to be earned for going beyond the call of duty
                  </td>
                  <td class=" performance-td text-center">
                    <input type="text" id="bonus_point" name="bonus_point_score" onkeyup="bonusPoint(this)"
                      style="width: 50px;border: none;outline: none;" class="form-input">
                  </td>
                  <td class=" performance-td text-center">
                    <input type="text" name="bonus_point_comment" style="width: 180px;border: none;outline: none;"
                      class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td text-center"></td>
                  <td class="performance-td" style="text-align: right;" colspan="5">
                    <input type="hidden" id="total_score_input" name="total_score">
                    Total Score
                  </td>
                  <td class="performance-td text-center" style="text-align: center;">
                    <input type="hidden" id="total_score_input" name="total_score"><span class="total-score">0</span>
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="achievement_of_goals_comment" disabled=""
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="col-md-12 mt-3">
          <p class="performance-title">C. Recommendations by Reviewer</p>
          <hr>
          <textarea name="recommendation_by_reviewer" class="form-input" placeholder="Enter your recommendations"
            style="height: 80px"></textarea>

        </div>
        <div class="col-md-12 mt-3">
          <p class="performance-title">D. Comments by Employee</p>
          <hr>
          <textarea name="employee_comments" class="form-input" placeholder="Enter your comments here"
            style="height: 80px"></textarea>
        </div>
        <div class="col-md-12 mt-3">
          <p class="performance-title">E. Development Plan</p>
          <table class="table-bordered mt-3" style="width: 100%;">
            <thead style="width: 100%;">
              <tr>
                <th class="performance-th"><b>Areas for Improvement</b></th>
                <th class="performance-th"><b>Expected Outcome(s)</b></th>
                <th class="performance-th"><b>Supervisor's Name</b></th>
                <th class="performance-th"><b>Start Date</b></th>
                <th class="performance-th"><b>End Date</b></th>
                <th class="d-flex performance-th pt-2">
                  <img onclick="addRecommendedAreas()" src="../../assets/images/add.png" alt="">
                </th>
              </tr>
            </thead>
            <tbody id="recommendation-container"></tbody>
          </table>
        </div>
        <div class="col-md-12 mt-3">
          <p class="performance-title">F. KEY GOALS FOR NEXT REVIEW PERIOD </p>
          <table class="table-bordered mt-3" style="width: 100%;">
            <thead style="width: 100%;">
              <tr>
                <th class="performance-th"><b>Goal (s) Set and Agreed on with Employee</b></th>
                <th class="performance-th"><b>Proposed Completion Period</b></th>
                <th class="performance-th"><b>
                    <img onclick="addKeyGoals()" src="../../assets/images/add.png" alt="">
                  </b></th>
              </tr>
            </thead>

            <tbody id="key-goals-container"></tbody>
          </table>
        </div>

      </div>
      <button type="submit" class="save-btn">Save</button>
    </form>
  </div>
</div>
<div class="modal2 staff-performance" id="edit">
  <div class="modal-content" style="width: 90%; max-width: 1200px; position: static; margin: auto;">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Performance Appraisal Interview Form</h2>
    <form method="POST" style="width: 100%;">
      <input type="hidden" name="createPerformance" value="Performance">
      <div class="row">
        <div class="col">
          <label class="form-label">Name of Employee*</label>
          <input type="text" name="employee_name" class="form-input" required="">
        </div>
        <div class="col">
          <label class="form-label">Review Period*</label>
          <input type="text" name="review_period" class="form-input" required="">
        </div>
        <div class="col">
          <label class="form-label">Name of Supervisor/Head of Department</label>
          <input type="text" name="supervisor_name" class="form-input" style="width: 100%;">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label class="form-label">Staff ID</label>
          <input type="text" name="staff_id" class="form-input">
        </div>
        <div class="col">
          <label class="form-label">Date*</label>
          <input type="date" name="performance_date" class="form-input" required="">
        </div>
        <div class="col">
          <div class="form-group">
            <label class="form-label">Position of Supervisor/Head of Department</label>
            <input type="text" name="supervisor_position" class="form-input" style="width: 100%;">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p class="performance-note">Please provide a critical assessment of the performance of the employee
            within the review period using the following rating scale. Provide examples where applicable. Please
            use a separate sheet if required.</p>
        </div>
        <div class="col" style="flex: 1;">
          <table>
            <thead>
              <tr>
                <th class="text-center performance-th">E</th>
                <th class="text-center performance-th">VG</th>
                <th class="text-center performance-th">G</th>
                <th class="text-center performance-th">NI</th>
                <th class="text-center performance-th">P</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="text-center performance-td">Excellent</td>
                <td class="text-center performance-td">Very Good</td>
                <td class="text-center performance-td">Good</td>
                <td class="text-center performance-td"> Needs Improvement</td>
                <td class="text-center performance-td"> Poor</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="col">
        <div class="col-md-12 ">
          <p class="performance-title">B. ASSESSMENT OF GOALS/OBJECTIVES SET DURING THE REVIEW PERIOD</p>
          <div style="overflow-x: scroll;">
            <table class="table-bordered table-width mt-3">
              <thead>
                <tr>
                  <th style="width: 400px;" class="performance-th"><b>Criteria</b></th>
                  <th class="performance-th text-center"><b>P(0)</b></th>
                  <th class="performance-th text-center"><b>NI(3)</b></th>
                  <th class="performance-th text-center"><b>G(6)</b></th>
                  <th class="performance-th text-center"><b>VG(9)</b></th>
                  <th class="performance-th text-center"><b>E(12)</b></th>
                  <th class="performance-th text-center"><b>Score</b></th>
                  <th class="performance-th text-center"><b>Comments</b></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Demonstrated Knowledge of duties &amp; Quality of Work
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="P(0)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="NI(3)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="G(6)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="VG(9)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="demonstrated_knowledge" value="E(12)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" id="demonstrated_knowledge_score" name="demonstrated_knowledge_score"
                      style="width: 50px;border: none;outline: none;" onkeyup="demonstratedScore(this)"
                      class="form-input">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="demonstrated_knowledge_comment"
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Timeliness of Delivery
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="P(0)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="NI(3)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="G(6)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="VG(9)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="timeliness_of_delivery" value="E(12)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" id="timeliness_of_delivery_score" name="timeliness_of_delivery_score"
                      onkeyup="timelinesScore(this)" style="width: 50px;border: none;outline: none;" class="form-input">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="timeliness_of_delivery_comment"
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Impact of Achievement
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="P(0)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="NI(3)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="G(6)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="VG(9)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="impact_of_investment" value="E(12)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" id="impact_of_investment_score" name="impact_of_investment_score"
                      onkeyup="impactInvestment(this)" style="width: 50px;border: none;outline: none;"
                      class="form-input">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="impact_of_investment_comment"
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Overall Achievement of Goals/Objectives
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="P(0)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="NI(3)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="G(6)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="VG(9)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="radio" name="achievement_of_goals" value="E(12)">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" id="achievement_of_goals_score" name="achievement_of_goals_score"
                      onkeyup="achievementGoal(this)" style="width: 50px;border: none;outline: none;"
                      class="form-input">
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="achievement_of_goals_comment"
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td" style="text-align: left;">
                    Going beyond the call of Duty
                  </td>
                  <td class="performance-td text-center" colspan="5">
                    Extra (6, 9, or 12) bonus points to be earned for going beyond the call of duty
                  </td>
                  <td class=" performance-td text-center">
                    <input type="text" id="bonus_point" name="bonus_point_score" onkeyup="bonusPoint(this)"
                      style="width: 50px;border: none;outline: none;" class="form-input">
                  </td>
                  <td class=" performance-td text-center">
                    <input type="text" name="bonus_point_comment" style="width: 180px;border: none;outline: none;"
                      class="form-input">
                  </td>
                </tr>
                <tr>
                  <td class="performance-td text-center"></td>
                  <td class="performance-td" style="text-align: right;" colspan="5">
                    <input type="hidden" id="total_score_input" name="total_score">
                    Total Score
                  </td>
                  <td class="performance-td text-center" style="text-align: center;">
                    <input type="hidden" id="total_score_input" name="total_score"><span class="total-score">0</span>
                  </td>
                  <td class="performance-td text-center">
                    <input type="text" name="achievement_of_goals_comment" disabled=""
                      style="width: 180px;border: none;outline: none;" class="form-input">
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="col-md-12 mt-3">
          <p class="performance-title">C. Recommendations by Reviewer</p>
          <hr>
          <textarea name="recommendation_by_reviewer" class="form-input" placeholder="Enter your recommendations"
            style="height: 80px"></textarea>

        </div>
        <div class="col-md-12 mt-3">
          <p class="performance-title">D. Comments by Employee</p>
          <hr>
          <textarea name="employee_comments" class="form-input" placeholder="Enter your comments here"
            style="height: 80px"></textarea>
        </div>
        <div class="col-md-12 mt-3">
          <p class="performance-title">E. Development Plan</p>
          <table class="table-bordered mt-3" style="width: 100%;">
            <thead style="width: 100%;">
              <tr>
                <th class="performance-th"><b>Areas for Improvement</b></th>
                <th class="performance-th"><b>Expected Outcome(s)</b></th>
                <th class="performance-th"><b>Supervisor's Name</b></th>
                <th class="performance-th"><b>Start Date</b></th>
                <th class="performance-th"><b>End Date</b></th>
                <th class="d-flex performance-th pt-2">
                  <img onclick="addRecommendedAreas()" src="../../assets/images/add.png" alt="">
                </th>
              </tr>
            </thead>
            <tbody id="recommendation-container"></tbody>
          </table>
        </div>
        <div class="col-md-12 mt-3">
          <p class="performance-title">F. KEY GOALS FOR NEXT REVIEW PERIOD </p>
          <table class="table-bordered mt-3" style="width: 100%;">
            <thead style="width: 100%;">
              <tr>
                <th class="performance-th"><b>Goal (s) Set and Agreed on with Employee</b></th>
                <th class="performance-th"><b>Proposed Completion Period</b></th>
                <th class="performance-th"><b>
                    <img onclick="addKeyGoals()" src="../../assets/images/add.png" alt="">
                  </b></th>
              </tr>
            </thead>

            <tbody id="key-goals-container"></tbody>
          </table>
        </div>

      </div>
      <button type="submit" class="save-btn">Save</button>
    </form>
  </div>
</div>

<div class="main">
  <?php include_once '../components/common_header.php'; ?>


  <!-- Your page content goes here -->
  <section class="content">

    <div class="top flex">
      <div class="left">
        <div class="breadcrumb">
          <a href="./index.php">Human Resources</a> | <span>Staff Performance</span>
        </div>
      </div>
      <div class="right">
        <button class="add-new-button" style="border-radius: 15px">
          Add Staff Performance
        </button>
      </div>
    </div>
    <div class="row1">
      <div class="col1">
        <label>Filter by Name</label>
        <input type="text" placeholder="Enter company name" />
      </div>
      <div class="col1">
        <label>Filter by Month</label>
        <select>
          <option>Select Month</option>
          <option value="January">January</option>
          <option value="Febuary">Febuary</option>
          <option value="March">March</option>
          <option value="April">April</option>
          <option value="May">May</option>
          <option value="June">June</option>
          <option value="July">July</option>
          <option value="August">August</option>
          <option value="September">September</option>
          <option value="October">October</option>
          <option value="November">November</option>
          <option value="December">December</option>
        </select>
      </div>
      <div class="col1">
        <label>Filter by Year</label>
        <select>
          <option>Select Year</option>
          <!-- DYNAMIC  -->
        </select>
      </div>
      <div class="col1">
        <label>Filter by Type</label>
        <select>
          <option>Select Title</option>
          <option>Mr.</option>
          <option>Mrs.</option>
          <option>Dr.</option>
        </select>
      </div>
    </div>
    <?php
    require_once '../settings/connection.php';

    $sql = "SELECT staff_id, employee_name, supervisor_position, review_period, performance_date 
        FROM performance_appraisals";
    $stmt = $pdo->query($sql);
    $rows = $stmt->fetchAll();
    ?>
    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table class="leads-table">
        <thead>
          <tr>
            <th>Staff ID</th>
            <th>Name</th>
            <th>Position</th>
            <th>Status</th>
            <th>Joined Date</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td><?= htmlspecialchars($row['staff_id']) ?></td>
              <td><?= htmlspecialchars($row['employee_name']) ?></td>
              <td><?= htmlspecialchars($row['supervisor_position']) ?></td>
              <td>Full staff</td>
              <td><?= htmlspecialchars($row['performance_date']) ?></td>
              <td>
                <i class="view-icon" data-id="<?= $row['id'] ?>">
                  <img src="../assets/eye-open.png" />
                </i>
              </td>

              <td><i class="view-icon"><img src="../assets/eye-open.png" /></i></td>
              <td><i class="edit-icon"><img src="../assets/edit.svg" /></i></td>
              <td><i class="delete-icon"><img src="../assets/Delete.svg" /></i></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

  </section>
</div>
<script>
  document.querySelectorAll('.view-icon').forEach(icon => {
    icon.addEventListener('click', function () {
      const id = this.getAttribute('data-id');
      fetch(`../backend/human-resource/performance/get-performance.php?id=${id}`)
        .then(res => res.json())
        .then(data => {
          const escapeCSS = (value) => CSS.escape(value);

          // Populate modal fields
          document.querySelector('input[name="employee_name"]').value = data.employee_name;
          document.querySelector('input[name="review_period"]').value = data.review_period;
          document.querySelector('input[name="supervisor_name"]').value = data.supervisor_name;
          document.querySelector('input[name="staff_id"]').value = data.staff_id;
          document.querySelector('input[name="performance_date"]').value = data.performance_date;
          document.querySelector('input[name="supervisor_position"]').value = data.supervisor_position;

          // Performance fields (safe selectors)
          document.querySelector(`input[name="demonstrated_knowledge"][value="${escapeCSS(data.demonstrated_knowledge)}"]`)?.checked = true;
          document.querySelector('input[name="demonstrated_knowledge_score"]').value = data.demonstrated_knowledge_score;
          document.querySelector('input[name="demonstrated_knowledge_comment"]').value = data.demonstrated_knowledge_comment;

          document.querySelector(`input[name="timeliness_of_delivery"][value="${escapeCSS(data.timeliness_of_delivery)}"]`)?.checked = true;
          document.querySelector('input[name="timeliness_of_delivery_score"]').value = data.timeliness_of_delivery_score;
          document.querySelector('input[name="timeliness_of_delivery_comment"]').value = data.timeliness_of_delivery_comment;

          document.querySelector(`input[name="impact_of_investment"][value="${escapeCSS(data.impact_of_investment)}"]`)?.checked = true;
          document.querySelector('input[name="impact_of_investment_score"]').value = data.impact_of_investment_score;
          document.querySelector('input[name="impact_of_investment_comment"]').value = data.impact_of_investment_comment;

          document.querySelector(`input[name="achievement_of_goals"][value="${escapeCSS(data.achievement_of_goals)}"]`)?.checked = true;
          document.querySelector('input[name="achievement_of_goals_score"]').value = data.achievement_of_goals_score;
          document.querySelector('input[name="achievement_of_goals_comment"]').value = data.achievement_of_goals_comment;

          document.querySelector('input[name="bonus_point_score"]').value = data.bonus_point_score;
          document.querySelector('input[name="bonus_point_comment"]').value = data.bonus_point_comment;
          document.querySelector('.total-score').innerText = data.total_score;

          document.querySelector('textarea[name="recommendation_by_reviewer"]').value = data.recommendation_by_reviewer;
          document.querySelector('textarea[name="employee_comments"]').value = data.employee_comments;

          // Show modal
          document.querySelector('.modal1.staff-performance').style.display = 'block';
        });
    });
  });
</script>


<?php include_once '../components/cashflow_footer.php'; ?>