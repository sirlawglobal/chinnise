<?php include_once '../components/header.php'; ?>
<div class="main">
  <?php include_once '../components/common_header.php'; ?>

  <!-- Your page content goes here -->
  <section class="content">
    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Report - Daily Attendance</h3>
          <button class="add-new-button" onclick="location.href='./attendance-reports/daily-attendance-report.php'">
            View Report
          </button>
        </div>
      </div>
    </div>

    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Report - Monthly Attendance</h3>
          <button onclick="location.href='./attendance-reports/summary.php'" class="add-new-button">
            View Report
          </button>
        </div>
      </div>
    </div>

    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Report - Employee Absence</h3>
          <button onclick="location.href='./attendance-reports/absenteesim.php'" class="add-new-button">
            View Report
          </button>
        </div>
      </div>
    </div>

    <!-- <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Punctuality Report</h3>
          <button onclick="location.href='./attendance-reports/punctuality.php'" class="add-new-button">
            View Report
          </button>
        </div>
      </div>
    </div> -->

    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Report - Employee Overtime</h3>
          <button onclick="location.href='./attendance-reports/overtime.php'" class="add-new-button">
            View Report
          </button>
        </div>
      </div>
    </div>

    <!-- <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Leave Report</h3>
          <button onclick="location.href='./attendance-reports/leave.php'" class="add-new-button">
            View Report
          </button>
        </div>
      </div>
    </div>

    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Yearly Attendance Report</h3>
          <button onclick="location.href='./attendance-reports/yearly-report.php'" class="add-new-button">
            View Report
          </button>
        </div>
      </div>
    </div>

    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Holiday and Special Events Report</h3>
          <button onclick="location.href='./attendance-reports/hoilday.php'" class="add-new-button">
            View Report
          </button>
        </div>
      </div>
    </div> -->
  </section>
</div>

<?php include_once '../components/common_footer.php'; ?>
