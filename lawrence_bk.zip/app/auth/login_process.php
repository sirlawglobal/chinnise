<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

include_once '../settings/connection.php'; // This sets up $pdo

// Check if POST data exists
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please enter both email and password.';
    } else {
        try {
            // Prepare statement to fetch user by email
            $stmt = $pdo->prepare('SELECT * FROM staffs WHERE email = ? LIMIT 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // Password matches, create session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['firstname'] = $user['firstname'];
                $_SESSION['surname'] = $user['surname'];
                $_SESSION['staff_id'] = $user['staff_id'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['access'] = $user['access'];

                // Redirect to dashboard or home page
                header('Location: ../');
                exit;
            } else {
                $error = "Invalid email or password.";
            }
        } catch (PDOException $e) {
            // Handle DB error
            $error = "Database error: " . $e->getMessage();
        }
    }
} else {
    $error = "Invalid request.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Login Error</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 2rem;
            background: #f9f9f9;
        }

        .error {
            color: red;
        }

        a {
            text-decoration: none;
            color: blue;
        }
    </style>
</head>

<body>
    <h1>Login Failed</h1>
    <p class="error"><?= htmlspecialchars($error) ?></p>
    <p><a href="../auth/login.php">Go back to login page</a></p>
</body>

</html>