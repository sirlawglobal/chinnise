<!-- <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>CRM128 Login</title>
  <link rel="stylesheet" href="login.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
  <div class="container">
    <div class="left-panel">
      <h1><span class="blue">CRM</span><span class="green">128</span></h1>
      <p>
        Collect more leads, manage your projects and staff,<br>
        keep record of your finances, all in one place with CRM128.
      </p>
      <img src="../assets/animation.gif" alt="CRM UI Illustration"/>
    </div>
    <div class="right-panel">
      <form class="login-form" method="post" action="login_process.php">

        <h2>Log in</h2>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="sample@mail.com" />

        <label for="password">Password</label>
        <div class="password-container">
          <input type="password" id="password" name="password" placeholder="Enter password" />
          <span class="eye" id="togglePassword">
            <i class="fas fa-eye"></i>
          </span>
        </div>

        <button type="submit">Login</button>
      </form>
    </div>
  </div>
  <footer>
    <p>© Copyright 2025 <span class="blue">CRM</span><span class="green">128</span></p>
    <p><a href="#">Built by Hans Technology</a></p>
  </footer>

  <script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#password');
    const eyeIcon = document.querySelector('#togglePassword i'); // Select the <i> tag inside the span

    togglePassword.addEventListener('click', function () {
      // Toggle the type attribute of the password input
      const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
      password.setAttribute('type', type);

      // Toggle the Font Awesome icon classes
      if (type === 'password') {
        eyeIcon.classList.remove('fa-eye-slash'); // Remove closed eye
        eyeIcon.classList.add('fa-eye');        // Add open eye
      } else {
        eyeIcon.classList.remove('fa-eye');     // Remove open eye
        eyeIcon.classList.add('fa-eye-slash');  // Add closed eye
      }
    });
  </script>
</body>
</html> -->









<!-- <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>CRM128 Login</title>
  <link rel="stylesheet" href="login.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
  <div class="container">
    <div class="left-panel">
      <h1><span class="blue">CRM</span><span class="green">128</span></h1>
      <p>
        Collect more leads, manage your projects and staff,<br>
        keep record of your finances, all in one place with CRM128.
      </p>
      <img src="../assets/animation.gif" alt="CRM UI Illustration"/>
    </div>
    <div class="right-panel">
      <form class="login-form" method="post" action="login_process.php">

        <h2>Log in</h2>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="sample@mail.com" />

        <label for="password">Password</label>
        <div class="password-container">
          <input type="password" id="password" name="password" placeholder="Enter password" />
          <span class="eye" id="togglePassword">
            <i class="fas fa-eye"></i>
          </span>
        </div>

        <button type="submit">Login</button>
      </form>
    </div>
  </div>
  <footer>
    <p>© Copyright 2025 <span class="blue">CRM</span><span class="green">128</span></p>
    <p><a href="#">Built by Hans Technology</a></p>
  </footer>

  <script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#password');
    const eyeIcon = document.querySelector('#togglePassword i'); // Select the <i> tag inside the span

    togglePassword.addEventListener('click', function () {
      // Toggle the type attribute of the password input
      const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
      password.setAttribute('type', type);

      // Toggle the Font Awesome icon classes
      if (type === 'password') {
        eyeIcon.classList.remove('fa-eye-slash'); // Remove closed eye
        eyeIcon.classList.add('fa-eye');        // Add open eye
      } else {
        eyeIcon.classList.remove('fa-eye');     // Remove open eye
        eyeIcon.classList.add('fa-eye-slash');  // Add closed eye
      }
    });
  </script>
</body>
</html> -->









<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login</title>
   <link rel="stylesheet" href="login.css"/>
    <link href="https://api.fontshare.com/v2/css?f[]=clash-grotesk@400&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
      integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <style>
      .error {
        background: #F2DEDE;
        color: #A94442;
        padding: 10px;
        width: 95%;
        border-radius: 5px;
      }
    </style>
  </head>

  <body>
    <div class="container">
      <img class="pic1" src="./assets/icons/vector-3.svg" alt="" />
      <div class="crm_header">
        <h3 class="crm"><span>CRM</span><span class="span">128</span></h3>
        <p style="margin-top: 50px; font-size:1.2rem;padding-top:20px; width:100%">
          Collect more leads, manage your projects and staff, keep record of
          your finances, all in one place with CRM128. <br />
          <img class="animation" src="../assets/animation.gif" alt="" />
        </p>
      </div>
      <div class="form-div">

        <div class="form-div1" style="font-size: 36px; color: red">
          Log in
        </div>

        <form class="form" method="POST" action="login_process.php" id="login-form">
          <label for="">Email
            <input class="input-field" type="email" name="email" id="email" placeholder="sample@mail.com" />
          </label>
          <label class="password" for="">Password
            <input class="input-field" type="password" id="password" name="password" placeholder="Enter password" />
            <i class="fa fa-eye" id="password-eye" aria-hidden="true"></i>
          </label>

          <div class="mb-5 w-100 mt-1">
            <div style="text-align: center;">
              <button class="btn btn-primary" type="submit" name="submit">Login</button>
            </div>
          </div>
        </form>
      </div>
    </div>

    <footer>
      <div class="copyright-2023-crm128-parent justify-content-between">
        <div class="copyright-2023-crm128-container">
          <span style="color: #003e9c">© Copyright <?php echo date('Y'); ?> CRM<span
              style="color: #57bc4a">128</span></span>

        </div>
        <div style="color: #003e9c">Built by Hans Technology</div>
      </div>
    </footer>

    <script src="./assets/js/main.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(document).ready(function () {
        $("#password-eye").click(function () {
          const passwordInput = $("#password");
          const type =
            passwordInput.attr("type") === "password" ? "text" : "password";
          passwordInput.attr("type", type);
        });
      });
    </script>
  </body>

</html>