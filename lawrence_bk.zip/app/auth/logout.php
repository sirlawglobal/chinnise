<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Unset all session variables
$_SESSION = [];

// Destroy the session
session_destroy();

// Redirect to login page
header("Location: ../auth/login.php");
exit;
