<script>
    const sidebar = document.getElementById("sidebar");
    const overlay = document.getElementById("overlay");
    const btnOpen = document.getElementById("openSidebar");

    function openNav() {
        sidebar.classList.add("active");
        overlay.classList.add("active");
    }

    function closeNav() {
        sidebar.classList.remove("active");
        overlay.classList.remove("active");
    }
    const btn = document.querySelector(".add-new-button");
    const btn1 = document.querySelectorAll(".view-icon");
    const btn2 = document.querySelectorAll(".edit-icon");
    const modal = document.querySelector(".modal");
    const modal1 = document.querySelector(".modal1");
    const modal2 = document.querySelector(".modal2");
    const closeBtn = document.querySelector(".close");
    const closeBtn1 = document.querySelector(".close1");
    const closeBtn2 = document.querySelector(".close2");
    btn == null ? () => {} :
        btn.addEventListener("click", () => {
            console.log("Add new button clicked");
            modal.style.display = "block";
        });

    btn1 == null ? () => {} :
        btn1.forEach((btns) => {
            btns.addEventListener("click", () => {
                console.log("View button clicked");
                modal1.style.display = "block";
            });
        });


    btn2 == null ? () => {} : btn2.forEach((btns) => {
        btns.addEventListener("click", () => {
            console.log("Edit button clicked");

            modal2.style.display = "block";
        });
    });

    closeBtn == null ? () => {} : closeBtn.addEventListener("click", () => {
        modal.style.display = "none";
    });


    closeBtn1 == null ? () => {} : closeBtn1.addEventListener("click", () => {
        modal1.style.display = "none";
    });
    closeBtn2 == null ? () => {} : closeBtn2.addEventListener("click", () => {
        modal2.style.display = "none";
    });
    window.addEventListener("click", (event) => {
        if (event.target == modal) {
            modal.style.display = "none";
        } else if (event.target == modal1) {
            modal1.style.display = "none";
        } else if (event.target == modal2) {
            modal2.style.display = "none";
        }
    });
    btnOpen.addEventListener("click", openNav); // click anywhere on overlay -> close
    overlay.addEventListener("click", closeNav);

    // // NEW: dropdown toggles
    // document.querySelectorAll(".has-dropdown > .dropbtn").forEach((btn) => {
    //     btn.addEventListener("click", () => {
    //         const li = btn.parentElement;
    //         li.classList.toggle("open");
    //     });
    // });

    // NEW: dropdown toggles for nested dropdowns

    document.addEventListener("DOMContentLoaded", () => { // Ensure DOM is fully loaded
        // Select all dropdown buttons that are direct children of an element with 'has-dropdown'
        document.querySelectorAll(".has-dropdown > .dropbtn").forEach((btn) => {
            btn.addEventListener("click", (event) => {
                // Stop propagation to prevent the document click listener from closing it immediately
                event.stopPropagation();

                const li = btn.parentElement;

                // Close other *sibling* dropdowns at the same level
                // This ensures only one dropdown at a given level is open at a time,
                // unless it's a child dropdown of an already open parent.
                const parentUl = li.parentElement;
                if (parentUl) {
                    parentUl.querySelectorAll(":scope > .has-dropdown").forEach((siblingLi) => {
                        if (siblingLi !== li) {
                            siblingLi.classList.remove("open");
                            // Recursively close any open nested dropdowns within siblings
                            closeNestedDropdowns(siblingLi);
                        }
                    });
                }

                // Toggle the 'open' class for the clicked dropdown
                li.classList.toggle("open");
            });
        });

        // Close dropdowns when clicking outside
        document.addEventListener("click", (event) => {
            document.querySelectorAll(".has-dropdown.open").forEach((openDropdown) => {
                // Check if the click occurred outside the current open dropdown
                if (!openDropdown.contains(event.target)) {
                    openDropdown.classList.remove("open");
                    // Recursively close any nested dropdowns within this one
                    closeNestedDropdowns(openDropdown);
                }
            });
        });

        // Helper function to recursively close nested dropdowns
        function closeNestedDropdowns(element) {
            element.querySelectorAll(".has-dropdown.open").forEach((nestedOpenDropdown) => {
                nestedOpenDropdown.classList.remove("open");
                closeNestedDropdowns(nestedOpenDropdown); // Recurse for deeper nesting
            });
        }
    });
</script>
</body>

</html>