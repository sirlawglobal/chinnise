<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title><?php
            $uri = $_SERVER['REQUEST_URI'];
            $uri = strtok($uri, '?'); // Remove query string
            $uri = rtrim($uri, '/');  // Remove trailing slash
            $segments = explode('/', $uri);
            $last = end($segments);
            // Remove .php extension if present
            $last = preg_replace('/\.php$/i', '', $last);
            // Replace underscores with spaces and convert to uppercase
            echo $last === '' ? 'CRM128' : strtoupper(str_replace('_', ' ', $last));
            ?></title>
    <style>
        /* Add these styles to your CSS */
        .sidebar {
            position: relative;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
            transition: none !important;
            /* Remove any transitions */
        }

        /* .menu li a.active {
            background-color: #3a7bd5;
            color: white !important;
            border-radius: 4px;
        } */

        /* .menu li a.active .more-icon {
            filter: brightness(0) invert(1);
        } */

        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
        }

        .submenu.show {
            max-height: 1000px;
            /* Adjust based on your content */
        }

        .has-dropdown.active>.submenu {
            max-height: 1000px;
        }

        .has-dropdown.active>.dropbtn .arrow {
            transform: rotate(180deg);
        }

        .arrow,
        .arrow2 {
            display: inline-block;
            transition: transform 0.3s ease;
            margin-left: auto;
        }

        ul li a {
            height: 30px;
        }
    </style>
    <link rel="stylesheet" href="/app/index.css" />
    <!-- <link rel="stylesheet" href="/app/input.css" /> -->
    <link rel="stylesheet" href="/app/fullcalendar.css" />
    <link rel="stylesheet" href="/app/human-resource.css" />
    <link rel="stylesheet" href="/app/table.css">
    <?php
    if (! empty($cdn)) {
        foreach ($cdn as $scriptTag) {
            echo $scriptTag;
        }
    }
    if (! empty($pageCSS)) {
        foreach ($pageCSS as $cssFile) {
            echo "<link rel='stylesheet' href='$cssFile'>
    ";
        }
    } ?>
    <?php
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        // Not logged in, redirect to login page
        header("Location: ../auth/login.php");
        exit;
    }
    ?>
</head>

<body>
    <div id="overlay"></div>
    <!-- Sidebar -->
    <nav class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <img src="/app/assets/logo.png" alt="logo" />
            </div>
            <!-- <button class="close-btn" id="closeSidebar">&times;</button> -->
        </div>
        <ul class="menu">
            <li>
                <a href="/app/" class="<?php echo basename($_SERVER['REQUEST_URI']) === 'index.php' || $_SERVER['REQUEST_URI'] === '/app/' ? 'active' : '' ?>">
                    <img
                        class="more-icon"
                        alt=""
                        src="https://gn128.com/crm5/assets/icons/dashboard.svg" />
                    Overview
                </a>
            </li>
            <li class="has-dropdown                                                                                                                                                                                <?php echo strpos($_SERVER['REQUEST_URI'], '/contact-management/') !== false ? 'active' : '' ?>">
                <button class="dropbtn">
                    <a href="/app/contact-management/" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/contact-management/' ? 'active' : '' ?>">
                        <img
                            class="more-icon"
                            alt=""
                            src="https://gn128.com/crm5/assets/icons/clients.svg" />
                        Contact Management</a><span class="arrow">▾</span>
                </button>
                <ul class="submenu <?php echo strpos($_SERVER['REQUEST_URI'], '/contact-management/') !== false ? 'show' : '' ?>">
                    <li><a href="/app/contact-management/leads" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/contact-management/leads' ? 'active' : '' ?>">Manage Leads</a></li>
                    <li>
                        <a href="/app/contact-management/clients" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/contact-management/clients' ? 'active' : '' ?>">Manage Clients</a>
                    </li>
                    <li><a href="/app/contact-management/report" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/contact-management/report' ? 'active' : '' ?>">Reports</a></li>
                </ul>
            </li>
            <li style="padding-top: -5px;">
                <a href="/app/appointments" class="<?php echo strpos($_SERVER['REQUEST_URI'], '/app/appointments') !== false ? 'active' : '' ?>">
                    <img
                        class="more-icon"
                        alt=""
                        src="https://gn128.com/crm5/assets/icons/appointment.svg" />
                    Appointment
                </a>
            </li>
            <li style="padding-top: 15px;">
                <a href="/app/time-sheet" class="<?php echo strpos($_SERVER['REQUEST_URI'], '/time-sheet') !== false ? 'active' : '' ?>">
                    <img
                        class="more-icon"
                        alt=""
                        style="width: 26px; height: 26px"
                        src="https://gn128.com/crm5/assets/icons/time.png" />
                    Time Sheet</a>
            </li>
            <li class="has-dropdown                                                                                                                                                                                <?php echo strpos($_SERVER['REQUEST_URI'], '/human-resource/') !== false ? 'active' : '' ?>">
                <button class="dropbtn">
                    <a href="/app/human-resource/" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/human-resource/' ? 'active' : '' ?>">
                        <img
                            class="more-icon"
                            alt=""
                            src="https://gn128.com/crm5/assets/icons/human-resources.svg" />Human Resource</a><span class="arrow">▾</span>
                </button>
                <ul class="submenu                                                                                                                                                                           <?php echo strpos($_SERVER['REQUEST_URI'], '/human-resource/') !== false ? 'show' : '' ?>">
                    <li>
                        <a href="/app/human-resource/departments" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/human-resource/departments' ? 'active' : '' ?>"> Departments</a>
                    </li>
                    <li>
                        <a href="/app/human-resource/employee-management" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/human-resource/employee-management' ? 'active' : '' ?>">Employee Management</a>
                    </li>
                    <li>
                        <a href="/app/human-resource/leave-management" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/human-resource/leave-management' ? 'active' : '' ?>">Leave Management</a>
                    </li>
                    <li>
                        <a href="/app/human-resource/attendances" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/human-resource/attendances' ? 'active' : '' ?>">Attendances</a>
                    </li>
                    <li>
                        <a href="/app/human-resource/attendance-report" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/human-resource/attendance-report' ? 'active' : '' ?>">
                            Attendance Reports
                        </a>
                    </li>
                    <li><a href="/app/human-resource/my-payroll" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/human-resource/my-payroll' ? 'active' : '' ?>">Payroll</a></li>

                    <li>
                        <a href="/app/human-resource/awards-and-incentives" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/human-resource/awards-and-incentives' ? 'active' : '' ?>">
                            Awards and Incentives
                        </a>
                    </li>
                    <li><a href="/app/human-resource/onboarding" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/human-resource/onboarding' ? 'active' : '' ?>">Onboarding</a></li>
                    <li><a href="/app/human-resource/training" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/human-resource/training' ? 'active' : '' ?>">Training</a></li>
                </ul>
            </li>

            <li class="has-dropdown                                                                                                                                                                                <?php echo strpos($_SERVER['REQUEST_URI'], '/project-management') !== false ? 'active' : '' ?>">
                <button class="dropbtn">
                    <a href="/app/project-management" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/project-management' ? 'active' : '' ?>">
                        <img
                            class="more-icon"
                            alt=""
                            src="/app/assets/project.svg" />
                        Project Management
                    </a>
                    <span class="arrow">▾</span>
                </button>
                <ul class="submenu                                                                                                                                                                           <?php echo strpos($_SERVER['REQUEST_URI'], '/project-management') !== false ? 'show' : '' ?>">
                    <li class="has-dropdown                                                                                                                                                                                                                        <?php echo strpos($_SERVER['REQUEST_URI'], '/project-management/projects') !== false ? 'active' : '' ?>">
                        <button class="dropbtn">
                            <a href="/app/project-management/projects" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/project-management/projects' ? 'active' : '' ?>">
                                Manage Projects</a>
                            <span class="arrow2">▾</span>
                        </button>
                        <ul class="dropdown-content <?php echo strpos($_SERVER['REQUEST_URI'], '/project-management/projects') !== false ? 'show' : '' ?>">
                            <li><a href="/app/project-management/projects?tab=ongoing" class="<?php echo isset($_GET['tab']) && $_GET['tab'] === 'ongoing' ? 'active' : '' ?>">On Going Projects</a></li>
                            <li><a href="/app/project-management/projects?tab=pending" class="<?php echo isset($_GET['tab']) && $_GET['tab'] === 'pending' ? 'active' : '' ?>">Pending Projects</a></li>
                            <li><a href="/app/project-management/projects?tab=completed" class="<?php echo isset($_GET['tab']) && $_GET['tab'] === 'completed' ? 'active' : '' ?>">Completed Projects</a></li>
                            <li><a href="/app/project-management/projects?tab=reports" class="<?php echo isset($_GET['tab']) && $_GET['tab'] === 'reports' ? 'active' : '' ?>">Reports</a></li>
                        </ul>
                    </li>
                    <li><a href="/app/project-management/risk-assessment" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/project-management/risk-assessment' ? 'active' : '' ?>">Risk Assessment</a></li>
                    <li><a href="/app/project-management/budget-management" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/project-management/budget-management' ? 'active' : '' ?>">Budget Management</a></li>
                    <li>Resource Plan</li>

                </ul>
            </li>
            <li class="has-dropdown                                                                                                                                                                                <?php echo strpos($_SERVER['REQUEST_URI'], '/inventory/') !== false ? 'active' : '' ?>">
                <button class="dropbtn">
                    <a href="/app/inventory/" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/inventory/' ? 'active' : '' ?>">
                        <img
                            class="more-icon"
                            alt=""
                            src="/app/assets/inventory.svg" />
                        Inventory Management</a><span class="arrow">▾</span>
                </button>
                <ul class="submenu <?php echo strpos($_SERVER['REQUEST_URI'], '/inventory/') !== false ? 'show' : '' ?>">
                    <a href="/app/inventory/suppliers" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/inventory/suppliers' ? 'active' : '' ?>">
                        <li>Suppliers</li>
                    </a>
                    <a href="/app/inventory/current_stock" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/inventory/current_stock' ? 'active' : '' ?>">
                        <li>Current Stock</li>
                    </a>
                    <a href="/app/inventory/clients_orders" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/inventory/clients_orders' ? 'active' : '' ?>">
                        <li>Clients Orders</li>
                    </a>
                    <a href="/app/inventory/suppliers_orders" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/inventory/suppliers_orders' ? 'active' : '' ?>">
                        <li>Suppliers Orders</li>
                    </a>
                    <a href="/app/inventory/suppliers_returns" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/inventory/suppliers_returns' ? 'active' : '' ?>">
                        <li>Supplier Returns</li>
                    </a>
                    <a href="/app/inventory/customer_returns" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/inventory/customer_returns' ? 'active' : '' ?>">
                        <li>Customer Returns</li>
                    </a>
                    <a href="/app/inventory/reports" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/inventory/reports' ? 'active' : '' ?>">
                        <li>Reports</li>
                    </a>
                </ul>
            </li>
            <li class="has-dropdown                                                                                                                                                                                <?php echo strpos($_SERVER['REQUEST_URI'], '/cash-flow/') !== false ? 'active' : '' ?>">
                <button class="dropbtn">
                    <a href="/app/cash-flow/" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/cash-flow/' ? 'active' : '' ?>">
                        <img
                            class="more-icon"
                            alt=""
                            src="https://gn128.com/crm5/assets/icons/accounting.svg" />
                        Cash Flow</a>
                    <span class="arrow">▾</span>
                </button>
                <ul class="submenu <?php echo strpos($_SERVER['REQUEST_URI'], '/cash-flow/') !== false ? 'show' : '' ?>">
                    <li><a href="/app/cash-flow/income" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/cash-flow/income' ? 'active' : '' ?>"> Income</a></li>
                    <li><a href="/app/cash-flow/expense" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/cash-flow/expense' ? 'active' : '' ?>">Expenses</a></li>
                    <li><a href="/app/cash-flow/report" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/cash-flow/report' ? 'active' : '' ?>">Reports</a></li>
                </ul>
            </li>
            <li class="has-dropdown                                                                                                                                                                                <?php echo strpos($_SERVER['REQUEST_URI'], '/admin/') !== false ? 'active' : '' ?>">
                <button class="dropbtn">
                    <a href="/app/admin/" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/admin/' ? 'active' : '' ?>">
                        <img
                            class="more-icon"
                            alt=""
                            src="https://gn128.com/crm5/assets/icons/settings.svg" />
                        Admin</a>
                    <span class="arrow">▾</span>
                </button>
                <ul class="submenu <?php echo strpos($_SERVER['REQUEST_URI'], '/admin/') !== false ? 'show' : '' ?>">
                    <li><a href="/app/admin/users" class="<?php echo $_SERVER['REQUEST_URI'] === '/app/admin/users' ? 'active' : '' ?>">Users</a></li>
                    <!-- <li><a href="/app/admin/settings">Settings</a></li> -->
                </ul>
            </li>
            <li>
                <a
                    href="/app/auth/logout.php"
                    style="
              display: flex;
              align-items: center;
              text-decoration: none;
              color: inherit;
            ">
                    <img
                        class="more-icon"
                        alt="Logout Icon"
                        src="https://gn128.com/crm5/assets/icons/logout.svg" />
                    <span style="margin-left: 8px">Logout</span>
                </a>
            </li>
        </ul>
    </nav>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const dropdownButtons = document.querySelectorAll('.dropbtn');

            dropdownButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    // Only handle clicks on the button or arrow
                    if (e.target === this || e.target.classList.contains('arrow') || e.target.classList.contains('arrow2')) {
                        e.preventDefault();
                        e.stopPropagation();

                        const dropdown = this.parentElement;
                        const isActive = dropdown.classList.contains('active');

                        // Close all other dropdowns at the same level
                        if (dropdown.parentElement) {
                            Array.from(dropdown.parentElement.children).forEach(item => {
                                if (item !== dropdown && item.classList.contains('has-dropdown')) {
                                    item.classList.remove('active');
                                    const submenu = item.querySelector('.submenu');
                                    if (submenu) submenu.style.maxHeight = '0';
                                }
                            });
                        }

                        // Toggle current dropdown
                        if (isActive) {
                            dropdown.classList.remove('active');
                            const submenu = dropdown.querySelector('.submenu');
                            if (submenu) submenu.style.maxHeight = '0';
                        } else {
                            dropdown.classList.add('active');
                            const submenu = dropdown.querySelector('.submenu');
                            if (submenu) submenu.style.maxHeight = submenu.scrollHeight + 'px';
                        }
                    }
                });
            });

            // Keep dropdowns open for active links
            const currentPath = window.location.pathname;
            document.querySelectorAll('.menu a').forEach(link => {
                if (link.getAttribute('href') === currentPath || link.href === window.location.href) {
                    link.classList.add('active');

                    // Open parent dropdowns
                    let parent = link.closest('.has-dropdown');
                    while (parent) {
                        parent.classList.add('active');
                        const submenu = parent.querySelector('.submenu');
                        if (submenu) submenu.style.maxHeight = submenu.scrollHeight + 'px';
                        parent = parent.parentElement.closest('.has-dropdown');
                    }
                }
            });
        });
    </script>
</body>

</html>