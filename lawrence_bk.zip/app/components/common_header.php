<header class="mobile-header">
    <button id="openSidebar">&#9776;</button>
    <div class="logo">
        <img src="/crm128/assets/logo.png" alt="logo" />
    </div>
</header>

<!-- Desktop Header -->
<header class="header">
    <div class="search-container">
        <div class="search-input-wrapper">
            <!-- <svg viewBox="0 0 24 24">
                <path
                    d="M10 2a8 8 0 105.29 14.29l4.3 4.3 1.42-1.42-4.30-4.30A8 8 0 0010 2zm0 2a6 6 0 110 12A6 6 0 0110 4z" />
            </svg>
            <input type="text" placeholder="Search" /> -->
        </div>
    </div>
    <div class="actions">
        <button class="notification-btn" aria-label="Notifications">
            <svg viewBox="0 0 24 24">
                <path
                    d="M12 2a7 7 0 00-7 7v4H4l2 2v1h12v-1l2-2h-1V9a7 7 0 00-7-7zm0 18a2 2 0 002-2h-4a2 2 0 002 2z" />
            </svg>
        </button>
        <div class="avatar">
            <img src="/crm128/assets/avatar.jpg" alt="User Avatar" />
        </div>
    </div>
</header>