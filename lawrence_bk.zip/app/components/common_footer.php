<script>
    const sidebar = document.getElementById("sidebar");
    const overlay = document.getElementById("overlay");
    const btnOpen = document.getElementById("openSidebar");

    function openNav() {
        sidebar.classList.add("active");
        overlay.classList.add("active");
    }

    function closeNav() {
        sidebar.classList.remove("active");
        overlay.classList.remove("active");
    }

    btnOpen.addEventListener("click", openNav);

    // click anywhere on overlay -> close
    overlay.addEventListener("click", closeNav);

    // NEW: dropdown toggles
    document.querySelectorAll(".has-dropdown > .dropbtn").forEach((btn) => {
        btn.addEventListener("click", () => {
            const li = btn.parentElement;
            li.classList.toggle("open");
        });
    });
    const btn = document.querySelector(".add-new-button");
    const modal = document.querySelector(".modal");
    const closeBtn = document.querySelector(".close");
    btn.addEventListener("click", () => {
        modal.style.display = "block";
    });
    closeBtn.addEventListener("click", () => {
        modal.style.display = "none";
    });
    window.addEventListener("click", (event) => {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    });
</script>
</body>

</html>