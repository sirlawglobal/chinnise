<?php require('../components/header.php')  ?>
<div class="main">
  <?php require('../components/common_header.php')  ?>

  <!-- Your page content goes here -->
  <section class="content">
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Accounting Management</span>
        <span class="divider"></span>
        <span class="tab active">Reports</span>
      </div>

      <!-- <div class="box1">
            <div class="box2">
              <h4 class="box2-title">Active Clients</h4>
              <div class="box2-val">0</div>
            </div> -->
      <!-- <button class="add-new-button">Add New Lead</button> -->
    </div>

    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Income Statement</h3>
          <button
            class="add-new-button"
            onclick="location.href='./income-statement'">
            View
          </button>
        </div>
      </div>
    </div>
    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Expense Report</h3>
          <button
            onclick="location.href='./expense-report'"
            class="add-new-button">
            View
          </button>
        </div>
      </div>
    </div>
  </section>
</div>

<?php require('../components/common_footer.php')  ?>