<?php require('../components/header.php')  ?>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php require('../components/common_header.php')  ?>
  <!-- Your page content goes here -->
  <section class="content" style="overflow: hidden">
    <!-- Tabs for Clients and Leads -->
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Accounting Management</span>
        <span class="divider"></span>
        <span class="tab active">Income Statement</span>
      </div>
      <div class="anb-container">
        <button
          class="add-new-button add-new-income"
          style="border-radius: 15px">
          Print Report
        </button>
      </div>
      <!-- <button class="add-new-button">Add New Lead</button> -->
    </div>
    <!-- <div class="row1">
      <div class="row2">
        <div class="col1">
        <label>Start Date</label>
        <input type="date" id="startDate" placeholder="dd/mm/yyyy" />
      </div>
      <div class="col1">
        <label>End Date</label>
        <input type="date" id="endDate" placeholder="dd/mm/yyyy" />
      </div>

      </div>
    </div> -->
    <!-- Table for Leads -->
    <?php
      require '../settings/connection.php';

      try {
          // Prepare and execute the SELECT query
          $stmt = $pdo->query("SELECT date as date_added, description, client_name, project_value, amount_received FROM incomes");
          $incomes = $stmt->fetchAll();
      } catch (PDOException $e) {
          die("Query failed: " . $e->getMessage());
      }
    ?>

<div class="over-table">
  <table class="leads-table">
    <thead>
      <tr>
        <th>Date Added</th>
        <th>Description</th>
        <th>Client Name</th>
        <th>Project Value</th>
        <th>Amount Received</th>
      </tr>
    </thead>
    <tbody id="incomeTableBody">
      <?php if (!empty($incomes)): ?>
        <?php foreach ($incomes as $row): ?>
          <tr>
            <td><?= date('d-m-Y', strtotime($row['date_added'])) ?></td>
            <td><?= htmlspecialchars($row['description']) ?></td>
            <td><?= htmlspecialchars($row['client_name']) ?></td>
            <td><?= htmlspecialchars($row['project_value']) ?></td>
            <td><?= number_format($row['amount_received'], 2) ?></td>
          </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr>
          <td colspan="5">No income records found.</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

  </section>
</div>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const startInput = document.getElementById('startDate');
  const endInput = document.getElementById('endDate');

  function fetchFilteredIncomes() {
    const startDate = startInput.value;
    const endDate = endInput.value;

    const params = new URLSearchParams({
      start: startDate,
      end: endDate
    });

    fetch(`filter_incomes.php?${params}`)
      .then(response => response.text())
      .then(data => {
        document.getElementById('incomeTableBody').innerHTML = data;
      })
      .catch(err => console.error('Error fetching filtered incomes:', err));
  }

  // Attach event listeners
  startInput.addEventListener('change', fetchFilteredIncomes);
  endInput.addEventListener('change', fetchFilteredIncomes);
});
</script>
<script>
  document.querySelector('.add-new-income').addEventListener('click', () => {
  const table = document.querySelector('.leads-table');

  // Create a new window
  const printWindow = window.open('', '', 'width=800,height=600');
  printWindow.document.write('<html><head><title>Income Statement Report</title>');

  // Optional: copy some CSS to make print look nice
  const styles = `
    <style>
      body { font-family: Arial, sans-serif; padding: 20px; }
      table { width: 100%; border-collapse: collapse; }
      th, td { border: 1px solid #333; padding: 8px; text-align: left; }
      th { background-color: #f2f2f2; }
    </style>
  `;
  printWindow.document.write(styles);
  printWindow.document.write('</head><body>');
  
  // Write the table HTML
  printWindow.document.write(table.outerHTML);

  printWindow.document.write('</body></html>');
  printWindow.document.close();

  // Wait for content to load then print and close
  printWindow.onload = function () {
    printWindow.focus();
    printWindow.print();
    printWindow.close();
  };
});

</script>
<?php require('../components/common_footer.php')  ?>