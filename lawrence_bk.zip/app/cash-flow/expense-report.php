<?php require('../components/header.php')  ?>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php require('../components/common_header.php')  ?>

  <!-- Your page content goes here -->
  <section class="content" style="overflow: hidden">
    <!-- Tabs for Clients and Leads -->
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Accounting Management</span>
        <span class="divider"></span>
        <span class="tab active">Expense Report</span>
      </div>
      <div class="anb-container">
        <button
          class="add-new-button add-new-income"
          style="border-radius: 15px">
          Print Report
        </button>
      </div>
      <!-- <button class="add-new-button">Add New Lead</button> -->
    </div>


    <!-- <div class="row1">
      <div class="row2">
        <div class="col1">
          <label>Start Date</label>
          <input type="date" placeholder="dd/mm/yyyy" />
        </div>
        <div class="col1">
          <label>End Date</label>
          <input type="date" placeholder="dd/mm/yyyy" />
        </div>
      </div>

      <div class="row2">
        <div class="col1">
          <label>Category</label>
          <select>
            <option value="all">All</option>
            <option value="website">Website</option>
            <option value="social-media">Social Media</option>
            <option value="referral">Referral</option>
            <option value="advertisement">Advertisement</option>
          </select>
        </div>
      </div>
    </div> -->
    
    <!-- Table for Leads -->
<?php
// Include your existing PDO connection
require_once '../settings/connection.php';

// Prepare and execute the query
$sql = "SELECT date, description, category_id, transaction_type, total_price FROM expenses ORDER BY date";
$stmt = $pdo->prepare($sql);
$stmt->execute();

$expenses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="over-table">
  <table class="leads-table">
    <thead>
      <tr>
        <th>Date Added</th>
        <th>Description</th>
        <th>Category</th>
        <th>Transaction Type</th>
        <th>Amount</th>
      </tr>
    </thead>
    <tbody id="incomeTableBody">
      <?php if (count($expenses) > 0): ?>
        <?php foreach ($expenses as $expense): ?>
          <tr>
            <td><?= htmlspecialchars($expense['date']) ?></td>
            <td><?= htmlspecialchars($expense['description']) ?></td>
            <td><?= htmlspecialchars($expense['category_id']) ?></td>
            <td><?= htmlspecialchars($expense['transaction_type']) ?></td>
            <td><?= number_format($expense['total_price'], 2) ?></td>
          </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr><td colspan="5">No expenses found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

  </section>
</div>
<script>
  document.querySelector('.add-new-income').addEventListener('click', () => {
  const table = document.querySelector('.leads-table');

  // Create a new window
  const printWindow = window.open('', '', 'width=800,height=600');
  printWindow.document.write('<html><head><title>Income Statement Report</title>');

  // Optional: copy some CSS to make print look nice
  const styles = `
    <style>
      body { font-family: Arial, sans-serif; padding: 20px; }
      table { width: 100%; border-collapse: collapse; }
      th, td { border: 1px solid #333; padding: 8px; text-align: left; }
      th { background-color: #f2f2f2; }
    </style>
  `;
  printWindow.document.write(styles);
  printWindow.document.write('</head><body>');
  
  // Write the table HTML
  printWindow.document.write(table.outerHTML);

  printWindow.document.write('</body></html>');
  printWindow.document.close();

  // Wait for content to load then print and close
  printWindow.onload = function () {
    printWindow.focus();
    printWindow.print();
    printWindow.close();
  };
});

</script>
<?php require('../components/common_footer.php')  ?>