<?php require('../components/header.php')  ?>
<style>
  .expenses-card {
    background-color: #ffeaea;
    justify-content: normal;
  }

  .income-card {
    background-color: #eff8ed;
    justify-content: normal;
  }

  .balance-card {
    background-color: #e6f0ff;
    justify-content: normal;
  }

  .box2-val {
    color: gray;
  }
</style>
<div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">Add Expenses</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Date</label>
          <input type="date" placeholder="dd/mm/yyyy" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Company Category</label>
          <select>
            <option value="">Please select</option>
            <option value="Fuel">Fuel</option>
            <option value="Telecoms">Telecoms</option>
            <option value="Transport">Transport</option>
            <option value="Repairs">Repairs</option>
            <option value="Water">Water</option>
            <option value="Socials">Socials</option>
          </select>
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Debit</label>
          <input type="number" placeholder="Enter amount" />
        </div>
        <div class="col">
          <label>Credit</label>
          <input type="number" placeholder="Enter amount" />
        </div>
        <div class="col">
          <label>Balance</label>
          <input type="number" placeholder="Enter amount" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Total Balance</label>
          <input type="number" readonly value="0" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Description</label>
          <textarea rows="4" placeholder="Description..."></textarea>
        </div>
      </div>
      <button type="submit" class="save-btn">Save</button>
    </form>
  </div>
</div>
<div class="modal2">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Add New Income</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Date</label>
          <input type="date" placeholder="dd/mm/yyyy" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Client Name</label>
          <input type="text" placeholder="" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Project Value</label>
          <input type="number" placeholder="Enter amount" />
        </div>
        <div class="col">
          <label>Amount Received</label>
          <input type="number" placeholder="Enter amount" />
        </div>
        <div class="col">
          <label>Balance</label>
          <input type="number" readonly value="0" />
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Description</label>
          <textarea rows="4" placeholder="Description..."></textarea>
        </div>
      </div>
      <button type="submit" class="save-btn">Save</button>
    </form>
  </div>
</div>
<!-- Main content -->
<div class="main" style="overflow: hidden">

  <?php require('../components/common_header.php')  ?>
  <!-- Your page content goes here -->
  <section class="content">
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Accounting</span>
        <span class="divider"></span>
        <span class="tab active">Income</span>
      </div>
      <div class="anb-container">
        <button
          class="add-new-button add-new-expense view-icon"
          style="border-radius: 15px">
          Add New Expense
        </button>
        <button
          class="add-new-button add-new-income edit-icon"
          style="border-radius: 15px">
          Add New Income
        </button>
      </div>
    </div>
    <div class="box1">
      <div class="box2 income-card">
        <div>
          <div>
            <img
              id="income-disable-img"
              class="eye-icon iv1"
              onclick="enableIncome(event)"
              src="https://crm128.com/app/assets/images/eye closed.png"
              alt=""
              style="display: block" />
            <img
              id="income-enable-img "
              onclick="enableIncome(event)"
              class="eye-icon iu1"
              style="display: none"
              src="../assets/eye-open.png"
              alt="" />
          </div>
          <h4 class="box2-title">YEAR TO DATE INCOME</h4>
        </div>

        <div class="box2-val val1">&#8358;160,000.00</div>
      </div>

      <div class="box2 expenses-card">
        <div>
          <div>
            <img
              id="income-disable-img"
              class="eye-icon iv2"
              onclick="enableIncome(event)"
              src="https://crm128.com/app/assets/images/eye closed.png"
              alt=""
              style="display: block" />
            <img
              id="income-enable-img"
              onclick="enableIncome(event)"
              class="eye-icon iu2"
              style="display: none"
              src="../assets/eye-open.png"
              alt="" />
          </div>
          <h4 class="box2-title">YEAR TO DATE EXPENSES</h4>
        </div>
        <div class="box2-val val2">&#8358;6,421,992.00</div>
      </div>
      <div class="box2 balance-card">
        <div>
          <div>
            <img
              id="income-disable-img"
              class="eye-icon iv3"
              onclick="enableIncome(event)"
              src="https://crm128.com/app/assets/images/eye closed.png"
              alt=""
              style="display: block" />
            <img
              id="income-enable-img"
              onclick="enableIncome(event)"
              class="eye-icon iu3"
              style="display: none"
              src="../assets/eye-open.png"
              alt="" />
          </div>
          <h4 class="box2-title">YEAR TO DATE BALANCE</h4>
        </div>

        <div class="box2-val val3">&#8358;160,000.00</div>
      </div>
    </div>
    <div class="box1">
      <div class="box2 income-card">
        <div>
          <div>
            <img
              id="income-disable-img"
              class="eye-icon iv4"
              onclick="enableIncome(event)"
              src="https://crm128.com/app/assets/images/eye closed.png"
              alt=""
              style="display: block" />
            <img
              id="income-enable-img "
              onclick="enableIncome(event)"
              class="eye-icon iu4"
              style="display: none"
              src="../assets/eye-open.png"
              alt="" />
          </div>
          <h4 class="box2-title">YEAR TO DATE INCOME</h4>
        </div>

        <div class="box2-val val4">&#8358;160,000.00</div>
      </div>

      <div class="box2 expenses-card">
        <div>
          <div>
            <img
              id="income-disable-img"
              class="eye-icon iv5"
              onclick="enableIncome(event)"
              src="https://crm128.com/app/assets/images/eye closed.png"
              alt=""
              style="display: block" />
            <img
              id="income-enable-img"
              onclick="enableIncome(event)"
              class="eye-icon iu5"
              style="display: none"
              src="../assets/eye-open.png"
              alt="" />
          </div>
          <h4 class="box2-title">YEAR TO DATE EXPENSES</h4>
        </div>
        <div class="box2-val val5">&#8358;6,421,992.00</div>
      </div>
      <div class="box2 balance-card">
        <div>
          <div>
            <img
              id="income-disable-img"
              class="eye-icon iv6"
              onclick="enableIncome(event)"
              src="https://crm128.com/app/assets/images/eye closed.png"
              alt=""
              style="display: block" />
            <img
              id="income-enable-img"
              onclick="enableIncome(event)"
              class="eye-icon iu6"
              style="display: none"
              src="../assets/eye-open.png"
              alt="" />
          </div>
          <h4 class="box2-title">YEAR TO DATE BALANCE</h4>
        </div>

        <div class="box2-val val6">&#8358;160,000.00</div>
      </div>
    </div>
  </section>
</div>

<script>
  function enableIncome(event) {
    let clicked = event.target.classList[1];

    if (clicked.includes("iv")) {
      console.log("iv clicked");
      let other = clicked.replace("iv", "iu");
      let val = clicked.replace("iv", "val");
      document.querySelector(`.${clicked}`).style.display = "none";
      document.querySelector(`.${other}`).style.display = "block";

      //
      document.querySelector(`.${val}`).style.display = "block";

      let text = document.querySelector(`.${val}`);
      text.style.color = "transparent";
      text.style.textShadow = "rgb(0, 0, 0) 0px 0px 20px";
    } else {
      console.log("iu clicked");
      let other = clicked.replace("iu", "iv");
      let val = clicked.replace("iu", "val");

      document.querySelector(`.${clicked}`).style.display = "none";
      document.querySelector(`.${other}`).style.display = "block";
      let text = document.querySelector(`.${val}`);
      text.style.color = "transparent";
      text.style.textShadow = "rgb(0, 0, 0) 0px 0px 0px";
    }
  }

  const btn1 = document.querySelectorAll(".add-new-expense");
  const btn2 = document.querySelectorAll(".add-new-income");
  const modal1 = document.querySelector(".modal1");
  const modal2 = document.querySelector(".modal2");
  const closeBtn1 = document.querySelector(".close1");
  const closeBtn2 = document.querySelector(".close2");
  btn1.forEach((btns) => {
    btns.addEventListener("click", () => {
      modal1.style.display = "block";
    });
  });

  btn2.forEach((btns) => {
    btns.addEventListener("click", () => {
      modal2.style.display = "block";
    });
  });

  closeBtn1.addEventListener("click", () => {
    modal1.style.display = "none";
  });
  closeBtn2.addEventListener("click", () => {
    modal2.style.display = "none";
  });
  window.addEventListener("click", (event) => {
    if (event.target == modal1) {
      modal1.style.display = "none";
    } else if (event.target == modal2) {
      modal2.style.display = "none";
    }
  });
  const sidebar = document.getElementById("sidebar");
  const overlay = document.getElementById("overlay");
  const btnOpen = document.getElementById("openSidebar");

  function openNav() {
    sidebar.classList.add("active");
    overlay.classList.add("active");
  }

  function closeNav() {
    sidebar.classList.remove("active");
    overlay.classList.remove("active");
  }
  btnOpen.addEventListener("click", openNav); // click anywhere on overlay -> close
  overlay.addEventListener("click", closeNav);

  // NEW: dropdown toggles
  document.querySelectorAll(".has-dropdown > .dropbtn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const li = btn.parentElement;
      li.classList.toggle("open");
    });
  });
</script>
</body>

</html>