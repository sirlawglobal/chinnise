<?php require('../components/header.php') ?>
<div class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con">Add New Income</h2>
    <form id="addIncomeForm">
      <div class="row">
        <div class="col">
          <label>Date</label>
          <input type="date" name="date" placeholder="dd/mm/yyyy" required />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Client Name</label>
          <input type="text" name="client_name" placeholder="" required />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Project Value</label>
          <input type="number" name="project_value" placeholder="Enter amount" required />
        </div>
        <div class="col">
          <label>Amount Received</label>
          <input type="number" name="amount_received" placeholder="Enter amount" required />
        </div>
        <div class="col">
          <label>Balance</label>
          <input type="number" name="balance" readonly value="0" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Description</label>
          <input name="description" placeholder="Description..." />
        </div>
      </div>
      <button type="submit" class="save-btn">Save</button>
    </form>
  </div>
</div>

<div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">View Income</h2>
    <form id="viewIncomeForm">
      <div class="row">
        <div class="col">
          <label>Date</label>
          <input type="date" name="date" readonly />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Client Name</label>
          <input type="text" name="client_name" readonly />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Project Value</label>
          <input type="number" name="project_value" readonly />
        </div>
        <div class="col">
          <label>Amount Received</label>
          <input type="number" name="amount_received" readonly />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Description</label>
          <textarea name="description" rows="4" readonly></textarea>
        </div>
      </div>
    </form>
  </div>
</div>

<div class="modal2">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Income</h2>
    <form id="editIncomeForm">
      <input type="hidden" name="id" />
      <div class="row">
        <div class="col">
          <label>Date</label>
          <input type="date" name="date" placeholder="dd/mm/yyyy" required />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Client Name</label>
          <input type="text" name="client_name" placeholder="" required />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Project Value</label>
          <input type="number" name="project_value" placeholder="Enter amount" required />
        </div>
        <div class="col">
          <label>Amount Received</label>
          <input type="number" name="amount_received" placeholder="Enter amount" required />
        </div>
        <div class="col">
          <label>Balance</label>
          <input type="number" name="balance" readonly />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Description</label>
          <input name="description" placeholder="Description..." />
        </div>
      </div>
      <button type="submit" class="save-btn">Update</button>
    </form>
  </div>
</div>

<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php require('../components/common_header.php') ?>
  <section class="content" style="overflow-y: hidden">
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Accounting</span>
        <span class="divider"></span>
        <span class="tab active">Income</span>
      </div>
      <div class="anb-container">
        <button class="add-new-button add-new-income" style="border-radius: 15px">
          Add New Income
        </button>
      </div>
    </div>
    <div class="row1" style="justify-content: center">
      <div class="row2">
        <div class="col1">
          <div class="search-input-wrapper">
            <svg viewBox="0 0 24 24">
              <path d="M10 2a8 8 0 105.29 14.29l4.3 4.3 1.42-1.42-4.30-4.30A8 8 0 0010 2zm0 2a6 6 0 110 12A6 6 0 0110 4z" />
            </svg>
            <input type="text" id="searchInput" placeholder="Search" style="background-color: white; border: 1px solid #4caf50" />
          </div>
        </div>
        <div class="col1">
          <select id="yearFilter">
            <option value="" selected style="display: none">Year</option>
            <option value="all">All</option>
            <option value="2024">2024</option>
            <option value="2023">2023</option>
            <option value="2022">2022</option>
            <option value="2021">2021</option>
            <option value="2020">2020</option>
            <option value="2019">2019</option>
            <option value="2018">2018</option>
            <option value="2017">2017</option>
            <option value="2016">2016</option>
          </select>
        </div>
      </div>
      <div class="row2">
        <div class="col1">
          <select id="monthFilter">
            <option value="" selected style="display: none">Month</option>
            <option value="all">All</option>
            <option value="01">January</option>
            <option value="02">February</option>
            <option value="03">March</option>
            <option value="04">April</option>
            <option value="05">May</option>
            <option value="06">June</option>
            <option value="07">July</option>
            <option value="08">August</option>
            <option value="09">September</option>
            <option value="10">October</option>
            <option value="11">November</option>
            <option value="12">December</option>
          </select>
        </div>
        <!-- <div class="col1">
          <select class="filter-select" id="categoryFilter" name="">
            <option value="" selected style="display: none">Category</option>
          </select>
        </div> -->
      </div>
    </div>
    <div class="row" style="justify-content: center">
      Total Income : <span id="totalIncome">&#8358;0.00</span>
    </div>
    <div class="over-table">
      <table>
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>S/N</th>
            <th>Date</th>
            <th>Name</th>
            <th>Description</th>
            <th>Project Value</th>
            <th>Amount Received</th>
            <th>Balance</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody id="incomeTableBody">
          <!-- Data will be loaded here via JavaScript -->
        </tbody>
      </table>
    </div>
  </section>
</div>

<?php require('../components/cashflow_footer.php') ?>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addIncomeModal = document.querySelector('.modal');
    const viewIncomeModal = document.querySelector('.modal1');
    const editIncomeModal = document.querySelector('.modal2');
    const addIncomeBtn = document.querySelector('.add-new-income');
    const closeBtns = document.querySelectorAll('.close, .close1, .close2');
    const searchInput = document.getElementById('searchInput');
    const yearFilter = document.getElementById('yearFilter');
    const monthFilter = document.getElementById('monthFilter');
    const categoryFilter = document.getElementById('categoryFilter');
    const incomeTableBody = document.getElementById('incomeTableBody');
    const totalIncomeSpan = document.getElementById('totalIncome');
    const addIncomeForm = document.getElementById('addIncomeForm');
    const editIncomeForm = document.getElementById('editIncomeForm');
    const viewIncomeForm = document.getElementById('viewIncomeForm');

    // Format currency
    function formatCurrency(amount) {
      return '&#8358;' + parseFloat(amount).toLocaleString('en-NG', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
    }

    // Calculate balance
    function calculateBalance(projectValue, amountReceived) {
      return parseFloat(projectValue) - parseFloat(amountReceived);
    }

    // Load incomes
    function loadIncomes() {
      const search = searchInput.value;
      const year = yearFilter.value;
      const month = monthFilter.value;

      console.log('Loading incomes with params:', {
        search,
        year,
        month
      }); // Debug log

      fetch(`../backend/cash-flow/incomes.php?search=${encodeURIComponent(search)}&year=${year}&month=${month}`)
        .then(response => {
          console.log('Response status:', response.status); // Debug log
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then(data => {
          console.log('Received data:', data); // Debug log
          incomeTableBody.innerHTML = '';

          if (data.incomes && data.incomes.length > 0) {
            data.incomes.forEach((income, index) => {
              const balance = calculateBalance(income.project_value, income.amount_received);
              const row = document.createElement('tr');

              const awardDate = new Date(income.date);

              // Get day, month, and year
              const day = String(awardDate.getDate()).padStart(2, '0');
              const month = String(awardDate.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
              const year = awardDate.getFullYear();

              // Format as dd-mm-yyyy
              const formattedDate = `${day}-${month}-${year}`;
              row.innerHTML = `
                        <td>100${income.id}</td>
                        <td>${formattedDate}</td>
                        <td>${income.client_name}</td>
                        <td>${income.description || ''}</td>
                        <td>${formatCurrency(income.project_value)}</td>
                        <td>${formatCurrency(income.amount_received)}</td>
                        <td>${formatCurrency(balance)}</td>
                        <td>
                            <i class="view-icon" data-id="${income.id}">
                                <img src="../assets/eye-open.png" />
                            </i>
                        </td>
                        <td>
                            <i class="edit-icon" data-id="${income.id}">
                                <img src="../assets/edit.svg" />
                            </i>
                        </td>
                        <td>
                            <i class="delete-icon" data-id="${income.id}">
                                <img src="../assets/Delete.svg" />
                            </i>
                        </td>
                    `;
              incomeTableBody.appendChild(row);
            });

            totalIncomeSpan.innerHTML = formatCurrency(data.total || 0);

            // Add event listeners to action buttons
            document.querySelectorAll('.view-icon').forEach(icon => {
              icon.addEventListener('click', () => viewIncome(icon.getAttribute('data-id')));
            });

            document.querySelectorAll('.edit-icon').forEach(icon => {
              icon.addEventListener('click', () => editIncome(icon.getAttribute('data-id')));
            });

            document.querySelectorAll('.delete-icon').forEach(icon => {
              icon.addEventListener('click', () => deleteIncome(icon.getAttribute('data-id')));
            });
          } else {
            console.log('No incomes found'); // Debug log
            incomeTableBody.innerHTML = '<tr><td colspan="10" style="text-align:center">No income records found</td></tr>';
            totalIncomeSpan.innerHTML = formatCurrency(0);
          }
        })
        .catch(error => {
          console.error('Error loading incomes:', error);
          incomeTableBody.innerHTML = '<tr><td colspan="10" style="text-align:center;color:red">Error loading income data</td></tr>';
          totalIncomeSpan.innerHTML = formatCurrency(0);
        });
    }

    // View income
    function viewIncome(id) {
      fetch(`../backend/cash-flow/incomes.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
          const income = data.incomes[0];
          viewIncomeForm.querySelector('[name="date"]').value = income.date;
          viewIncomeForm.querySelector('[name="client_name"]').value = income.client_name;
          viewIncomeForm.querySelector('[name="project_value"]').value = income.project_value;
          viewIncomeForm.querySelector('[name="amount_received"]').value = income.amount_received;
          viewIncomeForm.querySelector('[name="description"]').value = income.description || '';
          viewIncomeModal.style.display = 'block';
        })
        .catch(error => console.error('Error:', error));
    }

    // Edit income
    function editIncome(id) {
      fetch(`../backend/cash-flow/incomes.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
          const income = data.incomes[0];
          const balance = calculateBalance(income.project_value, income.amount_received);

          editIncomeForm.querySelector('[name="id"]').value = income.id;
          editIncomeForm.querySelector('[name="date"]').value = income.date;
          editIncomeForm.querySelector('[name="client_name"]').value = income.client_name;
          editIncomeForm.querySelector('[name="project_value"]').value = income.project_value;
          editIncomeForm.querySelector('[name="amount_received"]').value = income.amount_received;
          editIncomeForm.querySelector('[name="balance"]').value = balance;
          editIncomeForm.querySelector('[name="description"]').value = income.description || '';
          editIncomeModal.style.display = 'block';
        })
        .catch(error => console.error('Error:', error));
    }

    // Delete income
    function deleteIncome(id) {
      if (confirm('Are you sure you want to delete this income record?')) {
        fetch(`../backend/cash-flow/incomes.php?id=${id}`, {
            method: 'DELETE'
          })
          .then(response => response.json())
          .then(data => {
            alert(data.message);
            loadIncomes();
          })
          .catch(error => console.error('Error:', error));
      }
    }

    // Modal controls
    addIncomeBtn.addEventListener('click', () => {
      addIncomeModal.style.display = 'block';
    });

    closeBtns.forEach(btn => {
      btn.addEventListener('click', function() {
        if (this.classList.contains('close')) {
          addIncomeModal.style.display = 'none';
        } else if (this.classList.contains('close1')) {
          viewIncomeModal.style.display = 'none';
        } else if (this.classList.contains('close2')) {
          editIncomeModal.style.display = 'none';
        }
      });
    });

    window.addEventListener('click', (event) => {
      if (event.target === addIncomeModal) {
        addIncomeModal.style.display = 'none';
      }
      if (event.target === viewIncomeModal) {
        viewIncomeModal.style.display = 'none';
      }
      if (event.target === editIncomeModal) {
        editIncomeModal.style.display = 'none';
      }
    });

    // Form submissions
    addIncomeForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const formData = new FormData(this);
      const data = Object.fromEntries(formData.entries());

      fetch('../backend/cash-flow/incomes.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
          alert(data.message);
          addIncomeModal.style.display = 'none';
          addIncomeForm.reset();
          loadIncomes();
        })
        .catch(error => console.error('Error:', error));
    });

    editIncomeForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const formData = new FormData(this);
      const data = Object.fromEntries(formData.entries());
      const id = data.id;

      fetch(`../backend/cash-flow/incomes.php?id=${id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
          alert(data.message);
          editIncomeModal.style.display = 'none';
          loadIncomes();
        })
        .catch(error => console.error('Error:', error));
    });

    // Auto-calculate balance when project value or amount received changes
    ['project_value', 'amount_received'].forEach(field => {
      addIncomeForm.querySelector(`[name="${field}"]`).addEventListener('input', () => {
        const projectValue = parseFloat(addIncomeForm.querySelector('[name="project_value"]').value) || 0;
        const amountReceived = parseFloat(addIncomeForm.querySelector('[name="amount_received"]').value) || 0;
        addIncomeForm.querySelector('[name="balance"]').value = projectValue - amountReceived;
      });
    });

    ['project_value', 'amount_received'].forEach(field => {
      editIncomeForm.querySelector(`[name="${field}"]`).addEventListener('input', () => {
        const projectValue = parseFloat(editIncomeForm.querySelector('[name="project_value"]').value) || 0;
        const amountReceived = parseFloat(editIncomeForm.querySelector('[name="amount_received"]').value) || 0;
        editIncomeForm.querySelector('[name="balance"]').value = projectValue - amountReceived;
      });
    });

    // Filter events
    searchInput.addEventListener('input', loadIncomes);
    yearFilter.addEventListener('change', loadIncomes);
    monthFilter.addEventListener('change', loadIncomes);
    // categoryFilter.addEventListener('change', loadIncomes);

    // Initial load
    loadIncomes();
  });
</script>

<style>
     colgroup col:nth-child(6) {
    width: 150px;
  }
    colgroup col:nth-child(7) {
    width: 100px;
  }
</style>