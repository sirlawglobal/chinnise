<?php require('../components/header.php')  ?>
<div class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con">Add New Expense</h2>
    <form action="../backend/cash-flow/expenses/add_expense.php" method="POST">
  <div class="row">
    <div class="col">
      <label>Date</label>
      <input type="date" name="date" required />
    </div>
  </div>

  <div class="row">
    <div class="col">
      <label>Description</label>
      <input name="description" placeholder="Description..." required />
    </div>
  </div>

  <div class="row">
    <div class="col">
      <label>Category</label>
      <select name="category" required>
        <option value="">Please select</option>
        <option value="Fuel">Fuel</option>
        <option value="Telecoms">Telecoms</option>
        <option value="Transport">Transport</option>
        <option value="Repairs">Repairs</option>
        <option value="Water">Water</option>
        <option value="Socials">Socials</option>
        <option value="Funding">Funding</option>
        <option value="IT Gadget">IT Gadget</option>
      </select>
    </div>
  </div>

  <div class="row">
    <div class="col">
      <label>Transaction Type</label>
      <select name="txn_type" id="trans-value" required>
        <option value="">Please select</option>
        <option value="Debit">Debit</option>
        <option value="Credit">Credit</option>
      </select>
    </div>
  </div>

  <div class="row">
    <div class="col">
      <label>Balance</label>
      <input type="number" name="balance" readonly value="0" />
    </div>
    <div class="col">
      <label>Total Price</label>
      <input type="number" name="total_price" placeholder="Enter amount" required />
    </div>
  </div>

  <button type="submit" class="save-btn">Save</button>
</form>

  </div>
</div>
<div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">View Expense</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Date</label>
          <input type="date" value="2024-05-25" readonly />
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Description</label>
          <textarea rows="4" readonly placeholder="Description...">
                  Website Review</textarea>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Category</label>
          <select name="category">
            <option value="Telecoms">Telecoms</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Quantity</label>
          <input type="number" value="40000" readonly />
        </div>
        <div class="col">
          <label>Unit Price</label>
          <input type="number" value="10000" readonly />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Credit Amount</label>
          <input type="number" value="40000" readonly />
        </div>
        <div class="col">
          <label>Transaction Type</label>
          <select name="transaction_type" id="trans-value">
            <option value="Credit">Credit</option>
          </select>

        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Balance</label>
          <input type="number" readonly value="0" />
        </div>
        <div class="col">
          <label>Total Price</label>
          <input type="number" readonly value="0" />
        </div>
      </div>
    </form>
  </div>
</div>
<div class="modal2">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Expense</h2>
    <form id="edit-expense-form" action="../backend/cash-flow/expenses/edit_expense.php" method="POST">
  <input type="hidden" name="id" id="edit-id" />
  <div class="row">
    <div class="col">
      <label>Date</label>
      <input type="date" name="date" id="edit-date" />
    </div>
  </div>
  <div class="row">
    <div class="col">
      <label>Description</label>
      <input type="text" name="description" id="edit-description" />
    </div>
  </div>
  <div class="row">
    <div class="col">
      <label>Category</label>
      <select name="category" id="edit-category">
        <option value="Fuel">Fuel</option>
        <option value="Telecoms">Telecoms</option>
        <option value="Transport">Transport</option>
        <option value="Repairs">Repairs</option>
        <option value="Water">Water</option>
        <option value="Socials">Socials</option>
        <option value="Funding">Funding</option>
        <option value="IT Gadget">IT Gadget</option>
      </select>
    </div>
  </div>
  <div class="row">
    <div class="col">
      <label>Transaction Type</label>
      <select name="txn_type" id="edit-txn-type">
        <option value="Debit">Debit</option>
        <option value="Credit">Credit</option>
      </select>
    </div>
  </div>
  <div class="row">
    <div class="col">
      <label>Quantity</label>
      <input type="number" name="quantity" id="edit-quantity" />
    </div>
    <div class="col">
      <label>Unit Price</label>
      <input type="number" name="unit_price" id="edit-unit-price" />
    </div>
  </div>
  <button type="submit" class="save-btn">Update</button>
</form>

  </div>
</div>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php require('../components/common_header.php')  ?>

  <!-- Your page content goes here -->
  <section class="content" style="overflow-y: hidden">
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Accounting</span>
        <span class="divider"></span>
        <span class="tab active">Expenses</span>
      </div>
      <div class="anb-container">
        <button
          class="add-new-button"
          style="border-radius: 15px">
          Add New Expense
        </button>
      </div>
    </div>
    <div class="row1" style="justify-content: center">
      <div class="row2">
       <div class="row2">
  <div class="col1">
    <button class="fyn-btn" style="background-color: #4caf50" id="credit-summary">
      <!-- <img src="http://crm128.com/app02/assets/icon2/credit.png" /> -->
      <div>
        <strong>Credit</strong>
        <p id="credit-total">&#8358;0.00</p>
      </div>
    </button>
  </div>
  <div class="col1">
    <button class="fyn-btn" style="background-color: rgb(243, 59, 59)" id="debit-summary">
      <!-- <img width="30px" src="http://crm128.com/app02/assets/icon2/debit.png" /> -->
      <div>
        <strong>Debit</strong>
        <p id="debit-total">&#8358;0.00</p>
      </div>
    </button>
  </div>
  <div class="col1">
    <button class="fyn-btn" style="background-color: #007bff" id="balance-summary">
      <!-- <img width="30px" src="http://crm128.com/app02/assets/icon2/balance.png" /> -->
      <div>
        <strong>Balance</strong>
        <p id="balance-total">&#8358;0.00</p>
      </div>
    </button>
  </div>
</div>
      </div>
<!-- Replace your current filter section with this: -->
<div class="row2">
  <div class="col1">
    <div class="search-input-wrapper">
      <svg viewBox="0 0 24 24">
        <path d="M10 2a8 8 0 105.29 14.29l4.3 4.3 1.42-1.42-4.30-4.30A8 8 0 0010 2zm0 2a6 6 0 110 12A6 6 0 0110 4z" />
      </svg>
      <input type="text" id="search-input" placeholder="Search" style="background-color: white; border: 1px solid #4caf50" />
    </div>
  </div>
  <div class="col1">
    <select id="year-filter">
      <option value="" selected style="display: none">Year</option>
      <option value="all">All</option>
      <option value="2024">2024</option>
      <option value="2023">2023</option>
      <!-- Add more years as needed -->
    </select>
  </div>
</div>

<div class="row2">
  <div class="col1">
    <select id="month-filter">
      <option value="" selected style="display: none">Month</option>
      <option value="all">All</option>
      <option value="01">January</option>
      <option value="02">February</option>
      <option value="03">March</option>
      <option value="04">April</option>
      <option value="05">May</option>
      <option value="06">June</option>
      <option value="07">July</option>
      <option value="08">August</option>
      <option value="09">September</option>
      <option value="10">October</option>
      <option value="11">November</option>
      <option value="12">December</option>
    </select>
  </div>
  <div class="col1">
    <select id="category-filter" class="filter-select">
      <option value="" selected style="display: none">Category</option>
      <option value="all">All</option>
      <option value="Fuel">Fuel</option>
      <option value="Telecoms">Telecoms</option>
      <option value="Transport">Transport</option>
      <option value="Repairs">Repairs</option>
      <option value="Water">Water</option>
      <option value="Socials">Socials</option>
      <option value="Funding">Funding</option>
      <option value="IT Gadget">IT Gadget</option>
    </select>
  </div>
</div>
    </div>

    <div class="over-table">
      <table>
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>S/N</th>
            <th>Date</th>
            <th>Description</th>
            <th>Category</th>
            <th>Txn Type</th>
            <th>Qty</th>
            <th>Unit Price</th>
            <th>Total Price</th>
            <!-- <th>Credit</th>
            <th>Balance</th> -->
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          <?php
            include __DIR__ . '/../settings/connection.php';

            try {
                $stmt = $pdo->prepare("SELECT * FROM expenses");
                $stmt->execute();
                $expenses = $stmt->fetchAll();

                $sn = 1;
                foreach ($expenses as $row):
            ?>
            <tr>
              <td>100<?= htmlspecialchars($row['id']) ?></td>
              <td><?= date('d-m-Y', strtotime($row['date'])) ?></td>
              <td><?= htmlspecialchars($row['description']) ?></td>
              <td><?= htmlspecialchars($row['category_id']) ?></td>
              <td><?= htmlspecialchars($row['transaction_type']) ?></td>
              <td><?= (int)$row['quantity'] ?></td>
              <td>&#8358;<?= number_format($row['unit_price'], 2) ?></td>
              <td>&#8358;<?= number_format($row['total_price'], 2) ?></td>
              <!-- <td>&#8358;<?= number_format($row['credit'], 2) ?></td>
              <td>&#8358;<?= number_format($row['balance'], 2) ?></td> -->
              <td>
              <button class="view-expense-btn" data-id="<?= $row['id'] ?>">
                <img src="../assets/eye-open.png" alt="View" />
              </button>
            </td>

            <td>
              <button class="edit-btn"
                data-id="<?= $row['id'] ?>"
                data-date="<?= $row['date'] ?>"
                data-description="<?= htmlspecialchars($row['description']) ?>"
                data-category="<?= $row['category_id'] ?>"
                data-txn_type="<?= $row['transaction_type'] ?>"
                data-quantity="<?= $row['quantity'] ?>"
                data-unit_price="<?= $row['unit_price'] ?>"
              >
                ✏️
              </button>
            </td>


              <td>
                <button class="delete-btn" data-id="<?= $row['id'] ?>">
                  <img src="../assets/Delete.svg" alt="Delete" />
                </button>
              </td>

            </tr>
            <?php
                endforeach;
            } catch (PDOException $e) {
                echo "<tr><td colspan='13'>Error: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
            }
            ?>


        </tbody>
      </table>
    </div>
  </section>
</div>

<script>
document.querySelectorAll('.view-expense-btn').forEach(button => {
  button.addEventListener('click', function () {
    const id = this.dataset.id;

    fetch('../backend/cash-flow/expenses/get_expense.php?id=' + id)
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          alert(data.error);
          return;
        }

        // Populate modal fields
        document.querySelector('.modal1 input[type="date"]').value = data.date;
        document.querySelector('.modal1 textarea').value = data.description;
        document.querySelector('.modal1 select[name="category"]').innerHTML = `<option value="${data.category_id}">${data.category_id}</option>`;
        document.querySelector('.modal1 input[type="number"][value="40000"]').value = data.quantity;
        document.querySelector('.modal1 input[type="number"][value="10000"]').value = data.unit_price;
        document.querySelector('.modal1 select[name="transaction_type"]').innerHTML = `<option value="${data.transaction_type}">${data.transaction_type}</option>`;

        document.querySelector('.modal1 input[readonly][value="0"]').value = data.total_price;

        // Show the modal
        document.querySelector('.modal1').style.display = 'block';
      });
  });
});

// Close modal
document.querySelector('.close1').addEventListener('click', function () {
  document.querySelector('.modal1').style.display = 'none';
});
</script>
<script>
  document.querySelectorAll('.edit-btn').forEach(button => {
    button.addEventListener('click', () => {
      document.getElementById('edit-id').value = button.dataset.id;
      document.getElementById('edit-date').value = button.dataset.date;
      document.getElementById('edit-description').value = button.dataset.description;
      document.getElementById('edit-category').value = button.dataset.category;
      document.getElementById('edit-txn-type').value = button.dataset.txn_type;
      document.getElementById('edit-quantity').value = button.dataset.quantity;
      document.getElementById('edit-unit-price').value = button.dataset.unit_price;

      document.querySelector('.modal2').style.display = 'block';
    });
  });

  document.querySelector('.close2').addEventListener('click', () => {
    document.querySelector('.modal2').style.display = 'none';
  });
</script>
<script>
  document.querySelectorAll('.delete-btn').forEach(button => {
  button.addEventListener('click', () => {
    const id = button.dataset.id;
    if (confirm("Are you sure you want to delete this expense?")) {
      fetch(`../backend/cash-flow/expenses/delete_expense.php?id=${id}`, {
        method: 'DELETE'
      })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            alert("Expense deleted.");
            window.location.reload(); // Refresh the table
          } else {
            alert("Delete failed.");
          }
        })
        .catch(err => {
          console.error(err);
          alert("Error deleting expense.");
        });
    }
  });
});

</script>
<script>
// Function to format currency with Nigerian Naira symbol
function formatCurrency(amount) {
  return '₦' + amount.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
}

// Function to calculate and update summary totals
function updateSummaryTotals() {
  let creditTotal = 0;
  let debitTotal = 0;

  // Calculate totals from visible rows only
  document.querySelectorAll('table tbody tr').forEach(row => {
    if (row.style.display !== "none") {
      const txnType = row.cells[4].textContent.trim();
      const totalPriceText = row.cells[7].textContent;
      const totalPrice = parseFloat(totalPriceText.replace(/[^\d.-]/g, '')) || 0;

      if (txnType === "Credit") {
        creditTotal += totalPrice;
      } else if (txnType === "Debit") {
        debitTotal += totalPrice;
      }
    }
  });

  // Update the UI
  document.getElementById('credit-total').textContent = formatCurrency(creditTotal);
  document.getElementById('debit-total').textContent = formatCurrency(debitTotal);
  document.getElementById('balance-total').textContent = formatCurrency(creditTotal - debitTotal);
}

// Function to setup summary button click handlers (only once)
function setupSummaryButtons() {
  document.getElementById('credit-summary').addEventListener('click', () => {
    document.getElementById('category-filter').value = 'all';
    document.getElementById('year-filter').value = 'all';
    document.getElementById('month-filter').value = 'all';
    if (document.getElementById('transaction-type-filter')) {
      document.getElementById('transaction-type-filter').value = 'Credit';
    }
    applyFilters();
  });

  document.getElementById('debit-summary').addEventListener('click', () => {
    document.getElementById('category-filter').value = 'all';
    document.getElementById('year-filter').value = 'all';
    document.getElementById('month-filter').value = 'all';
    if (document.getElementById('transaction-type-filter')) {
      document.getElementById('transaction-type-filter').value = 'Debit';
    }
    applyFilters();
  });

  document.getElementById('balance-summary').addEventListener('click', () => {
    document.getElementById('category-filter').value = 'all';
    document.getElementById('year-filter').value = 'all';
    document.getElementById('month-filter').value = 'all';
    if (document.getElementById('transaction-type-filter')) {
      document.getElementById('transaction-type-filter').value = 'all';
    }
    applyFilters();
  });
}

document.addEventListener('DOMContentLoaded', () => {
  // Initialize filters with current year
  const currentYear = new Date().getFullYear();
  const yearFilter = document.getElementById('year-filter');
  if (!yearFilter.querySelector(`option[value="${currentYear}"]`)) {
    const option = document.createElement('option');
    option.value = currentYear;
    option.textContent = currentYear;
    yearFilter.insertBefore(option, yearFilter.children[2]);
  }

  // Get all table rows
  const rows = document.querySelectorAll('.leads-table tbody tr');

  // Function to apply all filters
  function applyFilters() {
    const search = document.getElementById('search-input').value.toLowerCase();
    const year = document.getElementById('year-filter').value;
    const month = document.getElementById('month-filter').value;
    const category = document.getElementById('category-filter').value;
    const txnType = document.getElementById('transaction-type-filter') ? 
                   document.getElementById('transaction-type-filter').value : 'all';

    rows.forEach(row => {
      const date = row.children[1].textContent;
      const description = row.children[2].textContent.toLowerCase();
      const rowCategory = row.children[3].textContent;
      const rowTxnType = row.children[4].textContent;

      // Extract year and month from date (format: YYYY-MM-DD)
      const dateParts = date.split('-');
      const rowYear = dateParts[0];
      const rowMonth = dateParts[1];

      // Check if row matches all filters
      const matchesSearch = description.includes(search) || search === '';
      const matchesYear = year === "all" || year === "" || rowYear === year;
      const matchesMonth = month === "all" || month === "" || rowMonth === month;
      const matchesCategory = category === "" || category === "all" || rowCategory === category;
      const matchesTxnType = txnType === "all" || rowTxnType === txnType;

      // Show/hide row based on filters
      row.style.display = (matchesSearch && matchesYear && matchesMonth && 
                         matchesCategory && matchesTxnType) ? "" : "none";
    });

    // Update the totals display
    updateSummaryTotals();
  }

  // Add event listeners to all filter controls
  document.getElementById('search-input').addEventListener('input', applyFilters);
  document.getElementById('year-filter').addEventListener('change', applyFilters);
  document.getElementById('month-filter').addEventListener('change', applyFilters);
  document.getElementById('category-filter').addEventListener('change', applyFilters);
  if (document.getElementById('transaction-type-filter')) {
    document.getElementById('transaction-type-filter').addEventListener('change', applyFilters);
  }

  // Setup summary button handlers
  setupSummaryButtons();

  // Initialize the view
  applyFilters();
});
</script>
<style>
   colgroup col:nth-child(1) {
    width: 80px;
  }

  colgroup col:nth-child(2) {
    width: 100px;
  }

  colgroup col:nth-child(3) {
    width: 120px;
  }

  colgroup col:nth-child(4) {
    width: 120px;
  }

  colgroup col:nth-child(5) {
    width: 100px;
  }

  colgroup col:nth-child(6) {
    width: 70px;
  }

  colgroup col:nth-child(7) {
    width: 100px;
  }

  colgroup col:nth-child(8) {
    width: 100px;
  }

  colgroup col:nth-child(9) {
    width: 50px;
  }

  colgroup col:nth-child(10) {
    width: 50px;
  }

  colgroup col:nth-child(11) {
    width: 60px;
  }
</style>
<?php require('../components/cashflow_footer.php')  ?>