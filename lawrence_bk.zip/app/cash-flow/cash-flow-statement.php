<?php require('../components/header.php')  ?>

<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php require('../components/common_header.php')  ?>

  <!-- Your page content goes here -->
  <section class="content" style="overflow: hidden">
    <!-- Tabs for Clients and Leads -->
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Accounting Management</span>
        <span class="divider"></span>
        <span class="tab active">Cash Flow Statement</span>
      </div>

      <div class="anb-container">
        <button
          class="add-new-button add-new-income"
          style="border-radius: 15px">
          Print Report
        </button>
      </div>
    </div>
    <div class="row1">
      <div class="row2">
        <div class="col1">
          <label>Start Date</label>
          <input type="date" placeholder="dd/mm/yyyy" />
        </div>
        <div class="col1">
          <label>End Date</label>
          <input type="date" placeholder="dd/mm/yyyy" />
        </div>
      </div>

      <div class="row2">
        <div class="col1">
          <label>Activity Type</label>
          <select>
            <option value="all">All</option>
            <option value="lead">Lead</option>
            <option value="customer">Customer</option>
            <option value="partner">Partner</option>
          </select>
        </div>
      </div>
    </div>
    <!-- Table for Leads -->
    <div class="over-table">
      <table class="leads-table">
        <thead>
          <tr>
            <th>Date Added</th>
            <th>Description</th>
            <th>Department</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>2024-01-15</td>
            <td>Website</td>
            <td>Lead</td>
            <td>$500</td>
          </tr>
          <tr>
            <td>2024-01-20</td>
            <td>Social Media</td>
            <td>Customer</td>
            <td>$300</td>
          </tr>
          <tr>
            <td>2024-01-25</td>
            <td>Referral</td>
            <td>Partner</td>
            <td>$700</td>
          </tr>
          <tr>
            <td>2024-02-01</td>
            <td>Advertisement</td>
            <td>Lead</td>
            <td>$400</td>
          </tr>
          <tr>
            <td>2024-01-15</td>
            <td>Website</td>
            <td>Lead</td>
            <td>$500</td>
          </tr>
          <tr>
            <td>2024-01-20</td>
            <td>Social Media</td>
            <td>Customer</td>
            <td>$300</td>
          </tr>
          <tr>
            <td>2024-01-25</td>
            <td>Referral</td>
            <td>Partner</td>
            <td>$700</td>
          </tr>
          <tr>
            <td>2024-02-01</td>
            <td>Advertisement</td>
            <td>Lead</td>
            <td>$400</td>
          </tr>
          <tr>
            <td>2024-01-15</td>
            <td>Website</td>
            <td>Lead</td>
            <td>$500</td>
          </tr>
          <tr>
            <td>2024-01-20</td>
            <td>Social Media</td>
            <td>Customer</td>
            <td>$300</td>
          </tr>
          <tr>
            <td>2024-01-25</td>
            <td>Referral</td>
            <td>Partner</td>
            <td>$700</td>
          </tr>
          <tr>
            <td>2024-02-01</td>
            <td>Advertisement</td>
            <td>Lead</td>
            <td>$400</td>
          </tr>
        </tbody>
      </table>
    </div>
    <!-- <div class="tabs">
          <div style="align-items: center; display: flex">
            <span class="tab">Total No of Leads: 26</span>
            <span class="divider"></span>
            <span class="tab active">Total No of Clients: 7</span>
          </div>

          <button class="add-new-button">Print Report</button>
        </div> -->
  </section>
</div>

<?php require('../components/common_footer.php')  ?>