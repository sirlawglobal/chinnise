<?php
include_once '../../settings/connection.php';
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // Handle search and filter
        $search = isset($_GET['search']) ? $_GET['search'] : '';
        $year = isset($_GET['year']) ? $_GET['year'] : '';
        $month = isset($_GET['month']) ? $_GET['month'] : '';
        
        $query = "SELECT * FROM incomes WHERE 1=1";
        $params = [];
        
        if (!empty($search)) {
            $query .= " AND (client_name LIKE :search OR description LIKE :search)";
            $params[':search'] = "%$search%";
        }
        
        if (!empty($year) && $year != 'all') {
            $query .= " AND YEAR(date) = :year";
            $params[':year'] = $year;
        }
        
        if (!empty($month) && $month != 'all') {
            $query .= " AND MONTH(date) = :month";
            $params[':month'] = $month;
        }
        
        $query .= " ORDER BY id ASC";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $incomes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate total income
        $totalStmt = $pdo->prepare("SELECT SUM(amount_received) as total FROM incomes");
        $totalStmt->execute();
        $total = $totalStmt->fetch(PDO::FETCH_ASSOC)['total'];
        
        echo json_encode([
            'incomes' => $incomes,
            'total' => $total
        ]);
        break;
        
    case 'POST':
        // Create new income
        $data = json_decode(file_get_contents('php://input'), true);
        
        $stmt = $pdo->prepare("INSERT INTO incomes (date, client_name, project_value, amount_received, description) 
                              VALUES (:date, :client_name, :project_value, :amount_received, :description)");
        $stmt->execute([
            ':date' => $data['date'],
            ':client_name' => $data['client_name'],
            ':project_value' => $data['project_value'],
            ':amount_received' => $data['amount_received'],
            ':description' => $data['description']
        ]);
        
        echo json_encode(['message' => 'Income added successfully', 'id' => $pdo->lastInsertId()]);
        break;
        
    case 'PUT':
        // Update income
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $_GET['id'];
        
        $stmt = $pdo->prepare("UPDATE incomes SET 
                              date = :date, 
                              client_name = :client_name, 
                              project_value = :project_value, 
                              amount_received = :amount_received, 
                              description = :description 
                              WHERE id = :id");
        $stmt->execute([
            ':date' => $data['date'],
            ':client_name' => $data['client_name'],
            ':project_value' => $data['project_value'],
            ':amount_received' => $data['amount_received'],
            ':description' => $data['description'],
            ':id' => $id
        ]);
        
        echo json_encode(['message' => 'Income updated successfully']);
        break;
        
    case 'DELETE':
        // Delete income
        $id = $_GET['id'];
        
        $stmt = $pdo->prepare("DELETE FROM incomes WHERE id = :id");
        $stmt->execute([':id' => $id]);
        
        echo json_encode(['message' => 'Income deleted successfully']);
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}
?>