<?php
require_once('../../../settings/connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && isset($_GET['id'])) {
  $id = $_GET['id'];
  $stmt = $pdo->prepare("DELETE FROM expenses WHERE id = ?");
  if ($stmt->execute([$id])) {
    echo json_encode(['success' => true]);
  } else {
    echo json_encode(['success' => false]);
  }
} else {
  http_response_code(400);
  echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
?>
