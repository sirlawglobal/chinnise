<?php
require_once '../../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $date = $_POST['date'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $txn_type = $_POST['txn_type'];
    $quantity = floatval($_POST['quantity']);
    $unit_price = floatval($_POST['unit_price']);

    $total = $quantity * $unit_price;

    try {
        $stmt = $pdo->prepare("UPDATE expenses SET date = ?, description = ?, category_id = ?, transaction_type = ?, quantity = ?, unit_price = ?, total_price = ? WHERE id = ?");
        $stmt->execute([$date, $description, $category, $txn_type, $quantity, $unit_price, $total, $id]);

        // Redirect with success
        header("Location: ../../../cash-flow/expense.php?success=1");
        exit();
    } catch (PDOException $e) {
        echo "Error updating expense: " . $e->getMessage();
    }
} else {
    echo "Invalid request method.";
}
