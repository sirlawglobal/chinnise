<?php
require_once __DIR__ . '/../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /');
    exit;
}

// Validate required fields
$requiredFields = ['expense_id', 'date', 'description', 'category', 'txn_type', 'quantity', 'unit_price', 'total_price'];
foreach ($requiredFields as $field) {
    if (empty($_POST[$field])) {
        die(json_encode(['success' => false, 'message' => "All fields are required"]));
    }
}

$expenseId = $_POST['expense_id'];
$date = $_POST['date'];
$description = $_POST['description'];
$category = $_POST['category'];
$txnType = $_POST['txn_type'];
$quantity = (int)$_POST['quantity'];
$unitPrice = (float)$_POST['unit_price'];
$totalPrice = (float)$_POST['total_price'];

try {
    $stmt = $pdo->prepare("UPDATE expenses SET 
        date = ?, 
        description = ?, 
        category = ?, 
        transaction_type = ?, 
        quantity = ?, 
        unit_price = ?, 
        total_price = ?,
        updated_at = NOW()
        WHERE expense_id = ?");
    
    $success = $stmt->execute([
        $date,
        $description,
        $category,
        $txnType,
        $quantity,
        $unitPrice,
        $totalPrice,
        $expenseId
    ]);

    if ($success) {
        echo json_encode(['success' => true, 'message' => 'Expense updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update expense']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>