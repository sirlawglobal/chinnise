<?php
require '../../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $txn_type = $_POST['txn_type'];
    $total_price = floatval($_POST['total_price']);
    $balance = floatval($_POST['balance']);

    // You can customize these
    $qty = 1;
    $unit_price = $total_price;
    $credit = 0;

    if (strtolower($txn_type) === 'credit') {
        $credit = $total_price;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO expenses (date, description, category_id, transaction_type, quantity, unit_price, total_price)
                               VALUES (:date, :description, :category, :txn_type, :qty, :unit_price, :total_price)");

        $stmt->execute([
            ':date' => $date,
            ':description' => $description,
            ':category' => $category,
            ':txn_type' => $txn_type,
            ':qty' => $qty,
            ':unit_price' => $unit_price,
            ':total_price' => $total_price,
        ]);

        header("Location: ../../../cash-flow/expense.php?success=1");
        exit;
    } catch (PDOException $e) {
        echo "Error saving expense: " . $e->getMessage();
    }
}
?>
