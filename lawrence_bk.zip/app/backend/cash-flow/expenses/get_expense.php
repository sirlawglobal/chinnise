<?php
require '../../../settings/connection.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $stmt = $pdo->prepare("SELECT * FROM expenses WHERE id = ?");
    $stmt->execute([$id]);
    $expense = $stmt->fetch();

    if ($expense) {
        echo json_encode($expense);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Expense not found']);
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'No ID provided']);
}
