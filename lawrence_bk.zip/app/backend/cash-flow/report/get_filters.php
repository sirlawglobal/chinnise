<?php
require '../../../settings/connection.php';

$categories = $pdo->query("SELECT DISTINCT category FROM incomes WHERE category IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);
$departments = $pdo->query("SELECT DISTINCT department FROM incomes WHERE department IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);

echo json_encode([
    'categories' => $categories,
    'departments' => $departments
]);
?>
