<?php
require '../../../settings/connection.php';

$start = $_GET['start'] ?? null;
$end = $_GET['end'] ?? null;

$sql = "SELECT date as date_added, description, client_name, project_value, amount_received FROM incomes WHERE 1";
$params = [];

if ($start) {
    $sql .= " AND date >= :start";
    $params['start'] = $start;
}
if ($end) {
    $sql .= " AND date <= :end";
    $params['end'] = $end;
}

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $incomes = $stmt->fetchAll();

    if (!empty($incomes)) {
        foreach ($incomes as $row) {
            echo "<tr>
                <td>" . htmlspecialchars($row['date_added']) . "</td>
                <td>" . htmlspecialchars($row['description']) . "</td>
                <td>" . htmlspecialchars($row['client_name']) . "</td>
                <td>" . htmlspecialchars($row['project_value']) . "</td>
                <td>" . number_format($row['amount_received'], 2) . "</td>
              </tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No income records found.</td></tr>";
    }
} catch (PDOException $e) {
    echo "<tr><td colspan='5'>Query failed: " . $e->getMessage() . "</td></tr>";
}
