<?php
header('Content-Type: application/json');
include_once '../../settings/connection.php';

// SQL query to count appointments for each day
// We use GROUP BY on the date part of the 'start' column
$query = "
    SELECT 
        COUNT(id) as title, 
        DATE(start) as start 
    FROM 
        appointments 
    GROUP BY 
        DATE(start)
";

$stmt = $pdo->query($query);
$eventCounts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// We need to format this for FullCalendar's event parsing.
// We'll use the count as the 'title' for simplicity.
// foreach ($eventCounts as &$event) {
// $event['title'] = $event['eventCount']; // The title will be the number of events
// $event['display'] = 'none'; // Hide the default event rendering
// }


echo json_encode($eventCounts);
