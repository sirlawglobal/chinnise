<?php
include_once '../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $start = $_POST['start'] ?? '';
    $end = $_POST['end'] ?? '';
    $description = $_POST['description'] ?? '';

    if ($title && $start && $end) {
        $stmt = $pdo->prepare("INSERT INTO appointments (title, start, end, description) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$title, $start, $end, $description])) {
            header("Location: ../../appointments.php"); // redirect back to calendar
            exit;
        } else {
            echo "Failed to save appointment.";
        }
    } else {
        echo "All fields are required.";
    }
}
