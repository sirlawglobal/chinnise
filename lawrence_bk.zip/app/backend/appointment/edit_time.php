<?php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

// Get POST data

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$id = $data['id'] ?? null;
$title = $data['title'] ?? '';
$start = $data['start'] ?? '';
$end = $data['end'] ?? '';
$description = $data['description'] ?? '';



try {
    $stmt = $pdo->prepare("UPDATE appointments SET title = ?, start = ?, end = ?, description = ? WHERE id = ?");
    $stmt->execute([$title, $start, $end, $description, $id]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'No changes made or event not found', 'data' => [$title, $start, $end, $description, $id]]);
    }
} catch (Exception $e) {
    http_response_code(500);
    file_put_contents(
        __DIR__ . '/events_error.log',
        date('Y-m-d H:i:s') . " - Error fetching events: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    echo json_encode(['success' => false, 'error' => 'Failed to update event']);
}
