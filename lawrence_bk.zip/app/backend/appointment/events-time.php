<?php


include_once '../../settings/connection.php';
header('Content-Type: application/json');

$date = $_GET['start'] ?? null;

if (!$date) {
    echo json_encode(['success' => false, 'error' => 'Missing start parameter']);
    exit;
}

try {
    // Assuming 'start' is a DATETIME or DATE column
    $stmt = $pdo->prepare("SELECT id,start,title,end as todate ,description FROM appointments WHERE DATE(`start`) = ?");
    $stmt->execute([$date]);
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($events);
} catch (Exception $e) {
    http_response_code(500);
    file_put_contents(
        __DIR__ . '/events_error.log',
        date('Y-m-d H:i:s') . " - Error fetching events: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    echo json_encode(['success' => false, 'error' => 'Failed to fetch events']);
}
