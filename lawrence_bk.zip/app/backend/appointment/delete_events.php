<?php
// filepath: d:\xampp\htdocs\crm128\backend\appointment\delete_events.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

$id = $_GET['id'] ?? null;

if (!$id) {
    echo json_encode(['success' => false, 'error' => 'Missing id parameter']);
    exit;
}

try {
    $stmt = $pdo->prepare("DELETE FROM appointments WHERE id = ?");
    $stmt->execute([$id]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Event not found or already deleted']);
    }
} catch (Exception $e) {
    http_response_code(500);
    file_put_contents(
        __DIR__ . '/events_error.log',
        date('Y-m-d H:i:s') . " - Error deleting event: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    echo json_encode(['success' => false, 'error' => 'Failed to delete event']);
}
