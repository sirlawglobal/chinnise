<?php

include_once 'settings/connection.php';

try {
    // Count active clients
    $stmt1 = $pdo->query("SELECT COUNT(*) FROM leads WHERE client_type = 'client' AND status = 'active'");
    $activeClients = $stmt1->fetchColumn();

    // Count active leads
    $stmt2 = $pdo->query("SELECT COUNT(*) FROM leads WHERE client_type = 'leads' AND status = 'active'");
    $activeLeads = $stmt2->fetchColumn();

    $stmt3 = $pdo->query("SELECT COUNT(*) FROM leads WHERE client_type = 'client' AND status = 'inactive'");
    $inactiveClients = $stmt3->fetchColumn();

    $stmt4 = $pdo->query("SELECT COUNT(*) FROM leads WHERE client_type = 'leads' AND status = 'inactive'");
    $inactiveleads = $stmt4->fetchColumn();

    $stmt5 = $pdo->query("SELECT COUNT(*) FROM timesheet");
    $time = $stmt5->fetchColumn();

    $stmt6 = $pdo->query("SELECT COUNT(*) FROM timesheet WHERE time_in <= '09:00:00'");
    $early = $stmt6->fetchColumn();

    $stmt7 = $pdo->query("SELECT COUNT(*) FROM timesheet WHERE time_in > '09:00:00'");
    $late = $stmt7->fetchColumn();

    $stmt8 = $pdo->query("SELECT COUNT(*) FROM leave_requests");
    $leave = $stmt8->fetchColumn();

    $stmt9 = $pdo->query("SELECT COUNT(*) FROM leave_requests WHERE gender = 'male'");
    $leave_male = $stmt9->fetchColumn();

    $stmt10 = $pdo->query("SELECT COUNT(*) FROM leave_requests WHERE gender = 'female'");
    $leave_female = $stmt10->fetchColumn();

// Assuming $pdo is your PDO connection object

// 1. Get Total Incomes
$stmt11 = $pdo->query("SELECT SUM(amount_received) AS total_incomes FROM incomes");
$totalIncomes = $stmt11->fetchColumn();
// Ensure it's treated as a number, especially if SUM could return null for no rows
$totalIncomes = (float) $totalIncomes; 

// 2. Get Total Expenses
$stmt12 = $pdo->query("SELECT SUM(total_price) AS total_expenses FROM expenses"); // Changed alias for clarity
$totalExpenses = $stmt12->fetchColumn();
// Ensure it's treated as a number
$totalExpenses = (float) $totalExpenses; 

// 3. Calculate Net Income (stmt11 - stmt12 equivalent)
$netIncome = $totalIncomes - $totalExpenses;



$stmt13 = $pdo->query("SELECT COUNT(*) FROM leave_requests WHERE gender = 'female'");
$emp_female = $stmt13->fetchColumn();

// echo "Total Incomes: " . $totalIncomes . "<br>";
// echo "Total Expenses: " . $totalExpenses . "<br>";
// echo "Net Income: " . $netIncome;


// Now $totalIncomes will hold the numerical sum of amount_received
// echo "Total Incomes: " . $totalIncomes;

    // $stmt10 = $pdo->query("SELECT * FROM incomes WHERE SUM(amount_received)");
    // $incomes = $stmt10->fetchColumn();
    // Calculate average deal value (only if such a column exists)
    // $stmt3 = $pdo->query("SELECT AVG(deal_value) FROM leads WHERE status = 'won'");
    // $avgValue = $stmt3->fetchColumn();

    // Default fallback if null
    // $avgValue = $avgValue ? number_format($avgValue, 0) : "0";
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
