<?php

include_once '../settings/connection.php';

header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT
        (SELECT COALESCE(SUM(quantity), 0) FROM `customer_return_items`)
        AS total_creturns");

    $stmt1 = $pdo->query("SELECT
         
        (SELECT COALESCE(SUM(quantity), 0) FROM `supplier_return_items`)
        AS total_sreturns");
    $stmt2 = $pdo->query("SELECT COUNT(*) AS total_stock FROM `stocks`");

    // Fetch the result
    $total_stock = $stmt2->fetch(PDO::FETCH_ASSOC);

    $total_orders = $stmt->fetch(PDO::FETCH_ASSOC);
    $total_returns = $stmt1->fetch(PDO::FETCH_ASSOC);

    $data = [];

    $data['creturns'] = ($total_orders && $total_orders['total_creturns'] > 0) ? (int)$total_orders['total_creturns'] : 0;

    $data['sreturns'] = ($total_returns && $total_returns['total_sreturns'] > 0) ? (int)$total_returns['total_sreturns'] : 0;
    $data['stocks'] = ($total_stock && $total_stock['total_stock'] > 0) ? (int)$total_stock['total_stock'] : null;
    $data['returns'] = $data['creturns'] + $data['sreturns'];

    echo json_encode(['success' => true, 'data' => $data]);
} catch (Exception $e) {

    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Fetch Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch inventory data']);
}
