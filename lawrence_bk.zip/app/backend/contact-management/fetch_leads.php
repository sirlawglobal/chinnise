<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Not logged in, redirect to login page (consider returning an error for AJAX requests)
    // For AJAX, you might return a JSON error and handle redirection on the client-side.
    header("Location: ../../auth/login.php");
    exit;
}

include_once '../../settings/connection.php';

// Get current page number from query parameter, default to 1
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max(1, $page); // Ensure page is at least 1

// Get rows per page from query parameter, default to 10
$rows_per_page = isset($_GET['rows_per_page']) ? (int)$_GET['rows_per_page'] : 10;
// Validate rows_per_page to be within a reasonable range (e.g., 5 to 100)
$rows_per_page = max(5, min(100, $rows_per_page));

// Calculate offset
$offset = ($page - 1) * $rows_per_page;

try {
    // Get total number of leads
    $countStmt = $pdo->query("SELECT COUNT(*) FROM leads WHERE client_type = 'leads'");
    $totalLeads = $countStmt->fetchColumn();

    // Calculate total pages
    $totalPages = ceil($totalLeads / $rows_per_page);

    // Fetch leads for the current page
    $stmt = $pdo->prepare("SELECT * FROM leads WHERE client_type = 'leads' ORDER BY id ASC LIMIT :limit OFFSET :offset");
    $stmt->bindParam(':limit', $rows_per_page, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $leads = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'leads' => $leads,
        'currentPage' => $page,
        'totalPages' => $totalPages,
        'totalLeads' => $totalLeads,
        'rowsPerPage' => $rows_per_page
    ]);

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => "Database error: " . $e->getMessage()
    ]);
}
?>