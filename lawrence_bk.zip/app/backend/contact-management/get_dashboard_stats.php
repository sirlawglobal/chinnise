<?php

// include_once '../settings/connection.php';
require_once(__DIR__ . '/../../settings/connection.php');

try {
    // Count active clients
    $stmt1 = $pdo->query("SELECT COUNT(*) FROM leads WHERE client_type = 'client' AND status = 'active'");
    $activeClients = $stmt1->fetchColumn();

    // Count active leads
    $stmt2 = $pdo->query("SELECT COUNT(*) FROM leads WHERE client_type = 'leads'");
    $activeLeads = $stmt2->fetchColumn();

    // Calculate average deal value (only if such a column exists)
    // $stmt3 = $pdo->query("SELECT AVG(deal_value) FROM leads WHERE status = 'won'");
    // $avgValue = $stmt3->fetchColumn();

    // Default fallback if null
    // $avgValue = $avgValue ? number_format($avgValue, 0) : "0";
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
