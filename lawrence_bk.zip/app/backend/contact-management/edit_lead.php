<?php
include_once '../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $sql = "UPDATE leads SET 
      company_name = :company_name,
      contact_title = :contact_title,
      contact_surname = :contact_surname,
      contact_firstname = :contact_firstname,
      email = :email,
      company_category = :company_category,
      position = :position,
      address = :address,
      source = :source,
      modified_date = :modified_date,
      phone_number = :phone_number,
      status = :status
    WHERE id = :id";

  $stmt = $pdo->prepare($sql);
  $stmt->execute([
    ':company_name' => $_POST['company_name'],
    ':contact_title' => $_POST['contact_title'],
    ':contact_surname' => $_POST['contact_surname'],
    ':contact_firstname' => $_POST['contact_firstname'],
    ':email' => $_POST['email'],
    ':company_category' => $_POST['company_category'],
    ':position' => $_POST['position'],
    ':address' => $_POST['address'],
    ':source' => $_POST['source'],
    ':modified_date' => $_POST['modified_date'],
    ':phone_number' => $_POST['phone_number'],
    ':status' => $_POST['status'],
    ':id' => $_POST['id']
  ]);

  echo json_encode(['success' => true]);
}
?>
