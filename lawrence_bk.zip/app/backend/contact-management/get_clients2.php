<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
// require_once '../../settings/connection.php'; // Adjust path as needed
require_once(__DIR__ . '/../../settings/connection.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

try {
    // Get pagination parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $rowsPerPage = isset($_GET['rows_per_page']) ? (int)$_GET['rows_per_page'] : 25;
    $offset = ($page - 1) * $rowsPerPage;

    // Count total records
    $countStmt = $pdo->query("SELECT COUNT(*) FROM leads WHERE client_type = 'client'");
    $totalRecords = $countStmt->fetchColumn();
    $totalPages = ceil($totalRecords / $rowsPerPage);

    // Fetch paginated records
    $stmt = $pdo->prepare("SELECT * FROM leads WHERE client_type = 'client' LIMIT :offset, :rowsPerPage");
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindParam(':rowsPerPage', $rowsPerPage, PDO::PARAM_INT);
    $stmt->execute();
    $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // echo json_encode([
    //     'success' => true,
    //     'clients' => $clients,
    //     'currentPage' => $page,
    //     'totalPages' => $totalPages,
    //     'totalRecords' => $totalRecords
    // ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>