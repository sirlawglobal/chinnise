<?php
include_once '../../settings/connection.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $data) {
  // Check for duplicates based on email and/or company_name
  $checkSql = "SELECT COUNT(*) FROM leads WHERE email = :email OR company_name = :company_name";
  $checkStmt = $pdo->prepare($checkSql);
  $checkStmt->execute([
    ':email' => $data['email'],
    ':company_name' => $data['company_name']
  ]);

  $count = $checkStmt->fetchColumn();

  if ($count > 0) {
    echo json_encode([
      'success' => false,
      'message' => 'Duplicate entry.'
    ]);
    exit;
  }

  // Proceed to insert if not duplicate
  $sql = "INSERT INTO leads (
      company_name, contact_title, contact_surname, contact_firstname,
      email, company_category, position, address, source,
      modified_date, phone_number, status
  ) VALUES (
      :company_name, :contact_title, :contact_surname, :contact_firstname,
      :email, :company_category, :position, :address, :source,
      :modified_date, :phone_number, :status
  )";

  $stmt = $pdo->prepare($sql);
  $stmt->execute([
    ':company_name' => $data['company_name'],
    ':contact_title' => $data['contact_title'],
    ':contact_surname' => $data['contact_surname'],
    ':contact_firstname' => $data['contact_firstname'],
    ':email' => $data['email'],
    ':company_category' => $data['company_category'],
    ':position' => $data['position'],
    ':address' => $data['address'],
    ':source' => $data['source'],
    ':modified_date' => $data['modified_date'],
    ':phone_number' => $data['phone_number'],
    ':status' => $data['status']
  ]);

  echo json_encode(['success' => true]);
} else {
  echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>
