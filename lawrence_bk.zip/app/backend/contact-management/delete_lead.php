<?php
include_once '../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $stmt = $pdo->prepare("DELETE FROM leads WHERE id = :id");
  $stmt->execute([':id' => $_POST['id']]);

  echo json_encode(['success' => true]);
}
?>
