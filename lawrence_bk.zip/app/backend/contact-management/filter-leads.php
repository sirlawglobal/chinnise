<?php
include_once '../../settings/connection.php';

$page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
$rowsPerPage = isset($_POST['rows_per_page']) ? (int)$_POST['rows_per_page'] : 25;
$offset = ($page - 1) * $rowsPerPage;

$startDate = $_POST['start_date'] ?? null;
$endDate = $_POST['end_date'] ?? null;
$source = $_POST['source'] ?? 'all';
$clientType = $_POST['client_type'] ?? 'all';

$sql = "SELECT * FROM leads WHERE 1=1";
$countSql = "SELECT COUNT(*) FROM leads WHERE 1=1";
$params = [];
$countParams = [];

if (!empty($startDate)) {
  $sql .= " AND DATE(created_at) >= :start_date";
  $countSql .= " AND DATE(created_at) >= :start_date";
  $params['start_date'] = $countParams['start_date'] = $startDate;
}

if (!empty($endDate)) {
  $sql .= " AND DATE(created_at) <= :end_date";
  $countSql .= " AND DATE(created_at) <= :end_date";
  $params['end_date'] = $countParams['end_date'] = $endDate;
}

if ($source !== 'all') {
  $sql .= " AND source = :source";
  $countSql .= " AND source = :source";
  $params['source'] = $countParams['source'] = $source;
}

if ($clientType !== 'all') {
  $sql .= " AND client_type = :client_type";
  $countSql .= " AND client_type = :client_type";
  $params['client_type'] = $countParams['client_type'] = $clientType;
}

$sql .= " ORDER BY created_at ASC LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($sql);
foreach ($params as $key => $value) {
  $stmt->bindValue(":$key", $value);
}
$stmt->bindValue(':limit', $rowsPerPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$leads = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Count total results
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($countParams);
$totalRows = $countStmt->fetchColumn();
$totalPages = ceil($totalRows / $rowsPerPage);

echo json_encode([
  'success' => true,
  'data' => $leads,
  'totalPages' => $totalPages,
  'currentPage' => $page,
]);
