<?php
require '../../settings/connection.php';
if (!isset($_GET['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing client ID']);
    exit;
}

$id = (int) $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM leads WHERE id = ?");
$stmt->execute([$id]);
$client = $stmt->fetch();

if ($client) {
    echo json_encode($client);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Client not found']);
}
