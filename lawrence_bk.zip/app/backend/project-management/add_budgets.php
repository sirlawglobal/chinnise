<?php
// File: backend/budget/add_budget.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

// Get FormData inputs
$user_id  = $_POST['user_id'] ?? null;
$project_id  = $_POST['project_id'] ?? null;
$cost_type   = $_POST['cost_type'] ?? '';
$cost_item   = trim($_POST['cost_item'] ?? '');
$amount      = $_POST['amount'] ?? 0;
$description = trim($_POST['description'] ?? '');

if (!$user_id || !$project_id || !$cost_type || !$cost_item || !$amount || !$description) {
    echo json_encode(['success' => false, 'error' => 'All fields are required.']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        INSERT INTO project_budgets (project_id, cost_type, cost_item, amount, description,assignee)
        VALUES (?, ?, ?, ?, ?,?)
    ");
    $stmt->execute([
        $project_id,
        $cost_type,
        $cost_item,
        $amount,
        $description,
        $user_id
    ]);

    echo json_encode(['success' => true, 'message' => 'Budget entry added successfully.']);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/budget_err.log',
        date('Y-m-d H:i:s') . " - Add Budget Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Something went wrong. Try again.']);
}
