<?php


include_once '../../settings/connection.php';
header('Content-Type: application/json');

// Get POST data

$project_id = $_POST['project_id'] ?? null;
$name = trim($_POST['name'] ?? '');
$start_date = $_POST['start_date'] ?? '';
$due_date = $_POST['due_date'] ?? null;
$supervisor_id = $_POST['supervisor'] ?? null;
$status = $_POST['status'] ?? 'Pending';
$assignees = $_POST['assignees'] ?? [];

if (!$project_id || !$name || !$start_date || !$supervisor_id || empty($assignees)) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

try {
    $pdo->beginTransaction();

    // 1. Update project details
    $updateStmt = $pdo->prepare("UPDATE projects SET name = ?, start_date = ?, due_date = ?, supervisor_id = ?, status = ? WHERE id = ?");
    $updateStmt->execute([$name, $start_date, $due_date, $supervisor_id, $status, $project_id]);

    // 2. Fetch current assignees from DB
    $currentStmt = $pdo->prepare("SELECT user_id FROM project_assignees WHERE project_id = ?");
    $currentStmt->execute([$project_id]);
    $currentAssignees = $currentStmt->fetchAll(PDO::FETCH_COLUMN);

    // Normalize input
    if (!is_array($assignees)) {
        $assignees = [$assignees];
    }
    $assignees = array_map('intval', $assignees);
    $currentAssignees = array_map('intval', $currentAssignees);

    // 3. Determine additions and deletions
    $toAdd = array_diff($assignees, $currentAssignees);
    $toRemove = array_diff($currentAssignees, $assignees);

    // 4. Delete removed assignees
    if (!empty($toRemove)) {
        $placeholders = implode(',', array_fill(0, count($toRemove), '?'));
        $deleteStmt = $pdo->prepare("DELETE FROM project_assignees WHERE project_id = ? AND user_id IN ($placeholders)");
        $deleteStmt->execute(array_merge([$project_id], $toRemove));
    }

    // 5. Insert new assignees
    if (!empty($toAdd)) {
        $insertStmt = $pdo->prepare("INSERT INTO project_assignees (project_id, user_id) VALUES (?, ?)");
        foreach ($toAdd as $user_id) {
            $insertStmt->execute([$project_id, $user_id]);
        }
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'project_id' => $project_id]);
} catch (Exception $e) {
    $pdo->rollBack();
    file_put_contents(
        __DIR__ . '/project_err.log',
        date('Y-m-d H:i:s') . " - Edit Projects Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to update project: ' . $e->getMessage()]);
}
