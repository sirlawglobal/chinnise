<?php
// filepath: d:\xampp\htdocs\crm128\backend\project\delete_projects.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

// 1. Get and sanitize project_id
$project_id = isset($_POST['id']) ? intval($_POST['id']) : null;

if ($project_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid project ID']);
    exit;
}

try {
    // 2. Begin transaction
    $pdo->beginTransaction();

    // 3. Delete project
    $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
    $stmt->execute([$project_id]);

    if ($stmt->rowCount() === 0) {
        throw new Exception("Project not found or already deleted.");
    }

    // 4. Commit and respond
    $pdo->commit();
    echo json_encode(['success' => true, 'data' => 'Project deleted successfully']);
} catch (Exception $e) {
    $pdo->rollBack();

    // Log error to file
    file_put_contents(
        __DIR__ . '/project_err.log',
        date('Y-m-d H:i:s') . " - Delete Projects Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );

    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to delete project: ' . $e->getMessage()]);
}
