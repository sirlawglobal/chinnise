<?php


include_once '../../settings/connection.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->prepare("
        SELECT 
            CONCAT('B', b.id) AS id,
            b.cost_item,
            p.name AS project,
            b.cost_type,
            b.amount,
            b.description,
            CONCAT(s.firstname, ' ', s.lastname) AS added_by,
            DATE_FORMAT(b.created_at, '%M %e, %Y') AS created_at
        FROM project_budgets b
         JOIN projects p ON b.project_id = p.id
         JOIN staffs s ON b.assignee =s.id
        ORDER BY b.created_at ASC
    ");
    $stmt->execute();

    $budgets = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'data' => $budgets
    ]);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/budget_err.log',
        date('Y-m-d H:i:s') . " - Fetch Budgets Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );

    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to fetch budgets'
    ]);
}
