<?php
// filepath: d:\xampp\htdocs\crm128\backend\project\add_project.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

// Get POST data from FormData
$name = trim($_POST['name'] ?? '');
$start_date = $_POST['start_date'] ?? '';
$due_date = $_POST['due_date'] ?? null;
$supervisor_id = $_POST['supervisor'] ?? null;
$status = $_POST['status'] ?? 'Pending';
$assignees = $_POST['assignees'] ?? []; // This will be an array if multiple selected

if (!$name || !$start_date || !$supervisor_id || empty($assignees)) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Insert into projects
    $stmt = $pdo->prepare("INSERT INTO projects (name, start_date, due_date, supervisor_id, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $start_date, $due_date, $supervisor_id, $status]);
    $project_id = $pdo->lastInsertId();

    // Insert assignees
    $assigneeStmt = $pdo->prepare("INSERT INTO project_assignees (project_id, user_id) VALUES (?, ?)");
    // If only one assignee is selected, PHP may not make it an array
    if (!is_array($assignees)) {
        $assignees = [$assignees];
    }
    foreach ($assignees as $user_id) {
        $assigneeStmt->execute([$project_id, $user_id]);
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'project_id' => $project_id]);
} catch (Exception $e) {
    $pdo->rollBack();
    file_put_contents(
        __DIR__ . '/project_err.log',
        date('Y-m-d H:i:s') . " - Add Projects Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to add project: ' . $e->getMessage()]);
}
