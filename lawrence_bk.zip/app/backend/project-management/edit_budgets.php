<?php

include_once '../../settings/connection.php';

header('Content-Type: application/json');

// Fetch POST data from FormData
$user_id  = $_POST['user_id'] ?? null;
$budget_id   = $_POST['id'] ?? null;
$project_id  = $_POST['project_id'] ?? null;
$cost_type   = $_POST['cost_type'] ?? '';
$cost_item   = trim($_POST['cost_item'] ?? '');
$amount      = $_POST['amount'] ?? '';
$description = trim($_POST['description'] ?? '');

if (!$user_id || !$budget_id || !$project_id || !$cost_type || !$cost_item || !$amount || !$description) {
    echo json_encode(['success' => false, 'error' => 'All fields are required.']);
    exit;
}

// Strip 'B' prefix if it exists
$budget_id = preg_replace('/[^0-9]/', '', $budget_id);

try {
    $stmt = $pdo->prepare("
        UPDATE project_budgets
        SET 
            project_id = ?,
            cost_type = ?,
            cost_item = ?,
            amount = ?,
            description = ?,
            edit_assignee =?
        WHERE id = ?
    ");

    $stmt->execute([
        $project_id,
        $cost_type,
        $cost_item,
        $amount,
        $description,
        $user_id,
        $budget_id
    ]);

    if ($stmt->rowCount()) {
        echo json_encode(['success' => true, 'message' => 'Budget updated successfully.']);
    } else {
        echo json_encode(['success' => false, 'error' => 'No changes made or invalid budget ID.']);
    }
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/budget_err.log',
        date('Y-m-d H:i:s') . " - Edit Budget Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to update budget.']);
}
