<?php
// File: backend/budget/fetch_all_budgets.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->prepare("
        SELECT 
            cost_type, 
            SUM(amount) AS total
        FROM project_budgets
        GROUP BY cost_type
    ");
    $stmt->execute();

    $totals = [
        'direct_total' => 0,
        'indirect_total' => 0
    ];

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $type = strtolower($row['cost_type']);
        $amount = (float) $row['total'];

        if ($type === 'direct') {
            $totals['direct'] = $amount;
        } elseif ($type === 'indirect') {
            $totals['indirect'] = $amount;
        }
    }

    echo json_encode([
        'success' => true,
        'data' => $totals
    ]);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/budget_err.log',
        date('Y-m-d H:i:s') . " - Fetch All Budgets Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to fetch budget totals.'
    ]);
}
