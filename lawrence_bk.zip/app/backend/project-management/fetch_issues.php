<?php
// filepath: backend/project-management/fetch_issues.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->prepare("
        SELECT 
          i.id AS id,
        CONCAT('ISS', i.id) AS issue_code,
        p.id AS project_db_id,
        CONCAT('PRO', p.id) AS project_id,
            p.name AS project,
            i.issue_priority ,
            i.issue_status,
            i.issue_title,
            i.issue_description,
            i.created_at,
            CONCAT(emp.firstname, ' ', emp.lastname) AS added_by
        FROM issues i
        JOIN projects p ON i.project_id = p.id
        JOIN staffs emp ON i.user_id = emp.id
        ORDER BY i.created_at DESC
    ");
    $stmt->execute();
    $issues = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Format date
    foreach ($issues as &$issue) {
        $issue['created_at'] = date("F j, Y", strtotime($issue['created_at']));
    }

    echo json_encode([
        'success' => true,
        'data' => $issues
    ]);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/issues_error.log',
        date('Y-m-d H:i:s') . " - fetch issues error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to fetch issues'
    ]);
}
