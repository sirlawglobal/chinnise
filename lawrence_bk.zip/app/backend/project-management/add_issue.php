<?php
// filepath: backend/project-management/add_issue.php
include_once '../../settings/connection.php';
header('Content-Type: application/json');

$user_id = $_POST['user_id'] ?? '';
$project_id = $_POST['project_id'] ?? '';
$issue_status = $_POST['issue_status'] ?? '';
$issue_title = trim($_POST['issue_title'] ?? '');
$issue_priority = $_POST['issue_priority'] ?? '';
$issue_description = trim($_POST['issue_description'] ?? '');

if (!$user_id || !$project_id || !$issue_status || !$issue_title || !$issue_priority || !$issue_description) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        INSERT INTO issues (user_id, project_id, issue_status, issue_title, issue_priority, issue_description) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$user_id, $project_id, $issue_status, $issue_title, $issue_priority, $issue_description]);

    echo json_encode([
        'success' => true,
        'message' => 'Issue added successfully',
        'issue_id' => $pdo->lastInsertId()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    file_put_contents(
        __DIR__ . '/issue_err.log',
        date('Y-m-d H:i:s') . " - Add Issue Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    echo json_encode([
        'success' => false,
        'error' => 'Failed to add issue: ' . $e->getMessage()
    ]);
}
