<?php
// Filepath: backend/issue/delete_issue.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

// Get the issue ID from FormData
$issue_id = $_POST['id'] ?? null;

if (!$issue_id) {
    echo json_encode(['success' => false, 'error' => 'Issue ID is required.']);
    exit;
}



try {
    $stmt = $pdo->prepare("DELETE FROM issues WHERE id = ?");
    $stmt->execute([$issue_id]);

    if ($stmt->rowCount()) {
        echo json_encode(['success' => true, 'message' => 'Issue deleted successfully.']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Issue not found or already deleted.']);
    }
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/issue_err.log',
        date('Y-m-d H:i:s') . " - Delete issue Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );

    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'An error occurred while deleting the issue.'
    ]);
}
