<?php
// Filepath: backend/budget/delete_budget.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

// Get the budget ID from FormData
$budget_id = $_POST['id'] ?? null;

if (!$budget_id) {
    echo json_encode(['success' => false, 'error' => 'Budget ID is required.']);
    exit;
}

// Remove 'B' prefix if present
$budget_id = preg_replace('/[^0-9]/', '', $budget_id);

try {
    $stmt = $pdo->prepare("DELETE FROM project_budgets WHERE id = ?");
    $stmt->execute([$budget_id]);

    if ($stmt->rowCount()) {
        echo json_encode(['success' => true, 'message' => 'Budget deleted successfully.']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Budget not found or already deleted.']);
    }
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/budget_err.log',
        date('Y-m-d H:i:s') . " - Delete Budget Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );

    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'An error occurred while deleting the budget.'
    ]);
}
