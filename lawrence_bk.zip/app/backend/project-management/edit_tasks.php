<?php
// File: backend/task/edit_tasks.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

// Get data from FormData
$task_id     = $_POST['task_id'] ?? null;
$name        = trim($_POST['name'] ?? '');
$start_date  = $_POST['start_date'] ?? '';
$due_date    = $_POST['due_date'] ?? null;
$priority    = $_POST['priority'] ?? 'Low';
$status      = $_POST['status'] ?? 'Pending';
$project_id  = $_POST['project_id'] ?? null;
$assignees   = $_POST['assignees'] ?? [];

if (!$task_id || !$name || !$start_date || !$project_id || empty($assignees)) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

try {
    $pdo->beginTransaction();

    // 1. Update task details
    $stmt = $pdo->prepare("
        UPDATE tasks SET 
            name = ?, 
            start_date = ?, 
            due_date = ?, 
            priority = ?, 
            status = ?, 
            project_id = ?
        WHERE id = ?
    ");
    $stmt->execute([$name, $start_date, $due_date, $priority, $status, $project_id, $task_id]);

    // 2. Remove old assignees
    $delete = $pdo->prepare("DELETE FROM task_assignees WHERE task_id = ?");
    $delete->execute([$task_id]);

    // 3. Insert new assignees
    if (!is_array($assignees)) {
        $assignees = [$assignees];
    }

    $insert = $pdo->prepare("INSERT INTO task_assignees (task_id, user_id) VALUES (?, ?)");
    foreach ($assignees as $user_id) {
        $insert->execute([$task_id, $user_id]);
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Task updated successfully']);
} catch (Exception $e) {
    $pdo->rollBack();
    file_put_contents(
        __DIR__ . '/task_err.log',
        date('Y-m-d H:i:s') . " - Edit Task Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to update task']);
}
