<?php
// filepath: d:\xampp\htdocs\crm128\backend\project\fetch_projects.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

try {
    // Fetch all projects with supervisor name
    $stmt = $pdo->prepare("
        SELECT 
            p.id, 
            p.name, 
            p.start_date, 
            p.due_date, 
            p.status, 
            p.supervisor_id,
            CONCAT(e.first_name, ' ', e.last_name) AS supervisor_name,
            e.email AS supervisor_email,
            e.phone AS supervisor_phone
        FROM projects p
        JOIN employees e ON p.supervisor_id = e.id
        ORDER BY p.created_at DESC
    ");
    $stmt->execute();
    $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch assignees for each project
    foreach ($projects as &$project) {
        $assigneesStmt = $pdo->prepare("
            SELECT 
                a.user_id, 
                CONCAT(first_name, ' ', last_name) AS name,emp.email,emp.phone
            FROM project_assignees a
            JOIN employees emp ON a.user_id = emp.id
            WHERE a.project_id = ?
        ");
        $assigneesStmt->execute([$project['id']]);
        $project['assignees'] = $assigneesStmt->fetchAll(PDO::FETCH_ASSOC);
    }
    $statuses = ['Ongoing', 'Pending', 'Completed'];
    $result = [];

    foreach ($statuses as $status) {
        $key = strtolower($status);
        $filtered = array_filter($projects, function ($proj) use ($status) {
            return $proj['status'] === $status;
        });
        $filtered = array_values($filtered); // reindex

        $result[$key] = [
            'label' => "{$status} Projects",
            'count' => count($filtered),
            'rows' => $filtered
        ];
    }

    echo json_encode([
        'success' => true,
        'data' => $result
    ]);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/project_err.log',
        date('Y-m-d H:i:s') . " - Add Projects Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch projects']);
}
