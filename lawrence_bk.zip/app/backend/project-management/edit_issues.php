<?php
// File: backend/project-management/edit_issues.php
include_once '../../settings/connection.php';
header('Content-Type: application/json');

try {
    // Get POST data
    $issue_id = $_POST['id'] ?? null;
    $user_id = $_POST['user_id'] ?? null;
    $project_id = $_POST['project_id'] ?? null;
    $issue_status = $_POST['issue_status'] ?? null;
    $issue_title = $_POST['issue_title'] ?? null;
    $issue_priority = $_POST['issue_priority'] ?? null;
    $issue_description = $_POST['issue_description'] ?? null;

    // Validate required fields
    if (!$issue_id || !$user_id || !$project_id || !$issue_status || !$issue_title || !$issue_priority || !$issue_description) {
        http_response_code(400);
        echo json_encode(["success" => false, "error" => "All fields are required."]);
        exit;
    }

    // Perform the update
    $stmt = $pdo->prepare("
        UPDATE issues 
        SET 
            project_id = :project_id,
            issue_status = :issue_status,
            issue_title = :issue_title,
            issue_priority = :issue_priority,
            issue_description = :issue_description,
            edit_user_id = :user_id
        WHERE id = :issue_id
    ");
    $stmt->execute([
        ':project_id' => $project_id,
        ':issue_status' => $issue_status,
        ':issue_title' => $issue_title,
        ':issue_priority' => $issue_priority,
        ':issue_description' => $issue_description,
        ':user_id' => $user_id,
        ':issue_id' => $issue_id,
    ]);

    echo json_encode(["success" => true, "message" => "Issue updated successfully."]);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/issues_error.log',
        date('Y-m-d H:i:s') . " - Edit issues error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(["success" => false, "error" => "Unable to update the issue."]);
}
