<?php
// filepath: d:\xampp\htdocs\crm128\backend\project-management\fetch_tasks.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');
$id = $_GET['id'] ?? null;
try {
    // Fetch all tasks with project info
    $stmt = $pdo->prepare("
        SELECT 
            t.id, 
            t.name, 
            t.start_date, 
            t.due_date, 
            t.priority, 
            t.status,
            t.project_id,
            p.name AS project_name,
            p.supervisor_id,
            CONCAT(e.first_name, ' ', e.last_name) AS supervisor_name,
            e.email AS supervisor_email,
            e.phone AS supervisor_phone
        FROM tasks t
        JOIN projects p ON t.project_id = p.id
        JOIN employees e ON p.supervisor_id = e.id
        WHERE t.project_id = ?
        ORDER BY t.created_at DESC
    ");
    $stmt->execute([$id]);
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch assignees for each task
    foreach ($tasks as &$task) {
        $assigneesStmt = $pdo->prepare("
            SELECT 
                a.user_id, 
                CONCAT(emp.first_name, ' ', emp.last_name) AS name,
                emp.email,
                emp.phone
            FROM task_assignees a
            JOIN employees emp ON a.user_id = emp.id
            WHERE a.task_id = ?
        ");
        $assigneesStmt->execute([$task['id']]);
        $task['assignees'] = $assigneesStmt->fetchAll(PDO::FETCH_ASSOC);
    }
    unset($task);

    // Group by project_name and then by status
    $statuses = [
        'ongoing' => 'Ongoing',
        'pending' => 'Pending',
        'completed' => 'Completed'
    ];
    $grouped = [];

    foreach ($tasks as $task) {
        $projectName = $task['project_name'];
        $statusKey = strtolower($task['status']);

        // Initialize project group if not present
        if (!isset($grouped[$projectName])) {
            foreach ($statuses as $key => $label) {
                $grouped[$projectName][$key] = [
                    'label' => "{$label} Tasks for {$projectName}",
                    'count' => 0,
                    'rows' => []
                ];
            }
        }

        // Add task to the correct status group
        if (isset($grouped[$projectName][$statusKey])) {
            $grouped[$projectName][$statusKey]['rows'][] = $task;
            $grouped[$projectName][$statusKey]['count']++;
        }
    }

    echo json_encode([
        'success' => true,
        'data' => $grouped
    ]);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/task_err.log',
        date('Y-m-d H:i:s') . " - Fetch Tasks Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch tasks']);
}
