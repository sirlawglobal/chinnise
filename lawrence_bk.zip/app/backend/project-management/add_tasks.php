<?php
// File: backend/task/add_tasks.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

// Get data from POST (FormData)
$name        = trim($_POST['name'] ?? '');
$start_date  = $_POST['start_date'] ?? '';
$due_date    = $_POST['due_date'] ?? null;
$priority    = $_POST['priority'] ?? 'Low';
$status      = $_POST['status'] ?? 'Pending';
$project_id  = $_POST['project_id'] ?? null;
$assignees   = $_POST['assignees'] ?? []; // array from <select multiple>

if (!$name || !$start_date || !$project_id || empty($assignees)) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Insert into tasks table
    $stmt = $pdo->prepare("
        INSERT INTO tasks (name, start_date, due_date, priority, status, project_id)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$name, $start_date, $due_date, $priority, $status, $project_id]);
    $task_id = $pdo->lastInsertId();

    // Insert task assignees
    if (!is_array($assignees)) {
        $assignees = [$assignees]; // support for single selection
    }

    $insert = $pdo->prepare("INSERT INTO task_assignees (task_id, user_id) VALUES (?, ?)");
    foreach ($assignees as $user_id) {
        $insert->execute([$task_id, $user_id]);
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'task_id' => $task_id]);
} catch (Exception $e) {
    $pdo->rollBack();
    file_put_contents(
        __DIR__ . '/task_err.log',
        date('Y-m-d H:i:s') . " - Add Task Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to add task.']);
}
