<?php
// filepath: backend/project-management/get_project_assignees.php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

$project_id = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;

if ($project_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid project ID']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT employees.id, CONCAT(employees.first_name, ' ', employees.last_name) AS name,employees.email,employees.phone
        FROM employees
        INNER JOIN project_assignees ON employees.id = project_assignees.user_id
        WHERE project_assignees.project_id = ?
    ");
    $stmt->execute([$project_id]);

    $assignees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'assignees' => $assignees]);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/project_err.log',
        date('Y-m-d H:i:s') . " - fetch Projects Assignees Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);

    echo json_encode(['success' => false, 'error' => 'Server error']);
}
