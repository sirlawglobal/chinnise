<?php
require_once '../../../settings/connection.php';

try {
    $stmt = $pdo->query("SELECT staff_id, surname, first_name, basic_salary, monthly_bonus FROM payrolls WHERE monthly_bonus > 0");
    $bonuses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($bonuses);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
