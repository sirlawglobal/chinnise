<?php
require_once '../../../settings/connection.php';

try {
    $stmt = $pdo->prepare("SELECT id AS staff_id FROM employees");
    $stmt->execute(); // <-- You forgot this line
    $staffs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($staffs);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
