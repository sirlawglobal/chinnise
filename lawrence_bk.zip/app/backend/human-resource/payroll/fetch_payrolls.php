<?php
require_once '../../../settings/connection.php';

try {
    $stmt = $pdo->query("SELECT * FROM payrolls ORDER BY id DESC");
    $payrolls = $stmt->fetchAll();
    echo json_encode($payrolls);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
