<?php
require_once '../../../settings/connection.php';

if (isset($_GET['staff_id'])) {
    $staff_id = $_GET['staff_id'];

    try {
        $stmt = $pdo->prepare("SELECT first_name, last_name AS surname FROM employees WHERE id = ?");
        $stmt->execute([$staff_id]);
        $staff = $stmt->fetch(PDO::FETCH_ASSOC); // Ensures associative array format

        echo json_encode($staff ?: []);
    } catch (PDOException $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'staff_id not provided']);
}
