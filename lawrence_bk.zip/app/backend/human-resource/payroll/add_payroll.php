<?php
require_once '../../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("INSERT INTO payrolls (staff_id, surname, first_name, basic_salary, attendance_bonus, monthly_bonus, deductions, paye, pension, net_salary, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->execute([
        $_POST['staff_id'],
        $_POST['surname'],
        $_POST['first_name'],
        $_POST['basic_salary'],
        $_POST['attendance_bonus'],
        $_POST['monthly_bonus'],
        $_POST['deductions'],
        $_POST['paye'],
        $_POST['pension'],
        $_POST['net_salary'],
        $_POST['status']
    ]);

    echo json_encode(['success' => true]);
}
