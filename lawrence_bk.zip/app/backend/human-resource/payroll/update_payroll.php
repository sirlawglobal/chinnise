<?php
require_once '../../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  exit('Method not allowed');
}

try {
  $stmt = $pdo->prepare("
    UPDATE payrolls SET
    surname = ?, first_name = ?, basic_salary = ?,
      attendance_bonus = ?, monthly_bonus = ?, deductions = ?,
      paye = ?, pension = ?, net_salary = ?, status = ?
    WHERE id = ?
  ");

  $stmt->execute([
    $_POST['surname'],
    $_POST['first_name'],
    $_POST['basic_salary'],
    $_POST['attendance_bonus'],
    $_POST['monthly_bonus'],
    $_POST['deductions'],
    $_POST['paye'],
    $_POST['pension'],
    $_POST['net_salary'],
    $_POST['status'],
    $_POST['id']
  ]);

  echo json_encode(['success' => true]);
} catch (PDOException $e) {
  echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
