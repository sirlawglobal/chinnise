<?php
require_once '../../../settings/connection.php';

$year = $_GET['year'] ?? '';
$month = $_GET['month'] ?? '';
$search = $_GET['search'] ?? '';

$query = "SELECT * FROM payrolls WHERE 1=1";

// Apply filters
if ($year !== '') {
    $query .= " AND YEAR(created_at) = :year";
}
if ($month !== '') {
    $query .= " AND MONTHNAME(created_at) = :month";
}
if ($search !== '') {
    $query .= " AND (
        staff_id LIKE :search OR
        surname LIKE :search OR
        first_name LIKE :search
    )";
}

$stmt = $pdo->prepare($query);

// Bind values
if ($year !== '') {
    $stmt->bindValue(':year', $year, PDO::PARAM_INT);
}
if ($month !== '') {
    // Capitalize the first letter to match MONTHNAME format
    $stmt->bindValue(':month', ucfirst(strtolower($month)), PDO::PARAM_STR);
}
if ($search !== '') {
    $stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
}

$stmt->execute();
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($data);
