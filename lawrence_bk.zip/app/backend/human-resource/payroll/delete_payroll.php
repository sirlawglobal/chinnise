<?php
require_once '../../../settings/connection.php';

if (!isset($_GET['id'])) {
  http_response_code(400);
  exit('Missing ID.');
}

try {
  $stmt = $pdo->prepare("DELETE FROM payrolls WHERE id = ?");
  $stmt->execute([$_GET['id']]);
  echo 'Deleted';
} catch (PDOException $e) {
  http_response_code(500);
  echo $e->getMessage();
}
