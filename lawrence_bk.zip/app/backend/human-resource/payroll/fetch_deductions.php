<?php
require_once '../../../settings/connection.php';

try {
    $stmt = $pdo->query("SELECT staff_id, surname, first_name, basic_salary, deductions FROM payrolls WHERE deductions > 0");
    $payrolls = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($payrolls);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
