
<!--update-employer-->

<?php
require '../../../settings/connection.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid data']);
    exit;
}

$id = $data['id'];

// Prepare update statement with relevant fields (example)
$sql = "UPDATE employees SET 
    first_name = :first_name,
    last_name = :last_name,
    date_joined = :date_joined,
    position = :position,
    status = :status,
    department = :department,
    location = :location,
    marital_status = :marital_status,
    date_of_birth = :date_of_birth,
    phone = :phone,
    email = :email,
    gender = :gender,
    state_of_origin = :state_of_origin,
    nino = :nino,
    medical_condition = :medical_condition,
    bank_name = :bank_name,
    account_name = :account_name,
    account_number = :account_number,
    father_name = :father_name,
    father_occupation = :father_occupation,
    father_address = :father_address,
    father_phone = :father_phone,
    mother_name = :mother_name,
    mother_occupation = :mother_occupation,
    mother_address = :mother_address,
    mother_phone = :mother_phone,
    siblings_number = :siblings_number,
    nok_surname = :nok_surname,
    nok_other_names = :nok_other_names,
    nok_address = :nok_address,
    nok_phone = :nok_phone,
    nok_email = :nok_email,
    nok_relationship = :nok_relationship,
    ref1_surname = :ref1_surname,
    ref1_other_names = :ref1_other_names,
    ref1_company = :ref1_company,
    ref1_address = :ref1_address,
    ref1_phone = :ref1_phone,
    ref1_position = :ref1_position,
    ref2_surname = :ref2_surname,
    ref2_other_names = :ref2_other_names,
    ref2_company = :ref2_company,
    ref2_address = :ref2_address,
    ref2_phone = :ref2_phone,
    ref2_email = :ref2_email,
    ref2_position = :ref2_position
    WHERE id = :id";

$stmt = $pdo->prepare($sql);

$params = [
    ':first_name' => $data['first_name'] ?? null,
    ':last_name' => $data['last_name'] ?? null,
    ':date_joined' => $data['date_joined'] ?? null,
    ':position' => $data['position'] ?? null,
    ':status' => $data['status'] ?? null,
    ':department' => $data['department'] ?? null,
    ':location' => $data['location'] ?? null,
    ':marital_status' => $data['marital_status'] ?? null,
    ':date_of_birth' => $data['date_of_birth'] ?? null,
    ':phone' => $data['phone'] ?? null,
    ':email' => $data['email'] ?? null,
    ':gender' => $data['gender'] ?? null,
    ':state_of_origin' => $data['state_of_origin'] ?? null,
    ':nino' => $data['nino'] ?? null,
    ':medical_condition' => $data['medical_condition'] ?? null,
    ':bank_name' => $data['bank_name'] ?? null,
    ':account_name' => $data['account_name'] ?? null,
    ':account_number' => $data['account_number'] ?? null,
    ':father_name' => $data['father_name'] ?? null,
    ':father_occupation' => $data['father_occupation'] ?? null,
    ':father_address' => $data['father_address'] ?? null,
    ':father_phone' => $data['father_phone'] ?? null,
    ':mother_name' => $data['mother_name'] ?? null,
    ':mother_occupation' => $data['mother_occupation'] ?? null,
    ':mother_address' => $data['mother_address'] ?? null,
    ':mother_phone' => $data['mother_phone'] ?? null,
    ':siblings_number' => $data['siblings_number'] ?? null,
    ':nok_surname' => $data['nok_surname'] ?? null,
    ':nok_other_names' => $data['nok_other_names'] ?? null,
    ':nok_address' => $data['nok_address'] ?? null,
    ':nok_phone' => $data['nok_phone'] ?? null,
    ':nok_email' => $data['nok_email'] ?? null,
    ':nok_relationship' => $data['nok_relationship'] ?? null,
    ':ref1_surname' => $data['ref1_surname'] ?? null,
    ':ref1_other_names' => $data['ref1_other_names'] ?? null,
    ':ref1_company' => $data['ref1_company'] ?? null,
    ':ref1_address' => $data['ref1_address'] ?? null,
    ':ref1_phone' => $data['ref1_phone'] ?? null,
    ':ref1_position' => $data['ref1_position'] ?? null,
    ':ref2_surname' => $data['ref2_surname'] ?? null,
    ':ref2_other_names' => $data['ref2_other_names'] ?? null,
    ':ref2_company' => $data['ref2_company'] ?? null,
    ':ref2_address' => $data['ref2_address'] ?? null,
    ':ref2_phone' => $data['ref2_phone'] ?? null,
    ':ref2_email' => $data['ref2_email'] ?? null,
    ':ref2_position' => $data['ref2_position'] ?? null,
    ':id' => $id
];

if ($stmt->execute($params)) {
    echo json_encode(['success' => true]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Update failed']);
}
