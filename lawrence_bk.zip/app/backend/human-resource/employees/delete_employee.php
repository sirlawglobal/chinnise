
<!--delete-employer-->
<?php
require '../../../settings/connection.php';

$id = $_POST['id'] ?? null;

if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'No ID provided']);
    exit;
}

$stmt = $pdo->prepare("DELETE FROM employees WHERE id = ?");
if ($stmt->execute([$id])) {
    echo json_encode(['success' => true]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Delete failed']);
}
