
<?php
require '../../../settings/connection.php';

// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// If ID is passed via GET, fetch a single employee
if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    // $stmt = $pdo->prepare("SELECT e.id, e.first_name, e.last_name, e.position, d.dept_name AS department, e.date_joined
    //                       FROM employees e
    //                       LEFT JOIN departments d ON e.department = d.id
    //                       WHERE e.id = :id");
    // $stmt->execute([':id' => $id]);
    // $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $stmt = $pdo->prepare("SELECT e.id, e.first_name, e.last_name, e.position, d.dept_name AS department, 
                       e.date_joined, e.status, e.location, e.marital_status, e.date_of_birth, 
                       e.phone, e.email, e.gender, e.state_of_origin, e.nino, e.medical_condition, 
                       e.bank_name, e.account_name, e.account_number, e.father_name, e.father_occupation, 
                       e.father_address, e.father_phone, e.mother_name, e.mother_occupation, 
                       e.mother_address, e.mother_phone, e.siblings_number, e.nok_surname, 
                       e.nok_other_names, e.nok_address, e.nok_phone, e.nok_email, e.nok_relationship, 
                       e.ref1_surname, e.ref1_other_names, e.ref1_company, e.ref1_address, 
                       e.ref1_phone, e.ref1_position, e.ref2_surname, e.ref2_other_names, 
                       e.ref2_company, e.ref2_address, e.ref2_phone, e.ref2_email, e.ref2_position
                       FROM employees e
                       LEFT JOIN departments d ON e.department = d.id
                       WHERE e.id = :id");
$stmt->execute([':id' => $id]);
$employee = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($employee) {
        echo json_encode([
            'status' => 'success',
            'data' => $employee
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Employee not found'
        ]);
    }

    exit;
}

// Otherwise handle pagination (POST)
$page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
$rowsPerPage = isset($_POST['rows_per_page']) ? (int)$_POST['rows_per_page'] : 25;
$offset = ($page - 1) * $rowsPerPage;

$total = $pdo->query("SELECT COUNT(*) FROM employees")->fetchColumn();
$totalPages = ceil($total / $rowsPerPage);

$stmt = $pdo->prepare("SELECT e.id, e.first_name, e.last_name, e.position, d.dept_name AS department, e.date_joined
                       FROM employees e
                       LEFT JOIN departments d ON e.department = d.id
                       ORDER BY e.date_joined DESC
                       LIMIT :limit OFFSET :offset");

$stmt->bindValue(':limit', $rowsPerPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'status' => 'success',
    'data' => $rows,
    'totalPages' => $totalPages,
    'currentPage' => $page
]);













// // require '../../../settings/connection.php';

// error_reporting(E_ALL);
// ini_set('display_errors', 1);


// // require_once(__DIR__ . '/../../settings/connection.php');

// $page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
// $rowsPerPage = isset($_POST['rows_per_page']) ? (int)$_POST['rows_per_page'] : 25;
// $offset = ($page - 1) * $rowsPerPage;

// // Total count
// $total = $pdo->query("SELECT COUNT(*) FROM employees")->fetchColumn();
// $totalPages = ceil($total / $rowsPerPage);

// // Fetch paginated results
// $stmt = $pdo->prepare("SELECT e.id, e.staff_id, e.first_name, e.last_name, e.position, d.dept_name AS department, e.date_joined
//                       FROM employees e
//                       LEFT JOIN departments d ON e.department = d.id
//                       ORDER BY e.date_joined DESC
//                       LIMIT :limit OFFSET :offset");

// $stmt->bindValue(':limit', $rowsPerPage, PDO::PARAM_INT);
// $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
// $stmt->execute();
// $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// echo json_encode([
//   'status' => 'success',
//   'data' => $rows,
//   'totalPages' => $totalPages,
//   'currentPage' => $page
// ]);
