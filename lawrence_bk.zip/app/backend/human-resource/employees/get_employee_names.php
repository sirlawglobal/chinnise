<?php
// get_employee_names.php
require_once '../../../settings/connection.php'; // Adjust path as necessary

header('Content-Type: application/json'); // Tell the browser to expect JSON

try {
    // Fetch staff_id, first_name, and last_name from the employees table
    $stmt = $pdo->query("SELECT staff_id, first_name, last_name FROM employees ORDER BY first_name ASC, last_name ASC");
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['status' => 'success', 'data' => $employees]);

} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>