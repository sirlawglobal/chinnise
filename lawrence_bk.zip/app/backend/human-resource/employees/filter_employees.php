<?php
require '../../../settings/connection.php'; // Adjust path if needed

// Read JSON input if present (for filtering)
$data = json_decode(file_get_contents("php://input"), true);

$name = $data['name'] ?? '';
$month = $data['month'] ?? '';
$year = $data['year'] ?? '';
$type = $data['type'] ?? '';

// Build dynamic WHERE clause
$where = [];
$params = [];

if (!empty($name)) {
    $where[] = "(first_name LIKE :name OR last_name LIKE :name)";
    $params[':name'] = '%' . $name . '%';
}
if (!empty($month)) {
    $where[] = "MONTH(date_joined) = :month";
    $params[':month'] = $month;
}
if (!empty($year)) {
    $where[] = "YEAR(date_joined) = :year";
    $params[':year'] = $year;
}
if (!empty($type)) {
    $where[] = "status = :status";
    $params[':status'] = $type;
}

// Build final SQL
$sql = "SELECT id, first_name, last_name, position, department, phone, status, date_joined FROM employees";
if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Output table rows
foreach ($employees as $employee) {
    $id = htmlspecialchars($employee['id']);
    echo "<tr data-id='{$id}'>
        <td>100{$id}</td>
        <td>" . htmlspecialchars($employee['first_name'] . " " . $employee['last_name']) . "</td>
        <td>" . htmlspecialchars($employee['position']) . "</td>
        <td>" . htmlspecialchars($employee['department']) . "</td>
        <td>" . htmlspecialchars($employee['phone']) . "</td>
        <td>" . htmlspecialchars($employee['status']) . "</td>
        <td>" . htmlspecialchars($employee['date_joined']) . "</td>
        <td><button class='view-btn' data-id='{$id}'><i class='view-icon'><img src='../assets/eye-open.png' /></i></button></td>
        <td><button class='edit-btn' data-id='{$id}'><i class='edit-icon'><img src='../assets/edit.svg' /></i></button></td>
        <td><button class='delete-btn' data-id='{$id}'><i class='delete-icon'><img src='../assets/Delete.svg' /></i></button></td>
    </tr>";
}
?>
