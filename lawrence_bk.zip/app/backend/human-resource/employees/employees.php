<?php
header("Content-Type: application/json");
require_once '../../../settings/connection.php';

$method = $_SERVER['REQUEST_METHOD'];


$conn = $pdo;

switch ($method) {
    case 'GET':
        // Get all employees or single employee
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            
            try {
                $query = "SELECT e.*, 
                         ef.father_name, ef.father_occupation, ef.father_address, ef.father_phone,
                         ef.mother_name, ef.mother_occupation, ef.mother_address, ef.mother_phone, ef.siblings_count,
                         nok.surname as nok_surname, nok.other_names as nok_other_names, nok.address as nok_address, 
                         nok.phone as nok_phone, nok.email as nok_email, nok.relationship as nok_relationship,
                         ref1.surname as ref1_surname, ref1.other_names as ref1_other_names, ref1.company as ref1_company,
                         ref1.address as ref1_address, ref1.phone as ref1_phone, ref1.position as ref1_position, ref1.email as ref1_email,
                         ref2.surname as ref2_surname, ref2.other_names as ref2_other_names, ref2.company as ref2_company,
                         ref2.address as ref2_address, ref2.phone as ref2_phone, ref2.position as ref2_position, ref2.email as ref2_email
                         FROM employees e
                         LEFT JOIN employee_family ef ON e.id = ef.employee_id
                         LEFT JOIN employee_next_of_kin nok ON e.id = nok.employee_id
                         LEFT JOIN employee_references ref1 ON e.id = ref1.employee_id AND ref1.reference_type = 'Reference 1'
                         LEFT JOIN employee_references ref2 ON e.id = ref2.employee_id AND ref2.reference_type = 'Reference 2'
                         WHERE e.id = :id";
                
                $stmt = $conn->prepare($query);
                $stmt->bindParam(':id', $id, PDO::PARAM_INT);
                $stmt->execute();
                
                $employee = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($employee) {
                    echo json_encode($employee);
                } else {
                    http_response_code(404);
                    echo json_encode(['status' => 'error', 'message' => 'Employee not found']);
                }
            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            }
        } else {
            // Handle filters
            $filters = [];
            $params = [];
            
            if (!empty($_GET['name'])) {
                $filters[] = "(e.first_name LIKE :name OR e.last_name LIKE :name)";
                $params[':name'] = '%' . $_GET['name'] . '%';
            }
            
            if (!empty($_GET['month'])) {
                $filters[] = "MONTH(e.date_joined) = :month";
                $params[':month'] = $_GET['month'];
            }
            
            if (!empty($_GET['year'])) {
                $filters[] = "YEAR(e.date_joined) = :year";
                $params[':year'] = $_GET['year'];
            }
            
            if (!empty($_GET['type'])) {
                $filters[] = "e.status = :type";
                $params[':type'] = $_GET['type'];
            }
            
            $whereClause = !empty($filters) ? "WHERE " . implode(" AND ", $filters) : "";
            
            try {
                $query = "SELECT e.id, CONCAT(e.first_name, ' ', e.last_name) as name, 
                          e.position, e.department, e.phone, e.status, e.date_joined
                          FROM employees e $whereClause ORDER BY e.date_joined DESC";
                
                $stmt = $conn->prepare($query);
                
                foreach ($params as $key => &$val) {
                    $stmt->bindParam($key, $val);
                }
                
                $stmt->execute();
                $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo json_encode($employees);
            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            }
        }
        break;
        
    case 'POST':
        // Create new employee
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!$data) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid input data']);
            break;
        }
        
        try {
            $conn->beginTransaction();
            
            // Insert main employee data
            $query = "INSERT INTO employees (first_name, last_name, picture_path, date_joined, position, 
                      status, department, location_branch, marital_status, date_of_birth, phone, email, gender, 
                      state_of_origin, nino, medical_condition, bank_name, account_name, account_number)
                      VALUES (:first_name, :last_name, :picture_path, :date_joined, :position, 
                      :status, :department, :location_branch, :marital_status, :date_of_birth, :phone, :email, :gender, 
                      :state_of_origin, :nino, :medical_condition, :bank_name, :account_name, :account_number)";
            
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':first_name', $data['first_name']);
            $stmt->bindParam(':last_name', $data['last_name']);
            $stmt->bindParam(':picture_path', $data['picture_path']);
            $stmt->bindParam(':date_joined', $data['date_joined']);
            $stmt->bindParam(':position', $data['position']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':department', $data['department']);
            $stmt->bindParam(':location_branch', $data['location_branch']);
            $stmt->bindParam(':marital_status', $data['marital_status']);
            $stmt->bindParam(':date_of_birth', $data['date_of_birth']);
            $stmt->bindParam(':phone', $data['phone']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':gender', $data['gender']);
            $stmt->bindParam(':state_of_origin', $data['state_of_origin']);
            $stmt->bindParam(':nino', $data['nino']);
            $stmt->bindParam(':medical_condition', $data['medical_condition']);
            $stmt->bindParam(':bank_name', $data['bank_name']);
            $stmt->bindParam(':account_name', $data['account_name']);
            $stmt->bindParam(':account_number', $data['account_number']);
            
            $stmt->execute();
            $employee_id = $conn->lastInsertId();
            
            // Insert family data
            $query = "INSERT INTO employee_family (employee_id, father_name, father_occupation, father_address, 
                      father_phone, mother_name, mother_occupation, mother_address, mother_phone, siblings_count)
                      VALUES (:employee_id, :father_name, :father_occupation, :father_address, 
                      :father_phone, :mother_name, :mother_occupation, :mother_address, :mother_phone, :siblings_count)";
            
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':employee_id', $employee_id);
            $stmt->bindParam(':father_name', $data['father_name']);
            $stmt->bindParam(':father_occupation', $data['father_occupation']);
            $stmt->bindParam(':father_address', $data['father_address']);
            $stmt->bindParam(':father_phone', $data['father_phone']);
            $stmt->bindParam(':mother_name', $data['mother_name']);
            $stmt->bindParam(':mother_occupation', $data['mother_occupation']);
            $stmt->bindParam(':mother_address', $data['mother_address']);
            $stmt->bindParam(':mother_phone', $data['mother_phone']);
            $stmt->bindParam(':siblings_count', $data['siblings_count'], PDO::PARAM_INT);
            
            $stmt->execute();
            
            // Insert next of kin data
            $query = "INSERT INTO employee_next_of_kin (employee_id, surname, other_names, address, phone, email, relationship)
                      VALUES (:employee_id, :nok_surname, :nok_other_names, :nok_address, :nok_phone, :nok_email, :nok_relationship)";
            
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':employee_id', $employee_id);
            $stmt->bindParam(':nok_surname', $data['nok_surname']);
            $stmt->bindParam(':nok_other_names', $data['nok_other_names']);
            $stmt->bindParam(':nok_address', $data['nok_address']);
            $stmt->bindParam(':nok_phone', $data['nok_phone']);
            $stmt->bindParam(':nok_email', $data['nok_email']);
            $stmt->bindParam(':nok_relationship', $data['nok_relationship']);
            
            $stmt->execute();
            
            // Insert reference 1 data
            $query = "INSERT INTO employee_references (employee_id, reference_type, surname, other_names, company, 
                      address, phone, email, position)
                      VALUES (:employee_id, 'Reference 1', :ref1_surname, :ref1_other_names, :ref1_company, 
                      :ref1_address, :ref1_phone, :ref1_email, :ref1_position)";
            
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':employee_id', $employee_id);
            $stmt->bindParam(':ref1_surname', $data['ref1_surname']);
            $stmt->bindParam(':ref1_other_names', $data['ref1_other_names']);
            $stmt->bindParam(':ref1_company', $data['ref1_company']);
            $stmt->bindParam(':ref1_address', $data['ref1_address']);
            $stmt->bindParam(':ref1_phone', $data['ref1_phone']);
            $stmt->bindParam(':ref1_email', $data['ref1_email']);
            $stmt->bindParam(':ref1_position', $data['ref1_position']);
            
            $stmt->execute();
            
            // Insert reference 2 data
            $query = "INSERT INTO employee_references (employee_id, reference_type, surname, other_names, company, 
                      address, phone, email, position)
                      VALUES (:employee_id, 'Reference 2', :ref2_surname, :ref2_other_names, :ref2_company, 
                      :ref2_address, :ref2_phone, :ref2_email, :ref2_position)";
            
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':employee_id', $employee_id);
            $stmt->bindParam(':ref2_surname', $data['ref2_surname']);
            $stmt->bindParam(':ref2_other_names', $data['ref2_other_names']);
            $stmt->bindParam(':ref2_company', $data['ref2_company']);
            $stmt->bindParam(':ref2_address', $data['ref2_address']);
            $stmt->bindParam(':ref2_phone', $data['ref2_phone']);
            $stmt->bindParam(':ref2_email', $data['ref2_email']);
            $stmt->bindParam(':ref2_position', $data['ref2_position']);
            
            $stmt->execute();
            
            $conn->commit();
            echo json_encode(['status' => 'success', 'employee_id' => $employee_id]);
        } catch (PDOException $e) {
            $conn->rollBack();
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;
        
    case 'PUT':
        // Update employee
        $id = $_GET['id'];
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!$data) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid input data']);
            break;
        }
        
        try {
            $conn->beginTransaction();
            
            // Update main employee data
            $query = "UPDATE employees SET 
                      first_name = :first_name, last_name = :last_name, 
                      picture_path = :picture_path, date_joined = :date_joined, position = :position, 
                      status = :status, department = :department, location_branch = :location_branch, 
                      marital_status = :marital_status, date_of_birth = :date_of_birth, phone = :phone, 
                      email = :email, gender = :gender, state_of_origin = :state_of_origin, 
                      nino = :nino, medical_condition = :medical_condition, bank_name = :bank_name, 
                      account_name = :account_name, account_number = :account_number
                      WHERE id = :id";
            
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':first_name', $data['first_name']);
            $stmt->bindParam(':last_name', $data['last_name']);
            $stmt->bindParam(':picture_path', $data['picture_path']);
            $stmt->bindParam(':date_joined', $data['date_joined']);
            $stmt->bindParam(':position', $data['position']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':department', $data['department']);
            $stmt->bindParam(':location_branch', $data['location_branch']);
            $stmt->bindParam(':marital_status', $data['marital_status']);
            $stmt->bindParam(':date_of_birth', $data['date_of_birth']);
            $stmt->bindParam(':phone', $data['phone']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':gender', $data['gender']);
            $stmt->bindParam(':state_of_origin', $data['state_of_origin']);
            $stmt->bindParam(':nino', $data['nino']);
            $stmt->bindParam(':medical_condition', $data['medical_condition']);
            $stmt->bindParam(':bank_name', $data['bank_name']);
            $stmt->bindParam(':account_name', $data['account_name']);
            $stmt->bindParam(':account_number', $data['account_number']);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            
            $stmt->execute();
            
            // Update family data
            $query = "UPDATE employee_family SET 
                      father_name = :father_name, father_occupation = :father_occupation, 
                      father_address = :father_address, father_phone = :father_phone, 
                      mother_name = :mother_name, mother_occupation = :mother_occupation, 
                      mother_address = :mother_address, mother_phone = :mother_phone, 
                      siblings_count = :siblings_count
                      WHERE employee_id = :employee_id";
            
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':father_name', $data['father_name']);
            $stmt->bindParam(':father_occupation', $data['father_occupation']);
            $stmt->bindParam(':father_address', $data['father_address']);
            $stmt->bindParam(':father_phone', $data['father_phone']);
            $stmt->bindParam(':mother_name', $data['mother_name']);
            $stmt->bindParam(':mother_occupation', $data['mother_occupation']);
            $stmt->bindParam(':mother_address', $data['mother_address']);
            $stmt->bindParam(':mother_phone', $data['mother_phone']);
            $stmt->bindParam(':siblings_count', $data['siblings_count'], PDO::PARAM_INT);
            $stmt->bindParam(':employee_id', $id, PDO::PARAM_INT);
            
            $stmt->execute();
            
            // Update next of kin data
            $query = "UPDATE employee_next_of_kin SET 
                      surname = :nok_surname, other_names = :nok_other_names, 
                      address = :nok_address, phone = :nok_phone, 
                      email = :nok_email, relationship = :nok_relationship
                      WHERE employee_id = :employee_id";
            
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':nok_surname', $data['nok_surname']);
            $stmt->bindParam(':nok_other_names', $data['nok_other_names']);
            $stmt->bindParam(':nok_address', $data['nok_address']);
            $stmt->bindParam(':nok_phone', $data['nok_phone']);
            $stmt->bindParam(':nok_email', $data['nok_email']);
            $stmt->bindParam(':nok_relationship', $data['nok_relationship']);
            $stmt->bindParam(':employee_id', $id, PDO::PARAM_INT);
            
            $stmt->execute();
            
            // Update reference 1 data
            $query = "UPDATE employee_references SET 
                      surname = :ref1_surname, other_names = :ref1_other_names, 
                      company = :ref1_company, address = :ref1_address, 
                      phone = :ref1_phone, email = :ref1_email, position = :ref1_position
                      WHERE employee_id = :employee_id AND reference_type = 'Reference 1'";
            
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':ref1_surname', $data['ref1_surname']);
            $stmt->bindParam(':ref1_other_names', $data['ref1_other_names']);
            $stmt->bindParam(':ref1_company', $data['ref1_company']);
            $stmt->bindParam(':ref1_address', $data['ref1_address']);
            $stmt->bindParam(':ref1_phone', $data['ref1_phone']);
            $stmt->bindParam(':ref1_email', $data['ref1_email']);
            $stmt->bindParam(':ref1_position', $data['ref1_position']);
            $stmt->bindParam(':employee_id', $id, PDO::PARAM_INT);
            
            $stmt->execute();
            
            // Update reference 2 data
            $query = "UPDATE employee_references SET 
                      surname = :ref2_surname, other_names = :ref2_other_names, 
                      company = :ref2_company, address = :ref2_address, 
                      phone = :ref2_phone, email = :ref2_email, position = :ref2_position
                      WHERE employee_id = :employee_id AND reference_type = 'Reference 2'";
            
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':ref2_surname', $data['ref2_surname']);
            $stmt->bindParam(':ref2_other_names', $data['ref2_other_names']);
            $stmt->bindParam(':ref2_company', $data['ref2_company']);
            $stmt->bindParam(':ref2_address', $data['ref2_address']);
            $stmt->bindParam(':ref2_phone', $data['ref2_phone']);
            $stmt->bindParam(':ref2_email', $data['ref2_email']);
            $stmt->bindParam(':ref2_position', $data['ref2_position']);
            $stmt->bindParam(':employee_id', $id, PDO::PARAM_INT);
            
            $stmt->execute();
            
            $conn->commit();
            echo json_encode(['status' => 'success']);
        } catch (PDOException $e) {
            $conn->rollBack();
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;
        
    case 'DELETE':
        // Delete employee
        $id = $_GET['id'];
        
        try {
            $conn->beginTransaction();
            
            // The ON DELETE CASCADE will handle the related tables
            $query = "DELETE FROM employees WHERE id = :id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            
            $conn->commit();
            echo json_encode(['status' => 'success']);
        } catch (PDOException $e) {
            $conn->rollBack();
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
        break;
}