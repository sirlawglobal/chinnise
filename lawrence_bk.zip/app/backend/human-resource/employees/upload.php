<?php
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit;
}

if (!isset($_FILES['picture'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'No file uploaded']);
    exit;
}

$uploadDir = '../uploads/employees/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
$fileInfo = finfo_open(FILEINFO_MIME_TYPE);
$detectedType = finfo_file($fileInfo, $_FILES['picture']['tmp_name']);
finfo_close($fileInfo);

if (!in_array($detectedType, $allowedTypes)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid file type']);
    exit;
}

// Generate a unique filename
$fileName = uniqid() . '_' . preg_replace('/[^a-zA-Z0-9\.\-_]/', '', $_FILES['picture']['name']);
$targetPath = $uploadDir . $fileName;

try {
    if (move_uploaded_file($_FILES['picture']['tmp_name'], $targetPath)) {
        // Return the relative path (without the leading ../)
        $relativePath = str_replace('../', '', $targetPath);
        
        echo json_encode([
            'status' => 'success', 
            'path' => $relativePath
        ]);
    } else {
        throw new Exception('Failed to move uploaded file');
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}