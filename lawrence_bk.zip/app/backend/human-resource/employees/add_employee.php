
<!--add-employer-->
<?php
require '../../../settings/connection.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Handle image upload
    $target_dir = "uploads/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0755, true);
    }

    $picture = $_FILES["picture"]["name"];
    $target_file = $target_dir . basename($picture);
    move_uploaded_file($_FILES["picture"]["tmp_name"], $target_file);

    $sql = "INSERT INTO employees (
        picture, first_name, last_name, date_joined, position, status, department, location, marital_status,
        date_of_birth, phone, email, gender, state_of_origin, nino, medical_condition,
        bank_name, account_name, account_number,
        father_name, father_occupation, father_address, father_phone,
        mother_name, mother_occupation, mother_address, mother_phone,
        siblings_number,
        nok_surname, nok_other_names, nok_address, nok_phone, nok_email, nok_relationship,
        ref1_surname, ref1_other_names, ref1_company, ref1_address, ref1_phone, ref1_position,
        ref2_surname, ref2_other_names, ref2_company, ref2_address, ref2_phone, ref2_email, ref2_position
    ) VALUES (
        :picture, :first_name, :last_name, :date_joined, :position, :status, :department, :location, :marital_status,
        :date_of_birth, :phone, :email, :gender, :state_of_origin, :nino, :medical_condition,
        :bank_name, :account_name, :account_number,
        :father_name, :father_occupation, :father_address, :father_phone,
        :mother_name, :mother_occupation, :mother_address, :mother_phone,
        :siblings_number,
        :nok_surname, :nok_other_names, :nok_address, :nok_phone, :nok_email, :nok_relationship,
        :ref1_surname, :ref1_other_names, :ref1_company, :ref1_address, :ref1_phone, :ref1_position,
        :ref2_surname, :ref2_other_names, :ref2_company, :ref2_address, :ref2_phone, :ref2_email, :ref2_position
    )";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ':picture' => $target_file,
        ':first_name' => $_POST['first_name'],
        ':last_name' => $_POST['last_name'],
        ':date_joined' => $_POST['date_joined'],
        ':position' => $_POST['position'],
        ':status' => $_POST['status'],
        ':department' => $_POST['department'],
        ':location' => $_POST['location'],
        ':marital_status' => $_POST['marital_status'],
        ':date_of_birth' => $_POST['date_of_birth'],
        ':phone' => $_POST['phone'],
        ':email' => $_POST['email'],
        ':gender' => $_POST['gender'],
        ':state_of_origin' => $_POST['state_of_origin'],
        ':nino' => $_POST['nino'],
        ':medical_condition' => $_POST['medical_condition'],
        ':bank_name' => $_POST['bank_name'],
        ':account_name' => $_POST['account_name'],
        ':account_number' => $_POST['account_number'],
        ':father_name' => $_POST['father_name'],
        ':father_occupation' => $_POST['father_occupation'],
        ':father_address' => $_POST['father_address'],
        ':father_phone' => $_POST['father_phone'],
        ':mother_name' => $_POST['mother_name'],
        ':mother_occupation' => $_POST['mother_occupation'],
        ':mother_address' => $_POST['mother_address'],
        ':mother_phone' => $_POST['mother_phone'],
        ':siblings_number' => $_POST['siblings_number'],
        ':nok_surname' => $_POST['nok_surname'],
        ':nok_other_names' => $_POST['nok_other_names'],
        ':nok_address' => $_POST['nok_address'],
        ':nok_phone' => $_POST['nok_phone'],
        ':nok_email' => $_POST['nok_email'],
        ':nok_relationship' => $_POST['nok_relationship'],
        ':ref1_surname' => $_POST['ref1_surname'],
        ':ref1_other_names' => $_POST['ref1_other_names'],
        ':ref1_company' => $_POST['ref1_company'],
        ':ref1_address' => $_POST['ref1_address'],
        ':ref1_phone' => $_POST['ref1_phone'],
        ':ref1_position' => $_POST['ref1_position'],
        ':ref2_surname' => $_POST['ref2_surname'],
        ':ref2_other_names' => $_POST['ref2_other_names'],
        ':ref2_company' => $_POST['ref2_company'],
        ':ref2_address' => $_POST['ref2_address'],
        ':ref2_phone' => $_POST['ref2_phone'],
        ':ref2_email' => $_POST['ref2_email'],
        ':ref2_position' => $_POST['ref2_position']
    ]);

    echo "Employee data inserted successfully!";
}
?>
