<?php
require '../../../settings/connection.php';
$data = json_decode(file_get_contents('php://input'), true);
$sql = "INSERT INTO trainings (course_id, course_name, description, training_type, duration, training_date, training_time)
        VALUES (:ci, :cn, :desc, :type, :dur, :date, :time)";
$stmt = $pdo->prepare($sql);
$stmt->execute([
  ':ci'   => $data['course_id'],
  ':cn'   => $data['course_name'],
  ':desc' => $data['description'],
  ':type' => $data['training_type'],
  ':dur'  => $data['duration'],
  ':date' => $data['training_date'],
  ':time' => $data['training_time'],
]);
echo json_encode(['message' => 'Training added']);
