<?php
require '../../../settings/connection.php';
$data = json_decode(file_get_contents('php://input'), true);
$stmt = $pdo->prepare("DELETE FROM trainings WHERE id = ?");
$stmt->execute([$data['id']]);
echo json_encode(['message' => 'Deleted']);
