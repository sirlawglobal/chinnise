<?php
require '../../../settings/connection.php';
$data = json_decode(file_get_contents('php://input'), true);
$sql = "UPDATE trainings SET
  course_name = :cn,
  description = :desc,
  training_type = :type,
  duration = :dur,
  training_date = :date,
  training_time = :time
  WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([
  ':cn'   => $data['course_name'],
  ':desc' => $data['description'],
  ':type' => $data['training_type'],
  ':dur'  => $data['duration'],
  ':date' => $data['training_date'],
  ':time' => $data['training_time'],
  ':id'   => $data['id'],
]);
echo json_encode(['message' => 'Updated']);
