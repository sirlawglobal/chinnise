<?php
require '../../../settings/connection.php';
$stmt = $pdo->query("SELECT * FROM trainings ORDER BY id DESC");
echo json_encode($stmt->fetchAll());
