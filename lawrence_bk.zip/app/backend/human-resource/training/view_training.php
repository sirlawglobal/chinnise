<?php
require '../../../settings/connection.php';
$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM trainings WHERE id = ?");
$stmt->execute([$id]);
echo json_encode($stmt->fetch());
