<?php
require '../../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $id = $_POST['id'];
        
        $stmt = $pdo->prepare("DELETE FROM onboarding WHERE id = :id");
        $stmt->bindParam(':id', $id);
        
        if ($stmt->execute()) {
            echo "Onboarding record deleted successfully";
        } else {
            echo "Error deleting record";
        }
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
?>