<?php
require '../../../settings/connection.php';

if (isset($_GET['id'])) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM onboarding WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        header('Content-Type: application/json');
        echo json_encode($data);
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
?>