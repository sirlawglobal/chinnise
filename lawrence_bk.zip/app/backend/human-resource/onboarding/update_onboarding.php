<?php
require '../../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $id = $_POST['id'];
        
        // Prepare the update statement
        $stmt = $pdo->prepare("UPDATE onboarding SET 
            staff_id = :staff_id,
            staff_name = :staff_name,
            dept_name = :dept_name,
            hr_name = :hr_name,
            start_date = :start_date,
            offer_letter = :offer_letter,
            contract = :contract,
            employee_data_sheet = :employee_data_sheet,
            references_check = :references_check,
            nda = :nda,
            laptop = :laptop,
            headset = :headset,
            mouse = :mouse,
            domain_login = :domain_login,
            skype_logins = :skype_logins,
            other_logins = :other_logins,
            company_overview = :company_overview,
            company_culture = :company_culture,
            tour_premises = :tour_premises,
            staff_intro = :staff_intro,
            peer_mentor = :peer_mentor,
            responsibilities_discussed = :responsibilities_discussed,
            feedback_comment = :feedback_comment,
            time_keeping = :time_keeping,
            behaviour_integration = :behaviour_integration,
            initial_skills = :initial_skills,
            skills_14_learning = :skills_14_learning,
            skills_14_instructions = :skills_14_instructions,
            skills_14_review = :skills_14_review,
            skills_30_learning = :skills_30_learning,
            skills_30_instructions = :skills_30_instructions,
            skills_30_review = :skills_30_review,
            skills_60_learning = :skills_60_learning,
            skills_60_instructions = :skills_60_instructions,
            skills_60_review = :skills_60_review
            WHERE id = :id");

        // Bind all parameters
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':staff_id', $_POST['staff_id']);
        $stmt->bindParam(':staff_name', $_POST['staff_name']);
        $stmt->bindParam(':dept_name', $_POST['dept_name']);
        $stmt->bindParam(':hr_name', $_POST['hr_name']);
        $stmt->bindParam(':start_date', $_POST['start_date']);
        $stmt->bindParam(':offer_letter', $_POST['offer_letter']);
        $stmt->bindParam(':contract', $_POST['contract']);
        $stmt->bindParam(':employee_data_sheet', $_POST['employee_data_sheet']);
        $stmt->bindParam(':references_check', $_POST['references_check']);
        $stmt->bindParam(':nda', $_POST['nda']);
        $stmt->bindParam(':laptop', $_POST['laptop']);
        $stmt->bindParam(':headset', $_POST['headset']);
        $stmt->bindParam(':mouse', $_POST['mouse']);
        $stmt->bindParam(':domain_login', $_POST['domain_login']);
        $stmt->bindParam(':skype_logins', $_POST['skype_logins']);
        $stmt->bindParam(':other_logins', $_POST['other_logins']);
        $stmt->bindParam(':company_overview', $_POST['company_overview']);
        $stmt->bindParam(':company_culture', $_POST['company_culture']);
        $stmt->bindParam(':tour_premises', $_POST['tour_premises']);
        $stmt->bindParam(':staff_intro', $_POST['staff_intro']);
        $stmt->bindParam(':peer_mentor', $_POST['peer_mentor']);
        $stmt->bindParam(':responsibilities_discussed', $_POST['responsibilities_discussed']);
        $stmt->bindParam(':feedback_comment', $_POST['feedback_comment']);
        $stmt->bindParam(':time_keeping', $_POST['time_keeping']);
        $stmt->bindParam(':behaviour_integration', $_POST['behaviour_integration']);
        $stmt->bindParam(':initial_skills', $_POST['initial_skills']);
        $stmt->bindParam(':skills_14_learning', $_POST['skills_14_learning']);
        $stmt->bindParam(':skills_14_instructions', $_POST['skills_14_instructions']);
        $stmt->bindParam(':skills_14_review', $_POST['skills_14_review']);
        $stmt->bindParam(':skills_30_learning', $_POST['skills_30_learning']);
        $stmt->bindParam(':skills_30_instructions', $_POST['skills_30_instructions']);
        $stmt->bindParam(':skills_30_review', $_POST['skills_30_review']);
        $stmt->bindParam(':skills_60_learning', $_POST['skills_60_learning']);
        $stmt->bindParam(':skills_60_instructions', $_POST['skills_60_instructions']);
        $stmt->bindParam(':skills_60_review', $_POST['skills_60_review']);
        
        if ($stmt->execute()) {
            echo "Onboarding record updated successfully";
        } else {
            echo "Error updating record";
        }
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}