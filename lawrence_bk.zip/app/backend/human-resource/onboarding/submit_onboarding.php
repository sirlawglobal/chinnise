<?php
require '../../../settings/connection.php';

header('Content-Type: application/json');

error_reporting(E_ALL);
ini_set('display_errors', 1);

$response = ['success' => false, 'message' => ''];

try {
    $stmt = $pdo->prepare("
        INSERT INTO onboarding (
            staff_id, staff_name, dept_name, hr_name, start_date,
            offer_letter, contract, employee_data_sheet, references_check, nda,
            laptop, headset, mouse,
            domain_login, skype_logins, other_logins,
            company_overview, company_culture, tour_premises, staff_intro, peer_mentor,
            responsibilities_discussed, feedback_comment,
            time_keeping, behaviour_integration, initial_skills,
            skills_14_learning, skills_14_instructions, skills_14_review,
            skills_30_learning, skills_30_instructions, skills_30_review,
            skills_60_learning, skills_60_instructions, skills_60_review
        ) VALUES (
            :staff_id, :staff_name, :dept_name, :hr_name, :start_date,
            :offer_letter, :contract, :employee_data_sheet, :references_check, :nda,
            :laptop, :headset, :mouse,
            :domain_login, :skype_logins, :other_logins,
            :company_overview, :company_culture, :tour_premises, :staff_intro, :peer_mentor,
            :responsibilities_discussed, :feedback_comment,
            :time_keeping, :behaviour_integration, :initial_skills,
            :skills_14_learning, :skills_14_instructions, :skills_14_review,
            :skills_30_learning, :skills_30_instructions, :skills_30_review,
            :skills_60_learning, :skills_60_instructions, :skills_60_review
        )
    ");

    $params = [
        ':staff_id' => $_POST['staff_id'] ?? null,
        ':staff_name' => $_POST['staff_name'] ?? null,
        ':dept_name' => $_POST['dept_name'] ?? null,
        ':hr_name' => $_POST['hr_name'] ?? null,
        ':start_date' => $_POST['start_date'] ?? null,
        
        ':offer_letter' => $_POST['offer_letter'] ?? null,
        ':contract' => $_POST['contract'] ?? null,
        ':employee_data_sheet' => $_POST['employee_data_sheet'] ?? null,
        ':references_check' => $_POST['references_check'] ?? null,
        ':nda' => $_POST['nda'] ?? null,

        ':laptop' => $_POST['laptop'] ?? null,
        ':headset' => $_POST['headset'] ?? null,
        ':mouse' => $_POST['mouse'] ?? null,

        ':domain_login' => $_POST['domain_login'] ?? null,
        ':skype_logins' => $_POST['skype_logins'] ?? null,
        ':other_logins' => $_POST['other_logins'] ?? null,

        ':company_overview' => $_POST['company_overview'] ?? null,
        ':company_culture' => $_POST['company_culture'] ?? null,
        ':tour_premises' => $_POST['tour_premises'] ?? null,
        ':staff_intro' => $_POST['staff_intro'] ?? null,
        ':peer_mentor' => $_POST['peer_mentor'] ?? null,

        ':responsibilities_discussed' => $_POST['responsibilities_discussed'] ?? null,
        ':feedback_comment' => $_POST['feedback_comment'] ?? null,

        ':time_keeping' => $_POST['time_keeping'] ?? null,
        ':behaviour_integration' => $_POST['behaviour_integration'] ?? null,
        ':initial_skills' => $_POST['initial_skills'] ?? null,

        ':skills_14_learning' => $_POST['skills_14_learning'] ?? null,
        ':skills_14_instructions' => $_POST['skills_14_instructions'] ?? null,
        ':skills_14_review' => $_POST['skills_14_review'] ?? null,

        ':skills_30_learning' => $_POST['skills_30_learning'] ?? null,
        ':skills_30_instructions' => $_POST['skills_30_instructions'] ?? null,
        ':skills_30_review' => $_POST['skills_30_review'] ?? null,

        ':skills_60_learning' => $_POST['skills_60_learning'] ?? null,
        ':skills_60_instructions' => $_POST['skills_60_instructions'] ?? null,
        ':skills_60_review' => $_POST['skills_60_review'] ?? null
    ];

    // Debug: Check if all parameters are set
    file_put_contents('parameters.log', print_r($params, true));

    $success = $stmt->execute($params);

    if ($success) {
        $response['success'] = true;
        $response['message'] = "Onboarding data saved successfully!";
    } else {
        $response['message'] = "Failed to save data";
        $response['error_info'] = $stmt->errorInfo();
    }
} catch (PDOException $e) {
    $response['message'] = "Error saving data: " . $e->getMessage();
}

echo json_encode($response);
?>