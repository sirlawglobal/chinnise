<?php
header('Content-Type: application/json');
require_once '../../../settings/connection.php'; 

try {
    $stmt = $pdo->query("SELECT id, first_name, last_name, department FROM employees");
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($employees);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
