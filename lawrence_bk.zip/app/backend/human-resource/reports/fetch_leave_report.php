<?php
include_once '../../../settings/connection.php'; 

$startDate = $_GET['start_date'] ?? null;
$endDate = $_GET['end_date'] ?? null;
$employeeId = $_GET['employee_id'] ?? 'all';

$query = "SELECT lr.*, e.first_name 
          FROM leave_requests lr 
          JOIN employees e ON lr.employee_id = e.id 
          WHERE 1=1";

$params = [];

if ($startDate) {
    $query .= " AND lr.start_date >= :start_date";
    $params['start_date'] = $startDate;
}
if ($endDate) {
    $query .= " AND lr.end_date <= :end_date";
    $params['end_date'] = $endDate;
}
if ($employeeId !== 'all') {
    $query .= " AND lr.employee_id = :employee_id";
    $params['employee_id'] = $employeeId;
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);

$data = [];
$total_days = 0;

while ($row = $stmt->fetch()) {
    $days = (strtotime($row['end_date']) - strtotime($row['start_date'])) / (60 * 60 * 24);
    $row['leave_days'] = $days;
    $total_days += $days;
    $data[] = $row;
}

echo json_encode([
    'data' => $data,
    'total_days' => $total_days
]);
?>
