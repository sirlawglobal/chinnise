<?php
require_once '../../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("UPDATE leave_requests SET 
        employee_name = :employee_name,
        staff_id = :staff_id,
        leave_type = :leave_type,
        purpose = :purpose,
        description = :description,
        start_date = :start_date,
        duration = :duration,
        status = :status,
        approved_by = :approved_by,
        gender = :gender,
        request_date = :request_date
        WHERE id = :id");

    $stmt->execute([
        ':employee_name' => $_POST['employee_name'],
        ':staff_id' => $_POST['staff_id'],
        ':leave_type' => $_POST['leave_type'],
        ':purpose' => $_POST['purpose'],
        ':description' => $_POST['description'],
        ':start_date' => $_POST['start_date'],
        ':duration' => $_POST['duration'],
        ':status' => $_POST['status'],
        ':approved_by' => $_POST['approved_by'],
        ':gender' => $_POST['gender'],
        ':request_date' => $_POST['request_date'],
        ':id' => $_POST['id']
    ]);

    header("Location: ../../../human-resource/leave-management.php"); // adjust as needed
    exit();
}
?>
