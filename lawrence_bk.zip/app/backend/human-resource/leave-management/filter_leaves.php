<?php
require_once '../../../settings/connection.php';

$where = [];
$params = [];

if (!empty($_GET['name'])) {
    $where[] = "employee_name LIKE :name";
    $params[':name'] = "%" . $_GET['name'] . "%";
}

if (!empty($_GET['month'])) {
    $where[] = "MONTH(request_date) = :month";
    $params[':month'] = $_GET['month'];
}

if (!empty($_GET['year'])) {
    $where[] = "YEAR(request_date) = :year";
    $params[':year'] = $_GET['year'];
}

if (!empty($_GET['type'])) {
    $where[] = "leave_type = :type";
    $params[':type'] = $_GET['type'];
}

$sql = "SELECT * FROM leave_requests";
if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY request_date DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['staff_id']) . "</td>";
    echo "<td>" . htmlspecialchars($row['employee_name']) . "</td>";
    echo "<td>" . htmlspecialchars($row['leave_type']) . "</td>";
    echo "<td>" . htmlspecialchars($row['purpose']) . "</td>";
    echo "<td>" . htmlspecialchars($row['duration']) . "</td>";
    echo "<td>" . htmlspecialchars($row['request_date']) . "</td>";
    echo "<td>" . htmlspecialchars(ucfirst($row['status'])) . "</td>";
    echo "<td><i class='view-icon' data-id='{$row['id']}'><img src='../assets/eye-open.png'></i></td>";
    echo "<td><i class='edit-icon' data-id='{$row['id']}'><img src='../assets/edit.svg'></i></td>";
    echo "<td><i class='delete-icon' data-id='{$row['id']}'><img src='../assets/Delete.svg'></i></td>";
    echo "</tr>";
}
?>
