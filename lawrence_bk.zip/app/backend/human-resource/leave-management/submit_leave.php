<?php
// Include your database connection
require_once '../../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $stmt = $pdo->prepare("INSERT INTO leave_requests
            (employee_name, staff_id, leave_type, purpose, description, start_date, duration, status, approved_by, gender, request_date)
            VALUES
            (:employee_name, :staff_id, :leave_type, :purpose, :description, :start_date, :duration, :status, :approved_by, :gender, :request_date)");

        $stmt->execute([
            ':employee_name' => $_POST['employee_name'],
            ':staff_id'      => $_POST['staff_id'],
            ':leave_type'    => $_POST['leave_type'],
            ':purpose'       => $_POST['purpose'],
            ':description'   => $_POST['description'],
            ':start_date'    => $_POST['start_date'],
            ':duration'      => $_POST['duration'],
            ':status'        => $_POST['status'],
            ':approved_by'   => $_POST['approved_by'],
            ':gender'        => $_POST['gender'],
            ':request_date'  => $_POST['request_date']
        ]);

        // Redirect to index.php after successful submission
        header("Location: ../../../human-resource/leave-management.php");
        exit(); // Always call exit() after a header redirect to prevent further code execution
    } catch (PDOException $e) {
        // You might want to redirect to an error page or display a more user-friendly message
        echo "Error: " . $e->getMessage();
    }
}