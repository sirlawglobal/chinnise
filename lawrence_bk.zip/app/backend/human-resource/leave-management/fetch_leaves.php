<?php
require_once '../settings/connection.php';

try {
    $stmt = $pdo->query("SELECT id, staff_id, employee_name, leave_type, purpose, duration, request_date, status FROM leave_requests ORDER BY request_date DESC");

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>100" . htmlspecialchars($row['staff_id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['employee_name']) . "</td>";
        echo "<td>" . htmlspecialchars(ucwords(str_replace('_', ' ', $row['leave_type']))) . "</td>";
        echo "<td>" . htmlspecialchars($row['purpose']) . "</td>";
        echo "<td>" . htmlspecialchars($row['duration']) . "</td>";
        echo "<td>" . date('d-m-Y', strtotime($row['request_date'])) . "</td>";
        echo "<td>" . htmlspecialchars(ucfirst($row['status'])) . "</td>";

        // Add View, Edit, Delete icons with data-id for JS actions
        echo "<td><i class='view-icon' data-id='{$row['id']}'><img src='../assets/eye-open.png'></i></td>";
        echo "<td><i class='edit-icon' data-id='{$row['id']}'><img src='../assets/edit.svg'></i></td>";
        echo "<td><i class='delete-icon' data-id='{$row['id']}'><img src='../assets/Delete.svg'></i></td>";
        echo "</tr>";
    }
} catch (PDOException $e) {
    echo "<tr><td colspan='10'>Error fetching data: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
}
?>
