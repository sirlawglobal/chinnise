<?php
require_once '../../../settings/connection.php';

if (isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM leave_requests WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    echo "Leave request deleted successfully.";
}
?>
