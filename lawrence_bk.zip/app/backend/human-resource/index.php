<?
include_once 'settings/connection.php';

$stmt8 = $pdo->query("SELECT COUNT(*) FROM leave_requests");
$leave = $stmt8->fetchColumn();

$stmt9 = $pdo->query("SELECT COUNT(*) FROM leave_requests WHERE gender = 'male'");
$leave_male = $stmt9->fetchColumn();

$stmt10 = $pdo->query("SELECT COUNT(*) FROM leave_requests WHERE gender = 'female'");
$leave_female = $stmt10->fetchColumn();
