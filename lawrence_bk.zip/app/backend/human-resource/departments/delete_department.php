<?php
include_once '../../../settings/connection.php';
header('Content-Type: application/json');

try {
    if (!isset($_POST['id']) || !is_numeric($_POST['id']) || $_POST['id'] <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid or missing department ID']);
        exit;
    }

    $id = (int)$_POST['id'];
    $stmt = $pdo->prepare("DELETE FROM departments WHERE id = ?");
    $stmt->execute([$id]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(['status' => 'success', 'message' => 'Department deleted successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Department not found']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
?>