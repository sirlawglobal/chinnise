<?php
include_once '../../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $dept_name   = $_POST['dept_name'];
    $dept_head   = $_POST['dept_head'];
    $staff_count = $_POST['staff_count'];
    $admin_dept  = $_POST['admin_dept'];
    $location    = $_POST['location'];

$stmt = $pdo->prepare("INSERT INTO departments (dept_name, dept_head, staff_count, admin_dept, location) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$dept_name, $dept_head, $staff_count, $admin_dept, $location]);

    echo json_encode(['status' => 'success']);
}
?>
