<?php
include_once '../../../settings/connection.php';
header('Content-Type: application/json');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
        exit;
    }

    if (!isset($_POST['id']) || !is_numeric($_POST['id']) || $_POST['id'] <= 0 ||
        empty($_POST['dept_name']) || empty($_POST['dept_head']) ||
        !is_numeric($_POST['staff_count']) || $_POST['staff_count'] < 0 ||
        empty($_POST['admin_dept']) || empty($_POST['location'])) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid or missing input data']);
        exit;
    }

    $id = (int)$_POST['id'];
    $dept_name = $_POST['dept_name'];
    $dept_head = $_POST['dept_head'];
    $staff_count = (int)$_POST['staff_count'];
    $admin_dept = $_POST['admin_dept'];
    $location = $_POST['location'];

    $stmt = $pdo->prepare("UPDATE departments SET dept_name=?, dept_head=?, staff_count=?, admin_dept=?, location=? WHERE id=?");
    $stmt->execute([$dept_name, $dept_head, $staff_count, $admin_dept, $location, $id]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(['status' => 'success', 'message' => 'Department updated successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => ' Oppss! No changes made']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
?>