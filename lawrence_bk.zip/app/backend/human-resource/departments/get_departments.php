<?php
include_once '../../../settings/connection.php';

// Get pagination parameters
$page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
$rowsPerPage = isset($_POST['rows_per_page']) ? (int)$_POST['rows_per_page'] : 25;
$offset = ($page - 1) * $rowsPerPage;

// Count total rows
$totalRows = $pdo->query("SELECT COUNT(*) FROM departments")->fetchColumn();
$totalPages = ceil($totalRows / $rowsPerPage);

// Fetch paginated data
$stmt = $pdo->prepare("SELECT * FROM departments LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $rowsPerPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Respond with data and pagination info
echo json_encode([
  'status' => 'success',
  'data' => $departments,
  'totalPages' => $totalPages,
  'currentPage' => $page,
]);
