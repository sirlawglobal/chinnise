<?php
require '../../../settings/connection.php'; // Ensure this path is correct

header('Content-Type: application/json'); // Always send JSON response

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit();
}

// Assign POST data to variables, using null coalescing to be safe
$award_name = $_POST['award_name'] ?? '';
$award_description = $_POST['award_description'] ?? '';
$gift_item = $_POST['gift_item'] ?? '';
$award_date = $_POST['award_date'] ?? '';
$first_name = $_POST['first_name'] ?? '';
$last_name = $_POST['last_name'] ?? '';
$awarded_by = $_POST['awarded_by'] ?? '';

// Basic validation (you can add more robust validation here)
if (empty($award_name) || empty($award_description) || empty($gift_item) || empty($award_date) || empty($first_name) || empty($last_name) || empty($awarded_by)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit();
}

try {
    $stmt = $pdo->prepare("
        INSERT INTO awards (award_name, award_description, gift_item, award_date, first_name, last_name, awarded_by)
        VALUES (:award_name, :award_description, :gift_item, :award_date, :first_name, :last_name, :awarded_by)
    ");

    $stmt->execute([
        ':award_name' => $award_name,
        ':award_description' => $award_description,
        ':gift_item' => $gift_item,
        ':award_date' => $award_date,
        ':first_name' => $first_name,
        ':last_name' => $last_name,
        ':awarded_by' => $awarded_by
    ]);

    // Check if the insert was successful
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Award added successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to add award: No rows affected.']);
    }

} catch (PDOException $e) {
    // Log the error for debugging (check your server's error logs)
    error_log("Database error in add_award.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error: Could not add award.']);
}
?>