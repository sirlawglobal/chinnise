<?php
require '../../../settings/connection.php'; // Ensure this path is correct

header('Content-Type: application/json'); // Always send JSON response

try {
    // Prepare the statement
    $stmt = $pdo->prepare("SELECT * FROM awards ORDER BY award_date DESC");

    // Execute without binding any parameters
    $stmt->execute();

    // Fetch all results
    $awards = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Return JSON response
    echo json_encode($awards);

} catch (PDOException $e) {
    // Log the error
    error_log("Database error in fetch_awards.php: " . $e->getMessage());

    // Send error message to frontend
    echo json_encode(['error' => 'Failed to fetch awards. Please try again later.']);
}
?>
