<?php
require '../../../settings/connection.php'; // Ensure this path is correct

header('Content-Type: application/json'); // Always send JSON response

try {
    // 1. Define the award name you're looking for
    $awardName = "Top performer"; // Use a variable for clarity

    // 2. Prepare the statement with a placeholder for the string literal
    $stmt = $pdo->prepare("SELECT * FROM awards WHERE award_name = :award_name ORDER BY award_date DESC");

    // 3. Execute the statement, passing the value for the placeholder
    $stmt->execute([':award_name' => $awardName]);

    // 4. Fetch all results
    $awards = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 5. Encode and echo the JSON response
    echo json_encode($awards);

} catch (PDOException $e) {
    // Log the error for debugging purposes (check your server's error logs)
    error_log("Database error in fetch_awards.php: " . $e->getMessage());

    // Send an error response to the client
    echo json_encode(['error' => 'Failed to fetch awards. Please try again later.']);
}
?>