<?php
require '../../../settings/connection.php'; // Ensure this path is correct

header('Content-Type: application/json'); // Always send JSON response

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit();
}

// Check if ID is set (essential for an update)
if (!isset($_POST['id']) || empty($_POST['id'])) {
    echo json_encode(['success' => false, 'message' => 'Award ID is missing or empty.']);
    exit();
}

// Assign POST data to variables
$id = $_POST['id'];
$award_name = $_POST['award_name'] ?? ''; // Use null coalescing to prevent undefined index if field is missing
$award_description = $_POST['award_description'] ?? '';
$gift_item = $_POST['gift_item'] ?? '';
$award_date = $_POST['award_date'] ?? '';
$first_name = $_POST['first_name'] ?? '';
$last_name = $_POST['last_name'] ?? '';
$awarded_by = $_POST['awarded_by'] ?? '';

try {
    $stmt = $pdo->prepare("
        UPDATE awards SET
            award_name = :award_name,
            award_description = :award_description,
            gift_item = :gift_item,
            award_date = :award_date,
            first_name = :first_name,
            last_name = :last_name,
            awarded_by = :awarded_by
        WHERE id = :id
    ");

    $stmt->execute([
        ':award_name' => $award_name,
        ':award_description' => $award_description,
        ':gift_item' => $gift_item,
        ':award_date' => $award_date,
        ':first_name' => $first_name,
        ':last_name' => $last_name,
        ':awarded_by' => $awarded_by,
        ':id' => $id
    ]);

    // Check if any rows were affected
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Award updated successfully.']);
    } else {
        // This could mean the ID wasn't found, or no data actually changed
        echo json_encode(['success' => false, 'message' => 'No award found with the given ID, or no changes were made.']);
    }

} catch (PDOException $e) {
    // Log the error for debugging purposes (check your server's error logs)
    error_log("Database error in update_award.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error: Could not update award.']);
}
?>