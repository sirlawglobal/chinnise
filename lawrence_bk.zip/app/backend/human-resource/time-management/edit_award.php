<?php
require '../../../settings/connection.php';

$data = json_decode(file_get_contents("php://input"), true);

$stmt = $pdo->prepare("UPDATE awards SET 
    award_name = :award_name,
    award_description = :award_description,
    gift_item = :gift_item,
    award_date = :award_date,
    first_name = :first_name,
    last_name = :last_name,
    awarded_by = :awarded_by
WHERE id = :id");

$stmt->execute([
    ':award_name' => $data['award_name'],
    ':award_description' => $data['award_description'],
    ':gift_item' => $data['gift_item'],
    ':award_date' => $data['award_date'],
    ':first_name' => $data['first_name'],
    ':last_name' => $data['last_name'],
    ':awarded_by' => $data['awarded_by'],
    ':id' => $data['id']
]);

echo json_encode(["message" => "Award updated successfully"]);
?>
