<?php
require '../../../settings/connection.php';

$data = json_decode(file_get_contents("php://input"), true);

$stmt = $pdo->prepare("DELETE FROM awards WHERE id = :id");
$stmt->execute([':id' => $data['id']]);

echo json_encode(["message" => "Award deleted successfully"]);
?>
