<?php
require_once '../../../settings/connection.php';

$data = json_decode(file_get_contents("php://input"), true);

$id = intval($data['id']);
$level = trim($data['level']);
$name = trim($data['pay_grade_name']);
$salary = floatval($data['gross_salary']);
$paye = floatval($data['paye'] ?? 0);
$pension = floatval($data['pension']);
$overtime = floatval($data['overtime_rate'] ?? 0);

$query = "UPDATE pay_grades SET
            level = :level,
            pay_grade_name = :name,
            gross_salary = :salary,
            paye = :paye,
            pension = :pension,
            overtime_rate = :overtime
          WHERE id = :id";

$stmt = $pdo->prepare($query);
$result = $stmt->execute([
    ':level' => $level,
    ':name' => $name,
    ':salary' => $salary,
    ':paye' => $paye,
    ':pension' => $pension,
    ':overtime' => $overtime,
    ':id' => $id
]);

echo json_encode(['success' => $result]);
