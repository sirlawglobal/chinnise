<?php
require_once '../../../settings/connection.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data['id']);

$query = "DELETE FROM pay_grades WHERE id = :id";
$stmt = $pdo->prepare($query);
$result = $stmt->execute([':id' => $id]);

echo json_encode(['success' => $result]);
