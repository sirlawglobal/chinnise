<?php
require_once '../../../settings/connection.php';

$data = json_decode(file_get_contents("php://input"), true);

$level = trim($data['level']);
$name = trim($data['pay_grade_name']);
$salary = floatval($data['gross_salary']);
$paye = floatval($data['paye'] ?? 0);
$pension = floatval($data['pension']);
$overtime = floatval($data['overtime_rate'] ?? 0);

$query = "INSERT INTO pay_grades (level, pay_grade_name, gross_salary, paye, pension, overtime_rate)
          VALUES (:level, :name, :salary, :paye, :pension, :overtime)";

$stmt = $pdo->prepare($query);
$result = $stmt->execute([
    ':level' => $level,
    ':name' => $name,
    ':salary' => $salary,
    ':paye' => $paye,
    ':pension' => $pension,
    ':overtime' => $overtime
]);

echo json_encode(['success' => $result]);
