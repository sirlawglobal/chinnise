<?php
require_once '../../../settings/connection.php';

$query = "SELECT * FROM pay_grades ORDER BY created_at DESC";
$stmt = $pdo->prepare($query);
$stmt->execute();
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($data);
