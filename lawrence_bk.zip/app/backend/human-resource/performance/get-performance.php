<?php
require_once '../../../settings/connection.php';

if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $stmt = $pdo->prepare("SELECT * FROM performance_appraisals WHERE id = ?");
  $stmt->execute([$id]);
  $data = $stmt->fetch();
  if ($data) {
    echo json_encode($data);
  } else {
    echo json_encode(['error' => 'Not found']);
  }
} else {
  echo json_encode(['error' => 'No ID provided']);
}
?>
