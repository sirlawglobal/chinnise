<?php
require_once '../../../settings/connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['createPerformance'])) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO performance_appraisals (
                employee_name, review_period, supervisor_name, staff_id, performance_date, supervisor_position,
                demonstrated_knowledge, demonstrated_knowledge_score, demonstrated_knowledge_comment,
                timeliness_of_delivery, timeliness_of_delivery_score, timeliness_of_delivery_comment,
                impact_of_investment, impact_of_investment_score, impact_of_investment_comment,
                achievement_of_goals, achievement_of_goals_score, achievement_of_goals_comment,
                bonus_point_score
            ) VALUES (
                :employee_name, :review_period, :supervisor_name, :staff_id, :performance_date, :supervisor_position,
                :demonstrated_knowledge, :demonstrated_knowledge_score, :demonstrated_knowledge_comment,
                :timeliness_of_delivery, :timeliness_of_delivery_score, :timeliness_of_delivery_comment,
                :impact_of_investment, :impact_of_investment_score, :impact_of_investment_comment,
                :achievement_of_goals, :achievement_of_goals_score, :achievement_of_goals_comment,
                :bonus_point_score
            )
        ");

        $stmt->execute([
            ':employee_name' => $_POST['employee_name'],
            ':review_period' => $_POST['review_period'],
            ':supervisor_name' => $_POST['supervisor_name'] ?? null,
            ':staff_id' => $_POST['staff_id'] ?? null,
            ':performance_date' => $_POST['performance_date'],
            ':supervisor_position' => $_POST['supervisor_position'] ?? null,

            ':demonstrated_knowledge' => $_POST['demonstrated_knowledge'] ?? null,
            ':demonstrated_knowledge_score' => $_POST['demonstrated_knowledge_score'] ?? null,
            ':demonstrated_knowledge_comment' => $_POST['demonstrated_knowledge_comment'] ?? null,

            ':timeliness_of_delivery' => $_POST['timeliness_of_delivery'] ?? null,
            ':timeliness_of_delivery_score' => $_POST['timeliness_of_delivery_score'] ?? null,
            ':timeliness_of_delivery_comment' => $_POST['timeliness_of_delivery_comment'] ?? null,

            ':impact_of_investment' => $_POST['impact_of_investment'] ?? null,
            ':impact_of_investment_score' => $_POST['impact_of_investment_score'] ?? null,
            ':impact_of_investment_comment' => $_POST['impact_of_investment_comment'] ?? null,

            ':achievement_of_goals' => $_POST['achievement_of_goals'] ?? null,
            ':achievement_of_goals_score' => $_POST['achievement_of_goals_score'] ?? null,
            ':achievement_of_goals_comment' => $_POST['achievement_of_goals_comment'] ?? null,

            ':bonus_point_score' => $_POST['bonus_point_score'] ?? null,
        ]);

        echo "Performance appraisal successfully submitted.";
        header("Location: ../../../human-resource/staff-performance.php");
        exit();

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>