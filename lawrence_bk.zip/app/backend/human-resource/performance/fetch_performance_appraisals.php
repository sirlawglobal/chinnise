<?php
require_once '../../../settings/connection.php';

$sql = "SELECT staff_id, employee_name, supervisor_position, review_period, performance_date 
        FROM performance_appraisals";
$stmt = $pdo->query($sql);
$rows = $stmt->fetchAll();
?>
