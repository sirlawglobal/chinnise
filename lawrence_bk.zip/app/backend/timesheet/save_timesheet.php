<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
include_once '../../settings/connection.php';

if (!isset($_SESSION['user_id'])) {
    echo "Unauthorized";
    exit;
}

$staff_id = $_SESSION['user_id']; // This should match the 'id' column in the staff table
$type = $_POST['type'] ?? '';
$note = $_POST['note'] ?? '';
$time = $_POST['time'] ?? '';
$date = $_POST['date'] ?? '';

// Check if there's already a clock-in without clock-out for today (NT only)
if ($type === 'NT') {
    $stmt = $pdo->prepare("SELECT * FROM timesheet WHERE staff_id = ? AND date = ? AND time_out IS NULL");
    $stmt->execute([$staff_id, $date]);
    $existing = $stmt->fetch();

    if ($existing) {
        // Update time_out
        $update = $pdo->prepare("UPDATE timesheet SET time_out = ? WHERE id = ?");
        $update->execute([$time, $existing['id']]);
        echo "Clocked out successfully.";
    } else {
        // Insert new clock-in
        $insert = $pdo->prepare("INSERT INTO timesheet (staff_id, time_in, date, note, type) VALUES (?, ?, ?, ?, ?)");
        $insert->execute([$staff_id, $time, $date, $note, $type]);
        echo "Clocked in successfully.";
    }
} elseif ($type === 'OT') {
    // Always insert new record for overtime
    $insert = $pdo->prepare("INSERT INTO timesheet (staff_id, time_in, date, note, type) VALUES (?, ?, ?, ?, ?)");
    $insert->execute([$staff_id, $time, $date, $note, $type]);
    echo "Overtime logged successfully.";
} else {
    echo "Invalid type.";
}
