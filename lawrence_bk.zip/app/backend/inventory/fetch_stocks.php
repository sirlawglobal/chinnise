<?php
include_once '../../settings/connection.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT stock_id, item, size, unit_price, qty, total_price, description, reorder_trigger, created_at,colour FROM stocks ORDER BY stock_id ASC");
    $stocks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $stocks]);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Fetch Stocks Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch stocks']);
}
