<?php


include_once '../../../settings/connection.php';
header('Content-Type: application/json');

try {
    $client_id = $_GET['client_id'] ?? null;
    $sql = "
        SELECT o.id, o.order_date, o.delivery_date, o.total_amount, o.order_completed,
               s.id AS client_id, s.contact_firstname AS first_name, s.contact_surname AS last_name
        FROM orders o
        LEFT JOIN leads s ON o.client_id = s.id";
    $params = [];
    if ($client_id) {
        $sql .= " WHERE o.client_id = ? ";
        $params[] = $client_id;
    }
    $sql .= " ORDER BY o.id ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch items for all orders
    $orderIds = array_column($orders, 'id');
    $items = [];
    if (!empty($orderIds)) {
        $in = str_repeat('?,', count($orderIds) - 1) . '?';
        $stmtItems = $pdo->prepare("SELECT * FROM order_items WHERE order_id IN ($in)");
        $stmtItems->execute($orderIds);
        foreach ($stmtItems->fetchAll(PDO::FETCH_ASSOC) as $item) {
            $items[$item['order_id']][] = $item;
        }
    }

    // Attach items to orders
    foreach ($orders as &$order) {
        $order['items'] = $items[$order['id']] ?? [];
    }

    echo json_encode(['success' => true, 'data' => $orders]);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Fetch Client Orders Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch client orders']);
}
