<?php

include_once '../../../settings/connection.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit;
}

$order_id = $_POST['order_id'] ?? null;
if (!$order_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Order ID missing']);
    exit;
}

try {
    $pdo->beginTransaction();

    // 1. Fetch all items for this order
    $stmt = $pdo->prepare("SELECT item_name, quantity FROM order_items WHERE order_id = ?");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 2. Restore stock for each item
    foreach ($items as $item) {
        $stmtUpdate = $pdo->prepare("UPDATE stocks SET qty = qty + ? WHERE item = ?");
        $stmtUpdate->execute([$item['quantity'], $item['item_name']]);
    }

    // 3. Delete items
    $stmt = $pdo->prepare("DELETE FROM order_items WHERE order_id = ?");
    $stmt->execute([$order_id]);

    // 4. Delete the order
    $stmt = $pdo->prepare("DELETE FROM orders WHERE id = ?");
    $stmt->execute([$order_id]);

    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Delete Clients Order Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to delete order']);
}
