<?php

include_once '../../../settings/connection.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT id,email, phone_number,contact_surname AS last_name,contact_firstname AS first_name FROM leads WHERE client_type ='client' ORDER BY created_at DESC");
    $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $clients]);
} catch (Exception $e) {
    // Log error
    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Fetch Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch suppliers']);
}
