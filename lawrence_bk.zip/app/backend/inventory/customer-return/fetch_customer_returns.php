<?php

include_once '../../../settings/connection.php';
header('Content-Type: application/json');


try {

    $client_id = $_GET['client_id'] ?? null;
    $sql = "
        SELECT r.id, r.order_id, r.client_id, r.order_date, r.total_amount, r.return_reason, r.return_status, r.return_completed, r.received_date,
               c.contact_firstname AS first_name, c.contact_surname AS last_name,
               o.total_amount AS order_total
        FROM customer_returns r
        LEFT JOIN leads c ON r.client_id = c.id
        LEFT JOIN orders o ON r.order_id = o.id
    ";
    $params = [];
    if ($client_id) {
        $sql .= " WHERE r.client_id = ? ";
        $params[] = $client_id;
    }
    $sql .= " ORDER BY r.id DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $returns = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch items for all returns
    $returnIds = array_column($returns, 'id');
    $items = [];
    if (!empty($returnIds)) {
        $in = str_repeat('?,', count($returnIds) - 1) . '?';
        $stmtItems = $pdo->prepare("SELECT * FROM customer_return_items WHERE return_id IN ($in)");
        $stmtItems->execute($returnIds);
        foreach ($stmtItems->fetchAll(PDO::FETCH_ASSOC) as $item) {
            $items[$item['return_id']][] = $item;
        }
    }

    // Attach items to returns
    foreach ($returns as &$return) {
        $return['items'] = $items[$return['id']] ?? [];
    }

    echo json_encode(['success' => true, 'data' => $returns]);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Fetch Customer Returns Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch customer returns']);
}
