<?php

include_once '../../../settings/connection.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit;
}

$return_id = $_POST['return_id'] ?? null;
if (!$return_id) {
    echo json_encode(['success' => false, 'error' => 'Missing return ID']);
    exit;
}

try {
    $pdo->beginTransaction();
    $pdo->prepare("DELETE FROM supplier_return_items WHERE return_id = ?")->execute([$return_id]);
    $pdo->prepare("DELETE FROM supplier_returns WHERE id = ?")->execute([$return_id]);
    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to delete return']);
}
