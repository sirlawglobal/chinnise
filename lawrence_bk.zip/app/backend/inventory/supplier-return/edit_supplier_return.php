<?php


include_once '../../../settings/connection.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit;
}

try {
    $pdo->beginTransaction();

    $return_id = $_POST['return_id'];
    $order_id = $_POST['order_id'];
    $client_id = $_POST['client_id'];
    $order_date = $_POST['order_date'];
    $total_amount = $_POST['total_order_value'];
    $return_reason = $_POST['return_reason'];
    $return_status = $_POST['return_status'];
    $return_completed = $_POST['return_completed'];
    $received_date = $_POST['received_date'];

    // Update customer_returns
    $stmt = $pdo->prepare("UPDATE supplier_returns SET 
         supplier_id = ?, order_date = ?, total_amount = ?, 
        return_reason = ?, return_status = ?, return_completed = ?, received_date = ?
        WHERE id = ?");
    $stmt->execute([
        $client_id,
        $order_date,
        $total_amount,
        $return_reason,
        $return_status,
        $return_completed,
        $received_date,
        $return_id
    ]);

    // Remove old items
    $pdo->prepare("DELETE FROM supplier_return_items WHERE return_id = ?")->execute([$return_id]);

    // Insert new items
    $order_item_ids = $_POST['order_item_id'];
    $stock_ids = $_POST['stock_id'];
    $item_names = $_POST['item_name'];
    $unit_prices = $_POST['unit_price'];
    $quantities = $_POST['quantity'];

    $stmt_item = $pdo->prepare("INSERT INTO supplier_return_items 
        (order_item_id, return_id, stock_id, item_name, quantity, unit_price) 
        VALUES (?, ?, ?, ?, ?, ?)");

    for ($i = 0; $i < count($item_names); $i++) {
        $stmt_item->execute([
            $order_item_ids[$i],
            $return_id,
            $stock_ids[$i],
            $item_names[$i],
            $quantities[$i],
            $unit_prices[$i]
        ]);
    }

    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Edit Customer Return Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to update customer return']);
}
