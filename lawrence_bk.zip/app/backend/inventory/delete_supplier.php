<?php


include_once '../../settings/connection.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $sql = "DELETE FROM suppliers WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':id' => $_POST['supplier_id']
        ]);
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        file_put_contents(
            __DIR__ . '/inventory_log.log',
            date('Y-m-d H:i:s') . " - Delete Error: " . $e->getMessage() . PHP_EOL,
            FILE_APPEND
        );
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to delete supplier']);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
