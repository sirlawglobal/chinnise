<?php


include_once '../../settings/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $sql = "INSERT INTO suppliers (
          first_name, last_name, email, phone_number,name,address
      ) VALUES (
          :first_name, :last_name, :email, :phone_number,:name,:address
      )";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':first_name' => $_POST['first_name'],
            ':last_name' => $_POST['last_name'],
            ':email' => $_POST['email'],
            ':phone_number' => $_POST['phone_number'],
            ':name' => $_POST['name'],
            ':address' => $_POST['address']
        ]);

        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        // Log error to inventory_log.txt
        file_put_contents(
            __DIR__ . '/inventory_log.log',
            date('Y-m-d H:i:s') . " - Error: " . $e->getMessage() . PHP_EOL,
            FILE_APPEND
        );
        http_response_code(500);
        echo json_encode(['error' => 'Failed to add supplier']);
    }
}
