<?php


include_once '../../settings/connection.php';
header('Content-Type: application/json');

try {
    // Fetch orders with supplier info
    $client_id = $_GET['client_id'] ?? null;
    $sql = "
        SELECT o.id, o.order_date, o.delivery_date, o.total_amount, o.order_completed,s.id AS supplier_id, s.first_name, s.last_name
        FROM supplier_orders o
        LEFT JOIN suppliers s ON o.supplier_id = s.id";
    $params = [];
    if ($client_id) {
        $sql .= " WHERE o.supplier_id = ? ";
        $params[] = $client_id;
    }
    $sql .= " ORDER BY o.id ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch items for all orders
    $orderIds = array_column($orders, 'id');
    $items = [];
    if (!empty($orderIds)) {
        $in = str_repeat('?,', count($orderIds) - 1) . '?';
        $stmtItems = $pdo->prepare("SELECT * FROM supplier_order_items WHERE order_id IN ($in)");
        $stmtItems->execute($orderIds);
        foreach ($stmtItems->fetchAll(PDO::FETCH_ASSOC) as $item) {
            $items[$item['order_id']][] = $item;
        }
    }

    // Attach items to orders
    foreach ($orders as &$order) {
        $order['items'] = $items[$order['id']] ?? [];
    }

    echo json_encode(['success' => true, 'data' => $orders]);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Fetch Supplier Orders Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch supplier orders']);
}
