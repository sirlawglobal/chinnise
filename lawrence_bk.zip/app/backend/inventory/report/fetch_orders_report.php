<?php
// filepath: d:\xampp\htdocs\crm128\backend\inventory\fetch_returns.php

include_once '../../../settings/connection.php';
header('Content-Type: application/json');

// Get filter values from the request, with empty defaults
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';


$sql = "SELECT 
            cri.id,
            cri.order_id,
            l.id AS supplier_id,
            l.email, 
             CONCAT(l.first_name, ' ', l.last_name) AS customer_name,
            cri.item_name,
            cr.delivery_date,
            cr.order_completed AS status
        FROM 
            supplier_order_items cri
        LEFT JOIN 
            supplier_orders cr ON cri.order_id = cr.id
        LEFT JOIN 
            suppliers l ON cr.supplier_id = l.id
        WHERE 1";

$params = [];

// Append search condition if a search term is provided
if ($search !== '') {
    // The query searches the item name or the order ID.
    $sql .= " AND (cri.item_name LIKE ? OR cr.supplier_id LIKE ?)";
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

// Append status filter if a status is selected
if ($status !== '' && $status !== 'Filter by Status') {
    $sql .= " AND cr.order_completed = ?";
    $params[] = $status;
}

// Order the results by the most recent return date
$sql .= " ORDER BY cr.delivery_date DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $returns = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Return a success response with the fetched data
    echo json_encode(['success' => true, 'data' => $returns]);
} catch (PDOException $e) {
    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Fetch Stocks Report Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );

    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
