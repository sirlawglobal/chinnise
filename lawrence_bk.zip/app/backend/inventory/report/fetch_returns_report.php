<?php
// filepath: d:\xampp\htdocs\crm128\backend\inventory\fetch_returns.php

include_once '../../../settings/connection.php';
header('Content-Type: application/json');

// Get filter values from the request, with empty defaults
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';

// Base SQL query to select all necessary fields by joining the three tables.
// I've used LEFT JOINs to ensure that all return items are included,
// even if associated lead information is missing.
$sql = "SELECT 
            cri.id,
            cr.order_id,
            CONCAT(l.contact_firstname, ' ', l.contact_surname) AS customer_name,
            cri.item_name,
            cr.received_date,
            cr.return_completed AS status
        FROM 
            customer_return_items cri
        LEFT JOIN 
            customer_returns cr ON cri.return_id = cr.id
        LEFT JOIN 
            leads l ON cr.client_id = l.id
        WHERE 1";

$params = [];

// Append search condition if a search term is provided
if ($search !== '') {
    // The query searches the item name or the order ID.
    $sql .= " AND (cri.item_name LIKE ? OR cr.order_id LIKE ?)";
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

// Append status filter if a status is selected
if ($status !== '' && $status !== 'Filter by Status') {
    $sql .= " AND cr.return_completed = ?";
    $params[] = $status;
}

// Order the results by the most recent return date
$sql .= " ORDER BY cr.received_date DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $returns = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Return a success response with the fetched data
    echo json_encode(['success' => true, 'data' => $returns]);
} catch (PDOException $e) {
    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Fetch Stocks Report Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );

    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
