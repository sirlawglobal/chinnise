<?php
// filepath: d:\xampp\htdocs\crm128\backend\inventory\fetch_stocks_report.php

include_once '../../../settings/connection.php';
header('Content-Type: application/json');

// Get search term from the query string, default to empty string if not set
$search = $_GET['search'] ?? '';


$sql = "SELECT 
    s.stock_id, 
    s.item, 
    s.size, 
    s.unit_price, 
    s.qty, 
    s.total_price, 
    s.reorder_trigger, 
    s.created_at, 
    s.updated_at,
    GREATEST(
        COALESCE(ls.last_supplier_ordered_date, '0000-00-00'),
        COALESCE(lc.last_customer_ordered_date, '0000-00-00')
    ) AS last_ordered_date
FROM 
    stocks s
LEFT JOIN (
    SELECT
        soi.stock_id,
        MAX(so.order_date) AS last_supplier_ordered_date
    FROM
        supplier_orders so
    JOIN
        supplier_order_items soi ON so.id = soi.order_id
    GROUP BY
        soi.stock_id
) AS ls ON s.stock_id = ls.stock_id
LEFT JOIN (
    SELECT
        oi.stock_id,
        MAX(o.order_date) AS last_customer_ordered_date
    FROM
        orders o
    JOIN
        order_items oi ON o.id = oi.order_id
    GROUP BY
        oi.stock_id
) AS lc ON s.stock_id = lc.stock_id
WHERE 1 ";

$params = [];

// If a search term is provided, add a WHERE clause to filter the results
if ($search !== '') {
    // Use the alias 's' to specify columns from the stocks table
    $sql .= "AND (s.item LIKE ? OR s.stock_id = ?)";
    $params[] = "%$search%";
    // Ensure that we only match stock_id if the search term is numeric
    $params[] = is_numeric($search) ? $search : 0;
}

// Order the final results by item name
$sql .= " ORDER BY s.item ASC";

// Prepare and execute the SQL statement
try {

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $stocks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Iterate through each stock record to determine if an action is required
    foreach ($stocks as &$stock) {
        // Check if the quantity is zero or has fallen below the reorder trigger level
        if ($stock['qty'] == 0 || $stock['qty'] < (int)$stock['reorder_trigger']) {
            $stock['action_required'] = 'Yes';
        } else {
            $stock['action_required'] = 'No';
        }
    }

    // Encode the results into JSON and send the response
    echo json_encode(['success' => true, 'data' => $stocks]);
} catch (PDOException $e) {

    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Fetch Stocks Report Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );

    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch stocks report']);
}
