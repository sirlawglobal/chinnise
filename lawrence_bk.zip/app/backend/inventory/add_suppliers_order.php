<?php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();

        // Insert order (let trigger handle id)
        $sql = "INSERT INTO supplier_orders (order_date, supplier_id, delivery_date, total_amount, order_completed)
                VALUES (:order_date, :supplier_id, :delivery_date, :total_amount, :order_completed)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':order_date' => $_POST['order_date'],
            ':supplier_id' => $_POST['client_name'],
            ':delivery_date' => $_POST['delivery_date'],
            ':total_amount' => $_POST['total_order_value'],
            ':order_completed' => $_POST['order_completed']
        ]);

        // Fetch the last inserted order id
        $sql_get_id = "SELECT id FROM supplier_orders 
                       WHERE supplier_id = :supplier_id 
                         AND order_date = :order_date 
                         AND delivery_date = :delivery_date 
                         AND total_amount = :total_amount 
                       ORDER BY created_at DESC 
                       LIMIT 1";
        $stmt_get_id = $pdo->prepare($sql_get_id);
        $stmt_get_id->execute([
            ':supplier_id' => $_POST['client_name'],
            ':order_date' => $_POST['order_date'],
            ':delivery_date' => $_POST['delivery_date'],
            ':total_amount' => $_POST['total_order_value']
        ]);
        $order_id = $stmt_get_id->fetchColumn();

        // Insert items and update stock
        $stock_ids = $_POST['stock_id'];
        $item_names = $_POST['item_name'];
        $unit_prices = $_POST['unit_price'];
        $quantities = $_POST['quantity'];
        $totals = $_POST['total'];

        $sql_item = "INSERT INTO supplier_order_items (order_id, stock_id, item_name, unit_price, quantity, total)
                     VALUES (:order_id, :stock_id, :item_name, :unit_price, :quantity, :total)";
        $stmt_item = $pdo->prepare($sql_item);

        $sql_update_stock = "UPDATE stocks SET qty = qty - :quantity WHERE stock_id = :stock_id AND qty >= :quantity";
        $stmt_update_stock = $pdo->prepare($sql_update_stock);

        for ($i = 0; $i < count($item_names); $i++) {
            // Insert order item
            $stmt_item->execute([
                ':order_id' => $order_id,
                ':stock_id' => $stock_ids[$i],
                ':item_name' => $item_names[$i],
                ':unit_price' => $unit_prices[$i],
                ':quantity' => $quantities[$i],
                ':total' => $totals[$i]
            ]);

            // Update stock
            $stmt_update_stock->execute([
                ':quantity' => $quantities[$i],
                ':stock_id' => $stock_ids[$i]
            ]);

            // Check if stock was actually updated
            if ($stmt_update_stock->rowCount() === 0) {
                $pdo->rollBack();
                echo json_encode(['success' => false, 'error' => 'Insufficient stock for item: ' . $item_names[$i]]);
                exit;
            }
        }

        $pdo->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        file_put_contents(
            __DIR__ . '/inventory_log.log',
            date('Y-m-d H:i:s') . " - Add Order Error: " . $e->getMessage() . PHP_EOL,
            FILE_APPEND
        );
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to add order']);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
