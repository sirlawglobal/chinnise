<?php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {
        $sql = "UPDATE stocks SET
                    item = :item,
                    size = :size,
                    unit_price = :unit_price,
                    qty = :qty,
                    total_price = :total_price,
                    description = :description,
                    reorder_trigger = :reorder_trigger,
                    colour = :colour
                WHERE stock_id = :stock_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':item' => $_POST['item'],
            ':size' => $_POST['size'],
            ':unit_price' => $_POST['unit_price'],
            ':qty' => $_POST['qty'],
            ':total_price' => $_POST['total_price'],
            ':description' => $_POST['description'],
            ':reorder_trigger' => $_POST['reorder_trigger'],
            ':colour' => $_POST['colour'],
            ':stock_id' => $_POST['stock_id']
        ]);
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        file_put_contents(
            __DIR__ . '/inventory_log.log',
            date('Y-m-d H:i:s') . " - Edit Stock Error: " . $e->getMessage() . PHP_EOL,
            FILE_APPEND
        );
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to update stock']);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
