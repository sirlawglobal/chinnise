<?php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $sql = "INSERT INTO stocks (item, size, unit_price, qty, total_price, description, reorder_trigger,colour)
                VALUES (:item, :size, :unit_price, :qty, :total_price, :description, :reorder_trigger,:colour)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':item' => $_POST['item'],
            ':size' => $_POST['size'],
            ':unit_price' => $_POST['unit_price'],
            ':qty' => $_POST['qty'],
            ':total_price' => $_POST['total_price'],
            ':description' => $_POST['description'],
            ':reorder_trigger' => $_POST['reorder_trigger'] ?? null,
            ':colour' => $_POST['colour']
        ]);
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        file_put_contents(
            __DIR__ . '/inventory_log.log',
            date('Y-m-d H:i:s') . " - Add Stock Error: " . $e->getMessage() . PHP_EOL,
            FILE_APPEND
        );
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to add stock']);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
