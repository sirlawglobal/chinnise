<?php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit;
}

try {
    $pdo->beginTransaction();

    $order_id = $_POST['order_id'];
    $supplier_id = $_POST['client_name'];
    $order_date = $_POST['order_date'];
    $delivery_date = $_POST['delivery_date'];
    $total_amount = $_POST['total_order_value'];
    $order_completed = $_POST['order_completed'];

    // 1. Fetch old items for this order
    $stmt = $pdo->prepare("SELECT * FROM supplier_order_items WHERE order_id = ?");
    $stmt->execute([$order_id]);
    $old_items = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $old_items[$row['stock_id']] = $row;
    }

    // 2. Build new items array from POST
    $new_items = [];
    $stock_ids = $_POST['stock_id'];
    $item_names = $_POST['item_name'];
    $unit_prices = $_POST['unit_price'];
    $quantities = $_POST['quantity'];
    for ($i = 0; $i < count($stock_ids); $i++) {
        $new_items[$stock_ids[$i]] = [
            'stock_id' => $stock_ids[$i],
            'item_name' => $item_names[$i],
            'unit_price' => $unit_prices[$i],
            'quantity' => $quantities[$i]
        ];
    }

    // 3. Handle removed items (add their quantity back to stock)
    foreach ($old_items as $stock_id => $old_item) {
        if (!isset($new_items[$stock_id])) {
            $stmt = $pdo->prepare("UPDATE stocks SET qty = qty + ? WHERE stock_id = ?");
            $stmt->execute([$old_item['quantity'], $stock_id]);
        }
    }

    // 4. Handle updated and new items
    foreach ($new_items as $stock_id => $new_item) {
        $new_qty = (int)$new_item['quantity'];
        if (isset($old_items[$stock_id])) {
            $old_qty = (int)$old_items[$stock_id]['quantity'];
            $diff = $new_qty - $old_qty;
            if ($diff > 0) {
                // Decrease stock if quantity increased
                $stmt = $pdo->prepare("UPDATE stocks SET qty = qty - ? WHERE stock_id = ? AND qty >= ?");
                $stmt->execute([$diff, $stock_id, $diff]);
                if ($stmt->rowCount() === 0) {
                    $pdo->rollBack();
                    echo json_encode(['success' => false, 'error' => "Insufficient stock for item: " . $new_item['item_name']]);
                    exit;
                }
            } elseif ($diff < 0) {
                // Increase stock if quantity decreased
                $stmt = $pdo->prepare("UPDATE stocks SET qty = qty + ? WHERE stock_id = ?");
                $stmt->execute([abs($diff), $stock_id]);
            }
        } else {
            // New item: subtract from stock
            $stmt = $pdo->prepare("UPDATE stocks SET qty = qty - ? WHERE stock_id = ? AND qty >= ?");
            $stmt->execute([$new_qty, $stock_id, $new_qty]);
            if ($stmt->rowCount() === 0) {
                $pdo->rollBack();
                echo json_encode(['success' => false, 'error' => "Insufficient stock for item: " . $new_item['item_name']]);
                exit;
            }
        }
    }

    // 5. Update supplier_orders table
    $stmt = $pdo->prepare("UPDATE supplier_orders SET supplier_id = ?, order_date = ?, delivery_date = ?, total_amount = ?, order_completed = ? WHERE id = ?");
    $stmt->execute([$supplier_id, $order_date, $delivery_date, $total_amount, $order_completed, $order_id]);

    // 6. Delete all old items and re-insert new ones
    $pdo->prepare("DELETE FROM supplier_order_items WHERE order_id = ?")->execute([$order_id]);
    $stmt = $pdo->prepare("INSERT INTO supplier_order_items (order_id, stock_id, item_name, quantity, unit_price) VALUES (?, ?, ?, ?, ?)");
    foreach ($new_items as $item) {
        $stmt->execute([$order_id, $item['stock_id'], $item['item_name'], $item['quantity'], $item['unit_price']]);
    }

    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Edit Supplier Order Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to update order']);
}
