<?php

include_once '../../settings/connection.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $sql = "UPDATE suppliers SET
            last_name = :last_name,
            first_name = :first_name,
            email = :email,
            phone_number = :phone_number,
            name = :name,
            address = :address
            WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':last_name' => $_POST['last_name'],
            ':first_name' => $_POST['first_name'],
            ':email' => $_POST['email'],
            ':phone_number' => $_POST['phone_number'],
            ':name' => $_POST['name'],
            ':address' => $_POST['address'],
            ':id' => $_POST['supplier_id']
        ]);
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        file_put_contents(
            __DIR__ . '/inventory_log.log',
            date('Y-m-d H:i:s') . " - Edit Error: " . $e->getMessage() . PHP_EOL,
            FILE_APPEND
        );
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to update supplier']);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
