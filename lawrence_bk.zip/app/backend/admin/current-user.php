<?php
include_once '../../settings/connection.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT id, firstname,lastname,email,role,phonenumber,staff_id  FROM staffs where role = 'admin'");
    $stocks = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $stocks]);
} catch (Exception $e) {
    file_put_contents(
        __DIR__ . '/inventory_log.log',
        date('Y-m-d H:i:s') . " - Fetch Admin Error: " . $e->getMessage() . PHP_EOL,
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch Admin']);
}
