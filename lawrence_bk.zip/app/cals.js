// document.addEventListener("DOMContentLoaded", function () {
//     const today = new Date().toISOString().split("T")[0];
//     //2025-05-29
//     console.log("Today is: " + today);
//     var calendarEl = document.getElementById("calendar");
//     var calendar = new FullCalendar.Calendar(calendarEl, {
//         initialView: "dayGridMonth",
//         showNonCurrentDates: false,
//         fixedWeekCount: false,
//         weight: "100%", // Make width consistent across weeks
//         contentHeight: "auto", // Adjust height automatically
//         height: "100%", // Make height consistent across weeks
//         headerToolbar: {
//             left: "prev,next",
//             center: "title",
//             right: "",
//         },
//         events: [{
//             title: "Today",
//             start: today, // Convert to YYYY-MM-DD format
//             color: "#007bff", // Blue
//             textColor: "#fff", // White text
//         },],
//         // dayCellDidMount: function (info) {
//         //   if (
//         //     info.date.getDate() === 29 &&
//         //     info.date.getMonth() === 5 && // May is 4
//         //     info.date.getFullYear() === 2025
//         //   ) {
//         //     info.el.style.backgroundColor = "#007bff";
//         //     info.el.style.color = "#fff";
//         //   }
//         // },
//         dateClick: function (info) {
//             alert("Clicked on: " + info.dateStr);
//         },
//     });
//     calendar.render();
// });




document.addEventListener("DOMContentLoaded", function () {
    const calendarEl = document.getElementById("calendar");

    // Keep track of which days we've already styled
    const styledDates = new Set();

    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: "dayGridMonth",
        showNonCurrentDates: false,
        fixedWeekCount: false,
        headerToolbar: {
            left: "",
            center: "prev title next",
            right: ""
        },
        events: "backend/appointment/events.php",

        eventDidMount: function (arg) {
            const eventDate = new Date(arg.event.start);
            eventDate.setHours(0, 0, 0, 0);
            const dateKey = eventDate.getFullYear() + '-' +
                String(eventDate.getMonth() + 1).padStart(2, '0') + '-' +
                String(eventDate.getDate()).padStart(2, '0');


            // Avoid re-styling the same day if multiple events are there
            // if (styledDates.has(dateKey)) return;

            // Select the parent cell using the built-in FullCalendar method
            const frame = arg.el.closest('.fc-daygrid-day-frame');

            if (frame) {
                frame.style.backgroundColor = '#a2d896';
                frame.style.borderRadius = '999px';
                frame.style.cursor = 'pointer';

                frame.addEventListener('click', () => {
                    console.log(`Clicked on ${dateKey} which has appointment(s)`);
                    window.location.href = `./appointments-list?date=${dateKey}`;
                });

                // styledDates.add(dateKey);
            }
        }
    });

    calendar.render();
});

