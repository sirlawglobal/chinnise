<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
  // Not logged in, redirect to login page
  header("Location: auth/login.php");
  exit;
}
?>

<?php include_once '../components/header.php'; ?>
<!-- Main content -->
<div class="main">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content">
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Contact Management</span>
        <span class="divider"></span>
        <span class="tab active">Reports</span>
      </div>

      <!-- <div class="box1">
            <div class="box2">
              <h4 class="box2-title">Active Clients</h4>
              <div class="box2-val">0</div>
            </div> -->
      <!-- <button class="add-new-button">Add New Lead</button> -->
    </div>

    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Contact List Report</h3>
          <button
            class="add-new-button"
            onclick="location.href='./contact-list-report'">
            View
          </button>
        </div>
      </div>
    </div>
    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Contact Growth Report</h3>
          <button
            onclick="location.href='./contact-growth-report'"
            class="add-new-button">
            View
          </button>
        </div>
      </div>
    </div>
  </section>
</div>

<?php include_once '../components/cashflow_footer.php'; ?>