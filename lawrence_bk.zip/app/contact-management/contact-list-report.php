<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
  // Not logged in, redirect to login page
  header("Location: auth/login.php");
  exit;
}
?>

<?php include_once '../components/header.php'; ?>
<div class="main" style="overflow: hidden">
  <?php include_once '../components/common_header.php'; ?>
  <section class="content" style="overflow: hidden">
    <!-- Tabs for Clients and Leads -->
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Contact Management</span>
        <span class="divider"></span>
        <span class="tab active">Client List Report</span>
      </div>
      <button class="add-new-button" onclick="printReport()">Print Report</button>
    </div>
    <form method="GET">
      <div class="row1">
        <div class="col1">
          <label>Filter by Name</label>
          <input type="text" name="filter_name" id="filter_name" value="<?= htmlspecialchars($_GET['filter_name'] ?? '') ?>" placeholder="Enter client name" />
        </div>
        <div class="col1">
          <label>Filter by Month</label>
          <select name="filter_month" id="filter_month">
            <option value="">Select Month</option>
            <?php for ($m = 1; $m <= 12; $m++): ?>
              <option value="<?= $m ?>" <?= (($_GET['filter_month'] ?? '') == $m) ? 'selected' : '' ?>>
                <?= date('F', mktime(0, 0, 0, $m, 10)) ?>
              </option>
            <?php endfor; ?>
          </select>
        </div>
        <div class="col1">
          <label>Filter by Year</label>
          <select id="filter_year">
            <option value="">Select Year</option>
            <?php
            for ($i = date('Y'); $i >= 2000; $i--) {
              echo "<option value='$i'" . (($_GET['filter_year'] ?? '') == $i ? ' selected' : '') . ">$i</option>";
            }
            ?>
          </select>
        </div>
        <div class="col1">
          <label>Filter by Type</label>
          <select name="filter_type" id="filter_type">
            <option value="">Select Type</option>
            <option value="leads" <?= ($_GET['filter_type'] ?? '') == 'leads' ? 'selected' : '' ?>>Leads</option>
            <option value="Client" <?= ($_GET['filter_type'] ?? '') == 'Client' ? 'selected' : '' ?>>Client</option>
          </select>
        </div>
      </div>
    </form>

    <!-- Table for Leads -->
    <div class="over-table">
      <table id="print-table">
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>Client ID</th>
            <th>Name</th>
            <th>Address</th>
            <th>Role</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Data Type</th>
          </tr>
        </thead>
        <tbody id="leads-body"></tbody>
      </table>
    </div>

    <!-- Pagination Controls -->
    <div class="pagination-controls">
      <div class="RPP">
        <label for="rowsPerPage">Rows per page:</label>
        <select id="rowsPerPage">
          <option value="25" selected>25</option>
          <option value="50">50</option>
          <option value="75">75</option>
          <option value="100">100</option>
        </select>
      </div>
      <div>
        <button id="prevPage">Previous</button>
        <span id="pageInfo">Page 1 of 1</span>
        <button id="nextPage">Next</button>
      </div>
    </div>

    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab active" id="total-leads">Total No of Leads: 0</span>
        <span class="divider"></span>
        <span class="tab active" id="total-clients">Total No of Clients: 0</span>
      </div>
    </div>
  </section>
</div>

<style>
@media print {
  .main, .content {
    overflow: visible !important;
  }
  .tabs, .row1, .pagination-controls, .add-new-button {
    display: none !important;
  }
  #print-table {
    width: 100%;
    border-collapse: collapse;
  }
  #print-table th, #print-table td {
    border: 1px solid black;
    padding: 8px;
    font-size: 12pt;
  }
  #print-table th {
    background-color: #f2f2f2;
  }
}
</style>

<script>
  let currentPage = 1;
  let rowsPerPage = 25; // Default

  document.addEventListener('DOMContentLoaded', function() {
    const leadsTableBody = document.getElementById('leads-body');
    const rowsPerPageSelect = document.getElementById('rowsPerPage');
    const prevPageBtn = document.getElementById('prevPage');
    const nextPageBtn = document.getElementById('nextPage');
    const pageInfoSpan = document.getElementById('pageInfo');
    const nameInput = document.getElementById('filter_name');
    const monthSelect = document.getElementById('filter_month');
    const yearSelect = document.getElementById('filter_year');
    const typeSelect = document.getElementById('filter_type');

    // Utility functions for text truncation
    function truncateText(text, maxLength = 25) {
      if (text === null || text === undefined) return '';
      text = String(text);
      if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
      }
      return text;
    }

    function contact_truncateText(text, maxLength = 15) {
      if (text === null || text === undefined) return '';
      text = String(text);
      if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
      }
      return text;
    }

    function number(text, maxLength = 12) {
      if (text === null || text === undefined) return '';
      text = String(text);
      if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
      }
      return text;
    }

    async function fetchData() {
      const params = new URLSearchParams({
        name: nameInput.value,
        month: monthSelect.value,
        year: yearSelect.value,
        type: typeSelect.value,
        page: currentPage,
        rows_per_page: rowsPerPage
      });

      try {
        const response = await fetch(`fetch_leads.php?${params}`);
        const data = await response.json();
        console.log(data);
        
        if (data.success) {
          leadsTableBody.innerHTML = ''; // Clear existing rows
          data.data.forEach(row => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
              <td>100${row.id}</td>
              <td>${contact_truncateText(row.contact_surname)}</td>
              <td>${truncateText(row.address)}</td>
              <td>${truncateText(row.position)}</td>
              <td>${truncateText(row.email)}</td>
              <td>${number(row.phone_number)}</td>
              <td>${row.client_type}</td>
            `;
            leadsTableBody.appendChild(tr);
          });

          // Update pagination info
          currentPage = data.currentPage;
          const totalPages = data.totalPages;
          pageInfoSpan.textContent = `Page ${currentPage} of ${totalPages}`;

          prevPageBtn.disabled = currentPage === 1;
          nextPageBtn.disabled = currentPage === totalPages;

          // Update total counts
          document.getElementById('total-leads').textContent = `Total No of Leads: ${data.totalLeads}`;
          document.getElementById('total-clients').textContent = `Total No of Clients: ${data.totalClients}`;
        } else {
          alert('Error loading data: ' + (data.message || 'Unknown error'));
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        alert('An error occurred while loading data.');
      }
    }

    // Event listeners for pagination controls
    rowsPerPageSelect.addEventListener('change', () => {
      rowsPerPage = parseInt(rowsPerPageSelect.value);
      currentPage = 1; // Reset to first page
      fetchData();
    });

    prevPageBtn.addEventListener('click', () => {
      if (currentPage > 1) {
        currentPage--;
        fetchData();
      }
    });

    nextPageBtn.addEventListener('click', () => {
      currentPage++;
      fetchData();
    });

    // Event listeners for filters
    [nameInput, monthSelect, yearSelect, typeSelect].forEach(el =>
      el.addEventListener('input', () => {
        currentPage = 1; // Reset to first page on filter change
        fetchData();
      })
    );

    // Print report function
    window.printReport = function() {
      window.print();
    };

    // Fetch on load
    fetchData();
  });
</script>

<?php include_once '../components/cashflow_footer.php'; ?>