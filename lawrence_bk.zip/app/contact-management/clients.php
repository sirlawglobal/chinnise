<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
  // Not logged in, redirect to login page
  header("Location: auth/login.php");
  exit;
}
?>

<?php include_once '../components/header.php'; ?>

<style>
/* Toast Notification Styles */
.toast {
    position: fixed;
    top: 20px;
    right: 20px;
    background-color: #333;
    color: white;
    padding: 15px 20px;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    z-index: 1000;
    display: none;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.toast.show {
    display: block;
    opacity: 1;
}

.toast.success {
    background-color: #4CAF50;
}

.toast.error {
    background-color: #f44336;
}

#confirmModal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
    display: none;
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

#confirmModal .confirm-content {
    background-color: white;
    padding: 20px;
    border-radius: 5px;
    text-align: center;
    min-width: 300px;
}

#confirmModal .confirm-content button {
    margin: 10px 5px;
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

#confirmModal .confirm-content button.confirm-yes {
    background-color: #4CAF50;
    color: white;
}

#confirmModal .confirm-content button.confirm-no {
    background-color: #f44336;
    color: white;
}
</style>

<div class="modal1" id="viewModal">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">View Client</h2>
    <input type="hidden" name="id" id="view-id" />
    <div class="row">
      <div class="col">
        <label>Company Name</label>
        <input type="text" name="company_name" id="view-company_name" readonly />
      </div>
      <div class="col">
        <label>Contact Title</label>
        <select name="contact_title" id="view-contact_title" readonly>
          <option value="">Select Title</option>
          <option value="Mr.">Mr.</option>
          <option value="Mrs.">Mrs.</option>
          <option value="Dr.">Dr.</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <label>Contact Surname</label>
        <input type="text" name="contact_surname" id="view-contact_surname" readonly />
      </div>
      <div class="col">
        <label>Contact Firstname</label>
        <input type="text" name="contact_firstname" id="view-contact_firstname" readonly />
      </div>
    </div>
    <div class="row">
      <div class="col">
        <label>Email</label>
        <input type="email" name="email" id="view-email" readonly />
      </div>
      <div class="col">
        <label>Company Category</label>
        <select name="company_category" id="view-company_category" readonly>
          <option>Technology</option>
          <option>Finance</option>
          <option>Healthcare</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <label>Position</label>
        <input type="text" name="position" id="view-position" readonly />
      </div>
      <div class="col">
        <label>Address</label>
        <input type="text" name="address" id="view-address" readonly />
      </div>
    </div>
    <div class="row">
      <div class="col">
        <label>Source</label>
        <input type="text" name="source" id="view-source" readonly />
      </div>
      <div class="col">
        <label>Modified Date</label>
        <input type="date" name="modified_date" id="view-modified_date" readonly />
      </div>
    </div>
    <div class="row">
      <div class="col">
        <label>Phone Number</label>
        <input type="tel" name="phone_number" id="view-phone_number" readonly />
      </div>
      <div class="col">
        <label>Status</label>
        <select name="status" id="view-status" readonly>
          <option>Select status</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </div>
    </div>
  </div>
</div>
<div class="modal2" id="editModal">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Client</h2>
    <form id="editForm" method="POST">
      <input type="hidden" name="id" id="edit-id" />
      <div class="row">
        <div class="col">
          <label>Company Name</label>
          <input type="text" name="company_name" id="edit-company_name" />
        </div>
        <div class="col">
          <label>Contact Title</label>
          <select name="contact_title" id="edit-contact_title">
            <option value="">Select Title</option>
            <option value="Mr.">Mr.</option>
            <option value="Mrs.">Mrs.</option>
            <option value="Dr.">Dr.</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Contact Surname</label>
          <input type="text" name="contact_surname" id="edit-contact_surname" />
        </div>
        <div class="col">
          <label>Contact Firstname</label>
          <input type="text" name="contact_firstname" id="edit-contact_firstname" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Email</label>
          <input type="email" name="email" id="edit-email" />
        </div>
        <div class="col">
          <label>Company Category</label>
          <select name="company_category" id="edit-company_category">
            <option>Technology</option>
            <option>Finance</option>
            <option>Healthcare</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Position</label>
          <input type="text" name="position" id="edit-position" />
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="address" id="edit-address" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Source</label>
          <input type="text" name="source" id="edit-source" />
        </div>
        <div class="col">
          <label>Modified Date</label>
          <input type="date" name="modified_date" id="edit-modified_date" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Phone Number</label>
          <input type="number" name="phone_number" id="edit-phone_number" />
        </div>
        <div class="col">
          <label>Status</label>
          <select name="status" id="edit-status">
            <option>Select status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <button type="submit" class="save-btn">Update</button>
    </form>
  </div>
</div>
<div id="toastContainer"></div>
<div id="confirmModal">
    <div class="confirm-content">
        <p id="confirmMessage"></p>
        <button class="confirm-yes">Yes</button>
        <button class="confirm-no">No</button>
    </div>
</div>
<div class="main">
  <?php include_once '../components/common_header.php'; ?>
  <section class="content">
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Client Data</span>
        <span class="divider"></span>
        <span class="tab active">Company List</span>
      </div>
    </div>
    <div style="overflow: auto; padding: 0.7rem; height: 80%">
      <table>
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>Client ID</th>
            <th>Company Name</th>
            <th>Surname</th>
            <th>Firstname</th>
            <th>Position</th>
            <th>Phone Number</th>
            <th>Status</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody id="clientsTableBody"></tbody>
      </table>
      <div class="pagination-controls">
        <div class="RPP">
          <label for="rowsPerPage">Rows per page:</label>
          <select id="rowsPerPage">
            <option value="25" selected>25</option>
            <option value="50">50</option>
            <option value="75">75</option>
            <option value="100">100</option>
          </select>
        </div>
        <div class="">
          <button id="prevPage">Previous</button>
          <span id="pageInfo">Page 1 of 1</span>
          <button id="nextPage">Next</button>
        </div>
      </div>
    </div>
  </section>
</div>

<script>
// Toast Notification Functionality
function showToast(message, type = 'success') {
    const toastContainer = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    toastContainer.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, 3000);
    }, 100);
}

function showConfirm(message, callback) {
    const confirmModal = document.getElementById('confirmModal');
    const confirmMessage = document.getElementById('confirmMessage');
    const confirmYes = document.querySelector('.confirm-yes');
    const confirmNo = document.querySelector('.confirm-no');
    
    confirmMessage.textContent = message;
    confirmModal.style.display = 'flex';
    
    const handleYes = () => {
        callback(true);
        confirmModal.style.display = 'none';
        confirmYes.removeEventListener('click', handleYes);
        confirmNo.removeEventListener('click', handleNo);
    };
    
    const handleNo = () => {
        callback(false);
        confirmModal.style.display = 'none';
        confirmYes.removeEventListener('click', handleYes);
        confirmNo.removeEventListener('click', handleNo);
    };
    
    confirmYes.addEventListener('click', handleYes);
    confirmNo.addEventListener('click', handleNo);
}

// Pagination and Table Loading
let currentPage = 1;
let rowsPerPage = 25;

const clientsTableBody = document.getElementById('clientsTableBody');
const rowsPerPageSelect = document.getElementById('rowsPerPage');
const prevPageBtn = document.getElementById('prevPage');
const nextPageBtn = document.getElementById('nextPage');
const pageInfoSpan = document.getElementById('pageInfo');

function truncateText(text, maxLength = 25) {
    if (text === null || text === undefined) return '';
    text = String(text);
    if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
    }
    return text;
}

function company_truncateText(text, maxLength = 23) {
    if (text === null || text === undefined) return '';
    text = String(text);
    if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
    }
    return text;
}

function contact_truncateText(text, maxLength = 15) {
    if (text === null || text === undefined) return '';
    text = String(text);
    if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
    }
    return text;
}

function number(text, maxLength = 12) {
    if (text === null || text === undefined) return '';
    text = String(text);
    if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
    }
    return text;
}

async function loadClients() {
    try {
        const response = await fetch(`../backend/contact-management/get_clients.php?page=${currentPage}&rows_per_page=${rowsPerPage}`);
        const data = await response.json();
        if (data.success) {
            clientsTableBody.innerHTML = '';
            data.clients.forEach(client => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>100${client.id}</td>
                    <td>${company_truncateText(client.company_name)}</td>
                    <td>${contact_truncateText(client.contact_surname)}</td>
                    <td>${contact_truncateText(client.contact_firstname)}</td>
                    <td>${truncateText(client.position)}</td>
                    <td>${number(client.phone_number)}</td>
                    <td style='text-transform:capitalize;'>${truncateText(client.status)}</td>
                    <td>
                        <i class='view-icon'
                            data-id='${client.id}'
                            data-company_name='${htmlspecialchars(client.company_name)}'
                            data-contact_title='${htmlspecialchars(client.contact_title)}'
                            data-contact_surname='${htmlspecialchars(client.contact_surname)}'
                            data-contact_firstname='${htmlspecialchars(client.contact_firstname)}'
                            data-email='${htmlspecialchars(client.email)}'
                            data-company_category='${htmlspecialchars(client.company_category)}'
                            data-position='${htmlspecialchars(client.position)}'
                            data-address='${htmlspecialchars(client.address)}'
                            data-source='${htmlspecialchars(client.source)}'
                            data-modified_date='${htmlspecialchars(client.modified_date)}'
                            data-phone_number='${htmlspecialchars(client.phone_number)}'
                            data-status='${htmlspecialchars(client.status)}'>
                            <img src='../assets/eye-open.png' />
                        </i>
                    </td>
                    <td>
                        <i class='edit-icon'
                            data-id='${client.id}'
                            data-company_name='${htmlspecialchars(client.company_name)}'
                            data-contact_title='${htmlspecialchars(client.contact_title)}'
                            data-contact_surname='${htmlspecialchars(client.contact_surname)}'
                            data-contact_firstname='${htmlspecialchars(client.contact_firstname)}'
                            data-email='${htmlspecialchars(client.email)}'
                            data-company_category='${htmlspecialchars(client.company_category)}'
                            data-position='${htmlspecialchars(client.position)}'
                            data-address='${htmlspecialchars(client.address)}'
                            data-source='${htmlspecialchars(client.source)}'
                            data-modified_date='${htmlspecialchars(client.modified_date)}'
                            data-phone_number='${htmlspecialchars(client.phone_number)}'
                            data-status='${htmlspecialchars(client.status)}'>
                            <img src='../assets/edit.svg' />
                        </i>
                    </td>
                    <td>
                        <i class='delete-icon' data-id='${client.id}'>
                            <img src='../assets/Delete.svg' />
                        </i>
                    </td>
                `;
                clientsTableBody.appendChild(row);
            });
            currentPage = data.currentPage;
            const totalPages = data.totalPages;
            pageInfoSpan.textContent = `Page ${currentPage} of ${totalPages}`;
            prevPageBtn.disabled = currentPage === 1;
            nextPageBtn.disabled = currentPage === totalPages;
            attachIconEventListeners();
        } else {
            showToast('Error loading clients: ' + (data.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error fetching clients:', error);
        showToast('An error occurred while loading clients.', 'error');
    }
}

function htmlspecialchars(str) {
    if (typeof str !== 'string') return str;
    return str.replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;')
              .replace(/'/g, '&#039;');
}

function attachIconEventListeners() {
    document.querySelectorAll('.view-icon').forEach(icon => {
        icon.onclick = () => {
            const client = icon.dataset;
            openViewModal(client);
        };
    });
    document.querySelectorAll('.edit-icon').forEach(icon => {
        icon.onclick = () => {
            const client = icon.dataset;
            openEditModal(client);
        };
    });
    // edit_lead.
    document.querySelectorAll('.delete-icon').forEach(icon => {
        icon.onclick = () => {
            const clientId = icon.dataset.id;
            showConfirm("Are you sure you want to delete this client?", (confirmed) => {
                if (confirmed) {
                    fetch('../backend/contact-management/delete_lead.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: new URLSearchParams({
                            id: clientId
                        })
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            showToast("Client deleted successfully", 'success');
                            loadClients();
                        } else {
                            showToast("Failed to delete client: " + (data.message || 'Unknown error'), 'error');
                        }
                    })
                    .catch(err => {
                        console.error(err);
                        showToast("An error occurred while deleting", 'error');
                    });
                }
            });
        };
    });
}

rowsPerPageSelect.addEventListener('change', () => {
    rowsPerPage = parseInt(rowsPerPageSelect.value);
    currentPage = 1;
    loadClients();
});

prevPageBtn.addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        loadClients();
    }
});

nextPageBtn.addEventListener('click', () => {
    currentPage++;
    loadClients();
});

document.addEventListener('DOMContentLoaded', loadClients);

// View Modal Handler
document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('.close1').addEventListener('click', () => {
        document.getElementById('viewModal').style.display = 'none';
    });
    window.addEventListener('click', (e) => {
        if (e.target === document.getElementById('viewModal')) {
            document.getElementById('viewModal').style.display = 'none';
        }
    });
});

function openViewModal(client) {
    console.log(client);
    document.getElementById('view-id').value = client.id;
    document.getElementById('view-company_name').value = client.company_name;
    document.getElementById('view-contact_title').value = client.contact_title;
    document.getElementById('view-contact_surname').value = client.contact_surname;
    document.getElementById('view-contact_firstname').value = client.contact_firstname;
    document.getElementById('view-email').value = client.email;
    document.getElementById('view-company_category').value = client.company_category;
    document.getElementById('view-position').value = client.position;
    document.getElementById('view-address').value = client.address;
    document.getElementById('view-source').value = client.source;
    document.getElementById('view-modified_date').value = client.modified_date;
    document.getElementById('view-phone_number').value = client.phone_number;
    document.getElementById('view-status').value = client.status;
    document.getElementById('viewModal').style.display = 'block';
}

// Edit Modal Handler
function openEditModal(client) {
    console.log(client);
    document.getElementById('edit-id').value = client.id;
    document.getElementById('edit-company_name').value = client.company_name;
    document.getElementById('edit-contact_title').value = client.contact_title;
    document.getElementById('edit-contact_surname').value = client.contact_surname;
    document.getElementById('edit-contact_firstname').value = client.contact_firstname;
    document.getElementById('edit-email').value = client.email;
    document.getElementById('edit-company_category').value = client.company_category;
    document.getElementById('edit-position').value = client.position;
    document.getElementById('edit-address').value = client.address;
    document.getElementById('edit-source').value = client.source;
    document.getElementById('edit-modified_date').value = client.modified_date;
    document.getElementById('edit-phone_number').value = client.phone_number;
    document.getElementById('edit-status').value = client.status;
    document.getElementById('editModal').style.display = 'block';
}

// Edit Form Submission
document.getElementById('editForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('../backend/contact-management/edit_lead.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast('Client updated successfully', 'success');
            document.getElementById('editModal').style.display = 'none';
            loadClients();
        } else {
            showToast('Update failed', 'error');
        }
    })
    .catch(err => {
        console.error(err);
        showToast('An error occurred while updating', 'error');
    });
});
</script>

<style>
.leads-table th,
.leads-table td {
    padding: 5px 10px;
    text-align: left;
    font-weight: 400;
    word-break: break-all;
}
table {
    border-collapse: collapse;
    width: 100%;
    table-layout: auto;
}
</style>
<?php include_once '../components/cashflow_footer.php'; ?>