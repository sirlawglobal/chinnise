
<?php include_once '../backend/contact-management/get_clients2.php'; ?>
<?php include_once '../backend/contact-management/get_dashboard_stats.php'; ?>

<?php include_once '../components/header.php'; ?>
<div class="modal1" id="viewClientModal">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">View Client</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Company Name</label>
          <input type="text" id="company_name" readonly />
        </div>
        <div class="col">
          <label>Contact Title</label>
          <input type="text" id="contact_title" readonly />
        </div>
        <div class="col">
          <label>Contact Firstname</label>
          <input type="text" id="contact_firstname" readonly />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Contact Lastname</label>
          <input type="text" id="contact_lastname" readonly />
        </div>
        <div class="col">
          <label>Email</label>
          <input type="email" id="email" readonly />
        </div>
        <div class="col">
          <label>Company Category</label>
          <input type="text" id="company_category" readonly />
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>Position</label>
          <input type="text" id="position" readonly />
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" id="address" readonly />
        </div>
        <div class="col">
          <label>Source</label>
          <input type="text" id="source" readonly />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Modified Date</label>
          <input type="date" id="modified_date" readonly />
        </div>
        <div class="col">
          <label>Phone Number</label>
          <input type="tel" id="phone_number" readonly />
        </div>
        <div class="col">
          <label>Status</label>
          <select id="status" disabled></select>
        </div>
      </div>
    

      <button type="submit" class="save-btn">Save</button>
    </form>
  </div>
</div>
<!-- Main content -->
<div class="main">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content">
    <h3 style="padding: 1rem">Contact Management</h3>
    <div class="box1">
      <div class="box2">
        <h4 class="box2-title">Active Clients</h4>
        <div class="box2-val"><?= htmlspecialchars($activeClients) ?></div>
      </div>

      <div class="box2">
        <h4 class="box2-title">Active Leads</h4>
        <div class="box2-val"><?= htmlspecialchars($activeLeads) ?></div>
      </div>
      <!-- <div class="box2">
        <h4 class="box2-title">Avg. value of won deals</h4>
        <div class="box2-val">&#8358;0</div>
      </div> -->
    </div>
    <div class="box1" >
      <div class="box2" style="height: 100%; padding: 0">
        <h4>List of Client</h4>
        <div
          style="overflow: auto; padding: 0.7rem; height: 80%; width: 100%">
          <table class="leads-table">
            <thead>
              <tr>
                <th>Company Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Status</th>
                <th>View</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($clients)): ?>
                  <?php foreach ($clients as $client): ?>
                      <tr>
                          <td><?= htmlspecialchars($client['company_name']) ?></td>
                          <td><?= htmlspecialchars($client['email']) ?></td>
                          <td><?= htmlspecialchars($client['phone_number']) ?></td>
                          <td><?= htmlspecialchars($client['status']) ?></td>
                          <td>
                              <i class="view-icon" data-id="<?= $client['id'] ?>">
                                  <img src="../assets/eye-open.png" alt="View" />
                              </i>
                          </td>
                      </tr>
                  <?php endforeach; ?>
              <?php else: ?>
                  <tr>
                      <td colspan="5">No clients found.</td>
                  </tr>
              <?php endif; ?>
              </tbody>

          </table>
        </div>
      </div>
    </div>
  </section>
</div>
<script>
  document.querySelectorAll('.view-icon').forEach(icon => {
  icon.addEventListener('click', () => {
    const clientId = icon.getAttribute('data-id');
    
    fetch(`../backend/contact-management/get_client_by_id.php?id=${clientId}`)
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          alert(data.error);
          return;
        }

        document.getElementById('company_name').value = data.company_name || '';
        document.getElementById('contact_title').value = data.contact_title || '';
        document.getElementById('contact_firstname').value = data.contact_firstname || '';
        document.getElementById('contact_lastname').value = data.contact_lastname || '';
        document.getElementById('email').value = data.email || '';
        document.getElementById('company_category').value = data.company_category || '';
        document.getElementById('position').value = data.position || '';
        document.getElementById('address').value = data.address || '';
        document.getElementById('source').value = data.source || '';
        document.getElementById('modified_date').value = data.modified_date || '';
        document.getElementById('phone_number').value = data.phone_number || '';
        document.getElementById('status').innerHTML = `<option>${data.status || 'New'}</option>`;

        document.getElementById('viewClientModal').style.display = 'block';
      })
      .catch(err => {
        console.error(err);
        alert('Failed to load client data.');
      });
  });
});

document.querySelector('.close1').addEventListener('click', () => {
  document.getElementById('viewClientModal').style.display = 'none';
});

window.addEventListener('click', (event) => {
  const modal = document.getElementById('viewClientModal');
  if (event.target === modal) {
    modal.style.display = 'none';
  }
});

</script>
<?php include_once '../components/cashflow_footer.php'; ?>