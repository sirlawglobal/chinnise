<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Not logged in, redirect to login page
    header("Location: auth/login.php");
    exit;
}
?>

<?php include_once '../components/header.php'; ?>
<style>
/* Toast Notification Styles */
.toast {
    position: fixed;
    top: 20px;
    right: 20px;
    background-color: #333;
    color: white;
    padding: 15px 20px;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    z-index: 1000;
    display: none;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.toast.show {
    display: block;
    opacity: 1;
}

.toast.success {
    background-color: #4CAF50;
}

.toast.error {
    background-color: #f44336;
}

#confirmModal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
    display: none;
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

#confirmModal .confirm-content {
    background-color: white;
    padding: 20px;
    border-radius: 5px;
    text-align: center;
    min-width: 300px;
}

#confirmModal .confirm-content button {
    margin: 10px 5px;
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

#confirmModal .confirm-content button.confirm-yes {
    background-color: #4CAF50;
    color: white;
}

#confirmModal .confirm-content button.confirm-no {
    background-color: #f44336;
    color: white;
}
</style>

<div class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2 class="con">Add New Lead</h2>
        <form method="POST" id="addLeadForm">
            <div class="row">
                <div class="col">
                    <label>Company Name</label>
                    <input type="text" name="company_name" placeholder="Enter company name" required/>
                </div>
                <div class="col">
                    <label>Contact Title</label>
                    <select name="contact_title">
                        <option value="">Select Title</option>
                        <option value="Mr.">Mr.</option>
                        <option value="Mrs.">Mrs.</option>
                        <option value="Dr.">Dr.</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Contact Surname</label>
                    <input type="text" name="contact_surname" placeholder="Enter surname" required />
                </div>
                <div class="col">
                    <label>Contact Firstname</label>
                    <input type="text" name="contact_firstname" placeholder="Enter firstname"  required/>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Email</label>
                    <input type="email" name="email" placeholder="Enter email" required/>
                </div>
                <div class="col">
                    <label>Company Category</label>
                    <select name="company_category">
                        <option value="">Select category</option>
                        <option value="Technology">Technology</option>
                        <option value="Finance">Finance</option>
                        <option value="Healthcare">Healthcare</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Position</label>
                    <input type="text" name="position" placeholder="Enter position"  required/>
                </div>
                <div class="col">
                    <label>Address</label>
                    <input type="text" name="address" placeholder="Enter address" required/>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Source</label>
                    <input type="text" name="source" placeholder="Enter source" required/>
                </div>
                <div class="col">
                    <label>Modified Date</label>
                    <input type="date" name="modified_date" placeholder="dd/mm/yyyy" required/>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Phone Number</label>
                    <input type="number" name="phone_number" placeholder="Enter phone number" required />
                </div>
                <div class="col">
                    <label>Status</label>
                    <select name="status">
                        <option>Select status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="save-btn">Save</button>
        </form>
    </div>
</div>
<div class="modal1" id="viewModal">
    <div class="modal-content">
        <span class="close1">&times;</span>
        <h2 class="con">View Leads</h2>
        <input type="hidden" name="id" id="view-id" /> 
        <div class="row">
            <div class="col">
                <label>Company Name</label>
                <input type="text" name="company_name" id="view-company_name" readonly />
            </div>
            <div class="col">
                <label>Contact Title</label>
                <select name="contact_title" id="view-contact_title" readonly>
                    <option value="">Select Title</option>
                    <option value="Mr.">Mr.</option>
                    <option value="Mrs.">Mrs.</option>
                    <option value="Dr.">Dr.</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label>Contact Surname</label>
                <input type="text" name="contact_surname" id="view-contact_surname" readonly />
            </div>
            <div class="col">
                <label>Contact Firstname</label>
                <input type="text" name="contact_firstname" id="view-contact_firstname" readonly />
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label>Email</label>
                <input type="email" name="email" id="view-email" readonly />
            </div>
            <div class="col">
                <label>Company Category</label>
                <select name="company_category" id="view-company_category" readonly>
                    <option>Technology</option>
                    <option>Finance</option>
                    <option>Healthcare</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label>Position</label>
                <input type="text" name="position" id="view-position" readonly />
            </div>
            <div class="col">
                <label>Address</label>
                <input type="text" name="address" id="view-address" readonly />
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label>Source</label>
                <input type="text" name="source" id="view-source" readonly />
            </div>
            <div class="col">
                <label>Modified Date</label>
                <input type="date" name="modified_date" id="view-modified_date" readonly />
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label>Phone Number</label>
                <input type="tel" name="phone_number" id="view-phone_number" readonly />
            </div>
            <div class="col">
                <label>Status</label>
                <input type="text" name="status" id="view-status" readonly />
            </div>
        </div>
    </div>
</div>
<div class="modal2" id="editModal">
    <div class="modal-content">
        <span class="close2">&times;</span>
        <h2 class="con">Edit Leads</h2>
        <form id="editForm" method="POST">
            <input type="hidden" name="id" id="edit-id" /> 
            <div class="row">
                <div class="col">
                    <label>Company Name</label>
                    <input type="text" name="company_name" id="edit-company_name" />
                </div>
                <div class="col">
                    <label>Contact Title</label>
                    <select name="contact_title" id="edit-contact_title">
                        <option value="">Select Title</option>
                        <option value="Mr.">Mr.</option>
                        <option value="Mrs.">Mrs.</option>
                        <option value="Dr.">Dr.</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Contact Surname</label>
                    <input type="text" name="contact_surname" id="edit-contact_surname" />
                </div>
                <div class="col">
                    <label>Contact Firstname</label>
                    <input type="text" name="contact_firstname" id="edit-contact_firstname" />
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Email</label>
                    <input type="email" name="email" id="edit-email" />
                </div>
                <div class="col">
                    <label>Company Category</label>
                    <select name="company_category" id="edit-company_category">
                        <option>Technology</option>
                        <option>Finance</option>
                        <option>Healthcare</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Position</label>
                    <input type="text" name="position" id="edit-position" />
                </div>
                <div class="col">
                    <label>Address</label>
                    <input type="text" name="address" id="edit-address" />
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Source</label>
                    <input type="text" name="source" id="edit-source" />
                </div>
                <div class="col">
                    <label>Modified Date</label>
                    <input type="date" name="modified_date" id="edit-modified_date" />
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Phone Number</label>
                    <input type="number" name="phone_number" id="edit-phone_number" />
                </div>
                <div class="col">
                    <label>Status</label>
                    <select name="status" id="edit-status">
                        <option>Select status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="save-btn">Update</button>
            <button type="button" class="save-btn convert-btn">Convert to client</button>
        </form>
    </div>
</div>

<div id="toastContainer"></div>
<div id="confirmModal">
    <div class="confirm-content">
        <p id="confirmMessage"></p>
        <button class="confirm-yes">Yes</button>
        <button class="confirm-no">No</button>
    </div>
</div>

<div class main" style="overflow: hidden">
    <?php include_once '../components/common_header.php'; ?>
    <section class="content" style="overflow-y: scroll">
        <div class="tabs">
            <div style="align-items: center; display: flex">
                <span class="tab">Clients</span>
                <span class="divider"></span>
                <span class="tab active">Leads</span>
            </div>
            <button class="add-new-button">Add New Lead</button>
        </div>
        <table>
            <colgroup>
                <col>
                <col>
                <col>
                <col>
                <col>
                <col>
                <col>
                <col>
                <col>
                <col>
            </colgroup>
            <thead>
                <tr>
                    <th>Client ID</th>
                    <th>Company Name</th>
                    <th>Surname</th>
                    <th>Firstname</th>
                    <th>Position</th>
                    <th>Phone Number</th>
                    <th>Status</th>
                    <th>View</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody id="leadsTableBody"></tbody>
        </table>
        <div class="pagination-controls">
            <div class="RPP">
                <label for="rowsPerPage">Rows per page:</label>
                <select id="rowsPerPage">
                    <option value="25" selected>25</option>
                    <option value="50">50</option>
                    <option value="75">75</option>
                    <option value="100">100</option>
                </select>
            </div>
            <div class="">
                <button id="prevPage">Previous</button>
                <span id="pageInfo">Page 1 of 1</span>
                <button id="nextPage">Next</button>
            </div>
        </div>
    </section>
</div>

<script>
// Toast Notification Functionality
function showToast(message, type = 'success') {
    const toastContainer = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    toastContainer.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, 3000);
    }, 100);
}

function showConfirm(message, callback) {
    const confirmModal = document.getElementById('confirmModal');
    const confirmMessage = document.getElementById('confirmMessage');
    const confirmYes = document.querySelector('.confirm-yes');
    const confirmNo = document.querySelector('.confirm-no');
    
    confirmMessage.textContent = message;
    confirmModal.style.display = 'flex';
    
    const handleYes = () => {
        callback(true);
        confirmModal.style.display = 'none';
        confirmYes.removeEventListener('click', handleYes);
        confirmNo.removeEventListener('click', handleNo);
    };
    
    const handleNo = () => {
        callback(false);
        confirmModal.style.display = 'none';
        confirmYes.removeEventListener('click', handleYes);
        confirmNo.removeEventListener('click', handleNo);
    };
    
    confirmYes.addEventListener('click', handleYes);
    confirmNo.addEventListener('click', handleNo);
}

// Modified Convert to Client Handler
document.addEventListener('DOMContentLoaded', function() {
    const convertBtn = document.querySelector('.convert-btn');

    convertBtn.addEventListener('click', () => {
        const leadId = document.getElementById('edit-id').value;

        if (!leadId) {
            showToast('No lead selected to convert.', 'error');
            return;
        }

        showConfirm('Are you sure you want to convert this lead to a client?', (confirmed) => {
            if (confirmed) {
                fetch('../backend/contact-management/convert_to_client.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({
                        id: leadId
                    })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        showToast('Lead converted to client successfully', 'success');
                        document.getElementById('editModal').style.display = 'none';
                        loadLeads();
                    } else {
                        showToast('Conversion failed: ' + (data.message || 'Unknown error'), 'error');
                    }
                })
                .catch(err => {
                    console.error(err);
                    showToast('An error occurred while converting', 'error');
                });
            }
        });
    });
});

// View Modal Handlers
document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('.close1').addEventListener('click', () => {
        document.getElementById('viewModal').style.display = 'none';
    });

    window.addEventListener('click', (e) => {
        if (e.target === document.getElementById('viewModal')) {
            document.getElementById('viewModal').style.display = 'none';
        }
    });
});

function openViewModal(lead) {
    console.log(lead);
    document.getElementById('view-id').value = lead.id;
    document.getElementById('view-company_name').value = lead.company_name;
    document.getElementById('view-contact_title').value = lead.contact_title;
    document.getElementById('view-contact_surname').value = lead.contact_surname;
    document.getElementById('view-contact_firstname').value = lead.contact_firstname;
    document.getElementById('view-email').value = lead.email;
    document.getElementById('view-company_category').value = lead.company_category;
    document.getElementById('view-position').value = lead.position;
    document.getElementById('view-address').value = lead.address;
    document.getElementById('view-source').value = lead.source;
    document.getElementById('view-modified_date').value = lead.modified_date;
    document.getElementById('view-phone_number').value = lead.phone_number;
    document.getElementById('view-status').value = lead.status;
    document.getElementById('viewModal').style.display = 'block';
}

// Edit Modal Handler
function openEditModal(lead) {
    console.log(lead);
    document.getElementById('edit-id').value = lead.id;
    document.getElementById('edit-company_name').value = lead.company_name;
    document.getElementById('edit-contact_title').value = lead.contact_title;
    document.getElementById('edit-contact_surname').value = lead.contact_surname;
    document.getElementById('edit-contact_firstname').value = lead.contact_firstname;
    document.getElementById('edit-email').value = lead.email;
    document.getElementById('edit-company_category').value = lead.company_category;
    document.getElementById('edit-position').value = lead.position;
    document.getElementById('edit-address').value = lead.address;
    document.getElementById('edit-source').value = lead.source;
    document.getElementById('edit-modified_date').value = lead.modified_date;
    document.getElementById('edit-phone_number').value = lead.phone_number;
    document.getElementById('edit-status').value = lead.status;
    document.getElementById('editModal').style.display = 'block';
}

// Edit Form Submission
document.getElementById('editForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('../backend/contact-management/edit_lead.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast('Lead updated successfully', 'success');
            document.getElementById('editModal').style.display = 'none';
            loadLeads();
        } else {
            showToast('Update failed', 'error');
        }
    })
    .catch(err => {
        console.error(err);
        showToast('An error occurred while updating', 'error');
    });
});

// Add Lead Form Submission
document.addEventListener('DOMContentLoaded', function() {
    const addForm = document.getElementById('addLeadForm');
    if (addForm) {
        addForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(addForm);
            const jsonData = {};
            formData.forEach((value, key) => {
                jsonData[key] = value;
            });
            fetch('../backend/contact-management/add_lead.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(jsonData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('Lead added successfully', 'success');
                    document.querySelector('.modal').style.display = 'none';
                    loadLeads();
                } else {
                    showToast('Error adding lead: ' + (data.message || 'Unknown error'), 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('An error occurred while adding the lead', 'error');
            });
        });
    }
    document.querySelector('.close').addEventListener('click', function() {
        document.querySelector('.modal').style.display = 'none';
    });
    window.addEventListener('click', function(e) {
        if (e.target === document.querySelector('.modal')) {
            document.querySelector('.modal').style.display = 'none';
        }
    });
    document.querySelector('.add-new-button').addEventListener('click', function() {
        document.querySelector('.modal').style.display = 'block';
    });
});

// Pagination and Table Loading
let currentPage = 1;
let rowsPerPage = 25;

const leadsTableBody = document.getElementById('leadsTableBody');
const rowsPerPageSelect = document.getElementById('rowsPerPage');
const prevPageBtn = document.getElementById('prevPage');
const nextPageBtn = document.getElementById('nextPage');
const pageInfoSpan = document.getElementById('pageInfo');

function truncateText(text, maxLength = 25) {
    if (text === null || text === undefined) return '';
    text = String(text);
    if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
    }
    return text;
}

function company_truncateText(text, maxLength = 23) {
    if (text === null || text === undefined) return '';
    text = String(text);
    if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
    }
    return text;
}

function contact_truncateText(text, maxLength = 15) {
    if (text === null || text === undefined) return '';
    text = String(text);
    if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
    }
    return text;
}

function number(text, maxLength = 12) {
    if (text === null || text === undefined) return '';
    text = String(text);
    if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
    }
    return text;
}

async function loadLeads() {
    try {
        const response = await fetch(`../backend/contact-management/fetch_leads.php?page=${currentPage}&rows_per_page=${rowsPerPage}`);
        const data = await response.json();
        if (data.success) {
            leadsTableBody.innerHTML = '';
            data.leads.forEach(lead => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>100${lead.id}</td>
                    <td>${company_truncateText(lead.company_name)}</td>
                    <td>${contact_truncateText(lead.contact_surname)}</td>
                    <td>${contact_truncateText(lead.contact_firstname)}</td>
                    <td>${truncateText(lead.position)}</td>
                    <td>${number(lead.phone_number)}</td>
                    <td style='text-transform:capitalize;'>${truncateText(lead.status)}</td>
                    <td>
                        <i class='view-icon'
                            data-id='${lead.id}'
                            data-company_name='${htmlspecialchars(lead.company_name)}'
                            data-contact_title='${htmlspecialchars(lead.contact_title)}'
                            data-contact_surname='${htmlspecialchars(lead.contact_surname)}'
                            data-contact_firstname='${htmlspecialchars(lead.contact_firstname)}'
                            data-email='${htmlspecialchars(lead.email)}'
                            data-company_category='${htmlspecialchars(lead.company_category)}'
                            data-position='${htmlspecialchars(lead.position)}'
                            data-address='${htmlspecialchars(lead.address)}'
                            data-source='${htmlspecialchars(lead.source)}'
                            data-modified_date='${htmlspecialchars(lead.modified_date)}'
                            data-phone_number='${htmlspecialchars(lead.phone_number)}'
                            data-status='${htmlspecialchars(lead.status)}'>
                            <img src='../assets/eye-open.png' />
                        </i>
                    </td>
                    <td>
                        <i class='edit-icon'
                            data-id='${lead.id}'
                            data-company_name='${htmlspecialchars(lead.company_name)}'
                            data-contact_title='${htmlspecialchars(lead.contact_title)}'
                            data-contact_surname='${htmlspecialchars(lead.contact_surname)}'
                            data-contact_firstname='${htmlspecialchars(lead.contact_firstname)}'
                            data-email='${htmlspecialchars(lead.email)}'
                            data-company_category='${htmlspecialchars(lead.company_category)}'
                            data-position='${htmlspecialchars(lead.position)}'
                            data-address='${htmlspecialchars(lead.address)}'
                            data-source='${htmlspecialchars(lead.source)}'
                            data-modified_date='${htmlspecialchars(lead.modified_date)}'
                            data-phone_number='${htmlspecialchars(lead.phone_number)}'
                            data-status='${htmlspecialchars(lead.status)}'>
                            <img src='../assets/edit.svg' />
                        </i>
                    </td>
                    <td>
                        <i class='delete-icon' data-id='${lead.id}'>
                            <img src='../assets/Delete.svg' />
                        </i>
                    </td>
                `;
                leadsTableBody.appendChild(row);
            });
            currentPage = data.currentPage;
            const totalPages = data.totalPages;
            pageInfoSpan.textContent = `Page ${currentPage} of ${totalPages}`;
            prevPageBtn.disabled = currentPage === 1;
            nextPageBtn.disabled = currentPage === totalPages;
            attachIconEventListeners();
        } else {
            showToast('Error loading leads: ' + (data.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error fetching leads:', error);
        showToast('An error occurred while loading leads.', 'error');
    }
}

function htmlspecialchars(str) {
    if (typeof str !== 'string') return str;
    return str.replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;')
              .replace(/'/g, '&#039;');
}

function attachIconEventListeners() {
    document.querySelectorAll('.view-icon').forEach(icon => {
        icon.onclick = () => {
            const lead = icon.dataset;
            openViewModal(lead);
        };
    });
    document.querySelectorAll('.edit-icon').forEach(icon => {
        icon.onclick = () => {
            const lead = icon.dataset;
            openEditModal(lead);
        };
    });
    document.querySelectorAll('.delete-icon').forEach(icon => {
        icon.onclick = () => {
            const leadId = icon.dataset.id;
            showConfirm("Are you sure you want to delete this lead?", (confirmed) => {
                if (confirmed) {
                    fetch('../backend/contact-management/delete_lead.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: new URLSearchParams({
                            id: leadId
                        })
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            showToast("Lead deleted successfully", 'success');
                            loadLeads();
                        } else {
                            showToast("Failed to delete lead: " + (data.message || 'Unknown error'), 'error');
                        }
                    })
                    .catch(err => {
                        console.error(err);
                        showToast("An error occurred while deleting", 'error');
                    });
                }
            });
        };
    });
}

rowsPerPageSelect.addEventListener('change', () => {
    rowsPerPage = parseInt(rowsPerPageSelect.value);
    currentPage = 1;
    loadLeads();
});

prevPageBtn.addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        loadLeads();
    }
});

nextPageBtn.addEventListener('click', () => {
    currentPage++;
    loadLeads();
});

document.addEventListener('DOMContentLoaded', loadLeads);
</script>

<?php include_once '../components/cashflow_footer.php'; ?>
<style>
table {
    border-collapse: collapse;
    width: 100%;
    table-layout: auto;
}
</style>