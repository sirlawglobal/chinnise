<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
  // Not logged in, redirect to login page
  header("Location: auth/login.php");
  exit;
}
?>

<?php
include_once '../components/header.php';
include_once '../settings/connection.php'; // assumes $pdo is set here

// Fetch sources from DB
$sourceStmt = $pdo->query("SELECT DISTINCT source FROM leads");
$sources = $sourceStmt->fetchAll(PDO::FETCH_COLUMN);

// Initialize filters
$startDate = $_GET['start_date'] ?? null;
$endDate = $_GET['end_date'] ?? null;
$sourceFilter = $_GET['source'] ?? 'all';
$contactType = $_GET['client_type'] ?? 'all';

// Build SQL query
$sql = "SELECT * FROM leads WHERE 1=1";
$params = [];

if (!empty($startDate)) {
  $sql .= " AND DATE(created_at) >= :start_date";
  $params['start_date'] = $startDate;
}
if (!empty($endDate)) {
  $sql .= " AND DATE(created_at) <= :end_date";
  $params['end_date'] = $endDate;
}
if ($sourceFilter !== 'all') {
  $sql .= " AND source = :source";
  $params['source'] = $sourceFilter;
}
if ($contactType !== 'all') {
  $sql .= " AND client_type = :client_type";
  $params['client_type'] = $contactType;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$leads = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="main" style="overflow: hidden">
  <?php include_once '../components/common_header.php'; ?>

  <section class="content" style="overflow: hidden">
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Contact Management</span>
        <span class="divider"></span>
        <span class="tab active">Client Growth Report</span>
      </div>
      <div class="anb-container">
        <button class="add-new-button add-new-income" onclick="printReport()" style="border-radius: 15px">
          Print Report
        </button>
      </div>
    </div>

    <!-- Filters Form -->
    <div id="filter-form" style="margin-top: 15px;">
      <div class="row1">
        <!--<div class="row2">-->
          <div class="col1">
            <label>Start Date</label>
            <input type="date" id="start_date" value="<?= htmlspecialchars($startDate) ?>">
          </div>
          <div class="col1">
            <label>End Date</label>
            <input type="date" id="end_date" value="<?= htmlspecialchars($endDate) ?>">
          </div>
        <!--</div>-->

        <!--<div class="row2">-->
          <div class="col1">
            <label>Source</label>
            <select id="source">
              <option value="all">All</option>
              <?php foreach ($sources as $src): ?>
                <option value="<?= htmlspecialchars($src) ?>" <?= $sourceFilter === $src ? 'selected' : '' ?>>
                  <?= htmlspecialchars(ucwords($src)) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col1">
            <label>Contact Type</label>
            <select id="client_type">
              <option value="all">All</option>
              <option value="leads" <?= $contactType === 'leads' ? 'selected' : '' ?>>Leads</option>
              <option value="client" <?= $contactType === 'client' ? 'selected' : '' ?>>Client</option>
            </select>
          </div>
        <!--</div>-->
      </div>
    </div>

    <!-- Leads Table -->
    <div class="over-table">
      <table id="print-table">
        <colgroup>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>Date Added</th>
            <th>Contact Name</th>
            <th>Source</th>
            <th>Contact Type</th>
          </tr>
        </thead>
        <tbody id="leads-table-body">
          <?php foreach ($leads as $lead): ?>
            <tr>
              <td><?= date('Y-m-d', strtotime($lead['created_at'])) ?></td>
              <td><?= htmlspecialchars($lead['contact_surname']) ?> <?= htmlspecialchars($lead['contact_firstname']) ?></td>
              <td><?= htmlspecialchars(ucwords($lead['source'])) ?></td>
              <td><?= htmlspecialchars(ucwords($lead['client_type'])) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="pagination-controls" style="margin-top: 20px; display: flex; justify-content: space-between; align-items: center; background: #f2f2f2; padding: 10px; border-radius: 8px;">
      <div class="RPP">
        <label for="rowsPerPage">Rows per page:</label>
        <select id="rowsPerPage">
          <option value="25" selected>25</option>
          <option value="50">50</option>
          <option value="75">75</option>
          <option value="100">100</option>
        </select>
      </div>
      <div>
        <button id="prevPage">Previous</button>
        <span id="pageInfo">Page 1 of 1</span>
        <button id="nextPage">Next</button>
      </div>
    </div>
  </section>
</div>

<?php include_once '../components/cashflow_footer.php'; ?>

<style>
  table {
    border-collapse: collapse;
    width: 100%;
    table-layout: fixed;
  }

  @media print {
    .main, .content {
      overflow: visible !important;
    }
    .tabs, .anb-container, #filter-form, .pagination-controls {
      display: none !important;
    }
    #print-table {
      width: 100%;
      border-collapse: collapse;
    }
    #print-table th, #print-table td {
      border: 1px solid black;
      padding: 8px;
      font-size: 12pt;
    }
    #print-table th {
      background-color: #f2f2f2;
    }
  }
</style>

<script>
  let currentPage = 1;
  let rowsPerPage = 25; // Default

  function fetchFilteredLeads(printAll = false) {
    const startDate = document.getElementById('start_date').value;
    const endDate = document.getElementById('end_date').value;
    const source = document.getElementById('source').value;
    const contactType = document.getElementById('client_type').value;

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '../backend/contact-management/filter-leads.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onload = function () {
      if (xhr.status === 200) {
        try {
          const response = JSON.parse(xhr.responseText);

          if (response.success) {
            const tbody = document.getElementById('leads-table-body');
            tbody.innerHTML = '';

            response.data.forEach(lead => {
              const tr = document.createElement('tr');
              tr.innerHTML = `
                <td>${lead.created_at.split(' ')[0]}</td>
                <td>${lead.contact_surname} ${lead.contact_firstname}</td>
                <td>${lead.source}</td>
                <td>${lead.client_type}</td>
              `;
              tbody.appendChild(tr);
            });

            // Pagination UI
            document.getElementById('pageInfo').textContent = `Page ${response.currentPage} of ${response.totalPages}`;
            document.getElementById('prevPage').disabled = response.currentPage === 1;
            document.getElementById('nextPage').disabled = response.currentPage === response.totalPages;
          } else {
            alert(response.message || 'Failed to load data.');
          }
        } catch (e) {
          console.error('Invalid JSON:', xhr.responseText);
        }
      } else {
        console.error('Server error:', xhr.statusText);
      }
    };

    const params = `start_date=${startDate}&end_date=${endDate}&source=${source}&client_type=${contactType}&page=${currentPage}&rows_per_page=${printAll ? 999999 : rowsPerPage}`;
    xhr.send(params);
  }

  // Print report function
  window.printReport = function() {
    // Fetch all data (ignoring pagination) for printing
    fetchFilteredLeads(true);
    // Delay print to ensure table is populated
    setTimeout(() => {
      window.print();
    }, 500);
  };

  // Event listeners
  document.addEventListener('DOMContentLoaded', () => {
    const rowsPerPageSelect = document.getElementById('rowsPerPage');
    if (rowsPerPageSelect) {
      rowsPerPage = parseInt(rowsPerPageSelect.value);

      rowsPerPageSelect.addEventListener('change', () => {
        rowsPerPage = parseInt(rowsPerPageSelect.value);
        currentPage = 1;
        fetchFilteredLeads();
      });
    }

    // Filter listeners
    ['start_date', 'end_date', 'source', 'client_type'].forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('change', () => {
          currentPage = 1;
          fetchFilteredLeads();
        });
      }
    });

    // Pagination listeners
    document.getElementById('prevPage').addEventListener('click', () => {
      if (currentPage > 1) {
        currentPage--;
        fetchFilteredLeads();
      }
    });

    document.getElementById('nextPage').addEventListener('click', () => {
      currentPage++;
      fetchFilteredLeads();
    });

    fetchFilteredLeads();
  });
</script>