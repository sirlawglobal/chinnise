<?php
include_once '../settings/connection.php';

// Get filters
$name = $_GET['name'] ?? '';
$month = $_GET['month'] ?? '';
$year = $_GET['year'] ?? '';
$type = $_GET['type'] ?? '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$rowsPerPage = isset($_GET['rows_per_page']) ? (int)$_GET['rows_per_page'] : 25;
$offset = ($page - 1) * $rowsPerPage;

$sql = "SELECT * FROM leads WHERE 1=1";
$countSql = "SELECT COUNT(*) FROM leads WHERE 1=1";
$params = [];
$countParams = [];

if (!empty($name)) {
    $sql .= " AND contact_surname LIKE :name";
    $countSql .= " AND contact_surname LIKE :name";
    $params[':name'] = $countParams[':name'] = "%$name%";
}
if (!empty($month)) {
    $sql .= " AND MONTH(created_at) = :month";
    $countSql .= " AND MONTH(created_at) = :month";
    $params[':month'] = $countParams[':month'] = $month;
}
if (!empty($year)) {
    $sql .= " AND YEAR(created_at) = :year";
    $countSql .= " AND YEAR(created_at) = :year";
    $params[':year'] = $countParams[':year'] = $year;
}
if (!empty($type)) {
    $sql .= " AND client_type = :type";
    $countSql .= " AND client_type = :type";
    $params[':type'] = $countParams[':type'] = $type;
}

// Get total rows for pagination
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($countParams);
$totalRows = $countStmt->fetchColumn();
$totalPages = ceil($totalRows / $rowsPerPage);

// Add LIMIT for pagination
$sql .= " LIMIT :offset, :limit";
$params[':offset'] = $offset;
$params[':limit'] = $rowsPerPage;

$stmt = $pdo->prepare($sql);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':limit', $rowsPerPage, PDO::PARAM_INT);

// Bind other values
foreach ($params as $key => $val) {
    if ($key !== ':offset' && $key !== ':limit') {
        $stmt->bindValue($key, $val);
    }
}

$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Count total leads and clients (for stats)
$totalLeads = $pdo->query("SELECT COUNT(*) FROM leads WHERE client_type='Leads'")->fetchColumn();
$totalClients = $pdo->query("SELECT COUNT(*) FROM leads WHERE client_type='Client'")->fetchColumn();

// Return JSON
echo json_encode([
    'success' => true,
    'data' => $results,
    'totalLeads' => $totalLeads,
    'totalClients' => $totalClients,
    'currentPage' => $page,
    'totalPages' => $totalPages
]);
