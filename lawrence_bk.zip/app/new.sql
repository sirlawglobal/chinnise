CREATE TABLE
    `projects` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(45) NOT NULL,
        `start_date` date NOT NULL,
        `due_date` date DEFAULT NULL,
        `supervisor_id` int(11) NOT NULL,
        `status` enum('Pending', 'Ongoing', 'Completed') DEFAULT 'Pending',
        `created_at` timestamp NOT NULL DEFAULT current_timestamp (),
        `updated_at` timestamp NOT NULL DEFAULT current_timestamp () ON UPDATE current_timestamp (),
        PRIMARY KEY (`id`),
        KEY `supervisor_id` (`supervisor_id`),
        CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`supervisor_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
    ) ENGINE = InnoDB AUTO_INCREMENT = 6 DEFAULT CHARSET = utf8mb4
CREATE TABLE
    `project_assignees` (
        `project_id` int(11) NOT NULL,
        `user_id` int(11) NOT NULL,
        PRIMARY KEY (`project_id`, `user_id`),
        KEY `user_id` (`user_id`),
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
        FOREIGN KEY (`user_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4
CREATE TABLE
    `tasks` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `project_id` int(11) NOT NULL,
        `name` varchar(255) NOT NULL,
        `start_date` date NOT NULL,
        `due_date` date NOT NULL,
        `priority` enum('Low', 'Medium', 'High') NOT NULL DEFAULT 'Medium',
        `status` enum('Pending', 'Ongoing', 'Completed') NOT NULL DEFAULT 'Pending',
        `created_at` timestamp NOT NULL DEFAULT current_timestamp (),
        `updated_at` timestamp NOT NULL DEFAULT current_timestamp () ON UPDATE current_timestamp (),
        PRIMARY KEY (`id`),
        KEY `project_id` (`project_id`),
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 task_assignees
CREATE TABLE
    `task_assignees` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `task_id` int(11) NOT NULL,
        `user_id` int(11) NOT NULL,
        `assigned_at` timestamp NOT NULL DEFAULT current_timestamp (),
        PRIMARY KEY (`id`),
        KEY `task_id` (`task_id`),
        KEY `user_id` (`user_id`),
        FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE,
        FOREIGN KEY (`user_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4