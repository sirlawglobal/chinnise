<?php include_once '../components/header.php'; ?>
<style>
  .button-container {
    display: flex;
    justify-content: center;
    margin-top: 20px;
  }

  .large-btn {
    font-size: 18px;
    padding: 12px 24px;
  }
</style>

<div class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con">Add New Supplier</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Name</label>
          <input type="text" name="name" placeholder="Enter name" />
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="address" placeholder="Enter address" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Last Name</label>
          <input type="text" name="last_name" placeholder="Enter last name" />
        </div>
        <div class="col">
          <label>First Name</label>
          <input type="text" name="first_name" placeholder="Enter first name" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Email</label>
          <input type="text" name="email" placeholder="Enter email" />
        </div>
        <div class="col">
          <label>Phone Number</label>
          <input type="text" name="phone_number" placeholder="Enter phone number" />
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>
<div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">View Supplier</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Name</label>
          <input type="text" name="name" readonly placeholder="Enter name" />
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="address" readonly placeholder="Enter address" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Last Name</label>
          <input
            type="text"

            disabled
            placeholder="Enter last name" />
        </div>
        <div class="col">
          <label>First Name</label>
          <input
            type="text"

            disabled
            placeholder="Enter first name" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Email</label>
          <input
            type="text"

            disabled
            placeholder="Enter email" />
        </div>
        <div class="col">
          <label>Phone Number</label>
          <input
            type="text"

            disabled
            placeholder="Enter phone number" />
        </div>
      </div>
    </form>
  </div>
</div>
<div class="modal2" id="edit">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Supplier</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Name</label>
          <input type="text" name="name" placeholder="Enter name" />
        </div>
        <div class="col">
          <label>Address</label>
          <input type="text" name="address" placeholder="Enter address" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Last Name</label>
          <input
            type="text"
            name="last_name"
            placeholder="Enter last name" />
        </div>
        <div class="col">
          <label>First Name</label>
          <input type="text" name="first_name" placeholder="Enter first name" />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Email</label>
          <input
            type="text"
            name="email"
            placeholder="Enter email" />
        </div>
        <div class="col">
          <label>Phone Number</label>
          <input
            type="text"
            name="phone_number"
            placeholder="Enter phone number" />
        </div>
      </div>

      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update</button>
      </div>
    </form>
  </div>
</div>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content" style="overflow: hidden">
    <!-- Tabs for Clients and Leads -->
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Inventory</span>
        <span class="divider"></span>
        <span class="tab active">Suppliers</span>
      </div>

      <button class="add-new-button">Add New Supplier</button>
    </div>

    <!-- Table for Leads -->
    <div style="overflow: auto; padding: 0.7rem; height: 95%">
      <table>
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>Supplier ID</th>
            <th>Supplier Name</th>
            <th>Last Name</th>
            <th>First Name</th>
            <th>Phone Number</th>
            <th>Email</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
        </tbody>
      </table>
    </div>
  </section>
</div>



<script>
  // Fetch and map suppliers data to the table
  async function loadSuppliers() {
    try {
      const response = await fetch('../backend/inventory/fetch_suppliers.php');
      const result = await response.json();

      if (response.ok && result.success) {
        const tbody = document.querySelector('table tbody');
        tbody.innerHTML = ''; // Clear existing rows

        result.data.forEach(supplier => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td>${supplier.supplier_id || supplier.id || ''}</td>
            <td>${supplier.name}</td>
            <td>${supplier.last_name}</td>
            <td>${supplier.first_name}</td>
            <td>${supplier.phone_number}</td>
             <td>${supplier.email}</td>
            
             <td>
              <i class="view-icon"
                data-last_name="${supplier.last_name}"
                data-name="${supplier.name}"
                data-address="${supplier.address}"
                data-first_name="${supplier.first_name}"
                data-email="${supplier.email}"
                data-phone_number="${supplier.phone_number}">
                <img src="../assets/eye-open.png" />
              </i>
            </td>
             <td>
              <i class="edit-icon"
                data-supplier_id="${supplier.supplier_id || supplier.id || ''}"
                data-last_name="${supplier.last_name}"
                data-name="${supplier.name}"
                data-address="${supplier.address}"
                data-first_name="${supplier.first_name}"
                data-email="${supplier.email}"
                data-phone_number="${supplier.phone_number}">
                <img src="../assets/edit.svg" />
              </i>
            </td>
            <td>
              <i class="delete-icon">
                <img src="../assets/Delete.svg" />
              </i>
            </td>
          `;
          tbody.appendChild(tr);
        });
        document.querySelectorAll('.view-icon').forEach(icon => {
          icon.addEventListener('click', function() {
            // Fill modal1 fields with data attributes
            const modal = document.querySelector('.modal1');
            modal.querySelector('input[placeholder="Enter last name"]').value = this.getAttribute('data-last_name');
            modal.querySelector('input[placeholder="Enter name"]').value = this.getAttribute('data-name');
            modal.querySelector('input[placeholder="Enter address"]').value = this.getAttribute('data-address');
            modal.querySelector('input[placeholder="Enter first name"]').value = this.getAttribute('data-first_name');
            modal.querySelector('input[placeholder="Enter email"][disabled]').value = this.getAttribute('data-email');
            modal.querySelector('input[placeholder="Enter phone number"]').value = this.getAttribute('data-phone_number');
            modal.style.display = 'block';
          });
        });

        document.querySelectorAll('.edit-icon').forEach(icon => {
          icon.addEventListener('click', function() {
            const modal = document.querySelector('.modal2');
            const inputs = modal.querySelectorAll('input');
            // Set values
            inputs[0].value = this.getAttribute('data-name');
            inputs[1].value = this.getAttribute('data-address');
            inputs[2].value = this.getAttribute('data-last_name');
            inputs[3].value = this.getAttribute('data-first_name');
            inputs[4].value = this.getAttribute('data-email');
            inputs[5].value = this.getAttribute('data-phone_number');
            // Store supplier_id for update
            modal.dataset.supplierId = this.getAttribute('data-supplier_id');
            modal.style.display = 'block';
          });
        });

        document.querySelectorAll('.delete-icon').forEach((icon, idx) => {
          icon.addEventListener('click', async function() {
            // Get supplier_id from the row (assuming it's in the first cell)
            const tr = this.closest('tr');
            const supplierId = tr.children[0].textContent.trim();
            if (confirm('Are you sure you want to delete this supplier?')) {
              try {
                const formData = new FormData();
                formData.append('supplier_id', supplierId);
                const response = await fetch('../backend/inventory/delete_supplier.php', {
                  method: 'POST',
                  body: formData
                });
                const result = await response.json();
                if (response.ok && result.success) {
                  alert('Supplier deleted successfully!');
                  loadSuppliers();
                } else {
                  alert(result.error || 'Failed to delete supplier.');
                }
              } catch (error) {
                alert('An error occurred. Please try again.');
              }
            }
          });
        });
      } else {
        alert(result.error || 'Failed to fetch suppliers.');
      }
    } catch (error) {
      alert('An error occurred while fetching suppliers.');
    }
  }

  // Load suppliers on page load
  document.addEventListener('DOMContentLoaded', loadSuppliers);

  // Existing form submit handler
  document.querySelector('.modal form').addEventListener('submit', async function(e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);

    try {
      const response = await fetch('../backend/inventory/add_suppliers.php', {
        method: 'POST',
        body: formData
      });

      const result = await response.json();

      if (response.ok && result.success) {
        alert('Supplier added successfully!');
        document.querySelector(".close").click();
        form.reset();
        loadSuppliers(); // Refresh the suppliers list
      } else {
        alert(result.error || 'Failed to add supplier.');
      }
    } catch (error) {
      alert('An error occurred. Please try again.');
    }
  });
  document.querySelector('.modal2 form').addEventListener('submit', async function(e) {
    e.preventDefault();

    const modal = document.querySelector('.modal2');
    const supplierId = modal.dataset.supplierId;
    const inputs = modal.querySelectorAll('input');
    const form = e.target;
    const formData = new FormData(form);
    formData.append('supplier_id', supplierId)


    try {
      const response = await fetch('../backend/inventory/edit_supplier.php', {
        method: 'POST',
        body: formData
      });

      const result = await response.json();
      if (response.ok && result.success) {
        alert('Supplier updated successfully!');
        document.querySelector(".close2").click();
        loadSuppliers(); // Refresh the suppliers list
      } else {
        alert(result.error || 'Failed to update supplier.');
      }
    } catch (error) {
      alert('An error occurred. Please try again.');
    }
  });
</script>

<style>
  colgroup col:nth-child(6) {
    width: 150px;
  }

  colgroup col:nth-child(9) {
    width: 70px;
  }
</style>


<?php include_once '../components/cashflow_footer.php'; ?>