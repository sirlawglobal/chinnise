<?php include_once '../components/header.php'; ?>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content" style="overflow: hidden">
    <!-- Tabs for Clients and Leads -->
    <div class="tabs" style="margin-bottom: 5px">
      <div style="align-items: center; display: flex">
        <span class="tab">Inventory</span>
        <span class="divider"></span>
        <span class="tab active">Order And Reorder Report</span>
      </div>
      <div style="margin-bottom: 5px; margin-top: 0px; text-align: right">
        <div class="filters" style="display: inline-flex; gap: 10px">
          <select
            id="filter-priority"
            style="padding: 10px; width: 180px; font-size: 14px">
            <option>Filter by Performance</option>
            <option>High</option>
            <option>Moderate</option>
            <option>Low</option>
          </select>

          <select
            id="filter-status"
            style="padding: 10px; width: 180px; font-size: 14px">
            <option>Filter by Category</option>
            <option>Electronics</option>
            <option>Household</option>
            <option>Office Supplies</option>
          </select>
        </div>
      </div>

      <!-- <button class="add-new-button">Add New Lead</button> -->
    </div>

    <!-- Table for Leads -->
    <div class="over-table" style="margin-bottom: 20px">
      <table class="leads-table">
        <thead>
          <tr>
            <th>Product Name</th>
            <th>SKU</th>

            <th>Current Stock Level</th>
            <th>Reorder Point</th>
            <th>Last Ordered Date</th>
            <th>Action Required</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Laser Printer</td>
            <td>LP2300</td>
            <td>Electronics</td>
            <td>6</td>
            <td>10</td>
            <td>2025-05-10</td>
            <td>Yes</td>
          </tr>
          <tr>
            <td>Executive Desk</td>
            <td>ED4501</td>
            <td>Furniture</td>
            <td>22</td>
            <td>10</td>
            <td>2025-05-01</td>
            <td>No</td>
          </tr>
          <tr>
            <td>Ballpoint Pens</td>
            <td>BP1023</td>
            <td>Stationery</td>
            <td>8</td>
            <td>20</td>
            <td>2025-05-15</td>
            <td>Yes</td>
          </tr>
          <tr>
            <td>USB Hub</td>
            <td>UH7754</td>
            <td>Electronics</td>
            <td>16</td>
            <td>12</td>
            <td>2025-05-17</td>
            <td>No</td>
          </tr>
          <tr>
            <td>Paper Clips</td>
            <td>PC6543</td>
            <td>Stationery</td>
            <td>4</td>
            <td>15</td>
            <td>2025-05-12</td>
            <td>Yes</td>
          </tr>
          <tr>
            <td>Ergonomic Chair</td>
            <td>EC3098</td>
            <td>Furniture</td>
            <td>11</td>
            <td>10</td>
            <td>2025-05-08</td>
            <td>No</td>
          </tr>
          <tr>
            <td>Laptop Stand</td>
            <td>LS9843</td>
            <td>Accessories</td>
            <td>7</td>
            <td>10</td>
            <td>2025-05-19</td>
            <td>Yes</td>
          </tr>
          <tr>
            <td>Highlighters</td>
            <td>HL9081</td>
            <td>Stationery</td>
            <td>30</td>
            <td>25</td>
            <td>2025-05-05</td>
            <td>No</td>
          </tr>
          <tr>
            <td>Monitor 24”</td>
            <td>MN2400</td>
            <td>Electronics</td>
            <td>3</td>
            <td>5</td>
            <td>2025-05-16</td>
            <td>Yes</td>
          </tr>
          <tr>
            <td>File Organizer</td>
            <td>FO1122</td>
            <td>Office Supplies</td>
            <td>18</td>
            <td>15</td>
            <td>2025-05-14</td>
            <td>No</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="tabs">
      <button class="add-new-button">Print Report</button>
    </div>
  </section>
</div>

<?php include_once '../components/cashflow_footer.php'; ?>