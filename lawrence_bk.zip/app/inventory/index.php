<?php include_once '../components/header.php'; ?>

<!-- Main content -->
<div class="main">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content">
    <h3 style="padding: 1rem">Inventory Management</h3>
    <div class="box1">
      <div class="box2">
        <h4 class="box2-title">Current Stock Value</h4>
        <div class="box2-val" id="stocks">0</div>
      </div>
      <div class="box2">
        <h4 class="box2-title">Number of Supplier Returns</h4>
        <div class="box2-val" id="returns">0</div>
      </div>
      <div class="box2">
        <h4 class="box2-title">Number of Customer Returns</h4>
        <div class="box2-val" id="orders">0</div>
      </div>
    </div>
    <div class="box1" style="grid-template-columns: 1fr">
      <div class="box2" style="height: 100%; padding: 0">
        <h4>Order List And Quantity</h4>
        <div
          style="overflow: auto; padding: 0.7rem; height: 80%; width: 100%">
          <table class="leads-table">
            <thead>
              <tr>
                <th>Items</th>
                <th>Quantity</th>
                <th>Reorder Trigger</th>
              </tr>
            </thead>
            <tbody class="all-stocks-table">

            </tbody>

          </table>
        </div>
      </div>
      <!-- <div class="box2" style="height: 100%">
        <div id="calendar" style="overflow-y: auto;width:100%"></div>
      </div> -->
    </div>
  </section>
</div>
<!-- <script src="../fullcalendar.min.js"></script>
<script src="../cals.js"></script> -->
<script>
  async function fetchInventoryStats() {
    try {
      const response = await fetch('../backend/inventory/index.php');
      const result = await response.json();
      if (result.success && result.data) {
        // console.log(String(result.data.stocks).toLocaleString())
        document.getElementById('stocks').textContent = "₦" + result.data.stocks.toLocaleString() ?? 0;
        document.getElementById('returns').textContent = result.data.returns ?? 0;
        document.getElementById('orders').textContent = result.data.orders ?? 0;
      }
    } catch (e) {
      // Optionally handle error
      console.error('Failed to fetch inventory stats', e);
    }
  }
  async function loadStocks() {
    try {
      const response = await fetch('../backend/inventory/fetch_stocks_all.php');
      const result = await response.json();

      if (response.ok && result.success) {
        const tbody = document.querySelector('.all-stocks-table');
        tbody.innerHTML = '';

        result.data.forEach(stock => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
          <td>${stock.item} (${stock.size})</td>
          <td>${stock.qty}</td>
          <td>${stock.reorder_trigger}</td>`;
          tbody.appendChild(tr);
        });
      }
    } catch (e) {
      // Optionally handle error
      console.error('Failed to fetch inventory stats', e);
    }
  }

  document.addEventListener('DOMContentLoaded', fetchInventoryStats);
  document.addEventListener('DOMContentLoaded', loadStocks);
</script>
<?php include_once '../components/cashflow_footer.php' ?>