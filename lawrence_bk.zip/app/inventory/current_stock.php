<?php include_once '../components/header.php'; ?>

<style>
  .button-container {
    display: flex;
    justify-content: center;
    margin-top: 20px;
  }

  .large-btn {
    font-size: 18px;
    padding: 12px 50px;
  }
</style>
<div class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con">Add New Stock</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Item Name</label>
          <input type="text" name="item" placeholder="Enter Item Name" />
        </div>
        <div class="col">
          <label> Item Description </label>
          <input type="text" name="description" placeholder="Enter description" />
        </div>

      </div>
      <div class="row">
        <div class="col">
          <label>Item Colour</label>
          <input type="text" name="colour" placeholder="Enter Colour" />
        </div>
        <div class="col">
          <label>Item Size</label>
          <input type="text" name="size" placeholder="Enter Size" />
        </div>

      </div>
      <div class="row">
        <div class="col">
          <label>QTY</label>
          <input type="number" name="qty" placeholder="0" />
        </div>
        <div class="col">
          <label>Unit Price</label>
          <input type="number" name="unit_price" placeholder="0" />
        </div>

      </div>
      <div class="row">

        <div class="col">
          <label>Total Price </label>
          <input type="number" name="total_price" readonly placeholder="0" />
        </div>
        <div class="col">
          <label>Reorder Trigger</label>
          <input type="number" name="reorder_trigger" placeholder="0" />
        </div>
      </div>

      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>
<div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">View Stocks</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Item Name</label>
          <input type="text" name="item" placeholder="Enter Item Name" />
        </div>
        <div class="col">
          <label> Item Description </label>
          <input type="text" name="description" placeholder="Enter description" />
        </div>

      </div>
      <div class="row">
        <div class="col">
          <label>Item Colour</label>
          <input type="text" name="colour" placeholder="Enter Colour" />
        </div>
        <div class="col">
          <label>Item Size</label>
          <input type="text" name="size" placeholder="Enter Size" />
        </div>

      </div>
      <div class="row">
        <div class="col">
          <label>QTY</label>
          <input type="number" name="qty" />
        </div>
        <div class="col">
          <label>Unit Price</label>
          <input type="number" name="unit_price" />
        </div>

      </div>
      <div class="row">

        <div class="col">
          <label>Total Price </label>
          <input type="number" name="total_price" readonly />
        </div>
        <div class="col">
          <label>Reorder Trigger</label>
          <input type="number" name="reorder_trigger" placeholder="Enter reorder" />
        </div>
      </div>
    </form>
  </div>
</div>
<div class="modal2" id="edit">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Client</h2>
    <form>
      <div class="row">
        <div class="col">
          <label>Item Name</label>
          <input type="text" name="item" placeholder="Enter Item Name" />
        </div>
        <div class="col">
          <label> Item Description </label>
          <input type="text" name="description" placeholder="Enter description" />
        </div>

      </div>
      <div class="row">
        <div class="col">
          <label>Item Colour</label>
          <input type="text" name="colour" placeholder="Enter Colour" />
        </div>
        <div class="col">
          <label>Item Size</label>
          <input type="text" name="size" placeholder="Enter Size" />
        </div>

      </div>
      <div class="row">
        <div class="col">
          <label>QTY</label>
          <input type="number" name="qty" />
        </div>
        <div class="col">
          <label>Unit Price</label>
          <input type="number" name="unit_price" />
        </div>

      </div>
      <div class="row">

        <div class="col">
          <label>Total Price </label>
          <input type="number" name="total_price" readonly />
        </div>
        <div class="col">
          <label>Reorder Trigger</label>
          <input type="number" name="reorder_trigger" placeholder="Enter reorder" />
        </div>
      </div>
      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update</button>
      </div>
    </form>
  </div>
</div>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content" style="overflow: hidden">
    <!-- Tabs for Clients and Leads -->
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Inventory</span>
        <span class="divider"></span>
        <span class="tab active"> Current Stock</span>
      </div>

      <button class="add-new-button">Add New</button>
    </div>

    <!-- Table for Leads -->
    <div style="overflow: auto; padding: 0.7rem; height: 95%">
      <table cellpadding="8" cellspacing="0">
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col><col><col>
        </colgroup>
        <thead>
          <tr>
            <th>Stock ID</th>
            <th>Item Name</th>
            <th>Item Colour</th>
            <th>Item Size</th>
            
            <th>Unit Price</th>
            <th>Qty</th>
            <th>Total Price</th>
            <th>Reorder Trigger</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>

        </tbody>
      </table>
    </div>
  </section>
</div>
<script>
  // Fetch and display stocks in your table
  async function loadStocks() {
    try {
      const response = await fetch('../backend/inventory/fetch_stocks.php');
      const result = await response.json();

      if (response.ok && result.success) {
        const tbody = document.querySelector('table tbody');
        tbody.innerHTML = ''; // Clear existing rows

        result.data.forEach(stock => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
          <td>${stock.stock_id}</td>
          <td>${stock.item}</td>
           <td>${stock.colour}</td>
          <td>${stock.size}</td>
          <td>${stock.unit_price}</td>
          <td>${stock.qty}</td>
          <td>${stock.total_price}</td>
          <td>${stock.reorder_trigger}</td>
        
          <td>
            <i class="view-icon"
              data-item="${stock.item}"
              data-colour="${stock.colour}"
              data-size="${stock.size}"
              data-unit_price="${stock.unit_price}"
              data-qty="${stock.qty}"
              data-total_price="${stock.total_price}"
              data-description="${stock.description}"
              data-reorder_trigger="${stock.reorder_trigger}">
              <img src="../assets/eye-open.png" />
            </i>
          </td>
          <td>
            <i class="edit-icon"
              data-stock_id="${stock.stock_id}"
              data-item="${stock.item}"
              data-colour="${stock.colour}"
              data-size="${stock.size}"
              data-unit_price="${stock.unit_price}"
              data-qty="${stock.qty}"
              data-total_price="${stock.total_price}"
              data-description="${stock.description}"
              data-reorder_trigger="${stock.reorder_trigger}">
              <img src="../assets/edit.svg" />
            </i>
          </td>
          <td>
              <i class="delete-icon">
                <img src="../assets/Delete.svg" />
              </i>
            </td>
        `;
          tbody.appendChild(tr);
        });


        document.querySelectorAll('.view-icon').forEach(icon => {
          icon.addEventListener('click', function() {
            // Fill modal1 fields with data attributes
            const modal = document.querySelector('.modal1');
            modal.querySelector('input[name="item"]').value = this.getAttribute('data-item') || '';
            modal.querySelector('input[name="size"]').value = this.getAttribute('data-size') || '';
            modal.querySelector('input[name="colour"]').value = this.getAttribute('data-colour') || '';
            modal.querySelector('input[name="unit_price"]').value = this.getAttribute('data-unit_price') || '';
            modal.querySelector('input[name="qty"]').value = this.getAttribute('data-qty') || '';
            modal.querySelector('input[name="total_price"]').value = this.getAttribute('data-total_price') || '';
            modal.querySelector('input[name="reorder_trigger"]').value = this.getAttribute('data-reorder_trigger') || '';
            modal.querySelector('input[name="description"]').value = this.getAttribute('data-description') || '';
            modal.style.display = 'block';
          });
        });


        // Open Edit Modal and fill fields
        document.querySelectorAll('.edit-icon').forEach(icon => {
          icon.addEventListener('click', function() {
            const modal = document.querySelector('.modal2');
            // Fill fields
            const form = modal.querySelector('form');
            modal.querySelector('input[name="item"]').value = this.getAttribute('data-item') || '';
            modal.querySelector('input[name="size"]').value = this.getAttribute('data-size') || '';
            modal.querySelector('input[name="colour"]').value = this.getAttribute('data-colour') || '';
            modal.querySelector('input[name="unit_price"]').value = this.getAttribute('data-unit_price') || '';
            modal.querySelector('input[name="qty"]').value = this.getAttribute('data-qty') || '';
            modal.querySelector('input[name="total_price"]').value = this.getAttribute('data-total_price') || '';
            modal.querySelector('input[name="reorder_trigger"]').value = this.getAttribute('data-reorder_trigger') || '';
            modal.querySelector('input[name="description"]').value = this.getAttribute('data-description') || '';

            // Store stock_id for update
            modal.dataset.stockId = this.getAttribute('data-stock_id');
            modal.style.display = 'block';
          });
        });


        // Handle Delete Stock
        document.querySelectorAll('.delete-icon').forEach(icon => {
          icon.addEventListener('click', async function() {

            const tr = this.closest('tr');
            let stockId = null;

            const editIcon = tr.querySelector('.edit-icon');
            if (editIcon && editIcon.getAttribute('data-stock_id')) {
              stockId = editIcon.getAttribute('data-stock_id');
            } else if (tr.children[0]) {

              stockId = tr.children[0].textContent.trim();
            }
            if (!stockId) {
              alert('Could not determine stock ID.');
              return;
            }

            if (confirm('Are you sure you want to delete this stock?')) {
              try {
                const formData = new FormData();
                formData.append('stock_id', stockId);
                const response = await fetch('../backend/inventory/delete_stock.php', {
                  method: 'POST',
                  body: formData
                });
                const result = await response.json();
                if (response.ok && result.success) {
                  alert('Stock deleted successfully!');
                  loadStocks();
                } else {
                  alert(result.error || 'Failed to delete stock.');
                }
              } catch (error) {
                alert('An error occurred. Please try again.');
              }
            }
          });
        });

        // Close Edit Modal
        document.querySelector('.close2').onclick = function() {
          document.querySelector('.modal2').style.display = 'none';
        };

        // Calculate total price in edit modal
        const editModal = document.querySelector('.modal2');
        const editUnitPriceInput = editModal.querySelector('input[name="unit_price"]');
        const editQtyInput = editModal.querySelector('input[name="qty"]');
        const editTotalPriceInput = editModal.querySelector('input[name="total_price"]');

        function updateEditTotalPrice() {
          const unitPrice = parseFloat(editUnitPriceInput.value) || 0;
          const qty = parseFloat(editQtyInput.value) || 0;
          editTotalPriceInput.value = (unitPrice * qty).toFixed(2);
        }
        editUnitPriceInput.addEventListener('input', updateEditTotalPrice);
        editQtyInput.addEventListener('input', updateEditTotalPrice);



      } else {
        alert(result.error || 'Failed to fetch stocks.');
      }
    } catch (error) {
      alert('An error occurred while fetching stocks.');
    }
  }

  // Handle Edit Stock form submit
  document.querySelector('.modal2 form').addEventListener('submit', async function(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    formData.append('stock_id', form.dataset.stockId);
    modal2.style.display = 'none';
    try {
      const response = await fetch('../backend/inventory/edit_stock.php', {
        method: 'POST',
        body: formData
      });
      const result = await response.json();

      if (response.ok && result.success) {
        form.reset()
        console.log('edit submit')
        alert('Stock updated successfully!');

        loadStocks();
      } else {

        alert(result.error || 'Failed to update stock.');
        modal2.style.display = 'none';
      }
    } catch (error) {
      alert('An error occurred. Please try again.');
      modal2.style.display = 'none';
    }
  });

  document.addEventListener('DOMContentLoaded', function() {
    loadStocks();
    // Show modal on "Add New" button click
    document.querySelector('.add-new-button').addEventListener('click', function() {
      document.querySelector('.modal').style.display = 'block';
    });

    // Close modal
    document.querySelector('.close').onclick = function() {
      document.querySelector('.modal').style.display = 'none';
    };

    // Calculate total price when unit price or qty changes
    const unitPriceInput = document.querySelector('input[name="unit_price"]');
    const qtyInput = document.querySelector('input[name="qty"]');
    const totalPriceInput = document.querySelector('input[name="total_price"]');

    function updateTotalPrice() {
      const unitPrice = parseFloat(unitPriceInput.value) || 0;
      const qty = parseFloat(qtyInput.value) || 0;
      totalPriceInput.value = (unitPrice * qty).toFixed(2);
    }

    unitPriceInput.addEventListener('input', updateTotalPrice);
    qtyInput.addEventListener('input', updateTotalPrice);

    // AJAX form submit for Add New Stock
    document.querySelector('.modal form').addEventListener('submit', async function(e) {
      e.preventDefault();
      const form = e.target;
      const formData = new FormData(form);

      // Add reorder_trigger if you have a field for it
      const reorderInput = form.querySelector('input[placeholder="Enter reorder"]');
      if (reorderInput) {
        formData.append('reorder_trigger', reorderInput.value);
      }
      modal.style.display = 'none';
      try {
        const response = await fetch('../backend/inventory/add_stock.php', {
          method: 'POST',
          body: formData
        });
        const result = await response.json();

        if (response.ok && result.success) {
          alert('Stock added successfully!');

          form.reset();
          totalPriceInput.value = '';
          // Optionally, reload the stock table here
          loadStocks();
        } else {
          alert(result.error || 'Failed to add stock.');
          modal.style.display = 'none';
        }
      } catch (error) {
        alert('An error occurred. Please try again.');
        modal.style.display = 'none';
      }
    });
  });
</script>
<style>
  colgroup col:nth-child(5) {
    width: 100px;
  }
  colgroup col:nth-child(6) {
    width: 60px;
  }

  colgroup col:nth-child(7) {
    width: 100px;
  }

  colgroup col:nth-child(8) {
    width: 100px;
  }

  colgroup col:nth-child(9) {
    width: 50px;
  }

  colgroup col:nth-child(10) {
    width: 50px;
  }

  colgroup col:nth-child(11) {
    width: 60px;
  }
</style>
<?php include_once '../components/cashflow_footer.php'; ?>