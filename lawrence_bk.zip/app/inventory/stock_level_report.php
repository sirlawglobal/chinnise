<?php include_once '../components/header.php'; ?>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content" style="overflow: hidden">
    <!-- Tabs for Clients and Leads -->
    <div class="tabs" style="margin-bottom: 5px">
      <div style="align-items: center; display: flex">
        <span class="tab">Inventory</span>
        <span class="divider"></span>
        <span class="tab active">Stock level Report</span>
      </div>
      <div style="margin-bottom: 5px; margin-top: 0px; text-align: right">
        <div class="filters" style="display: inline-flex; gap: 10px">
          <input type="text" name="filter_name" id="filter_name" value="" placeholder="Enter Product name OR ID">

        </div>
      </div>

      <!-- <button class="add-new-button">Add New Lead</button> -->
    </div>

    <!-- Table for Leads -->
    <div class="over-table">
      <table class="leads-table">
        <thead>
          <tr>
            <th>Product Name</th>
            <th>SKU</th>
            <th>Current Stock Level</th>
            <th>Reorder Point</th>
            <th>Last Ordered Date</th>
            <th>Action Required</th>
          </tr>
        </thead>
        <tbody class="stock-level-table">


        </tbody>
      </table>
    </div>
    <!-- <div class="tabs">
      <button class="add-new-button">Print Report</button>
    </div> -->
  </section>
</div>

<?php include_once '../components/cashflow_footer.php'; ?>
<script>
  async function fetchStocksReport(search = '') {
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    const response = await fetch('../backend/inventory/report/fetch_stocks_report.php?' + params.toString());
    const result = await response.json();
    return result.success ? result.data : [];
  }

  function renderStocksTable(stocks) {
    const tbody = document.querySelector('.stock-level-table');
    tbody.innerHTML = '';
    if (stocks.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">No records found</td></tr>';
      return;
    }
    stocks.forEach(stock => {
      tbody.innerHTML += `
      <tr>
        <td>${stock.item}</td>
        <td>${stock.stock_id}</td>
        <td>${stock.qty}</td>
        <td>${stock.reorder_trigger ?? ''}</td>
        <td>${stock.last_ordered_date ?? ''}</td>
        <td>${stock.action_required ?? ''}</td>
      </tr>
    `;
    });
  }

  async function handleStockFilter() {
    const search = document.getElementById('filter_name').value.trim();
    const stocks = await fetchStocksReport(search);
    renderStocksTable(stocks);
  }

  document.addEventListener('DOMContentLoaded', () => {
    // Initial load
    handleStockFilter();

    // Filter on input
    document.getElementById('filter_name').addEventListener('input', () => {
      handleStockFilter();
    });
  });
</script>