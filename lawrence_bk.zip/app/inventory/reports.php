<?php include_once '../components/header.php'; ?>
<!-- Main content -->
<div class="main">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content">
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Inventory Management</span>
        <span class="divider"></span>
        <span class="tab active">Reports</span>
      </div>

    </div>

    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Supplier Performance Report</h3>
          <button
            class="add-new-button"
            onclick="location.href='./supplier_performance_report'">
            View Report
          </button>
        </div>
      </div>
    </div>




    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Stock Level Report</h3>
          <button
            onclick="location.href='./stock_level_report'"
            class="add-new-button">
            View Report
          </button>
        </div>
      </div>
    </div>
    <!-- 
    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Order and Reorder Report</h3>
          <button
            onclick="location.href='./order_and_reorder_report'"
            class="add-new-button">
            View Report
          </button>
        </div>
      </div>
    </div> -->
    <div class="box1" style="margin-bottom: 0">
      <div class="box2" style="height: 67px; display: inline">
        <div class="tabs">
          <h3>Returns and Refunds Report</h3>
          <button
            onclick="location.href='./returns_and_refunds_report'"
            class="add-new-button">
            View Report
          </button>
        </div>
      </div>
    </div>

















</div>
</section>
</div>

<?php include_once '../components/cashflow_footer.php'; ?>