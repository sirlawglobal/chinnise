<?php include_once '../components/header.php'; ?>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content" style="overflow: hidden">
    <!-- Tabs for Clients and Leads -->
    <div class="tabs" style="margin-bottom: 5px">
      <div style="align-items: center; display: flex">
        <span class="tab">Inventory</span>
        <span class="divider"></span>
        <span class="tab active">Returns and Refunds Report</span>
      </div>
      <div style="margin-bottom: 5px; margin-top: 0px; text-align: right">
        <div class="filters" style="display: inline-flex; gap: 10px">
          <input type="text" name="filter_name" id="filter_name" value="" placeholder="Enter Product name OR Order ID">

          <select
            id="filter-status"
            style="padding: 10px; width: 180px; font-size: 14px">
            <option>Filter by Status</option>
            <option value="Pending">Pending</option>
            <option value="Completed">Completed</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>
      </div>


    </div>

    <!-- Table for Leads -->
    <div class="over-table">
      <table class="leads-table">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Customer Name</th>
            <th>Product</th>
            <th>Return Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody class="returns-table-report">
          <!-- Data will be populated here via JavaScript -->
          <tr>
            <td colspan="5" style="text-align: center;">Loading returns data...</td>
          </tr>


        </tbody>
      </table>
    </div>
    <!-- <div class="tabs">
      <button class="add-new-button">Print Report</button>
    </div> -->
  </section>
</div>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('filter_name');
    const statusFilter = document.getElementById('filter-status');
    const tableBody = document.querySelector('.returns-table-report');

    // Function to fetch and display returns data
    function fetchReturns() {
      const searchValue = searchInput.value.trim();
      const statusValue = statusFilter.value;

      const url = `../backend/inventory/report/fetch_returns_report.php?search=${encodeURIComponent(searchValue)}&status=${encodeURIComponent(statusValue)}`;

      fetch(url)
        .then(response => response.json())
        .then(result => {
          if (result.success) {
            // Clear existing table rows
            tableBody.innerHTML = '';

            if (result.data.length > 0) {
              // Populate table with new data
              result.data.forEach(item => {
                const awardDate = new Date(item.received_date);

                    // Get day, month, and year
                    const day = String(awardDate.getDate()).padStart(2, '0');
                    const month = String(awardDate.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
                    const year = awardDate.getFullYear();

                    // Format as dd-mm-yyyy
                    const formattedDate = `${day}-${month}-${year}`;
                const row = `
                 <tr>
                 <td>${item.order_id || 'N/A'}</td>
                 <td>${item.customer_name || 'N/A'}</td>
                 <td>${item.item_name || 'N/A'}</td>
                 <td>${formattedDate || 'N/A'}</td>
                 <td><span class="status-${item.status ? item.status.toLowerCase() : ''}">${item.status || 'N/A'}</span></td>
                </tr>`;
                tableBody.innerHTML += row;
              });
            } else {
              // Display a message if no data is found
              tableBody.innerHTML = '<tr><td colspan="5" style="text-align: center;">No matching returns found.</td></tr>';
            }
          } else {
            // Display an error message if the fetch fails
            tableBody.innerHTML = `<tr><td colspan="5" style="text-align: center;">Error: ${result.message}</td></tr>`;
          }
        })
        .catch(error => {
          // Handle network errors
          console.error('Fetch error:', error);
          tableBody.innerHTML = '<tr><td colspan="5" style="text-align: center;">Failed to load data. Please check your connection.</td></tr>';
        });
    }

    // --- Event Listeners ---
    // Use 'input' for real-time searching as the user types
    searchInput.addEventListener('input', fetchReturns);
    statusFilter.addEventListener('change', fetchReturns);

    // Initial data load when the page is ready
    fetchReturns();
  });
</script>


<?php include_once '../components/cashflow_footer.php'; ?>