<?php include_once '../components/header.php'; ?>
<link rel="stylesheet" href="../input.css" />
<style>
  .input-group label {
    margin-bottom: 4px;
    font-weight: 600;
    font-size: 0.9em;
    color: #333;
  }
</style>

<div class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con">Add Order List</h2>
    <form id="orderForm">
      <div class="row">
        <div class="col">
          <label>Order Date</label>
          <input type="date" name="order_date" required />
        </div>
        <div class="col">
          <label>Select Suppliers</label>
          <select name="client_name" class="supplier-select" required>
            <option value="">Select Supplier</option>
          </select>
        </div>
      </div>

      <h3>Items Ordered</h3>
      <div id="items-container">
        <!-- Item rows will be inserted here -->
      </div>

      <div class="button-container">
        <button
          type="button"
          class="add-btn large-btn"
          onclick="addItemRow()">
          Add Item
        </button>
      </div>
      <hr style="margin: 20px" />
      <div class="row">
        <div class="col">
          <label>Total Order Value</label>
          <input type="text" name="total_amount" id="total-order-value" readonly />
        </div>
        <div class="col">
          <label>Delivery Date</label>
          <input type="date" name="delivery_date" />
        </div>

        <div class="col">
          <label>Order Status</label>
          <select name="order_completed" id="order-completed">
            <option value="Pending">Pending</option>
            <option value="Completed">Completed</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>
      </div>

      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Save</button>
      </div>
    </form>
  </div>
</div>

<div class="modal1">
  <div class="modal-content">
    <span class="close1">&times;</span>
    <h2 class="con">View Supplier</h2>
    <table
      style="margin-bottom: 20px"
      cellpadding="8"
      cellspacing="0"
      class="leads-table">
      <thead>
        <tr>
          <th>Ref No</th>
          <th>Order Date</th>
          <th>Supplier Name</th>
          <th>Delivery Date</th>
          <th>Order Status</th>
        </tr>
      </thead>

      <tbody>

      </tbody>
    </table>
    <hr style="margin-bottom: 20px" />

    <table class="leads-table">
      <thead>
        <tr>
          <th
            style="background-color: #fff; font-weight: bolder; color: #000">
            Items
          </th>
        </tr>
        <tr>
          <th>Item</th>
          <th>Quantity</th>
          <th>Unit Price</th>
          <th>Total Price</th>
        </tr>
      </thead>

      <tbody>

      </tbody>
    </table>
  </div>
</div>

<div class="modal2" id="edit">
  <div class="modal-content">
    <span class="close2">&times;</span>
    <h2 class="con">Edit Order List</h2>
    <form id="edit-orderForm">
      <div class="row">
        <div class="col">
          <label>Order Date</label>
          <input type="date" name="order_date" required />
        </div>
        <div class="col">
          <label>Select Suppliers</label>
          <select name="client_name" class="supplier-select" required>
            <option value="">Select Supplier</option>
          </select>
        </div>
      </div>

      <h3>Items Ordered</h3>
      <div id="edit-items-container">
        <!-- Item rows will be inserted here -->

      </div>
      <div class="button-container">
        <button
          type="button"
          class="add-btn large-btn"
          onclick="addItemRow('edit-items-container')">
          Add Item
        </button>
      </div>
      <hr style="margin: 20px" />
      <div class="row">
        <div class="col">
          <label>Total Order Value</label>
          <input type="text" id="edit-total-order-value" name="total_amount" readonly />
        </div>
        <div class="col">
          <label>Delivery Date</label>
          <input type="date" name="delivery_date" />
        </div>

        <div class="col">
          <label>Order Status</label>
          <select name="order_completed">
            <option value="Pending">Pending</option>
            <option value="Completed">Completed</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>
      </div>

      <div class="button-container">
        <button type="submit" class="save-btn large-btn">Update</button>
      </div>
    </form>
  </div>
</div>
<!-- Main content -->
<div class="main" style="overflow: hidden">
  <?php include_once '../components/common_header.php'; ?>
  <!-- Your page content goes here -->
  <section class="content" style="overflow: hidden">
    <!-- Tabs for Clients and Leads -->
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab">Inventory</span>
        <span class="divider"></span>
        <span class="tab active"> Suppliers Orders</span>
      </div>

      <button class="add-new-button">Add New</button>
    </div>

    <!-- Table for Leads -->
    <div style="overflow: auto; padding: 0.7rem; height: 95%">
      <table cellpadding="8" cellspacing="0">
        <colgroup>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>Invoice No</th>
            <th>Order Date</th>
            <th>Supplier Name</th>
            <th>Total Order Value</th>
            <th>Delivery Date</th>
            <th>Order Status</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody class="fetch-suppliers-orders">

        </tbody>
      </table>
    </div>
  </section>
</div>
<script src="../assets/supplier-order.js"></script>
<style>
     colgroup col:nth-child(1) {
    width: 100px;
  }
   colgroup col:nth-child(2) {
    width: 100px;
  }
   colgroup col:nth-child(9) {
    width: 60px;
  }
</style>
<?php include_once '../components/cashflow_footer.php'; ?>