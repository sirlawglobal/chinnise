// 1. Project Data - Now an array of properly structured objects
let projectData = {};
let employeesList = [];

// 2. Get DOM elements
const navTabs = document.querySelectorAll(".nav-tab");
const projectListTitle = document.querySelector(".project-list-title");
const responseMessageToast = document.getElementById("response-message-toast");
const projectTableContainer = document.getElementById("projectTableContainer");
const confirmationModal = document.getElementById("confirmationModal");
const confirmDeleteBtn = document.getElementById("confirmDeleteBtn");
const cancelDeleteBtn = document.getElementById("cancelDeleteBtn");

// Function to show the modal
function showConfirmationModal(itemId, dataSourceKey, categoryKey = null) {
  // Store information about the item to be deleted on the confirm button
  confirmDeleteBtn.dataset.itemId = itemId;
  confirmDeleteBtn.dataset.sourceKey = dataSourceKey; // e.g., 'ongoing', 'pending', 'completed'
  confirmDeleteBtn.dataset.categoryKey = categoryKey; // Only relevant for tasks, will be null for projects

  confirmationModal.classList.add("visible");
}

async function fetchEmployees() {
  try {
    fetch('../backend/project-management/fetch_employees.php')
      .then(response => response.json())
      .then(res => {
        // Assuming data is an array of employee objects
        const assigneeSelect = document.querySelector('.assignees');
        const supervisorSelect = document.querySelector('.supervisor');
        // assigneeSelect.innerHTML = '<option value="">Select Assignee </option>';
        supervisorSelect.innerHTML = '<option value="">Select Supervisor</option>';

        if (res.success) {
          employeesList = res.data;
          res.data.forEach(employee => {
            const option = document.createElement('option');
            option.value = employee.id; // Assuming each employee has a unique ID
            option.textContent = `${employee.employee_name}(${employee.email || employee.phone})`; // Display full name

            assigneeSelect.appendChild(option);

            supervisorSelect.appendChild(option.cloneNode(true));

          });
        }
        else {

          assigneeSelect.innerHTML = '<option value="">Error loading employees</option>';
          supervisorSelect.innerHTML = '<option value="">Error loading supervisors</option>';
          responseMessageToast.style.color = 'red'
          responseMessageToast.innerHTML = `Could not load employees`;
          responseMessageToast.classList.add("show");
          setTimeout(() => {
            responseMessageToast.classList.remove("show");
          }, 3000);
        }

      });
  } catch (error) {
    console.error("Error fetching employees:", error);
    responseMessageToast.style.color = 'red'
    responseMessageToast.innerHTML = `Could not load employees: ${error}`;
    responseMessageToast.classList.add("show");
    setTimeout(() => {
      responseMessageToast.classList.remove("show");
    }, 3000);
  }
}

async function fetchProjects() {
  try {
    await fetch('../backend/project-management/fetch_projects.php',)
      .then(response => response.json())
      .then(res => {
        projectData = res.data;
      });
  } catch (error) {
    responseMessageToast.style.color = 'red'
    responseMessageToast.innerHTML = `Could not load projects`;
    responseMessageToast.classList.add("show");
    setTimeout(() => {
      responseMessageToast.classList.remove("show");
    }, 3000);
    console.error("Error fetching projects:", error);
  }
}
document.querySelector('.modal form').addEventListener('submit', async function (e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);
  modal.style.display = 'none';
  fetch('../backend/project-management/add_projects.php', {
    method: 'POST',
    body: formData,
  })
    .then(response => response.json())
    .then(res => {
      if (res.success) {
        responseMessageToast.style.color = 'green'
        responseMessageToast.innerHTML = `Project Added Successfully!`;
        responseMessageToast.classList.add("show");
        setTimeout(() => {
          responseMessageToast.classList.remove("show");
        }, 3000);

        form.reset();
        $('.need-select').val(null).trigger('change');
        activateTab(formData.get('status').toLowerCase());

      } else {
        responseMessageToast.style.color = 'red'
        responseMessageToast.innerHTML = `Could not Add projects:  ${error}`;
        responseMessageToast.classList.add("show");

        setTimeout(() => {
          responseMessageToast.classList.remove("show");
        }, 3000);
        modal.style.display = 'block';
        console.error("Error updating project data:", res.message);
      }
    })

})
document.querySelector('.modal2 form').addEventListener('submit', async function (e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);
  modal2.style.display = 'none';
  fetch('../backend/project-management/edit_projects.php', {
    method: 'POST',
    body: formData,
  })
    .then(response => response.json())
    .then(res => {
      if (res.success) {
        responseMessageToast.style.color = 'green'
        responseMessageToast.innerHTML = `Project Updated Successfully!`;
        responseMessageToast.classList.add("show");
        setTimeout(() => {
          responseMessageToast.classList.remove("show");
        }, 3000);

        console.log("Project data updated successfully:", res.data, formData.get('status'));

        activateTab(formData.get('status').toLowerCase());
        form.reset();


      } else {
        responseMessageToast.style.color = 'red'
        responseMessageToast.innerHTML = `Could not Update projects`;
        responseMessageToast.classList.add("show");
        console.error(res.error)

        setTimeout(() => {
          responseMessageToast.classList.remove("show");
        }, 3000);
        modal2.style.display = 'block';
      }
    })

})

function hideConfirmationModal() {
  confirmationModal.classList.remove("visible");
  // Clear the stored data on the button
  confirmDeleteBtn.dataset.itemId = "";
  confirmDeleteBtn.dataset.sourceKey = "";
  confirmDeleteBtn.dataset.categoryKey = "";
}


projectTableContainer.addEventListener("click", (event) => {
  // Check if the clicked element or its parent is the delete icon
  const deleteIcon = event.target.closest(".fa-trash-alt");
  const viewIcon = event.target.closest(".view-icon");
  const editIcon = event.target.closest(".edit-icon");

  if (deleteIcon) {
    const rowElement = deleteIcon.closest("tr");
    if (rowElement) {

      const projectId = rowElement.dataset.projectId;

      const activeTab = document.querySelector(".nav-tab.active");
      const dataSourceKey = activeTab.dataset.tab;

      if (projectId && dataSourceKey) {
        showConfirmationModal(projectId, dataSourceKey);
      }
    }
  } else if (viewIcon) {
    const rowElement = viewIcon.closest("tr");
    if (rowElement) {
      // Get the ID of the project from the row's data
      const projectId = rowElement.dataset.projectId;
      const activeTab = document.querySelector(".nav-tab.active");
      const dataSourceKey = activeTab.dataset.tab;

      let project = projectData[dataSourceKey].rows.find(p => p.id == projectId);
      const form = modal1.querySelector('form');
      form.elements['name'].value = project.name || '';
      form.elements['start_date'].value = project.start_date || '';
      form.elements['due_date'].value = project.due_date || '';
      form.elements['supervisor'].innerHTML = `<option selected >${project.supervisor_name}</option>` || '';
      form.elements['status'].value = project.status || dataSourceKey;
      const assigneesSelect = form.elements['assignees[]'];
      assigneesSelect.innerHTML = '';
      project.assignees.forEach(assignee => {
        const option = document.createElement('option');
        option.value = assignee.user_id;
        option.textContent = assignee.name;
        option.selected = true; // If you want them pre-selected
        assigneesSelect.appendChild(option);
      })
      modal1.style.display = "block";

      console.log("View project details for ID:", projectId);

    }
  }
  else if (editIcon) {
    const rowElement = editIcon.closest("tr");
    if (rowElement) {
      // Get the ID of the project from the row's data
      const projectId = rowElement.dataset.projectId;
      const activeTab = document.querySelector(".nav-tab.active");
      const dataSourceKey = activeTab.dataset.tab;

      let project = projectData[dataSourceKey].rows.find(p => p.id == projectId);
      populateProjectModal(project);
    }
  }

});

function populateProjectModal(project) {

  const form = modal2.querySelector('form');

  // Fill text and date inputs
  form.elements['project_id'].value = project.id || '';
  form.elements['name'].value = project.name || '';
  form.elements['start_date'].value = project.start_date || '';
  form.elements['due_date'].value = project.due_date || '';

  // Populate supervisor select
  const supervisorSelect = form.elements['supervisor'];
  supervisorSelect.innerHTML = '';
  employeesList.forEach(sup => {
    const opt = document.createElement('option');
    opt.value = sup.id;
    opt.textContent = sup.employee_name;
    if (sup.id == project.supervisor_id) opt.selected = true;
    supervisorSelect.appendChild(opt);
  });

  // Set status
  form.elements['status'].value = project.status || 'Pending';

  // Populate assignees select
  const assigneesSelect = form.elements['assignees[]'];
  assigneesSelect.innerHTML = '';

  employeesList.forEach(emp => {
    const opt = document.createElement('option');
    opt.value = emp.id;
    opt.textContent = emp.employee_name;
    if (project.assignees && project.assignees.some(a => a.user_id == emp.id)) {
      opt.selected = true;
    }
    assigneesSelect.appendChild(opt);
  });

  // Show the modal
  modal2.style.display = 'block';
}


confirmDeleteBtn.addEventListener("click", () => {
  const itemId = confirmDeleteBtn.dataset.itemId;
  const dataSourceKey = confirmDeleteBtn.dataset.sourceKey;
  console.log("Deleting item with ID:", itemId, "from data source:", dataSourceKey);
  const formData = new FormData();
  formData.append("id", itemId);
  if (itemId && dataSourceKey) {
    fetch(`../backend/project-management/delete_projects.php`, {
      method: 'POST',
      body: formData
    }).then(response => response.json())
      .then(res => {
        if (res.success) {
          responseMessageToast.style.color = 'green'
          responseMessageToast.innerHTML = `Project Deleted Successfully!`;
          responseMessageToast.classList.add("show");
          setTimeout(() => {
            responseMessageToast.classList.remove("show");
          }, 3000);

          renderTable(dataSourceKey);
          console.log("Project deleted successfully:", res.data);
        } else {
          responseMessageToast.style.color = 'red'
          responseMessageToast.innerHTML = `Error deleting project!`;
          responseMessageToast.classList.add("show");
          setTimeout(() => {
            responseMessageToast.classList.remove("show");
          }, 3000);
          console.error("Error deleting project:", res.message);
        }
      })
  }
  hideConfirmationModal(); // Always hide modal after action
});

cancelDeleteBtn.addEventListener("click", () => {
  hideConfirmationModal(); // Just hide the modal
});

// 3. Function to render the table
async function renderTable(dataKey) {
  await fetchProjects()
  console.log("Rendering table for data key:", dataKey);

  const data = projectData[dataKey];

  console.log("Data for rendering:", data);
  if (!data || !data.rows) {
    projectTableContainer.innerHTML =
      "<p>No data available for this category.</p>";
    projectListTitle.textContent = "Projects"; // Default title if no data
    return;
  }
  document.querySelector('.ongo').textContent = `Ongoing (${projectData.ongoing.count})`;
  document.querySelector('.pend').textContent = `Pending (${projectData.pending.count})`;
  document.querySelector('.comp').textContent = `Completed (${projectData.completed.count})`;
  // Update the main title, using the count from the data object
  projectListTitle.textContent = `${data.label} (${data.count})`;

  // Define table headers
  const headers = [
    "Project Title",
    "Supervised by",
    "Assigned to",
    "Start Date",
    "Due Date",
    // "Status",
    "View",
    "Edit",
    "Delete",
    "View Tasks", // 'View Tasks' header is here
  ];

  // Create the table structure with dynamic headers
  let tableHTML = `
        <table>
            <thead>
                <tr>
                    ${headers
      .map(
        (header) =>
          `<th${header === "View" ||
            header === "Edit" ||
            header === "Delete"
            ? ' class="table-icon-col"'
            : header === "View Tasks"
              ? ' class="table-action-col"'
              : ""
          }>${header}</th>`
      )
      .join("")}
                </tr>
            </thead>
            <tbody>
    `;

  // Loop through each row object and build the table row
  data.rows.forEach((row) => {
    // Construct the URL for the tasks page, encoding the project title
    const tasksPageUrl = `tasks?project=${encodeURIComponent(row.name)}&project_id=${row.id}`;
{/* <td>${row.status || "N/A"}</td> */}
    tableHTML += `
      <tr data-project-id="${row.id}">
          <td>${row.name || "N/A"}</td>
          <td>${row.supervisor_name || "N/A"}</td>
          <td>${row.assignees[0].name || "N/A"}
          <td>${row.start_date || "N/A"}</td>
          <td>${row.due_date || "N/A"}</td>
          
          <td class=""><i class="fas fa-eye view-icon"></i></td>
          <td class=""><i class="fas fa-pencil-alt edit-icon"></i></td>
          <td class=""><i class="fas fa-trash-alt"></i></td>
          <td class="table-action-col"><a href="${tasksPageUrl}" class="tasks-link">View Tasks</a></td>
      </tr>
        `;
  });

  tableHTML += `
            </tbody>
        </table>
    `;

  projectTableContainer.innerHTML = tableHTML;
}

// Function to handle tab activation and URL update
function activateTab(tabKey) {
  // Remove 'active' class from all tabs
  navTabs.forEach((t) => t.classList.remove("active"));

  // Add 'active' class to the target tab
  const targetTab = document.querySelector(`.nav-tab[data-tab="${tabKey}"]`);
  if (targetTab) {
    targetTab.classList.add("active"); // Always activate the clicked tab

    if (tabKey === "reports") {
      // If it's the reports tab, don't render the table
      projectTableContainer.innerHTML = `<p>Reports content will be implemented here later.</p>`;
      projectListTitle.textContent = projectData.reports.label; // Update title
      // You might add specific reports rendering logic here
    } else {
      // For other tabs (pending, completed, ongoing), render the table
      renderTable(tabKey);
    }
  } else {
    console.warn(
      `Tab with key '${tabKey}' not found. Defaulting to 'ongoing'.`
    );
    const defaultTab = "ongoing";
    document
      .querySelector(`.nav-tab[data-tab="${defaultTab}"]`)
      .classList.add("active");
    renderTable("ongoing");
    history.replaceState(null, "", `?tab=${defaultTab}`);
  }
}

// 4. Add event listeners to navigation tabs
navTabs.forEach((tab) => {
  tab.addEventListener("click", (event) => {
    event.preventDefault();
    const dataKey = tab.dataset.tab; // Get the data-tab attribute value
    history.pushState({ tab: dataKey }, "", `?tab=${dataKey}`);

    activateTab(dataKey);
  });
});

window.addEventListener("popstate", (event) => {
  const params = new URLSearchParams(window.location.search);
  const tabFromUrl = params.get("tab");
  if (tabFromUrl) {
    activateTab(tabFromUrl);
  } else {
    activateTab("ongoing");
  }
});

// 5. Initial render when the page loads
document.addEventListener("DOMContentLoaded", () => {
  // Fetch employees for dropdowns

  const params = new URLSearchParams(window.location.search);
  const tabFromUrl = params.get("tab");

  if (tabFromUrl) {
    // If there's a 'tab' query in the URL, activate that tab
    activateTab(tabFromUrl);
  } else {
    // Otherwise, default to 'ongoing' and update the URL
    const defaultTab = "ongoing";
    activateTab(defaultTab);
    // Add the default tab to the URL without creating a new history entry
    history.replaceState(null, "", `?tab=${defaultTab}`);
  }
  fetchEmployees();
});
