const responseMessageToast = document.getElementById("response-message-toast");


let projectList = [];

let budgetData = [];

let currentBudgetTableData = [];

async function fetchBudget() {
    try {
        await fetch('../backend/project-management/fetch_budgets.php',)
            .then(response => response.json())
            .then(res => {

                budgetData = res.data;
                currentBudgetTableData = [...budgetData]
                // console.log(budgetData)
            });
    } catch (error) {
        responseMessageToast.style.color = 'red'
        responseMessageToast.innerHTML = `Could not load projects`;
        responseMessageToast.classList.add("show");
        setTimeout(() => {
            responseMessageToast.classList.remove("show");
        }, 3000);
        console.error("Error fetching projects:", error);
    }
}

// document.addEventListener("DOMContentLoaded", async () => { await fetchBudget() })
document.addEventListener("DOMContentLoaded", async () => {



    // Sample Data for Budget Table

    async function fetchIndex() {
        try {
            await fetch('../backend/project-management/fetch_all_budgets.php')
                .then(response => response.json())
                .then(res => {
                    // Assuming data is an array of employee objects


                    if (res.success) {
                        const indirect = Number(res.data.indirect || 0);
                        const direct = Number(res.data.direct || 0);
                        const total = indirect + direct;

                        // Optional formatting


                        document.getElementById('total').textContent = '₦' + total.toLocaleString()
                        document.getElementById('indirect').textContent = '₦' + indirect.toLocaleString()
                        document.getElementById('direct').textContent = '₦' + direct.toLocaleString()
                    }
                    else {

                        responseMessageToast.style.color = 'red'
                        responseMessageToast.innerHTML = res.error;
                        responseMessageToast.classList.add("show");
                        setTimeout(() => {
                            responseMessageToast.classList.remove("show");
                        }, 3000);
                    }

                });
        } catch (error) {
            console.error("Error fetching Budget count:", error);
            responseMessageToast.style.color = 'red'
            responseMessageToast.innerHTML = `Could not load Budget count: ${error}`;
            responseMessageToast.classList.add("show");
            setTimeout(() => {
                responseMessageToast.classList.remove("show");
            }, 3000);
        }
    }
    async function fetchProjects() {
        try {
            await fetch('../backend/project-management/fetch_all_projects.php')
                .then(response => response.json())
                .then(res => {
                    // Assuming data is an array of employee objects
                    const projectSelect = document.querySelectorAll('.project_loads');

                    if (res.success) {
                        projectList = res.data;
                        projectSelect.forEach((select => {


                            res.data.forEach(project => {
                                const option = document.createElement('option');
                                option.value = project.id; // Assuming each project has a unique ID
                                option.textContent = `${project.name} (${'PRO' + project.id})`; // Display full name

                                select.appendChild(option);

                            });
                        }));
                    }
                    else {

                        assigneeSelect.innerHTML = '<option value="">Error loading employees</option>';
                        supervisorSelect.innerHTML = '<option value="">Error loading supervisors</option>';
                        responseMessageToast.style.color = 'red'
                        responseMessageToast.innerHTML = `Could not load employees`;
                        responseMessageToast.classList.add("show");
                        setTimeout(() => {
                            responseMessageToast.classList.remove("show");
                        }, 3000);
                    }

                });
        } catch (error) {
            console.error("Error fetching employees:", error);
            responseMessageToast.style.color = 'red'
            responseMessageToast.innerHTML = `Could not load employees: ${error}`;
            responseMessageToast.classList.add("show");
            setTimeout(() => {
                responseMessageToast.classList.remove("show");
            }, 3000);
        }
    }
    fetchProjects()

    let sortColumn = "id";
    let sortDirection = "asc";

    const budgetTableBody = document.getElementById("budgetTableBody");
    const projectFilter = document.getElementById("projectFilter");
    const typeFilter = document.getElementById("typeFilter");
    const sortableHeaders = document.querySelectorAll("#budgetTable .sortable");

    async function renderBudgetTable(dataToRender) {
        await fetchIndex()
        await fetchBudget()

        if (typeof dataToRender == 'string' && dataToRender == 'first') {
            dataToRender = currentBudgetTableData;
            populateProjectFilter();
        }
        // console.log(dataToRender, budgetData, currentBudgetTableData)
        budgetTableBody.innerHTML = ""; // Clear existing rows

        if (dataToRender.length === 0) {
            budgetTableBody.innerHTML =
                '<tr><td colspan="7" style="text-align: center; padding: 20px;">No matching budget items found.</td></tr>';
            return;
        }

        dataToRender.forEach((item) => {
            const row = document.createElement("tr");
            const amount = Number(item.amount)
            row.innerHTML = `
        <td>${item.id}</td>
        <td>${item.project}</td>
        <td>${item.cost_item}</td>
        <td>${item.cost_type}</td>
        <td class="amount-cell">&#8358;${amount.toLocaleString()}</td>
        <td>${item.created_at}</td>
        <td>${item.added_by}</td>
        <td class="actions-cell">
          <i class="edit-icon fas fa-pencil-alt"></i>
          <i class="fas fa-trash-alt"></i>
        </td>
      `;
            budgetTableBody.appendChild(row);
        });
    }

    function filterBudgetTable() {
        const selectedProject = projectFilter.value;
        const selectedType = typeFilter.value;

        let filteredData = budgetData.filter((item) => {
            const projectMatch =
                selectedProject === "All" || item.project === selectedProject;
            const typeMatch =
                selectedType === "All" || item.cost_type === selectedType;
            return projectMatch && typeMatch;
        });

        currentBudgetTableData = filteredData; // Update the data to be sorted
        sortBudgetTable(); // Re-sort after filtering
    }

    function sortBudgetTable() {
        if (!sortColumn) {
            renderBudgetTable(currentBudgetTableData);
            return;
        }

        const sortedData = [...currentBudgetTableData].sort((a, b) => {
            let valA = Number(a[sortColumn].replace('B', ''));
            let valB = Number(b[sortColumn].replace('B', ''));

            // Handle numeric sort for 'amount'
            if (sortColumn === "amount") {
                valA = parseFloat(valA);
                valB = parseFloat(valB);
            }
            // Handle date sort for 'dateAdded' (basic string comparison for now, full date parsing for robust solution)
            if (sortColumn === "created_at") {
                valA = new Date(valA);
                valB = new Date(valB);
            }

            if (valA < valB) {
                return sortDirection === "asc" ? -1 : 1;
            }
            if (valA > valB) {
                return sortDirection === "asc" ? 1 : -1;
            }
            return 0;
        });
        console.log('Sorted Data' + sortedData)
        renderBudgetTable(sortedData);
    }

    function populateProjectFilter() {
        const projects = new Set(budgetData.map((item) => item.project));
        projectFilter.innerHTML = '<option value="All">All Projects</option>';
        projects.forEach((project) => {
            const option = document.createElement("option");
            option.value = project;
            option.textContent = project;
            projectFilter.appendChild(option);
        });
    }
    // Function to show the modal
    function showConfirmationModal(itemId) {
        const confirmationModal = document.getElementById("confirmationModal");
        const deleteButton = document.getElementById("confirmDeleteBtn");
        deleteButton.onclick = () => {
            const formData = new FormData();
            formData.append("id", itemId);
            fetch(`../backend/project-management/delete_budget.php`, {
                method: 'POST',
                body: formData
            }).then(response => response.json())
                .then(res => {
                    if (res.success) {
                        responseMessageToast.style.color = 'green'
                        responseMessageToast.innerHTML = res.message;
                        responseMessageToast.classList.add("show");
                        setTimeout(() => {
                            responseMessageToast.classList.remove("show");
                        }, 3000);

                        renderBudgetTable('first');
                        console.log("Budget deleted successfully:", res.message);
                    } else {
                        responseMessageToast.style.color = 'red'
                        responseMessageToast.innerHTML = res.error;
                        responseMessageToast.classList.add("show");
                        setTimeout(() => {
                            responseMessageToast.classList.remove("show");
                        }, 3000);
                        console.error("Error deleting budget:", res.error);
                    }
                })


            hideConfirmationModal();
        };
        const cancelButton = document.getElementById("cancelDeleteBtn");
        cancelButton.onclick = () => {
            hideConfirmationModal();
        };

        confirmationModal.classList.add("visible");
    }

    function hideConfirmationModal() {
        confirmationModal.classList.remove("visible");
    }

    projectFilter.addEventListener("change", filterBudgetTable);
    typeFilter.addEventListener("change", filterBudgetTable);

    sortableHeaders.forEach((header) => {
        header.addEventListener("click", () => {
            const column = header.dataset.sort;
            if (sortColumn === column) {
                sortDirection = sortDirection === "asc" ? "desc" : "asc";
            } else {
                sortColumn = column;
                sortDirection = "asc"; // Default to ascending for new column
            }

            sortableHeaders.forEach((h) => {
                const icon = h.querySelector(".fa-sort");
                if (icon) {
                    icon.classList.remove("fa-sort-up", "fa-sort-down");
                    icon.classList.add("fa-sort");
                }
            });
            const currentIcon = header.querySelector(".fa-sort");
            if (currentIcon) {
                currentIcon.classList.remove("fa-sort");
                currentIcon.classList.add(
                    sortDirection === "asc" ? "fa-sort-up" : "fa-sort-down"
                );
            }

            sortBudgetTable();
        });
    });

    document.querySelector('.modal form').addEventListener('submit', async function (e) {
        e.preventDefault();

        const form = e.target;
        const formData = new FormData(form);
        modal.style.display = 'none';
        try {
            const res = await fetch('../backend/project-management/add_budgets.php', {
                method: 'POST',
                body: formData
            });

            const result = await res.json();

            if (result.success) {
                form.reset();
                $('.need-select').val(null).trigger('change');

                responseMessageToast.style.color = 'green'
                responseMessageToast.innerHTML = result.message;
                responseMessageToast.classList.add("show");
                setTimeout(() => {
                    responseMessageToast.classList.remove("show");
                }, 3000);


                renderBudgetTable('first');
            } else {
                responseMessageToast.style.color = 'red'
                responseMessageToast.innerHTML = result.error || 'Failed to add budget';
                responseMessageToast.classList.add("show");
                setTimeout(() => {
                    responseMessageToast.classList.remove("show");
                }, 3000);
                modal2.style.display = 'block';
            }
        } catch (err) {
            console.error('Add Budget Error:', err);
            responseMessageToast.style.color = 'red'
            responseMessageToast.innerHTML = 'Unexpected error. Try again later.';
            responseMessageToast.classList.add("show");
            setTimeout(() => {
                responseMessageToast.classList.remove("show");
            }, 3000);
            modal.style.display = 'block';
        }
    });
    // document.querySelector('.modal2 form').addEventListener('submit', async function (e) {
    //     e.preventDefault();

    //     const form = e.target;
    //     const formData = new FormData(form);
    //     modal2.style.display = 'none';
    //     try {
    //         const res = await fetch('../backend/project-management/edit_budgets.php', {
    //             method: 'POST',
    //             body: formData
    //         });

    //         const result = await res.json();

    //         if (result.success) {
    //             form.reset();
    //             $('.need-select').val(null).trigger('change');

    //             responseMessageToast.style.color = 'green'
    //             responseMessageToast.innerHTML = result.message;
    //             responseMessageToast.classList.add("show");
    //             setTimeout(() => {
    //                 responseMessageToast.classList.remove("show");
    //             }, 3000);


    //             renderBudgetTable('first');
    //         } else {
    //             responseMessageToast.style.color = 'red'
    //             responseMessageToast.innerHTML = result.error || 'Failed to Update budget';
    //             responseMessageToast.classList.add("show");
    //             setTimeout(() => {
    //                 responseMessageToast.classList.remove("show");
    //             }, 3000);
    //             modal2.style.display = 'block';
    //         }
    //     } catch (err) {
    //         console.error('Update Budget Error:', err);
    //         responseMessageToast.style.color = 'red'
    //         responseMessageToast.innerHTML = 'Unexpected error. Try again later.';
    //         responseMessageToast.classList.add("show");
    //         setTimeout(() => {
    //             responseMessageToast.classList.remove("show");
    //         }, 3000);
    //         modal2.style.display = 'block';
    //     }
    // });
    // Initial render for Budget Management table

    renderBudgetTable('first');

    budgetTableBody.addEventListener("click", (event) => {
        // Check if the clicked element or its parent is the delete icon
        const deleteIcon = event.target.closest(".fa-trash-alt");
        const viewIcon = event.target.closest(".view-icon");
        const editIcon = event.target.closest(".edit-icon");
        if (deleteIcon) {
            const rowElement = deleteIcon.closest("tr");
            if (rowElement) {
                const itemId = rowElement.querySelector("td").textContent.trim();
                showConfirmationModal(itemId);
            }
        } else if (editIcon) {
            const rowElement = editIcon.closest("tr");
            if (rowElement) {
                // Get the ID of the project from the row's data
                const itemId = rowElement.querySelector("td").textContent.trim();

                let budget = budgetData.find(b => b.id == itemId);
                populateProjectModal(budget);
            }
        }
        // else if (viewIcon) {
        //   const rowElement = viewIcon.closest("tr");
        //   if (rowElement) {
        //     // Get the ID of the project from the row's data
        //     const projectId = rowElement.dataset.projectId;
        //     const activeTab = document.querySelector(".nav-tab.active");
        //     const dataSourceKey = activeTab.dataset.tab;

        //     let project = projectData[dataSourceKey].rows.find(p => p.id == projectId);
        //     const form = modal1.querySelector('form');
        //     form.elements['name'].value = project.name || '';
        //     form.elements['start_date'].value = project.start_date || '';
        //     form.elements['due_date'].value = project.due_date || '';
        //     form.elements['supervisor'].innerHTML = `<option value="">${project.supervisor_name}</option>` || '';
        //     form.elements['status'].value = project.status || dataSourceKey;
        //     const assigneesSelect = form.elements['assignees[]'];
        //     assigneesSelect.innerHTML = '';
        //     project.assignees.forEach(assignee => {
        //       const option = document.createElement('option');
        //       option.value = assignee.user_id;
        //       option.textContent = assignee.name;
        //       option.selected = true; // If you want them pre-selected
        //       assigneesSelect.appendChild(option);
        //     })
        //     modal1.style.display = "block";

        //     console.log("View project details for ID:", projectId);

        //   }
        // }
    });

    function populateProjectModal(budget) {

        const form = modal2.querySelector('form');
        form.elements['id'].value = budget.id || '';
        form.elements['cost_type'].value = budget.cost_type || '';
        form.elements['cost_item'].value = budget.cost_item || '';
        form.elements['amount'].value = budget.amount || '';
        form.elements['description'].value = budget.description || '';

        // Populate assignees select


        const select = form.elements['project_id'];
        select.innerHTML = '';
        projectList.forEach(project => {
            const option = document.createElement('option');
            option.value = project.id;
            option.textContent = project.name;
            if (project.name == budget.project) {
                option.selected = true;
            }
            // If you want them pre-selected
            select.appendChild(option);
        })
        // Show the modal
        modal2.style.display = 'block';
    }
});


