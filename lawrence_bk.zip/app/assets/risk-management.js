// Ensure you have an element with id="response-message-toast" and a variable `modal` referring to the Add Issue Modal
const responseMessageToast = document.getElementById("response-message-toast");
async function fetchProjects() {
    try {
        await fetch('../backend/project-management/fetch_all_projects.php')
            .then(response => response.json())
            .then(res => {
                // Assuming data is an array of employee objects
                const projectSelect = document.querySelectorAll('.project_loads');

                if (res.success) {
                    projectList = res.data;
                    projectSelect.forEach((select => {


                        res.data.forEach(project => {
                            const option = document.createElement('option');
                            option.value = project.id; // Assuming each project has a unique ID
                            option.textContent = `${project.name} (${'PRO' + project.id})`; // Display full name

                            select.appendChild(option);

                        });
                    }));
                }
                else {

                    assigneeSelect.innerHTML = '<option value="">Error loading employees</option>';
                    supervisorSelect.innerHTML = '<option value="">Error loading supervisors</option>';
                    responseMessageToast.style.color = 'red'
                    responseMessageToast.innerHTML = `Could not load employees`;
                    responseMessageToast.classList.add("show");
                    setTimeout(() => {
                        responseMessageToast.classList.remove("show");
                    }, 3000);
                }

            });
    } catch (error) {
        console.error("Error fetching employees:", error);
        responseMessageToast.style.color = 'red'
        responseMessageToast.innerHTML = `Could not load employees: ${error}`;
        responseMessageToast.classList.add("show");
        setTimeout(() => {
            responseMessageToast.classList.remove("show");
        }, 3000);
    }
}
document.addEventListener("DOMContentLoaded", async () => {
    await fetchProjects()
    await fetchIssues();
})



const issueTableBody = document.getElementById("issueTableBody");
const projectFilter = document.getElementById("projectFilter");
const typeFilter = document.getElementById("typeFilter");
const sortableHeaders = document.querySelectorAll("#issueTable .sortable");

let projectList = [];
let issueData = [];
let issueSummary = {
    all: { open: 0, closed: 0, critical: 0 },
    byProject: {} // Will be populated like { projectId: { open: x, closed: y, critical: z }, ... }
};



let currentIssueTableData = [];
let sortColumn = "id";
let sortDirection = "asc";

async function fetchIssues() {
    try {
        const res = await fetch('../backend/project-management/fetch_issues.php');
        const json = await res.json();

        if (json.success) {
            issueData = json.data;
            issueSummary = {
                all: { open: 0, closed: 0, critical: 0 },
                byProject: {}
            };

            issueData.forEach(issue => {
                const status = issue.issue_status.toLowerCase();
                const projectId = issue.project_id;

                // All projects totals
                if (issueSummary.all[status] !== undefined) {
                    issueSummary.all[status]++;
                }

                // Individual projects
                if (!issueSummary.byProject[projectId]) {
                    issueSummary.byProject[projectId] = { open: 0, closed: 0, critical: 0 };
                }
                if (issueSummary.byProject[projectId][status] !== undefined) {
                    issueSummary.byProject[projectId][status]++;
                }
            });
            currentIssueTableData = [...issueData];
            renderIssueTable(currentIssueTableData);
            populateProjectFilter();
        } else {
            showToast('red', json.error || 'Failed to load issues');
        }
    } catch (err) {
        console.error('Error fetching issues:', err);
        showToast('red', 'Unexpected error loading issues');
    }
}
function getIssueCountsForProject(projectId) {
    if (projectId === "All") {
        return issueSummary.all;
    } else {
        return issueSummary.byProject[projectId] || { open: 0, closed: 0, critical: 0 };
    }
}
function displayIssueCounts() {
    const selectedProject = projectFilter.value;
    const counts = getIssueCountsForProject(selectedProject);

    const total = document.querySelector('.total');
    const open = document.querySelector('.open');
    const closed = document.querySelector('.closed');
    const critical = document.querySelector('.critical');
    total.textContent = counts.open + counts.closed + counts.critical
    open.textContent = counts.open;
    closed.textContent = counts.closed;
    critical.textContent = counts.critical;
    console.log(`${selectedProject} counts: `, counts);
    // You can now display counts.open, counts.closed, counts.critical
}

function renderIssueTable(data) {
    issueTableBody.innerHTML = "";

    if (data.length === 0) {
        issueTableBody.innerHTML = `<tr><td colspan="9" style="text-align:center;">No matching issues found.</td></tr>`;
        return;
    }
    displayIssueCounts()
    data.forEach(item => {
        const statusClass = item.issue_status === 'Open' ? 'status-open' :
            item.issue_status === 'Closed' ? 'status-closed' :
                item.issue_status === 'Critical' ? 'status-critical' : '';
        const priorityClass = item.issue_priority === 'Low' ? 'priority-low' :
            item.issue_priority === 'Medium' ? 'priority-medium' :
                item.issue_priority === 'High' ? 'priority-high' : '';

        const row = document.createElement("tr");
        row.dataset.id = item.id;

        row.innerHTML = `
            <td>${item.issue_code}</td>
            <td>${item.project_id}</td>
            <td>${item.project}</td>
            <td class="${priorityClass}">${item.issue_priority}</td>
            <td class="${statusClass}">${item.issue_status}</td>
            <td>${item.issue_title}</td>
            <td>${item.created_at}</td>
            <td>${item.added_by}</td>
          <td class="actions-cell">
          <i class="edit-icon fas fa-pencil-alt"></i>
          <i class="fas fa-trash-alt"></i>
        </td>
        `;
        issueTableBody.appendChild(row);
    });
}


function populateProjectFilter() {
    const uniqueProjects = new Set(issueData.map(i => i.project_id));
    projectFilter.innerHTML = '<option value="All">All Projects</option>';
    uniqueProjects.forEach(pid => {
        const option = document.createElement('option');
        option.value = pid;
        option.textContent = pid;
        projectFilter.appendChild(option);
    });
}

function filterIssueTable() {
    const selectedProject = projectFilter.value;
    const selectedType = typeFilter.value;
    // displayIssueCounts()
    let filtered = issueData.filter(issue => {
        const projMatch = selectedProject === "All" || issue.project_id === selectedProject;
        const statusMatch = selectedType === "All" || issue.issue_status === selectedType
        return projMatch && statusMatch;
    });

    currentIssueTableData = filtered;
    sortAndRender();
}


function sortAndRender() {
    if (!sortColumn) {
        renderIssueTable(currentIssueTableData);
        return;
    }

    const sorted = [...currentIssueTableData].sort((a, b) => {
        let valA = a[sortColumn];
        let valB = b[sortColumn];

        // Handle numeric ID sort
        if (sortColumn === "id") {
            valA = Number(valA);
            valB = Number(valB);
        }
        // Date sort
        if (sortColumn === "created_at") {
            valA = new Date(valA);
            valB = new Date(valB);
        }
        if (valA < valB) return sortDirection === "asc" ? -1 : 1;
        if (valA > valB) return sortDirection === "asc" ? 1 : -1;
        return 0;
    });

    renderIssueTable(sorted);
}

// Sort header click
sortableHeaders.forEach(header => {
    header.addEventListener("click", () => {
        const col = header.dataset.sort;
        if (sortColumn === col) {
            sortDirection = sortDirection === "asc" ? "desc" : "asc";
        } else {
            sortColumn = col;
            sortDirection = "asc";
        }

        sortableHeaders.forEach(h => {
            const icon = h.querySelector(".fa-sort");
            if (icon) icon.classList.remove("fa-sort-up", "fa-sort-down");
        });
        const icon = header.querySelector(".fa-sort");
        if (icon) icon.classList.add(sortDirection === "asc" ? "fa-sort-up" : "fa-sort-down");

        sortAndRender();
    });
});

// Filter change
projectFilter.addEventListener("change", filterIssueTable);
typeFilter.addEventListener("change", filterIssueTable);

// Handle edit/delete icon clicks
issueTableBody.addEventListener("click", e => {
    const deleteIcon = e.target.closest(".fa-trash-alt");
    // const viewIcon = e.target.closest(".view-icon");
    const editIcon = e.target.closest(".edit-icon");
    if (deleteIcon) {
        const rowElement = deleteIcon.closest("tr");
        if (rowElement) {
            const id = rowElement.dataset.id;
            console.log(id)
            showConfirmationModal(id);
        }
    } else if (editIcon) {
        const rowElement = editIcon.closest("tr");
        if (rowElement) {
            // Get the ID of the project from the row's data
            const id = rowElement.dataset.id;

            let issue = issueData.find(b => b.id == id);
            handleEdit(issue);
        }
    }
    // const row = e.target.closest("tr");
    // if (!row) return;


    // if (e.target.classList.contains("delete-icon")) {
    //     handleDelete(id);
    // } else if (e.target.classList.contains("edit-icon")) {
    //     handleEdit(id);
    // }
});

function showConfirmationModal(itemId) {
    const confirmationModal = document.getElementById("confirmationModal");
    const deleteButton = document.getElementById("confirmDeleteBtn");
    deleteButton.onclick = () => {
        const formData = new FormData();
        formData.append("id", itemId);
        fetch(`../backend/project-management/delete_issue.php`, {
            method: 'POST',
            body: formData
        }).then(response => response.json())
            .then(res => {
                if (res.success) {
                    responseMessageToast.style.color = 'green'
                    responseMessageToast.innerHTML = res.message;
                    responseMessageToast.classList.add("show");
                    setTimeout(() => {
                        responseMessageToast.classList.remove("show");
                    }, 3000);
                    fetchIssues()
                    console.log("Issue deleted successfully:", res.message);
                } else {
                    responseMessageToast.style.color = 'red'
                    responseMessageToast.innerHTML = res.error;
                    responseMessageToast.classList.add("show");
                    setTimeout(() => {
                        responseMessageToast.classList.remove("show");
                    }, 3000);
                    console.error("Error deleting Issue:", res.error);
                }
            })


        hideConfirmationModal();
    };
    const cancelButton = document.getElementById("cancelDeleteBtn");
    cancelButton.onclick = () => {
        hideConfirmationModal();
    };

    confirmationModal.classList.add("visible");
}

function hideConfirmationModal() {
    confirmationModal.classList.remove("visible");
}
function handleDelete(id) {
    console.log("Delete issue", id);
    // Your delete logic here
}

function handleEdit(issue) {
    const form = document.querySelector('.modal2 form');
    form.elements['id'].value = issue.id || "";
    // Make sure you have this in your fetch
    // form.elements['project_id'].value = issue.project_id || "";

    const select = form.elements['project_id'];
    select.innerHTML = '';
    projectList.forEach(project => {
        const option = document.createElement('option');
        option.value = project.id;
        option.textContent = `${project.name} (${'PRO' + project.id})`
        if (project.name == issue.project_id) {
            option.selected = true;
        }
        // If you want them pre-selected
        select.appendChild(option);
    })
    form.elements['issue_status'].value = issue.issue_status || "";
    form.elements['issue_title'].value = issue.issue_title || "";
    form.elements['issue_priority'].value = issue.issue_priority || "";
    form.elements['issue_description'].value = issue.issue_description || "";

    // Store issue ID in the form for the save request

    modal2.style.display = 'block';
}

function showToast(color, message) {
    const toast = document.getElementById("response-message-toast");
    toast.style.color = color;
    toast.innerHTML = message;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 3000);
}




// INITIALIZATION
// document.addEventListener("DOMContentLoaded", async () => {
//     await fetchIssues();
// });





document.querySelector('.modal form').addEventListener('submit', async function (e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);
    modal.style.display = 'none';

    try {
        const res = await fetch('../backend/project-management/add_issue.php', {
            method: 'POST',
            body: formData
        });
        const result = await res.json();

        if (result.success) {
            form.reset();
            $('.need-select').val(null).trigger('change');

            responseMessageToast.style.color = 'green';
            responseMessageToast.innerHTML = result.message;
            responseMessageToast.classList.add("show");
            setTimeout(() => {
                responseMessageToast.classList.remove("show");
            }, 3000);

            // Call your `renderIssuesTable()` here if needed
            fetchIssues()

        } else {
            responseMessageToast.style.color = 'red';
            responseMessageToast.innerHTML = result.error || 'Failed to add issue';
            responseMessageToast.classList.add("show");
            setTimeout(() => {
                responseMessageToast.classList.remove("show");
            }, 3000);
            modal.style.display = 'block';
        }
    } catch (error) {
        console.error('Add Issue Error:', error);
        responseMessageToast.style.color = 'red';
        responseMessageToast.innerHTML = 'Unexpected error. Try again later.';
        responseMessageToast.classList.add("show");
        setTimeout(() => {
            responseMessageToast.classList.remove("show");
        }, 3000);
        modal.style.display = 'block';
    }
});
// Save changes
document.querySelector('.modal2 form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;

    const formData = new FormData(form);
    // formData.append('id', form.dataset.id);
    modal2.style.display = 'none';
    try {
        const res = await fetch('../backend/project-management/edit_issues.php', {
            method: 'POST',
            body: formData
        });
        const result = await res.json();

        if (result.success) {
            responseMessageToast.style.color = 'green';
            responseMessageToast.innerHTML = result.message;
            responseMessageToast.classList.add("show");
            setTimeout(() => {
                responseMessageToast.classList.remove("show");
            }, 3000);
            form.reset();

            document.querySelector('.modal2').style.display = 'none';
            fetchIssues()
        } else {
            responseMessageToast.style.color = 'red';
            responseMessageToast.innerHTML = result.error || 'Error updating issue';
            responseMessageToast.classList.add("show");
            setTimeout(() => {
                responseMessageToast.classList.remove("show");
            }, 3000);
            modal2.style.display = 'block';
        }
    } catch (error) {
        console.error(error);
        responseMessageToast.style.color = 'red';
        responseMessageToast.innerHTML = 'An unexpected error occurred';
        responseMessageToast.classList.add("show");
        setTimeout(() => {
            responseMessageToast.classList.remove("show");
        }, 3000);
        modal2.style.display = 'block';
    }
});

