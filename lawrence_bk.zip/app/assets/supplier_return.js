
let clientsList = [];
let returnsList = [];

async function fetchClientsList() {
    const response = await fetch('../backend/inventory/fetch_suppliers.php');
    const result = await response.json();
    clientsList = result.success ? result.data : [];
}
async function fetchCustomerReturns() {
    const response = await fetch('../backend/inventory/supplier-return/fetch_supplier_returns.php');
    const result = await response.json();
    return result.success ? result.data : [];
}

async function populateReturnsTable() {
    const returns = await fetchCustomerReturns();
    returnsList = returns; // Store the fetched returns globally for later use
    const tbody = document.querySelector('.supplier-returns-table');
    tbody.innerHTML = '';
    const formatDate = (date) => {
        const awardDate = new Date(date);

        // Get day, month, and year
        const day = String(awardDate.getDate()).padStart(2, '0');
        const month = String(awardDate.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
        const year = awardDate.getFullYear();

        // Format as dd-mm-yyyy
        return `${day}-${month}-${year}`;
    }
    returns.forEach(ret => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
 <td>${ret.id}</td>
    <td>${formatDate(ret.received_date)}</td>
    <td>${ret.order_id}</td>
    <td>${formatDate(ret.order_date)}</td>
    <td>${ret.first_name} ${ret.last_name}</td>
    <td>₦${parseFloat(ret.total_amount).toFixed(2)}</td>
    <td>${ret.return_completed || ''}</td>
    <td>
        <i class="view-icon" style="cursor:pointer" onclick="showReturnViewModal('${ret.id}')">
            <img src="../assets/eye-open.png" />
        </i>
    </td>
    <td>
        <i class="edit-icon" style="cursor:pointer" onclick="showReturnEditModal('${ret.id}')">
            <img src="../assets/edit.svg" />
        </i>
    </td>
    <td>
        <i class="delete-icon" style="cursor:pointer" onclick="deleteCustomerReturn('${ret.id}')">
            <img src="../assets/Delete.svg" />
        </i>
    </td>
    `;
        tbody.appendChild(tr);
    });
}
async function showReturnViewModal(returnId) {
    // const returns = await fetchCustomerReturns();
    const ret = returnsList.find(r => r.id == returnId);
    if (!ret) return;
    console.log(ret);
    console.log(returnsList);
    // Fill modal fields
    const modal = document.querySelector('.modal1');
    modal.querySelector('h2.con').textContent = `View Customer Return (${ret.id})`;
    // Fill main info
    const children = modal.querySelectorAll('.view-ret td');
    if (children.length > 0) {
        children[0].textContent = ret.id;
        children[1].textContent = ret.order_id;
        children[2].textContent = ret.order_date;
        children[3].textContent = `${ret.first_name} ${ret.last_name}`;
        children[4].textContent = ret.received_date || '';
        // children[5].textContent = ret.return_reason || '';
        children[5].textContent = ret.return_completed || '';
    }
    // Fill reason
    modal.querySelector('h4 + p').textContent = ret.return_reason || '';

    // Fill items table
    const itemsTbody = modal.querySelectorAll('table.leads-table')[1].querySelector('tbody');
    itemsTbody.innerHTML = '';
    let total = 0;
    ret.items.forEach(item => {
        total += parseFloat(item.total);
        itemsTbody.innerHTML += `
    <tr>
        <td>${item.item_name}</td>
        <td>${item.quantity}</td>
        <td>${item.unit_price}</td>
        <td>${item.total}</td>
    </tr>
    `;
    });
    // Add total row
    itemsTbody.innerHTML += `
    <tr>
        <td colspan="3" style="text-align:right;"><strong>Total</strong></td>
        <td>${total.toFixed(2)}</td>
    </tr>
    `;

    modal.style.display = 'block';
}

function populateClientSelect() {
    const selects = document.querySelectorAll('select[name="client_id"]');
    selects.forEach(select => {
        select.innerHTML = '<option value="">Select Customer</option>';
        clientsList.forEach(client => {
            const option = document.createElement('option');
            option.value = client.id;
            option.textContent = client.first_name + ' ' + client.last_name + '(' + client.email + ')';
            select.appendChild(option);
        });
    });
}
let clientOrders = [];

async function fetchOrdersForClient(clientId) {
    const response = await fetch('../backend/inventory/fetch_suppliers_orders.php?client_id=' + encodeURIComponent(clientId));
    const result = await response.json();
    clientOrders = result.success ? result.data : [];
    return clientOrders;
}

function populateOrderSelect(orders, select = document.querySelector('select[name="order_id"]')) {

    select.innerHTML = '<option value="">Select Order</option>';
    orders.forEach(order => {
        const option = document.createElement('option');
        option.value = order.id;
        option.textContent = order.id + ' (' + order.order_date + ')';
        select.appendChild(option);
    });
}

function populateItemsFromOrder(orderId) {
    const order = clientOrders.find(o => o.id == orderId);
    const items = order ? order.items : [];
    const container = document.getElementById('items-container');
    container.innerHTML = '';
    items.forEach((item, idx) => {
        const row = document.createElement('div');
        row.className = 'row item-row';
        row.innerHTML = `
    <input type="hidden" name="order_item_id[]" value="${item.id}" />
    <input type="hidden" name="stock_id[]" value="${item.stock_id}" />
    <div class="item-inputs">
        <div class="input-group">
            <label>Item</label>
            <input type="text" name="item_name[]" value="${item.item_name}" readonly />
        </div>
        <div class="input-group">
            <label>Unit Price</label>
            <input type="number" name="unit_price[]" value="${item.unit_price}" readonly />
        </div>
        <div class="input-group">
            <label>Quantity</label>
            <input type="number" name="quantity[]" min="1" data-max="${item.quantity}" value="1" oninput="validateQtyAndUpdateTotal(this)" required />
        </div>
        <div class="input-group">
            <label>Total</label>
            <input type="text" name="total[]" class="item-total" value="${item.unit_price}" readonly />
        </div>
        <button type="button" class="remove-btn" onclick="removeItemRow(this)">Remove</button>
    </div>
    `;
        container.appendChild(row);
    });
    calculateTotalOrderValue();
    // Set the order date field to the selected order's date
    if (order) {
        document.getElementById('order-date').value = order.order_date;
    } else {
        document.getElementById('order-date').value = '';
    }
}
let itemCount = 0;

function addReturnItemRow(containerId = "items-container") {
    // Get the current order
    const orderId = document.querySelector('select[name="order_id"]').value;
    const order = clientOrders.find(o => o.id == orderId);
    if (!order) return;

    // Get already added order_item_ids
    const container = document.getElementById(containerId);
    const existingIds = Array.from(container.querySelectorAll('input[name="order_item_id[]"]'))
        .map(input => input.value);

    // Find items not yet added
    const availableItems = order.items.filter(item => !existingIds.includes(String(item.id)));
    if (availableItems.length === 0) {
        alert("All items from this order are already added.");
        return;
    }

    // Build select options
    let options = '<option value="">Select Item</option>';
    availableItems.forEach(item => {
        options += `<option value="${item.id}" data-stock_id="${item.stock_id}" data-item_name="${item.item_name}" data-unit_price="${item.unit_price}" data-quantity="${item.quantity}">${item.item_name}</option>`;
    });

    // Create row
    const row = document.createElement('div');
    row.className = 'row item-row';
    row.innerHTML = `
    <input type="hidden" name="order_item_id[]" />
    <input type="hidden" name="stock_id[]" />
    <div class="item-inputs">
        <div class="input-group">
            <label>Item</label>
            <select onchange="fillReturnItemRow(this)">
                ${options}
            </select>
        </div>
        <div class="input-group">
            <label>Unit Price</label>
            <input type="number" name="unit_price[]" readonly />
        </div>
        <div class="input-group">
            <label>Quantity</label>
            <input type="number" name="quantity[]" min="1" oninput="validateQtyAndUpdateTotal(this)" required />
        </div>
        <div class="input-group">
            <label>Total</label>
            <input type="text" name="total[]" class="item-total" readonly />
        </div>
        <button type="button" class="remove-btn" onclick="removeItemRow(this)">Remove</button>
    </div>
    `;
    container.appendChild(row);
}
async function showReturnEditModal(returnId) {
    const ret = returnsList.find(r => r.id == returnId);
    if (!ret) return;

    // Show the edit modal
    const modal = document.querySelector('.modal2');
    modal.style.display = 'block';

    // Set modal title
    modal.querySelector('h2.con').textContent = `Edit Customer Return (${ret.id})`;

    // Populate main fields
    modal.querySelector('select[name="client_id"]').value = ret.supplier_id;
    console.log(ret);
    // Fetch and populate orders for this client
    const orderSelect = modal.querySelector('select[name="order_id"]');
    // const orders = await fetchOrdersForClient(ret.supplier_id;);
    // populateOrderSelect(orders, orderSelect);
    modal.querySelector('input[name="order_id"]').value = ret.order_id;
    modal.querySelector('input[name="order_date"]').value = ret.order_date;
    modal.querySelector('input[name="return_id"]').value = ret.id;
    modal.querySelector('input[name="received_date"]').value = ret.received_date || '';
    modal.querySelector('select[name="return_completed"]').value = ret.return_completed || '';
    modal.querySelector('input[name="return_status"]').value = ret.return_status || '';
    modal.querySelector('input[name="return_reason"]').value = ret.return_reason || '';

    // Populate items
    const container = modal.querySelector('#items-container');
    container.innerHTML = '';
    ret.items.forEach((item, idx) => {
        const row = document.createElement('div');
        row.className = 'row item-row edit-row';
        row.innerHTML = `
    <input type="hidden" name="order_item_id[]" value="${item.order_item_id}" />
    <input type="hidden" name="stock_id[]" value="${item.stock_id}" />
    <div class="item-inputs">
        <div class="input-group">
            <label>Item</label>
            <input type="text" name="item_name[]" value="${item.item_name}" readonly />
        </div>
        <div class="input-group">
            <label>Unit Price</label>
            <input type="number" name="unit_price[]" value="${item.unit_price}" readonly />
        </div>
        <div class="input-group">
            <label>Quantity</label>
            <input type="number" name="quantity[]" min="1" data-max="${item.quantity}" value="${item.quantity}" oninput="validateQtyAndUpdateTotal(this)" required />
        </div>
        <div class="input-group">
            <label>Total</label>
            <input type="text" name="total[]" class="item-total" value="${item.total}" readonly />
        </div>
        <button type="button" class="remove-btn" onclick="removeItemRow(this)">Remove</button>
    </div>
    `;
        container.appendChild(row);
    });
    calculateTotalOrderValue('edit-total-order-value');
}
async function deleteCustomerReturn(returnId) {
    if (!confirm('Are you sure you want to delete this customer return?')) return;
    try {
        const response = await fetch('../backend/inventory/supplier-return/delete_supplier_return.php', {
            method: 'POST',
            body: new URLSearchParams({
                return_id: returnId
            })
        });
        const result = await response.json();
        if (result.success) {
            alert('Customer return deleted.');
            populateReturnsTable();
        } else {
            alert(result.error || 'Failed to delete customer return.');
        }
    } catch (e) {
        alert('An error occurred. Please try again.');
    }
}

function removeItemRow(button) {
    const row = button.closest(".item-row");
    row.remove();
    calculateTotalOrderValue();
}

function validateQtyAndUpdateTotal(input) {
    const max = parseInt(input.getAttribute('data-max'), 10) || 0;
    let val = parseInt(input.value, 10) || 0;
    if (max && val > max) {
        alert('You cannot return more than what you ordered (' + max + ')');
        input.value = max;
        val = max;
    }
    updateTotal(input);
}

function updateTotal(input) {
    const row = input.closest(".item-row");
    const unitPrice =
        parseFloat(row.querySelector('[name="unit_price[]"]').value) || 0;
    const quantity =
        parseFloat(row.querySelector('[name="quantity[]"]').value) || 0;
    const total = unitPrice * quantity;
    row.querySelector(".item-total").value = total.toFixed(2);
    calculateTotalOrderValue();
}

function calculateTotalOrderValue(valueId = "total-order-value") {
    const totalInput = document.getElementById(valueId);

    let total = 0;
    document.querySelectorAll(".item-total").forEach((input) => {
        total += parseFloat(input.value) || 0;
    });
    if (totalInput) totalInput.value = total.toFixed(2);
}

document.getElementById('orderForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    // Prevent submitting if no items
    if (document.querySelectorAll('#items-container .item-row').length === 0) {
        alert('Please select at least one item to return.');
        return;
    }

    const form = e.target;
    const formData = new FormData(form);

    // Add total value (in case it's not in the form)
    formData.set('total_order_value', document.getElementById('total-order-value').value);

    // Optional: disable the save button to prevent double submit
    const saveBtn = form.querySelector('.save-btn');
    if (saveBtn) saveBtn.disabled = true;

    try {
        const response = await fetch('../backend/inventory/supplier-return/add_supplier_return.php', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();

        if (response.ok && result.success) {
            alert('Customer return added successfully!');
            // Optionally reset the form and items
            form.reset();
            document.getElementById("items-container").innerHTML = '';
            document.getElementById("total-order-value").value = '';
            // Optionally close the modal or reload the table
            populateReturnsTable();
            document.querySelector('.modal').style.display = 'none';
        } else {
            alert(result.error || 'Failed to add customer return.');
        }
    } catch (error) {
        alert('An error occurred. Please try again.');
    } finally {
        if (saveBtn) saveBtn.disabled = false;
    }
});
document.getElementById('edit-form').addEventListener('submit', async function (e) {
    e.preventDefault();

    if (document.querySelectorAll('#items-container .item-row').length === 0) {
        alert('Please select at least one item to return.');
        return;
    }

    const form = e.target;
    const formData = new FormData(form);
    formData.set('total_order_value', document.getElementById('edit-total-order-value').value);

    // Optional: add the return id
    // const retId = returnsList.find(r => r.id == form.querySelector('select[name="order_id"]').value)?.id;
    // if (retId) formData.set('return_id', retId);

    const saveBtn = form.querySelector('.save-btn');
    if (saveBtn) saveBtn.disabled = true;

    try {
        const response = await fetch('../backend/inventory/supplier-return/edit_supplier_return.php', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();

        if (response.ok && result.success) {
            alert('Customer return updated successfully!');
            form.reset();
            document.getElementById("items-container").innerHTML = '';
            document.getElementById("total-order-value").value = '';
            populateReturnsTable();
            document.querySelector('.modal2').style.display = 'none';
        } else {
            alert(result.error || 'Failed to update customer return.');
        }
    } catch (error) {
        alert('An error occurred. Please try again.');
    } finally {
        if (saveBtn) saveBtn.disabled = false;
    }
});
window.addEventListener("DOMContentLoaded", async () => {
    await fetchClientsList();
    populateClientSelect();
    populateReturnsTable();

    document.querySelector('select[name="client_id"]').addEventListener('change', async function () {
        const orders = await fetchOrdersForClient(this.value);
        populateOrderSelect(orders);
        document.getElementById('items-container').innerHTML = '';
    });

    document.querySelector('select[name="order_id"]').addEventListener('change', function () {
        populateItemsFromOrder(this.value);
    });
});
