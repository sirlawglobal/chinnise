
let taskData = {}
let employeesList = []

document.querySelector('#add form').addEventListener('submit', async function (e) {
  e.preventDefault();

  const form = e.target;
  const formData = new FormData(form);

  // Assume project_id is set dynamically via JS when opening the modal
  const projectId = getIdFromUrl()
  if (!projectId) {

    responseMessageToast.style.color = 'red'
    responseMessageToast.innerHTML = `Project ID not found.`;
    responseMessageToast.classList.add("show");


    setTimeout(() => {
      responseMessageToast.classList.remove("show");
    }, 3000);
    return;
  }

  formData.append('project_id', projectId);

  modal.style.display = 'none';
  try {
    const res = await fetch('../backend/project-management/add_tasks.php', {
      method: 'POST',
      body: formData
    });

    const result = await res.json();

    if (result.success) {
      const status = formData.get('status')
      const tab = status.slice(0, 4).toLowerCase()
      // console.log(tab)
      form.reset();
      $('.need-select').val(null).trigger('change');



      responseMessageToast.innerHTML = `Task Added Successfully!`;
      responseMessageToast.classList.add("show");
      setTimeout(() => {
        responseMessageToast.classList.remove("show");
      }, 3000);
      document.querySelector('.' + tab).click();
      // activateTab(formData.get('status').toLowerCase())
      // Optionally reload tasks here
    } else {
      responseMessageToast.style.color = 'red'
      responseMessageToast.innerHTML = result.error;
      responseMessageToast.classList.add("show");
      setTimeout(() => {
        responseMessageToast.classList.remove("show");
      }, 3000);

    }
  } catch (err) {
    responseMessageToast.style.color = 'red'
    responseMessageToast.innerHTML = `Error Adding Task ${err}`;
    responseMessageToast.classList.add("show");
    setTimeout(() => {
      responseMessageToast.classList.remove("show");
    }, 3000);
    modal.style.display = 'block';

  }
});

document.querySelector('.modal2 form').addEventListener('submit', async function (e) {
  e.preventDefault();

  const form = e.target;
  const formData = new FormData(form);
  const status = formData.get('status')
  const tab = status.slice(0, 4).toLowerCase()
  modal2.style.display = 'none';
  fetch('../backend/project-management/edit_tasks.php', {
    method: 'POST',
    body: formData,
  })
    .then(response => response.json())
    .then(res => {
      if (res.success) {
        form.reset()
        $('.need-select').val(null).trigger('change');

        console.log("Task data updated successfully:", res.data);
        responseMessageToast.innerHTML = `Task Updated Successfully!`;
        responseMessageToast.classList.add("show");
        setTimeout(() => {
          responseMessageToast.classList.remove("show");
        }, 3000);
        document.querySelector('.' + tab).click();


      } else {
        console.error("Error updating project data:", res.message);
        responseMessageToast.style.color = 'red'
        responseMessageToast.innerHTML = `Error Updating Task`;
        responseMessageToast.classList.add("show");
        setTimeout(() => {
          responseMessageToast.classList.remove("show");
        }, 3000);
        modal2.style.display = 'block';
      }
    })

})
async function fetchTasks(id) {
  try {
    await fetch(`../backend/project-management/fetch_tasks.php?id=${id}`,)
      .then(response => response.json())
      .then(res => {
        if (res.success) {
          taskData = res.data;
        } else {
          responseMessageToast.style.color = 'red'
          responseMessageToast.innerHTML = `Could not load tasks:${res.error}`;
          responseMessageToast.classList.add("show");
          setTimeout(() => {
            responseMessageToast.classList.remove("show");
          }, 3000);
        }
      });
  } catch (error) {
    responseMessageToast.style.color = 'red'
    responseMessageToast.innerHTML = `Error fetching tasks: ${error}`;
    responseMessageToast.classList.add("show");
    setTimeout(() => {
      responseMessageToast.classList.remove("show");
    }, 3000);
    // console.error( error);
  }
}

async function loadProjectAssignees(projectId) {
  await fetch(`../backend/project-management/get_project_assignees.php?project_id=${projectId}`)
    .then(res => res.json())
    .then(data => {
      employeesList = data.assignees;
      const select = document.querySelector('.assignees');
      select.innerHTML = ''; // Clear existing

      if (data.success) {
        data.assignees.forEach(user => {
          const option = document.createElement('option');
          option.value = user.id;
          option.textContent = `${user.name} (${user.email || user.phone})`;
          select.appendChild(option);
        });
      } else {
        responseMessageToast.style.color = 'red'
        responseMessageToast.innerHTML = `Could not load assignees: ' + ${data.error}`;
        responseMessageToast.classList.add("show");
        setTimeout(() => {
          responseMessageToast.classList.remove("show");
        }, 3000);
      }
    });
}

// 2. Get DOM elements
const navTabs = document.querySelectorAll(".nav-tab");
const projectListTitle = document.querySelector(".project-list-title");
const projectTableContainer = document.getElementById("projectTableContainer");
const responseMessageToast = document.getElementById("response-message-toast");
const addModal = document.querySelector("#add");
const addModalForm = document.querySelector("#add form");

const confirmationModal = document.getElementById('confirmationModal');
const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
const cancelDeleteBtn = document.getElementById('cancelDeleteBtn');

// Function to show the modal
function showConfirmationModal(itemId, dataSourceKey, categoryKey = null) {
  confirmDeleteBtn.dataset.itemId = itemId;
  confirmDeleteBtn.dataset.sourceKey = dataSourceKey; // This will be the project name (e.g., 'Project Alpha')
  confirmDeleteBtn.dataset.categoryKey = categoryKey; // This will be the task category (e.g., 'ongoing', 'pending')

  confirmationModal.classList.add('visible');
}

// Function to hide the modal
function hideConfirmationModal() {
  confirmationModal.classList.remove('visible');
  confirmDeleteBtn.dataset.itemId = '';
  confirmDeleteBtn.dataset.sourceKey = '';
  confirmDeleteBtn.dataset.categoryKey = '';
}



// --- Event Listener for Delete Icons (Tasks Table) ---
projectTableContainer.addEventListener('click', (event) => {
  const deleteIcon = event.target.closest('.fa-trash-alt');
  const viewIcon = event.target.closest(".view-icon");
  const editIcon = event.target.closest(".edit-icon");
  if (deleteIcon) {
    const rowElement = deleteIcon.closest('tr');
    if (rowElement) {
      const taskId = rowElement.dataset.taskId; // Get the ID of the task from the row's data

      // Get the current project name from the URL
      const projectName = getProjectNameFromUrl();
      // Get the current active task category tab
      const activeTab = document.querySelector('.nav-tab.active');
      const categoryKey = activeTab.dataset.taskCategory; // e.g., 'ongoing', 'pending'

      if (taskId && projectName && categoryKey) {
        showConfirmationModal(taskId, projectName, categoryKey);
      }
    }
  } else if (viewIcon) {
    const rowElement = viewIcon.closest("tr");
    if (rowElement) {

      const activeTab = document.querySelector(".nav-tab.active");

      const categoryKey = activeTab.dataset.taskCategory;
      const taskId = rowElement.dataset.taskId;
      const projectSpecificTasks = taskData[getProjectNameFromUrl()];
      const task = projectSpecificTasks[categoryKey].rows.find(t => t.id == taskId);
      const form = modal1.querySelector('form');
      form.elements['name'].value = task.name || '';
      form.elements['start_date'].value = task.start_date || '';
      form.elements['due_date'].value = task.due_date || '';
      form.elements['priority'].innerHTML = `<option value="">${task.priority}</option>` || '';
      form.elements['status'].value = task.status || categoryKey;
      const assigneesSelect = form.elements['assignees[]'];
      assigneesSelect.innerHTML = '';
      task.assignees.forEach(assignee => {
        const option = document.createElement('option');
        option.value = assignee.user_id;
        option.textContent = `${assignee.name} (${assignee.email || assignee.phone})`;
        option.selected = true; // If you want them pre-selected
        assigneesSelect.appendChild(option);
      })
      modal1.style.display = "block";

      console.log("View project details for ID:", taskId);

    }
  }
  else if (editIcon) {
    const rowElement = editIcon.closest("tr");
    if (rowElement) {
      // Get the ID of the project from the row's data
      const activeTab = document.querySelector(".nav-tab.active");

      const categoryKey = activeTab.dataset.taskCategory;
      const taskId = rowElement.dataset.taskId;
      const projectSpecificTasks = taskData[getProjectNameFromUrl()];
      const task = projectSpecificTasks[categoryKey].rows.find(t => t.id == taskId);
      populateTaskModal(task);
    }
  }
});

function populateTaskModal(task) {

  const form = modal2.querySelector('form');

  // Fill text and date inputs
  form.elements['project_id'].value = getIdFromUrl() || '';
  form.elements['task_id'].value = task.id || '';
  form.elements['name'].value = task.name || '';
  form.elements['start_date'].value = task.start_date || '';
  form.elements['due_date'].value = task.due_date || '';

  // Populate supervisor select
  form.elements['priority'].value = task.priority

  // Set status
  form.elements['status'].value = task.status || 'Pending';

  // Populate assignees select
  const assigneesSelect = form.elements['assignees[]'];
  assigneesSelect.innerHTML = '';

  employeesList.forEach(emp => {
    const opt = document.createElement('option');
    opt.value = emp.id;
    opt.textContent = `${emp.name} (${emp.email || emp.phone})`;;
    if (task.assignees && task.assignees.some(a => a.user_id == emp.id)) {
      opt.selected = true;
    }
    assigneesSelect.appendChild(opt);
  });

  // Show the modal
  modal2.style.display = 'block';
}
// --- Event Listener for Modal Buttons ---
confirmDeleteBtn.addEventListener('click', () => {
  const itemId = confirmDeleteBtn.dataset.itemId;
  const projectName = confirmDeleteBtn.dataset.sourceKey;
  const categoryKey = confirmDeleteBtn.dataset.categoryKey;
  const formData = new FormData();
  formData.append("task_id", itemId);
  console.log(itemId)

  if (itemId) {
    // Update count
    fetch(`../backend/project-management/delete_tasks.php`, {
      method: 'POST',
      body: formData
    }).then(response => response.json())
      .then(res => {
        if (res.success) {
          console.log("Project deleted successfully:", res.message);
          hideConfirmationModal();
          responseMessageToast.innerHTML = `Task Deleted Successfully!`;
          responseMessageToast.classList.add("show");
          setTimeout(() => { responseMessageToast.classList.remove("show"); }, 3000);
          renderTasksTable(projectName, categoryKey, getIdFromUrl());
        } else {
          console.error("Error deleting project:", res.error);
          hideConfirmationModal();
          responseMessageToast.style.color = 'red'
          responseMessageToast.innerHTML = `Task Deleted Successfully!`;
          responseMessageToast.classList.add("show");
          setTimeout(() => { responseMessageToast.classList.remove("show"); }, 3000);
        }
      })
  }
}

);

cancelDeleteBtn.addEventListener('click', () => {
  hideConfirmationModal();
});



// Function to parse project name from URL
function getProjectNameFromUrl() {
  const params = new URLSearchParams(window.location.search);
  return params.get("project");
}
function getIdFromUrl() {
  const params = new URLSearchParams(window.location.search);
  return params.get("project_id");
}

// 3. Function to render the tasks table for a specific project and category
async function renderTasksTable(projectName, categoryKey, ID) {
  await fetchTasks(ID)
  const projectSpecificTasks = taskData[projectName];
  console.log(projectName, categoryKey, ID)
  if (!projectSpecificTasks) {
    projectTableContainer.innerHTML = `<p>No tasks found for project: ${projectName}.</p>`;
    projectListTitle.textContent = "Project Tasks";
    return;
  }

  const categoryData = projectSpecificTasks[categoryKey];

  if (!categoryData || !categoryData.rows) {
    // Fallback for cases where a specific category might not have data for a project
    projectTableContainer.innerHTML = `<p>No ${categoryKey} tasks available for ${projectName}.</p>`;
    projectListTitle.textContent = `${projectName} Tasks`;
    return;
  }

  function getPriorityColor(priority) {
    switch ((priority || '').toLowerCase()) {
      case 'high': return 'red';
      case 'medium': return 'orange';
      case 'low': return 'green';
      default: return '';
    }
  }
  // Update the main title for tasks page
  projectListTitle.textContent = `${categoryData.label} (${categoryData.count})`;

  // Define table headers for tasks (excluding 'View Tasks' from projects page)
  const headers = [
    "Task Title",
    "Assigned to",
    "Due Date",
    "Status",
    "Priority",
    "View",
    "Edit",
    "Delete", // Icons for task actions
  ];

  let tableHTML = `
      <table>
          <thead>
              <tr>
                  ${headers
      .map(
        (header) =>
          `<th${header === "View" ||
            header === "Edit" ||
            header === "Delete"
            ? ' class="table-icon-col"'
            : ""
          }>${header}</th>`
      )
      .join("")}
              </tr>
          </thead>
          <tbody>
  `;

  categoryData.rows.forEach((task) => {
    tableHTML += `
          <tr data-task-id="${task.id}">
              <td>${task.name || "N/A"}</td>
              <td>${task.assignees[0].name || "N/A"}
           <i class="fas fa-eye assign-view" style="cursor: pointer;"></i></td>
              <td>${task.due_date || "N/A"}</td>
              <td>${task.status || "N/A"}</td>
           <td style="color: ${getPriorityColor(task.priority)}">${task.priority || "N/A"}</td>
              <td class="table-icon-col"><i class="fas fa-eye view-icon"></i></td>
              <td class="table-icon-col"><i class="fas fa-pencil-alt edit-icon"></i></td>
              <td class="table-icon-col"><i class="fas fa-trash-alt"></i></td>
          </tr>
      `;
  });

  tableHTML += `
          </tbody>
      </table>
  `;

  projectTableContainer.innerHTML = tableHTML;
}

// 4. Add event listeners to task navigation tabs
navTabs.forEach((tab) => {
  tab.addEventListener("click", (event) => {
    event.preventDefault(); // Prevent default link behavior

    // Remove 'active' class from all tabs
    navTabs.forEach((t) => t.classList.remove("active"));

    // Add 'active' class to the clicked tab
    event.currentTarget.classList.add("active");

    // Get the current project name from the URL
    const projectName = getProjectNameFromUrl();
    // Get the task category key from the data-task-category attribute
    const categoryKey = event.currentTarget.dataset.taskCategory;

    // Render the appropriate tasks table
    console.log(categoryKey)
    renderTasksTable(projectName, categoryKey, getIdFromUrl());
  });
});

// 5. Initial render when the page loads
document.addEventListener("DOMContentLoaded", () => {
  const initialProjectName = getProjectNameFromUrl();
  const ID = getIdFromUrl();
  loadProjectAssignees(ID)

  if (initialProjectName && ID) {
    // Set the initial section title to include the project name
    document.querySelector(
      ".section-title-text"
    ).textContent = `${decodeURIComponent(initialProjectName)} Tasks Overview`;
    // console.log(cate)
    renderTasksTable(initialProjectName, "ongoing", ID); // Default to 'ongoing' tasks for the project
  } else {
    // Handle case where project name is not in URL
    document.querySelector(".section-title-text").textContent =
      "Tasks Overview";
    projectTableContainer.innerHTML =
      "<p>Please select a project to view its tasks.</p>";
    projectListTitle.textContent = "No Project Selected";
  }
});


