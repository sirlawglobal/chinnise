
// Fetch and display supplier orders in the table

async function loadSupplierOrders() {
    try {
        const response = await fetch('../backend/inventory/fetch_suppliers_orders.php');
        const result = await response.json();

        if (response.ok && result.success) {
            console.log(result.data); // Debugging line to check fetched data
            const tbody = document.querySelector('.fetch-suppliers-orders');
            tbody.innerHTML = ''; // Clear existing rows

            result.data.forEach((order) => {
                const tr = document.createElement("tr");
                const awardDate = new Date(order.order_date);

          // Get day, month, and year
          const day = String(awardDate.getDate()).padStart(2, '0');
          const month = String(awardDate.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
          const year = awardDate.getFullYear();

                const awardDate1 = new Date(order.delivery_date);

          // Get day, month, and year
          const days = String(awardDate1.getDate()).padStart(2, '0');
          const months = String(awardDate1.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
          const years = awardDate1.getFullYear();

          // Format as dd-mm-yyyy
          const formattedDate = `${day}-${month}-${year}`;
          const formattedDate1 = `${days}-${months}-${years}`;
                tr.innerHTML = `
    <td>${order.id || ""}</td>
    <td>${formattedDate || ""}</td>
    <td>${order.first_name + " " + order.last_name || ""}</td>
    <td>${order.total_amount
                        ? "₦" + Number(order.total_amount).toLocaleString()
                        : ""
                    }</td>
    <td>${formattedDate1 || ""}</td>
    <td>${order.order_completed}</td>
    <td>
        <i class="view-icon"
            data-order='${JSON.stringify(order)}'>
            <img src="../assets/eye-open.png" />
        </i>
    </td>
    <td>
        <i class="edit-icon"
            data-order='${JSON.stringify(order)}'>
            <img src="../assets/edit.svg" />
        </i>
    </td>
    <td>
        <i class="delete-icon"
            data-order_id="${order.id}">
            <img src="../assets/Delete.svg" />
        </i>
    </td>
    `;
                tbody.appendChild(tr);
            });

            // View modal logic
            document.querySelectorAll('.view-icon').forEach(icon => {
                icon.addEventListener('click', function () {
                    const order = JSON.parse(this.getAttribute('data-order'));
                    fillViewOrderModal(order);
                });
            });
            // Delete order logic
            document.querySelectorAll('.edit-icon').forEach(icon => {
                icon.addEventListener('click', function () {
                    const order = JSON.parse(this.getAttribute('data-order'));
                    fillEditOrderModal(order);
                });
            });

            // Delete order handler
            document.querySelectorAll('.delete-icon').forEach(icon => {
                icon.addEventListener('click', function () {
                    const orderId = icon.getAttribute('data-order_id');
                    if (!orderId) return;

                    if (!confirm('Are you sure you want to delete this order?')) return;

                    deleteOrder(orderId);
                });
            });

        } else {
            alert(result.error || 'Failed to fetch supplier orders.');
        }
    } catch (error) {
        console.error(error)
        alert('An error occurred while fetching supplier orders.');
    }
}
// Fill the view modal with order and items
function fillViewOrderModal(order) {
    // Fill order summary table
    const modal = document.querySelector('.modal1');
    const summaryTbody = modal.querySelector('table.leads-table:nth-of-type(1) tbody');
    summaryTbody.innerHTML = `
    <tr>
        <td>${order.id}</td>
        <td>${order.order_date}</td>
        <td>${order.first_name + ' ' + order.last_name}</td>
        <td>${order.delivery_date}</td>
        <td>${order.order_completed == 'Yes' ? 'Completed' : 'Pending'}</td>
    </tr>`;

    // Fill items table
    const itemsTbody = modal.querySelector('table.leads-table:nth-of-type(2) tbody');
    let itemsHtml = '';
    let total = 0;
    if (order.items && order.items.length) {
        order.items.forEach(item => {
            itemsHtml += `
        <tr>
          <td>${item.item_name}</td>
          <td>${item.quantity}</td>
          <td>${item.unit_price}</td>
          <td>${item.total}</td>
        </tr>
      `;
            total += parseFloat(item.total);
        });
        // Add total row
        itemsHtml += `
    <tr>
        <td colspan="2"></td>
        <td><strong>Total</strong></td>
        <td>${total.toFixed(2)}</td>
    </tr>
    `;
    } else {
        itemsHtml = `<tr><td colspan="4">No items</td></tr>`;
    }
    itemsTbody.innerHTML = itemsHtml;

    modal.style.display = 'block';
}

async function fillEditOrderModal(order) {
    const modal = document.getElementById('edit');
    const form = modal.querySelector('form');
    // Set order fields
    form.dataset.orderId = order.id;
    form.elements['order_date'].value = order.order_date;
    form.elements['total_amount'].value = order.total_amount;
    form.elements['delivery_date'].value = order.delivery_date;
    form.elements['order_completed'].value = order.order_completed;


    // Populate supplier select

    form.elements['client_name'].value = order.supplier_id || order.client_name;

    // Clear and add item rows
    const container = document.getElementById('edit-items-container');
    container.innerHTML = '';
    let editItemCount = 0;
    order.items.forEach((item, idx) => {
        editItemCount++;
        // Gather all stock_ids already used in other rows (except this one)
        const usedStockIds = order.items
            .filter((it, i) => i !== idx)
            .map(it => it.stock_id);

        // Build options for the select, excluding already used stock_ids
        let options = '<option value="">Select Item</option>';
        stocksList.forEach(stock => {
            if (!usedStockIds.includes(stock.stock_id) || stock.stock_id === item.stock_id) {
                const selected = stock.stock_id === item.stock_id ? 'selected' : '';
                options += `<option value="${stock.stock_id}" data-unit_price="${stock.unit_price}" data-name="${stock.item}" data-qty="${stock.qty}" ${selected}>${stock.item} (${stock.size})</option>`;
            }
        });
        const stock = stocksList.find(s => s.stock_id == item.stock_id);
        const maxQty = stock ? stock.qty : '';

        const row = document.createElement('div');
        row.className = 'item-inputs item-row';
        row.innerHTML = `
            <div class="input-group">
                <label for="stock_id_edit_${editItemCount}">Item</label>
                <select id="stock_id_edit_${editItemCount}" name="stock_id[]" onchange="updateUnitPriceAndName(this, ${editItemCount}, 'edit-items-container'); refreshAllItemSelects('edit-items-container')" required>
                    ${options}
                </select>
            </div>
            <div class="input-group">
                <label for="item_name_edit_${editItemCount}">Item Name</label>
                <input id="item_name_edit_${editItemCount}" type="text" name="item_name[]" value="${item.item_name}" readonly />
            </div>
            <div class="input-group">
                <label for="unit_price_edit_${editItemCount}">Unit Price</label>
                <input id="unit_price_edit_${editItemCount}" type="number" name="unit_price[]" placeholder="Unit Price" step="0.01" min="0" oninput="updateTotal(this, 'edit-items-container')" required readonly value="${item.unit_price}" />
            </div>
            <div class="input-group">
                <label for="quantity_edit_${editItemCount}">Quantity</label>
               <input id="quantity_edit_${editItemCount}" type="number" name="quantity[]" placeholder="Quantity" min="1" data-max="${maxQty}" oninput="validateQtyAndUpdateTotal(this,'edit-items-container')" required value="${item.quantity}" />
            </div>
            <div class="input-group">
                <label for="total_edit_${editItemCount}">Total</label>
                <input id="total_edit_${editItemCount}" type="text" name="total[]" placeholder="Total" class="item-total" readonly value="${item.total}" />
            </div>
            <button type="button" class="remove-btn" onclick="removeItemRow(this,'edit-items-container')">Remove</button>
        `;
        container.appendChild(row);
    });

    // Recalculate total order value
    calculateTotalOrderValue("edit-items-container");

    // Show modal
    modal.style.display = 'block';
}

async function deleteOrder(orderId) {
    try {
        const response = await fetch('../backend/inventory/delete_suppliers_order.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: 'order_id=' + encodeURIComponent(orderId)
        });
        const result = await response.json();

        if (response.ok && result.success) {
            alert('Order deleted successfully!');
            await loadSupplierOrders();
            await fetchStocksList(); // Refresh stocks in case they changed
        } else {
            alert(result.error || 'Failed to delete order.');
        }
    } catch (error) {
        alert('An error occurred. Please try again.');
    }

}

// Call this function on page load or after adding/editing/deleting an order
window.addEventListener('DOMContentLoaded', loadSupplierOrders());
let stocksList = [];

async function fetchStocksList() {
    try {
        const response = await fetch('../backend/inventory/fetch_stocks.php');
        const result = await response.json();
        if (response.ok && result.success) {
            stocksList = result.data;
        } else {
            stocksList = [];
        }
    } catch (error) {
        stocksList = [];
    }
}

let itemCount = 0;

function addItemRow(containerId = "items-container") {
    itemCount++;
    const container = document.getElementById(containerId);

    // Gather all selected stock_ids in current rows
    const selectedStockIds = Array.from(container.querySelectorAll('select[name="stock_id[]"]'))
        .map(sel => sel.value)
        .filter(val => val); // Exclude empty selections

    // Build options for the select, excluding already selected stock_ids
    let options = '<option value="">Select Item</option>';
    stocksList.forEach(stock => {
        if (!selectedStockIds.includes(stock.stock_id)) {
            options += `<option value="${stock.stock_id}" data-unit_price="${stock.unit_price}" data-name="${stock.item}" data-qty="${stock.qty}">${stock.item} (${stock.size})</option>`;
        }
    });

    const row = document.createElement('div');
    row.className = 'item-inputs item-row';
    row.setAttribute("data-id", itemCount);

    row.innerHTML = `
        <div class="input-group">
            <label for="stock_id_${itemCount}">Item</label>
            <select id="stock_id_${itemCount}" name="stock_id[]" onchange="updateUnitPriceAndName(this, ${itemCount}, '${containerId}'); refreshAllItemSelects('${containerId}')" required>
                ${options}
            </select>
        </div>
        <div class="input-group">
            <label for="item_name_${itemCount}">Item Name</label>
            <input id="item_name_${itemCount}" type="text" name="item_name[]" placeholder="Item Name" readonly />
        </div>
        <div class="input-group">
            <label for="unit_price_${itemCount}">Unit Price</label>
            <input id="unit_price_${itemCount}" type="number" name="unit_price[]" placeholder="Unit Price" step="0.01" min="0" oninput="updateTotal(this)" required readonly value="" />
        </div>
        <div class="input-group">
            <label for="quantity_${itemCount}">Quantity</label>
            <input id="quantity_${itemCount}" type="number" name="quantity[]" placeholder="Quantity" min="1" oninput="validateQtyAndUpdateTotal(this,'${containerId}')" required value="" />
        </div>
        <div class="input-group">
            <label for="total_${itemCount}">Total</label>
            <input id="total_${itemCount}" type="text" name="total[]" placeholder="Total" class="item-total" readonly value="" />
        </div>
        <button type="button" class="remove-btn" onclick="removeItemRow(this,'${containerId}')">Remove</button>
    `;

    container.appendChild(row);
    refreshAllItemSelects(containerId);
    calculateTotalOrderValue(containerId);
}

function refreshAllItemSelects(containerId = "items-container") {
    const container = document.getElementById(containerId);
    const selects = Array.from(container.querySelectorAll('select[name="stock_id[]"]'));
    const selectedValues = selects.map(sel => sel.value);

    selects.forEach((select, idx) => {
        const currentValue = select.value;
        let options = '<option value="">Select Item</option>';
        stocksList.forEach(stock => {
            if (!selectedValues.includes(stock.stock_id) || stock.stock_id === currentValue) {
                options += `<option value="${stock.stock_id}" data-unit_price="${stock.unit_price}" data-name="${stock.item}" data-qty="${stock.qty}"${stock.stock_id === currentValue ? ' selected' : ''}>${stock.item} (${stock.size})</option>`;
            }
        });
        select.innerHTML = options;
    });
}

function removeItemRow(button, containerId = "items-container") {
    const row = button.closest(".item-row");
    row.remove();
    refreshAllItemSelects(containerId);
    calculateTotalOrderValue(containerId);
}

function updateUnitPriceAndName(select, idx, containerId = 'items-container') {
    const selectedOption = select.options[select.selectedIndex];
    const unitPrice = selectedOption.getAttribute('data-unit_price') || '';
    const maxQty = selectedOption.getAttribute('data-qty') || '';
    const itemName = selectedOption.getAttribute('data-name') || '';

    const row = select.closest('.item-row');
    const qtyInput = row.querySelector('[name="quantity[]"]');
    row.querySelector('[name="unit_price[]"]').value = unitPrice;
    row.querySelector('[name="item_name[]"]').value = itemName;
    qtyInput.value = '';
    qtyInput.setAttribute('data-max', maxQty);

    row.querySelector('.item-total').value = '';
    calculateTotalOrderValue(containerId);
}

function validateQtyAndUpdateTotal(input, containerId = 'items-container') {
    const max = parseInt(input.getAttribute('data-max'), 10) || 0;
    let val = parseInt(input.value, 10) || 0;
    if (max && val > max) {
        alert('You cannot order more than what is in stock (' + max + ')');
        input.value = max;
        val = max;
    }
    updateTotal(input, containerId);
}

function updateTotal(input, containerId = 'items-container') {
    const row = input.closest(".item-row");
    const unitPrice =
        parseFloat(row.querySelector('[name="unit_price[]"]').value) || 0;
    const quantity =
        parseFloat(row.querySelector('[name="quantity[]"]').value) || 0;
    const total = unitPrice * quantity;
    row.querySelector(".item-total").value = total.toFixed(2);
    calculateTotalOrderValue(containerId);
}

function calculateTotalOrderValue(containerId = 'items-container') {
    let total = 0;
    let container;
    if (containerId) {
        container = document.getElementById(containerId);
        if (!container) return;
        container.querySelectorAll(".item-total").forEach((input) => {
            total += parseFloat(input.value) || 0;
        });
    } else {
        // fallback: sum all on page (should not be used)
        document.querySelectorAll(".item-total").forEach((input) => {
            total += parseFloat(input.value) || 0;
        });
    }
    // Update the correct total field
    if (containerId === "items-container") {
        const addTotal = document.getElementById("total-order-value");
        if (addTotal) addTotal.value = total.toFixed(2);
    } else if (containerId === "edit-items-container") {
        const editTotal = document.getElementById("edit-total-order-value");
        if (editTotal) editTotal.value = total.toFixed(2);
    }
}

// Optionally add one row at start
window.addEventListener("DOMContentLoaded", async () => {
    await fetchStocksList();
    populateSupplierSelect();
    addItemRow();
});


// Fetch suppliers and populate the select
async function populateSupplierSelect() {
    try {
        const response = await fetch('../backend/inventory/fetch_suppliers.php');
        const result = await response.json();
        const selects = document.querySelectorAll('.supplier-select');
        selects.forEach(select => select.innerHTML = '<option value="">Select Supplier</option>');

        if (response.ok && result.success) {
            result.data.forEach(supplier => {
                selects.forEach(select => {
                    const option = document.createElement('option');
                    option.value = supplier.supplier_id || supplier.id || supplier.email;
                    option.textContent = supplier.first_name + ' ' + supplier.last_name + ' (' + (supplier.email || supplier.phone_number) + ')';
                    select.appendChild(option);
                });
            });
        } else {
            selects.forEach(select => {
                const option = document.createElement('option');
                option.value = '';
                option.textContent = 'No suppliers found';
                select.appendChild(option);
            });
        }
    } catch (error) {
        document.querySelectorAll('.supplier-select').forEach(select => {
            select.innerHTML = '<option value="">Error loading suppliers</option>';
        });
    }
}




// Handle Add Order form submit
document.getElementById('orderForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    // Prevent submitting if no items
    if (document.querySelectorAll('.item-row').length === 0) {
        alert('Please add at least one item.');
        return;
    }

    // Add total_order_value and order_completed to the form data
    const form = e.target;
    const formData = new FormData(form);
    formData.append('total_order_value', document.getElementById('total-order-value').value);
    // formData.append('order_completed', 'No'); // Or get from a field if you have one

    const saveBtn = form.querySelector('.save-btn');
    saveBtn.disabled = true;

    try {
        const response = await fetch('../backend/inventory/add_suppliers_order.php', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();

        if (response.ok && result.success) {
            alert('Order added successfully!');
            document.querySelector('.modal').style.display = 'none';
            form.reset();
            document.getElementById("items-container").innerHTML = '';
            itemCount = 0;
            // Optionally, reload the orders table here
            loadSupplierOrders()

        } else {
            alert(result.error || 'Failed to add order.');
        }
    } catch (error) {
        alert('An error occurred. Please try again.');
    } finally {
        document.querySelector('.modal').style.display = 'none';
        await fetchStocksList();
        saveBtn.disabled = false;

    }
});

document.getElementById('edit-orderForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    // Prevent submitting if no items
    if (document.querySelectorAll('#edit-items-container .item-row').length === 0) {
        alert('Please add at least one item.');
        return;
    }

    const form = e.target;
    const formData = new FormData(form);

    // You must include the order ID for editing
    // You can store it as a data attribute on the modal or form when opening the edit modal
    const orderId = form.dataset.orderId || form.getAttribute('data-order-id');
    if (!orderId) {
        alert('Order ID missing.');
        return;
    }
    formData.append('order_id', orderId);

    // Add the correct total value
    formData.set('total_order_value', document.getElementById('edit-total-order-value').value);

    const saveBtn = form.querySelector('.save-btn');
    saveBtn.disabled = true;

    try {
        const response = await fetch('../backend/inventory/edit_suppliers_order.php', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();

        if (response.ok && result.success) {
            alert('Order updated successfully!');
            document.getElementById('edit').style.display = 'none';
            // Optionally reset the form and items
            form.reset();
            document.getElementById("edit-items-container").innerHTML = '';
            // Reload the orders table
            await loadSupplierOrders();
            await fetchStocksList(); // Refresh stocks in case they changed
        } else {
            alert(result.error || 'Failed to update order.');
        }
    } catch (error) {
        alert('An error occurred. Please try again.');
    } finally {
        saveBtn.disabled = false;
    }
});
