<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Not logged in, redirect to login page
    header("Location: auth/login.php");
    exit;
}
?>

<?php include_once('./components/header.php') ?>
<div class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2 class="con">New Appointment</h2>
        <form action="backend/appointment/save_appointment.php" method="POST" id="appointmentForm">
            <div class="row">
                <div class="col">
                    <label>Title</label>
                    <input type="text" name="title" placeholder="Title" required />
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>From</label>
                    <input type="datetime-local" name="start" required />
                </div>
                <div class="col">
                    <label>To</label>
                    <input type="datetime-local" name="end" required />
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Description</label>
                    <textarea name="description" rows="4" placeholder="Description..."></textarea>
                </div>
            </div>
            <button type="submit" class="save-btn">Save</button>
        </form>

    </div>
</div>
<div class="modal2">
    <div class="modal-content">
        <span class="close2">&times;</span>
        <h2 class="con">Edit Appointment</h2>
        <form id="editEventForm">
            <div class="row">
                <div class="col">
                    <label>Title</label>
                    <input type="text" name="title" placeholder="Title" value="" required />
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>From</label>
                    <input type="datetime-local" name="start" value="" required />
                </div>
                <input type="hidden" name="id" value="" />
                <div class="col">
                    <label>To</label>
                    <input type="datetime-local" name="end" value="" required />
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Description</label>
                    <textarea name="description" rows="4"
                        value="" placeholder="Description..."></textarea>
                </div>
            </div>
            <button type="submit" class="save-btn">Update</button>
        </form>

    </div>
</div>

<!-- Main content -->
<div class="main">
    <!-- Mobile hamburger -->
    <?php include_once('./components/common_header.php') ?>

    <!-- Your page content goes here -->
    <section class="content" padding="2rem">
        <div class="tabs">
            <div style="align-items: center; display: flex">
                <span class="tab active"></span>
            </div>

            <button class="add-new-button">Add Appointment</button>
        </div>
        <div id="calendar" style="overflow-y: auto"></div>
    </section>
</div>
<?php include_once('./components/cashflow_footer.php') ?>
<script src="./fullcalendar.min.js"></script>
<?php $date = $_GET['date'];
if (!empty($date)) {


?>
    <style>
        .fc-day-today {
            background-color: white !important;
            color: white !important;
        }

        .fc-timegrid-slot {
            font-size: 1rem;
        }

        .fc-event {
            display: flex;
            flex-direction: column-reverse;
            background-color: #a2d896;
            color: black !important;
            padding: 2px 4px;
            border-radius: unset;
            font-size: 1rem;
            border: none;
            font-family: calibri;
            /* font-size: 15px; */
            font-weight: 400;
            color: #091e42;
            /* font-size: 12px; */
        }

        .fc-event:hover {
            background-color: #8ecf7c !important;
            cursor: pointer;
        }

        .fc .fc-scrollgrid-liquid {
            align-self: center;
            /* width: 90%; */

            height: 90%;
        }

        .fc-timegrid-body {

            height: 90%;
        }

        .fc-timegrid-cols {
            height: 90%;
        }
    </style>
    <script>
        let calendar;
        document.addEventListener("DOMContentLoaded", function() {
            const calendarEl = document.getElementById("calendar");
            calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: "timeGridDay",
                initialDate: '<?= $date ?>', // Start from 7 days ago
                allDaySlot: false,
                dayHeaders: false,
                locale: 'en',
                slotLabelFormat: {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true
                },
                slotMinTime: "07:00:00", // Optional: set your start time
                slotMaxTime: "20:30:00",
                headerToolbar: {
                    left: "",
                    center: "title",
                    right: ""
                },
                events: "backend/appointment/events-time.php",
                datesSet: function() {
                    // Remove old GMT row if exists
                    console.log('Dates set, updating GMT row');
                    const oldGmt = document.getElementById('fc-gmt-row');
                    if (oldGmt) oldGmt.remove();

                    setTimeout(function() {
                        let slotTable = document.querySelector('.fc-timegrid-slots table tbody');
                        if (!slotTable) {
                            slotTable = document.querySelector('.fc-scrollgrid-sync-table tbody');
                        }
                        if (slotTable) {
                            const gmtRow = document.createElement('tr');
                            gmtRow.id = 'fc-gmt-row';
                            const gmtCell = document.createElement('td');
                            gmtCell.className = 'fc-timegrid-slot fc-timegrid-slot-label';
                            gmtCell.style.textAlign = 'center';


                            // Get GMT offset in format GMT+01
                            const offset = -new Date().getTimezoneOffset() / 60;
                            const gmtString = 'GMT' + (offset >= 0 ? '+' : '') + offset.toString().padStart(2, '0');
                            gmtCell.textContent = gmtString;

                            gmtRow.appendChild(gmtCell);
                            slotTable.prepend(gmtRow);
                        }
                    }, 10);
                },
                eventContent: function(arg) {
                    // Create event title
                    const title = document.createElement('span');
                    title.textContent = arg.event.title + ' ';
                    title.style.cursor = 'pointer';
                    title.onclick = function(e) {
                        e.stopPropagation(); // Prevent triggering eventClick
                        openEditModal(arg.event); // Your function to open the edit modal
                    };

                    // Create X button
                    const xBtn = document.createElement('span');
                    xBtn.textContent = '✖';
                    xBtn.style.color = 'red';
                    xBtn.style.cursor = 'pointer';
                    xBtn.style.marginLeft = '4px';
                    xBtn.onclick = function(e) {
                        e.stopPropagation();
                        deleteEventById(arg.event.id); // Call your delete function
                    };

                    // Container
                    const container = document.createElement('span');
                    container.appendChild(title);
                    container.appendChild(xBtn);

                    return {
                        domNodes: [container]
                    };
                },

            });
            calendar.render();
            // After your calendar.render();


        });
        async function deleteEventById(id) {
            if (!id) {
                alert('Missing event ID');
                return;
            }
            if (!confirm('Are you sure you want to delete this event?')) return;
            try {
                const response = await fetch(`./backend/appointment/delete_events.php?id=${encodeURIComponent(id)}`);
                const result = await response.json();
                if (result.success) {
                    alert('Event deleted successfully.');
                    // Remove the event from the calendar
                    calendar.refetchEvents()
                    // Optionally, refresh your calendar or event list here
                } else {
                    alert(result.error || 'Failed to delete event.');
                }
            } catch (e) {
                alert('An error occurred while deleting the event.');
            }
        }

        function openEditModal(event) {

            // Get the form
            const form = document.getElementById('editEventForm');

            function toDatetimeLocal(dt) {
                // dt: Date object
                const offset = dt.getTimezoneOffset();
                const local = new Date(dt.getTime() - offset * 60000);
                return local.toISOString().slice(0, 16);
            }
            // Fill the fields
            form.elements['id'].value = event.id || '';
            form.elements['title'].value = event.title || '';
            form.elements['start'].value = event.start ?
                toDatetimeLocal(event.start) :
                '';
            form.elements['end'].value = event.extendedProps.todate ?
                event.extendedProps.todate :
                '';
            form.elements['description'].value = event.extendedProps.description || '';

            // Show the modal (example for your custom modal)
            document.querySelector('.modal2').style.display = 'block';
        }
        document.getElementById('editEventForm').addEventListener('submit', async function(e) {
            e.preventDefault();

            // Collect form data
            const form = e.target;
            const data = {
                id: form.elements['id'].value,
                title: form.elements['title'].value,
                start: form.elements['start'].value,
                end: form.elements['end'].value,
                description: form.elements['description'].value
            };

            // Send AJAX request to edit_time.php
            const response = await fetch('./backend/appointment/edit_time.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            const result = await response.json();

            if (result.success) {
                // Hide modal (adjust for your modal system)
                form.reset()
                document.querySelector('.modal2').style.display = 'none';


                alert('Event updated!');
                calendar.refetchEvents();

            } else {
                alert(result.error || 'Failed to update event.');
            }
        });
    </script>
<?php }  ?>