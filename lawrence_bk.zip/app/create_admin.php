<?php
include_once "settings/connection.php";

// Admin details
$firstname = 'Admin';
$lastname = 'User';
$email = 'admin@example.com';
$role = 'Admin';
$phonenumber = '1234567890';
$access = 'admin';
$plain_password = 'Admin@123';
$staff_id = 'STAFF001';
$position = 'Administrator';
$profile_picture = null; // can be a URL or base64 string if needed

// Hash password using bcrypt
$hashed_password = password_hash($plain_password, PASSWORD_BCRYPT);

// Prepare SQL statement
$stmt = $conn->prepare(
    "INSERT INTO staffs 
    (firstname, lastname, email, role, phonenumber, access, password, staff_id, position, profile_picture) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
);

$stmt->bind_param(
    "ssssssssss",
    $firstname,
    $lastname,
    $email,
    $role,
    $phonenumber,
    $access,
    $hashed_password,
    $staff_id,
    $position,
    $profile_picture
);

// Execute and check
if ($stmt->execute()) {
    echo "Admin user created successfully.";
} else {
    echo "Error: " . $stmt->error;
}

// Close connections
$stmt->close();
$conn->close();
