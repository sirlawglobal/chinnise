<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
  // Not logged in, redirect to login page
  header("Location: auth/login.php");
  exit;
}
?>

<?php include_once('./components/header.php') ?>
<div class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 class="con">New Appointment</h2>
    <form action="backend/appointment/save_appointment.php" method="POST" id="appointmentForm">
      <div class="row">
        <div class="col">
          <label>Title</label>
          <input type="text" name="title" placeholder="Title" required />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>From</label>
          <input type="datetime-local" name="start" required />
        </div>
        <div class="col">
          <label>To</label>
          <input type="datetime-local" name="end" required />
        </div>
      </div>
      <div class="row">
        <div class="col">
          <label>Description</label>
          <textarea name="description" rows="4" placeholder="Description..."></textarea>
        </div>
      </div>
      <button type="submit" class="save-btn">Save</button>
    </form>

  </div>
</div>

<!-- Main content -->
<div class="main">
  <!-- Mobile hamburger -->
  <?php include_once('./components/common_header.php') ?>

  <!-- Your page content goes here -->
  <section class="content" padding="2rem">
    <div class="tabs">
      <div style="align-items: center; display: flex">
        <span class="tab active"></span>
      </div>

      <button class="add-new-button">Add Appointment</button>
    </div>
    <div id="calendar" style="overflow-y: auto"></div>
  </section>
</div>
<?php include_once('./components/common_footer.php') ?>
<script src="./fullcalendar.min.js"></script>
<script src="./cals.js"></script>