<?php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error_log.txt'); // Log errors to a local file

require_once '../../config/db.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'PATCH') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Extract item ID from URI
$requestUri = $_SERVER['REQUEST_URI'];
$parts = explode('/', $requestUri);
$itemId = intval(end($parts));

if (!$itemId) {
    http_response_code(400); 
    echo json_encode(['success' => false, 'message' => 'Missing or invalid item ID']);
    exit;
}

try {
    // Capture raw input for debugging
    $rawInput = file_get_contents("php://input");
    error_log("RAW PATCH INPUT: " . $rawInput);

    // Parse input
    parse_str($rawInput, $data);
    error_log("PARSED DATA: " . print_r($data, true));

    // Sanitize and validate inputs
    $name = trim(filter_var($data['name'] ?? '', FILTER_SANITIZE_STRING));
    $price = filter_var($data['price'] ?? null, FILTER_VALIDATE_FLOAT);

    if (empty($name) || $price === false) {
        throw new Exception('Name and valid Price are required.');
    }

    // Prepare and execute update query
    $query = "UPDATE items SET name = :name, price = :price WHERE id = :id";
    $params = ['id' => $itemId, 'name' => $name, 'price' => $price];

    if (!db_query($query, $params)) {
        throw new Exception("Update failed: " . $GLOBALS['DB_STATE']['error']);
    }

    $response['success'] = true;
    $response['message'] = 'Item updated successfully';

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log("ERROR: " . $e->getMessage());
}

// Return JSON response
echo json_encode($response);
exit;
