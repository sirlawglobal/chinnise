-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 14, 2025 at 10:11 AM
-- Server version: 10.6.22-MariaDB-cll-lve-log
-- PHP Version: 8.3.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `soyoruba_restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `note` varchar(223) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `note`) VALUES
(1, 'STARTERS', '2025-06-03 14:26:00', ''),
(2, 'SOUP', '2025-06-03 14:26:00', '0'),
(3, 'CHICKEN', '2025-06-03 14:26:00', '0'),
(4, 'BEEF', '2025-06-03 14:26:00', '0'),
(5, 'LAMB', '2025-06-03 14:26:00', '0'),
(6, 'PORK & ROAST PORK', '2025-06-03 14:26:00', '0'),
(7, 'DUCK', '2025-06-03 14:26:00', '0'),
(8, 'SEAFOOD', '2025-06-03 14:26:00', '0'),
(9, 'KING PRAWNS', '2025-06-03 14:26:00', '0'),
(10, 'VEGETABLES', '2025-06-03 14:26:00', '0'),
(11, 'CHOP SUEY (BEANSPROUTS)', '2025-06-03 14:26:00', '0'),
(12, 'SWEET & SOUR', '2025-06-03 14:26:00', '0'),
(13, 'CURRY', '2025-06-03 14:26:00', '0'),
(14, 'RICE', '2025-06-03 14:26:00', 'LARGE EXTRA £'),
(15, 'NOODLES', '2025-06-03 14:26:00', 'LARGE EXTRA £'),
(16, 'NOODLE SOUP', '2025-06-03 14:26:00', '0'),
(17, 'OMELETTE', '2025-06-03 14:26:00', '0'),
(18, 'EXTRAS & DESSERTS', '2025-06-03 14:26:00', '0'),
(19, 'SPECIAL HOUSE MEALS', '2025-06-03 14:26:00', 'All Served in One Container with Boiled Rice (Noodle or Egg Fried Rice 50p Extra)'),
(20, 'SET MENU', '2025-06-03 14:26:00', '0');

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL,
  `message_id` int(11) DEFAULT NULL,
  `text` text NOT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_read` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `message_id`, `text`, `is_admin`, `created_at`, `is_read`) VALUES
(1, 1, 'how are you', 1, '2025-06-10 08:18:24', 0),
(4, 3, 'hi', 1, '2025-06-10 14:25:06', 0),
(9, 3, 'hi', 1, '2025-06-10 14:25:15', 0),
(13, 4, 'sampje', 0, '2025-07-08 17:04:35', 1),
(14, 4, 'dddd', 1, '2025-07-10 18:01:17', 0),
(15, 4, 'dddddd', 1, '2025-07-10 18:01:25', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ev_categories`
--

CREATE TABLE `ev_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ev_categories`
--

INSERT INTO `ev_categories` (`id`, `name`, `slug`) VALUES
(1, 'Meetings', 'meetings'),
(2, 'Menu Updates', 'menu'),
(3, 'Inventory Checks', 'inventory'),
(4, 'Events', 'events');

-- --------------------------------------------------------

--
-- Table structure for table `inves_categories`
--

CREATE TABLE `inves_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inves_categories`
--

INSERT INTO `inves_categories` (`id`, `name`, `created_at`) VALUES
(1, 'Ketchen tools', '2025-06-11 08:23:39'),
(2, 'Food ingredients', '2025-06-11 08:23:39'),
(3, 'others', '2025-06-11 08:23:39'),
(5, 'Hello', '2025-07-08 13:07:45'),
(6, 'MEchanical Testing', '2025-07-08 14:10:39'),
(7, 'MEchanical Testing 3', '2025-07-08 14:10:39'),
(8, 'Smapel11', '2025-07-10 17:16:04');

-- --------------------------------------------------------

--
-- Table structure for table `inves_orders`
--

CREATE TABLE `inves_orders` (
  `id` int(11) NOT NULL,
  `order_id` varchar(20) NOT NULL COMMENT 'Format P10001',
  `order_date` date NOT NULL,
  `vendor_supplier` varchar(255) NOT NULL,
  `status` enum('pending','shipped','delivered') NOT NULL DEFAULT 'pending',
  `delivery_date` date DEFAULT NULL,
  `unit_price` decimal(6,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(6,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inves_orders`
--

INSERT INTO `inves_orders` (`id`, `order_id`, `order_date`, `vendor_supplier`, `status`, `delivery_date`, `unit_price`, `quantity`, `total_price`, `created_at`) VALUES
(27, 'P27712', '2025-07-03', 'wrer', 'pending', '2025-07-10', 0.00, 0, 9999.99, '2025-07-03 11:58:57'),
(28, 'P51792', '2025-07-03', 'Mma Bus', 'pending', '2025-07-10', 0.00, 0, 900.00, '2025-07-03 12:43:52'),
(29, 'PO10029', '2025-07-03', 'Mma Bus', 'pending', '2025-07-10', 0.00, 0, 1936.00, '2025-07-03 14:16:59'),
(30, 'PO10030', '2025-07-03', 'Mma Bus', 'pending', '2025-07-10', 0.00, 0, 1936.00, '2025-07-03 14:20:28'),
(31, 'PO10031', '2025-07-05', 'Accusantium optio s', 'pending', '2025-07-12', 0.00, 0, 9999.99, '2025-07-05 17:20:26'),
(32, 'PO10032', '2025-07-05', 'Expedita nostrum aut', 'pending', '2025-07-12', 0.00, 0, 9999.99, '2025-07-05 17:23:02'),
(33, 'PO10033', '2025-07-06', 'ASDFGHJ', 'pending', '2025-07-13', 0.00, 0, 144.00, '2025-07-06 16:59:20'),
(34, 'PO10034', '2025-07-08', 'rrg', 'pending', '2025-07-15', 0.00, 0, 1496.00, '2025-07-08 09:12:40'),
(35, 'PO10035', '2025-07-08', '123', 'pending', '2025-07-15', 0.00, 0, 9999.99, '2025-07-08 09:51:28'),
(36, 'PO10036', '2025-07-08', '123', 'pending', '2025-07-15', 0.00, 0, 9999.99, '2025-07-08 10:03:45'),
(37, 'PO10037', '2025-07-08', '123', 'pending', '2025-07-15', 0.00, 0, 9999.99, '2025-07-08 10:05:00'),
(38, 'PO10038', '2025-07-08', '123', 'pending', '2025-07-15', 0.00, 0, 9999.99, '2025-07-08 10:07:48'),
(39, 'PO10039', '2025-07-08', '123', 'pending', '2025-07-15', 0.00, 0, 9999.99, '2025-07-08 10:08:16'),
(40, 'PO10040', '2025-07-08', '123', 'pending', '2025-07-15', 0.00, 0, 9999.99, '2025-07-08 10:10:31'),
(41, 'PO10041', '2025-07-08', 'dniela', 'pending', '2025-07-15', 0.00, 0, 1496.00, '2025-07-08 10:13:59'),
(42, 'PO10042', '2025-07-08', '123', 'pending', '2025-07-15', 0.00, 0, 121.00, '2025-07-08 10:18:46'),
(43, 'PO10043', '2025-07-08', '123', 'pending', '2025-07-15', 0.00, 0, 9999.99, '2025-07-08 10:42:07'),
(44, 'PO10044', '2025-07-08', '123', 'pending', '2025-07-15', 0.00, 0, 9999.99, '2025-07-08 13:07:45'),
(46, 'PO10046', '2025-07-09', 'Tosin mic', 'delivered', '2025-06-12', 5.00, 4, 20.00, '2025-07-09 15:40:31'),
(48, 'PO10047', '2025-07-10', 'Tosin mic', 'delivered', '2025-06-12', 12.00, 1, 12.00, '2025-07-10 17:16:04');

-- --------------------------------------------------------

--
-- Table structure for table `inves_order_items`
--

CREATE TABLE `inves_order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `vendor` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` enum('pending','shipped','delivered') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inves_order_items`
--

INSERT INTO `inves_order_items` (`id`, `order_id`, `item_name`, `vendor`, `category_id`, `price`, `quantity`, `status`, `created_at`) VALUES
(42, 26, 'Chicken Breast', '', 1, 43.00, 444, 'pending', '2025-07-03 10:31:16'),
(43, 27, 'Chicken Breast', 'wrer', 1, 5656.00, 6565, 'pending', '2025-07-03 11:58:57'),
(44, 28, 'Tomatoes', 'Mma Bus', 1, 45.00, 20, 'pending', '2025-07-03 12:43:52'),
(45, 29, 'Tomatoes', 'Mma Bus', 1, 44.00, 44, 'pending', '2025-07-03 14:16:59'),
(46, 30, 'Rodo', 'Mma Bus', 2, 44.00, 44, 'pending', '2025-07-03 14:20:28'),
(47, 31, 'Rodo', 'Accusantium optio s', 2, 667.00, 536, 'pending', '2025-07-05 17:20:26'),
(48, 32, 'Tomatoes', 'Expedita nostrum aut', 1, 81.00, 530, 'pending', '2025-07-05 17:23:02'),
(49, 33, 'Tomatoes', 'ASDFGHJ', 1, 12.00, 12, 'pending', '2025-07-06 16:59:20'),
(50, 34, 'Epo', 'rrg', 2, 44.00, 34, 'pending', '2025-07-08 09:12:40'),
(51, 35, 'Hi', '123', 1, 222.00, 332, 'pending', '2025-07-08 09:51:28'),
(52, 36, 'Hi', '123', 0, 222.00, 332, 'pending', '2025-07-08 10:03:45'),
(53, 37, 'Hi', '123', 0, 222.00, 332, 'pending', '2025-07-08 10:05:00'),
(54, 38, 'Hi', '123', 0, 222.00, 332, 'pending', '2025-07-08 10:07:48'),
(55, 39, 'Hi', '123', 0, 222.00, 332, 'pending', '2025-07-08 10:08:16'),
(56, 40, 'Hi', '123', 0, 222.00, 332, 'pending', '2025-07-08 10:10:31'),
(57, 41, 'testcus', 'dniela', 0, 44.00, 34, 'pending', '2025-07-08 10:13:59'),
(58, 42, 'oli', '123', 2, 11.00, 11, 'pending', '2025-07-08 10:18:46'),
(59, 43, 'Hi', '123', 0, 222.00, 332, 'pending', '2025-07-08 10:42:07'),
(60, 44, 'Hi', '123', 5, 222.00, 332, 'pending', '2025-07-08 13:07:45'),
(61, 45, 'Testing MEch', 'Tosin mic', 6, 3000.00, 3, 'shipped', '2025-07-08 14:10:39'),
(62, 45, 'Testing MEch 2', 'Tosin Mic', 7, 1000.00, 5, 'pending', '2025-07-08 14:10:39'),
(63, 46, 'Testing MEch', 'Tosin mic', 5, 4.00, 3, 'pending', '2025-07-09 15:40:31'),
(64, 46, 'Plegde to be paid before next month', 'Tosin Mic', 5, 5.00, 4, 'shipped', '2025-07-09 15:40:31'),
(65, 47, 'Testing MEch', '123', 7, 222.00, 332, 'pending', '2025-07-09 16:46:50'),
(66, 48, 'Testing MEch', 'Tosin mic', 8, 12.00, 1, 'pending', '2025-07-10 17:16:04');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `reorder_quantity` int(11) DEFAULT 0,
  `stock_quantity` int(11) DEFAULT 0,
  `has_options` tinyint(1) DEFAULT 0,
  `is_set_menu` tinyint(1) DEFAULT 0,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `category_id`, `name`, `description`, `price`, `reorder_quantity`, `stock_quantity`, `has_options`, `is_set_menu`, `image_url`, `created_at`) VALUES
(11, 20, 'Crispy seaweed', NULL, 0.00, 0, 0, 0, 1, NULL, '2025-07-14 13:42:03'),
(13, 20, 'crispy Seaweed', 'MENU C- F0R 2 PERSONS', 0.00, 0, 0, 0, 1, NULL, '2025-07-14 13:49:04'),
(14, 20, 'Crispy Seaweed', 'MENU D- FOR 2 PERSONS', 0.00, 0, 0, 0, 1, NULL, '2025-07-14 13:51:14'),
(15, 20, 'Crispy Seaweed', 'MENU E- FOR 3 PERSONS', 0.00, 0, 0, 0, 1, NULL, '2025-07-14 13:52:40'),
(16, 1, 'Crispy Aromatic Duck', '( With Pancakes, spring Onions, Cucumber & Plum Sauce)', 0.00, 0, 0, 1, 0, NULL, '2025-07-14 13:59:34'),
(17, 1, 'Mixed Platter (min for 2)', '(Seaweed, Sesame Prawn On Toast, Chicken Satay, Barbecued Spare Ribs, Vegetarian Spring Rolls)', 14.80, 0, 0, 0, 0, NULL, '2025-07-14 14:00:42'),
(18, 1, 'Crispy Seaweed', NULL, 5.50, 0, 0, 0, 0, NULL, '2025-07-14 14:01:54'),
(19, 1, 'Sesame Prawn On Toast', NULL, 7.00, 0, 0, 0, 0, NULL, '2025-07-14 14:02:14'),
(20, 6, 'Pork with Green Pepper in Black Bean Sauce', NULL, 7.30, 0, 0, 0, 0, NULL, '2025-07-14 14:04:54'),
(21, 6, 'Pork with Mixed Vegetables', NULL, 7.30, 0, 0, 0, 0, NULL, '2025-07-14 14:05:44'),
(22, 6, 'Pork with Mushrooms', NULL, 7.30, 0, 0, 0, 0, NULL, '2025-07-14 14:06:02'),
(23, 6, 'Pork with Ginger & Spring Onions in Oyster Sauce', NULL, 7.30, 0, 0, 0, 0, NULL, '2025-07-14 14:06:26'),
(24, 6, 'Pork with Cashewnuts', NULL, 7.50, 0, 0, 0, 0, NULL, '2025-07-14 14:09:50'),
(25, 6, 'Pork with Cashewnuts in Yellow Bean Sauce', NULL, 7.50, 0, 0, 0, 0, NULL, '2025-07-14 14:10:24'),
(26, 6, 'Pork Chop in Mandarin Sauce', NULL, 8.50, 0, 0, 0, 0, NULL, '2025-07-14 14:10:44'),
(27, 6, 'Pork Chop in Honey Sauce', NULL, 8.50, 0, 0, 0, 0, NULL, '2025-07-14 14:11:05'),
(28, 6, 'Roast Pork with Onions', NULL, 7.80, 0, 0, 0, 0, NULL, '2025-07-14 14:11:22'),
(29, 6, 'Roast Pork (Char Siu) in Tasty Soya Sauce', NULL, 8.80, 0, 0, 0, 0, NULL, '2025-07-14 14:11:43');

-- --------------------------------------------------------

--
-- Table structure for table `item_options`
--

CREATE TABLE `item_options` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `portion` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `item_options`
--

INSERT INTO `item_options` (`id`, `item_id`, `portion`, `price`) VALUES
(7, 16, '1/4 (6 Pancakes)', 13.50),
(8, 16, '1/2 (12 Pancakes)', 21.80),
(9, 16, 'Whole (24 pancakes) (', 36.80);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `status` enum('sent','failed','read','pending','replied','closed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `telephone`, `message`, `status`, `created_at`) VALUES
(1, 'Balogun Ayomiposi', 'balpos07@gmail.com', '09157874468', 'how are you', 'replied', '2025-06-10 08:18:24'),
(2, 'Charles', 'charlesebuka162@gmail.com', '5656677734', 'please help okay', 'sent', '2025-06-10 08:20:36'),
(3, 'Balogun Ayomiposi', 'charlesebuka162@gmail.com', '09157874468', 'hi', 'replied', '2025-07-10 14:01:51'),
(4, 'Gbenga', 'ayodeleoluwagbemiga2@gmail.com', '09060288600', 'dddddd', 'replied', '2025-07-10 14:01:25');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tx_ref` varchar(50) NOT NULL,
  `delivery_address` text NOT NULL,
  `order_notes` text DEFAULT NULL,
  `order_type` enum('now','schedule') NOT NULL,
  `schedule_date` date DEFAULT NULL,
  `schedule_time` time DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','completed','processing','cancelled') DEFAULT 'pending',
  `transaction_id` varchar(50) DEFAULT NULL,
  `guest_email` varchar(255) DEFAULT NULL,
  `guest_name` varchar(223) DEFAULT NULL,
  `guest_phone` varchar(223) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_email` varchar(255) DEFAULT NULL,
  `user_name` varchar(223) DEFAULT NULL,
  `user_phone` varchar(225) DEFAULT NULL,
  `order_type2` enum('Online','Telephone','Walk-in') NOT NULL DEFAULT 'Online'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `tx_ref`, `delivery_address`, `order_notes`, `order_type`, `schedule_date`, `schedule_time`, `total_amount`, `status`, `transaction_id`, `guest_email`, `guest_name`, `guest_phone`, `created_at`, `user_email`, `user_name`, `user_phone`, `order_type2`) VALUES
(44, NULL, 'ADM_ :TRF_9826203', '196 High Road', '', 'now', NULL, NULL, 456.00, 'completed', NULL, 'admin@admin.com', 'Tosin Esohe', '09034600436', '2025-07-10 15:39:53', NULL, NULL, NULL, 'Online'),
(45, 19, 'GD_324024336_1752162200131', '', 'Sample address', 'now', NULL, NULL, 470.00, 'pending', NULL, '', '', '', '2025-07-10 15:44:33', 'ayodeleoluwagbemiga2@gmail.com', 'G1280', '09060288600', 'Online'),
(46, 2, 'GD_12278088_1752162908098', 'edded', 'ddeedeed', 'now', NULL, NULL, 355.00, 'pending', NULL, '', '', '', '2025-07-10 15:55:10', 'admin@gmail.com', 'mike', '08165999946', 'Online'),
(47, NULL, 'ADM_ :TRF_5241196', '21 Diran Alake', '', 'now', NULL, NULL, 91.44, 'completed', NULL, 'admin@example.com', 'Sample Meal Test Meal', '09034600436', '2025-07-10 15:59:33', NULL, NULL, NULL, 'Telephone'),
(48, NULL, 'ADM_ :TRF_8049582', 'lagere', '', 'now', NULL, NULL, 529.00, 'pending', NULL, 'admin@gmail.com', 'lawrence akanji', '08165999946', '2025-07-11 08:20:10', NULL, NULL, NULL, 'Online'),
(49, NULL, 'ADM_ :TRF_2650153', 'lagere', '', 'now', NULL, NULL, 759.00, 'processing', NULL, 'admin@gmail.com', 'lawrence akanji', '08165999946', '2025-07-11 08:27:49', NULL, NULL, NULL, 'Walk-in'),
(50, NULL, 'ADM_ :TRF_7850300', 'lagere', '', 'now', NULL, NULL, 759.00, 'processing', NULL, 'admin@gmail.com', 'lawrence akanji', '08165999946', '2025-07-11 08:28:45', NULL, NULL, NULL, 'Walk-in'),
(51, NULL, 'ADM_ :TRF_0083635', 'lagere', '', 'now', NULL, NULL, 782.00, 'pending', NULL, 'admin@gmail.com', 'lawrence akanji', '08165999946', '2025-07-11 08:30:35', NULL, NULL, NULL, 'Online'),
(52, NULL, 'ADM_ :TRF_2043784', 'lagere', '', 'now', NULL, NULL, 1012.00, 'pending', NULL, 'admin@gmail.com', 'lawrence akanji', '08165999946', '2025-07-11 08:34:25', NULL, NULL, NULL, 'Walk-in');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `portion` varchar(50) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `item_name`, `portion`, `category_id`, `price`, `quantity`) VALUES
(10, 6, 'Beef with Green Pepper in Black Bean Sauce', 'standard', 0, 7.30, 1),
(11, 7, 'Beef with Green Pepper in Black Bean Sauce', 'standard', 0, 7.30, 1),
(12, 8, 'Beef with Green Pepper in Black Bean Sauce', 'standard', 0, 7.30, 1),
(13, 9, 'Beef with Green Pepper in Black Bean Sauce', 'standard', 0, 7.30, 1),
(29, 23, 'King Prawn Omelette', NULL, 17, 8.30, 4),
(30, 24, 'Plain Chow Mein', NULL, 15, 5.30, 2),
(31, 25, 'Duck with Pineapple', NULL, 7, 9.50, 5),
(32, 26, 'King Prawn Omelette', NULL, 17, 8.30, 5),
(33, 27, 'Pork with Green Pepper in Black Bean Sauce', NULL, 6, 7.30, 4),
(34, 28, 'Pork Chow Mein', NULL, 15, 6.80, 5),
(35, 29, 'Duck with Pineapple', NULL, 7, 9.50, 3),
(36, 32, 'Fillet Steak in Mandarin Sauce', 'standard', 4, 13.80, 1),
(37, 33, 'Beef with Cashewnuts', 'standard', 4, 7.50, 1),
(38, 35, 'Special Chop Suey', 'standard', 11, 6.80, 1),
(39, 36, 'Duck with Cashewnuts', NULL, 7, 9.50, 5),
(40, 37, 'Beef with Cashewnuts', 'standard', 4, 7.50, 2),
(41, 38, 'souptest', 'standard', 2, 345.00, 1),
(42, 39, 'startertest', NULL, 1, 23.00, 4),
(43, 40, 'startertests', NULL, 1, 23.00, 33),
(44, 41, 'startertests', NULL, 1, 23.00, 33),
(45, 42, 'startertests', NULL, 1, 23.00, 33),
(46, 43, 'startertests', NULL, 1, 23.00, 3445),
(47, 44, 'Maxine Holcomb', NULL, 4, 111.00, 3),
(48, 44, 'Ima Gardner', NULL, 3, 123.00, 1),
(49, 45, 'souptest', 'standard', 2, 345.00, 1),
(50, 45, 'Ima Gardner', 'standard', 3, 123.00, 1),
(51, 46, 'Maxine Holcomb', 'standard', 4, 111.00, 2),
(52, 47, 'startertests', NULL, 1, 23.00, 1),
(53, 47, 'testsoup', NULL, 2, 34.22, 2),
(54, 48, 'startertests', NULL, 1, 23.00, 23),
(55, 49, 'startertests', NULL, 1, 23.00, 33),
(56, 50, 'startertests', NULL, 1, 23.00, 33),
(57, 51, 'startertests', NULL, 1, 23.00, 34),
(58, 52, 'startertests', NULL, 1, 23.00, 44);

-- --------------------------------------------------------

--
-- Table structure for table `order_sequence`
--

CREATE TABLE `order_sequence` (
  `id` int(11) NOT NULL,
  `last_number` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `order_sequence`
--

INSERT INTO `order_sequence` (`id`, `last_number`) VALUES
(1, 1000);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `dish_id` int(11) NOT NULL,
  `dish_name` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `reviewer_name` varchar(100) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` >= 1 and `rating` <= 5),
  `review_text` text NOT NULL,
  `review_date` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `start_time` varchar(10) DEFAULT NULL,
  `end_time` varchar(10) DEFAULT NULL,
  `team` text DEFAULT NULL,
  `venue` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `user_id`, `title`, `date`, `start_time`, `end_time`, `team`, `venue`, `notes`, `created_at`, `category_id`) VALUES
(1, 1, 'Weekly Specials Review', '2025-06-14', '15:00', '16:00', '[\"HC\", \"SC\", \"+3\"]', 'Kitchen', 'Finalize weekly specials.', '2025-06-12 17:37:05', 3),
(2, 1, 'Inventory Check', '2025-06-15', '10:00', '11:30', '[\"JM\", \"AO\"]', 'Store Room', 'Review current stock.', '2025-06-12 17:37:05', 2),
(3, 1, 'Morning Briefing', '2025-06-16', '09:00', '09:30', '[\"HC\", \"Team Lead\"]', 'Meeting Room 1', 'Discuss daily goals.', '2025-06-12 17:37:05', 1),
(4, 1, 'Vendor Meeting', '2025-06-17', '13:00', '14:00', '[\"MD\", \"Procurement Team\"]', 'Office', 'Talk with new vegetable suppliers.', '2025-06-12 17:37:05', 1),
(5, 1, 'Seasonal Tasting', '2025-06-18', '11:00', '12:00', '[\"SC\", \"Kitchen Team\"]', 'Kitchen', 'Try out seasonal menu options.', '2025-06-12 17:37:05', 3),
(7, 2, 'Customer Feedback Review', '2025-06-20', '16:00', '17:00', '[\"MD\",\"HC\"]', 'Conference Room', 'Review customer feedback forms.', '2025-06-12 17:37:05', 3),
(8, 2, 'Fridge Maintenance', '2025-06-21', '08:30', '09:30', '[\"Maintenance Team\"]', 'Cold Room', 'Check fridge status.', '2025-06-12 17:37:05', 2),
(9, 2, 'Weekly Review', '2025-06-22', '10:00', '11:00', '[\"SC\", \"HC\", \"+2\"]', 'Office', 'Weekly progress review.', '2025-06-12 17:37:05', 3),
(10, 2, 'Birthday Celebration', '2025-06-23', '17:00', '18:00', '[\"All Staff\"]', 'Lounge', 'Celebrate staff birthdays.', '2025-06-12 17:37:05', 1),
(11, 2, 'letseded2ww', '2025-06-11', '12:30', '12:02', '[\"letds\"]', 'let', 'letd', '2025-06-12 17:57:35', 3),
(12, 1, 'let1', '2025-06-12', '12:30', '22:02', '[\"let2\"]', 'jdd', 'xjs', '2025-06-12 18:13:54', 3),
(13, 19, 'New', '2025-07-01', '12:30', '11:56', '[\"Team\"]', 'Ikeja', 'sample', '2025-07-10 10:51:43', 2),
(14, 2, 'axaxa', '2025-07-16', '12:33', '18:05', '[\"axa\"]', 'xax', 'xaax', '2025-07-10 14:02:30', 2),
(15, 2, 'fddf', '2025-07-24', '17:35', '20:15', '[\"ddfdf\"]', 'fd', 'dfd', '2025-07-10 14:10:35', 1),
(16, 2, 'cssc', '2025-07-18', '12:30', '20:16', '[\"sccs\"]', 'cscs', 'csc', '2025-07-10 14:11:22', 1),
(17, 2, 'sdssd', '2025-07-11', '12:30', '18:12', '[\"dsds\"]', 'sdds', 'sdd', '2025-07-10 14:12:30', 2),
(18, 2, 'sdds', '2025-07-31', '12:30', '19:13', '[\"dsd\"]', 'dss', 'sdds', '2025-07-10 14:13:16', 2),
(19, 2, 'dcddc', '2025-08-01', '12:36', '20:18', '[\"dcdccd\"]', 'cdcd', 'dccd', '2025-07-10 14:14:09', 1),
(20, 2, 'deed', '2025-07-25', '12:30', '21:20', '[\"dee\"]', 'ede', 'dede', '2025-07-10 14:16:59', 2),
(21, 2, 'zsccs', '2025-07-24', '12:30', '18:17', '[\"ssc\"]', 'sccs', 'sccscs', '2025-07-10 14:18:00', 2),
(22, 2, 'qqq', '2025-07-24', '12:30', '15:21', '[]', '', '', '2025-07-10 14:19:19', 1),
(23, 2, 'ssxs', '2025-07-25', '15:33', '20:57', '[\"sss\"]', 'cssc', 'sssc', '2025-07-10 14:53:15', 2),
(24, 2, '12344555', '2025-07-18', '12:30', '20:08', '[\"aweda\"]', 'weee', 'aass', '2025-07-10 15:08:24', 2),
(25, 2, '12', '2025-07-31', '12:30', '16:22', '[\"sss\"]', 'sss', 'sss', '2025-07-10 15:18:13', 2),
(26, 2, 'aaa', '2025-07-25', '12:30', '20:20', '[\"swww\"]', 'www', 'www', '2025-07-10 15:20:40', 1),
(27, 2, 'ddd', '2025-07-30', '12:30', '18:20', '[\"ddd\"]', 'ddd', 'dd', '2025-07-10 15:20:59', 1);

-- --------------------------------------------------------

--
-- Table structure for table `set_menus`
--

CREATE TABLE `set_menus` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `items` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `set_menus`
--

INSERT INTO `set_menus` (`id`, `item_id`, `name`, `price`, `items`) VALUES
(10, 11, 'MENU B- FOR 2 PERSONS', 25.80, '[\"Crispy seaweed\",\"Sesame Prawns on Toast\",\"Chicken with Cashewnuts in Yellow Bean Sauce\",\"Sweet &amp; Sour Pork (Hong Kong Style)\",\"Special Fried Rice\"]'),
(12, 13, 'MENU C- F0R 2 PERSONS', 36.80, '[\"crispy Seaweed\",\"Sesame Prawn on Toast\",\"Kung po Chicken\",\"Beef with Mixed Vegetables\",\"Roasted Port in Tasty Soya sauce\",\"Special Fried Rice.\"]'),
(13, 14, 'MENU D- FOR 2 PERSONS', 42.80, '[\"crispy Seaweed\",\"Satay Chicken on skewer(4)\\nSalt &amp; Pepper Spare Ribs\",\"Chicken with Ginger &amp; Spring Onions in Oyster sauce\",\"Beef with Cashenuts\",\"Sweet &amp; Sour Pork\",\"Special Fried Rice\"]'),
(14, 15, 'MENU E- FOR 3 PERSONS', 51.80, '[\"crispy Seaweed\",\"Sesame Prawn on Toast\\nSpare Ribs in Mandarin Sauce\",\"Crispy Aromatic Duck with Pancakes\",\"Crispy Chilli Beef\",\"Chicken in Black Bean sauce\",\"Pork with Cashewnuts\",\"Special Fried Rice\"]');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL COMMENT 'last updtd qty frm qtyDlv',
  `record_qty` varchar(220) DEFAULT NULL,
  `cat_id` varchar(225) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `name` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `category_id`, `qty`, `record_qty`, `cat_id`, `updated_at`, `created_at`, `name`) VALUES
(49, 1, '90', '140', NULL, '2025-07-08 19:56:01', '2025-07-08 19:55:32', 'Oil'),
(50, 2, '120', '270', NULL, '2025-07-08 20:01:50', '2025-07-08 19:56:25', 'Epo'),
(51, 5, '60', '60', NULL, '2025-07-09 19:38:13', '2025-07-09 19:38:13', 'Plegde to be paid before next month');

-- --------------------------------------------------------

--
-- Table structure for table `stock_history`
--

CREATE TABLE `stock_history` (
  `id` int(11) NOT NULL,
  `stock_id` int(11) NOT NULL,
  `old_qty` int(11) NOT NULL,
  `new_qty` int(11) NOT NULL,
  `qty_change` int(11) NOT NULL,
  `change_date` datetime NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `changed_by` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_history`
--

INSERT INTO `stock_history` (`id`, `stock_id`, `old_qty`, `new_qty`, `qty_change`, `change_date`, `notes`, `changed_by`) VALUES
(33, 49, 0, 50, 50, '2025-07-08 15:55:32', 'Initial stock entry', NULL),
(34, 49, 50, 90, 90, '2025-07-08 15:56:01', 'Manual update via form - added 90 items', NULL),
(35, 50, 0, 80, 80, '2025-07-08 15:56:25', 'Initial stock entry', NULL),
(36, 50, 80, 70, 70, '2025-07-08 16:00:54', 'Manual update via form - added 70 items', NULL),
(37, 50, 70, 120, 120, '2025-07-08 16:01:50', 'Manual update via form - added 120 items', NULL),
(38, 51, 0, 60, 60, '2025-07-09 15:38:13', 'Initial stock entry', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` enum('admin','staff','chef','waiter','cashier','manager','user','dishwasher','delivery','bartender','user') DEFAULT 'user',
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `role`, `password`, `created_at`) VALUES
(2, 'mike ', '08165999946', 'admin@gmail.com', 'admin', '$2y$10$xWzmpjvLkhzqCPplcK/SG.3wL1PPR8KZOvQHCvPXILuUrKvruP56W', '2025-06-06 16:22:26'),
(19, 'G128 gn122', '09060288600', 'ayodeleoluwagbemiga2@gmail.com', 'admin', '$2y$10$6ygU0skZsQRhX3D6g7i9ye.JGjL6//6Pj6Zesk6UVgd2hJJEGgo2G', '2025-07-09 16:24:51'),
(22, 'htest htest2', '08165999946', 'htest@eh.org.ng', 'admin', '$2y$10$2TKLVLxWZIDx8HL0JdVHNevF9jY65gAhWbjvrPKPVrhxgNTUOvwq6', '2025-07-10 05:55:29'),
(23, 'law test', '08165999946', 'lawtest@t.com', 'admin', '$2y$10$63/A5kWV6WnwGHaRvZBwa.onUUbB4hxeTH5HrbTx4vqFeX59XJEwK', '2025-07-10 05:56:21'),
(24, 'G1280 GEN1280 ', '', 'tessanota@ehicentre.org.ng', 'admin', '$2y$10$AZNkGFtASwIY5vsGG3YtIeXdiqwibl7B84jF4MnsxiYfmANBwUm6K', '2025-07-10 11:12:59'),
(25, 'slg slg2', '0816599994644', 'slg@gmail.com', 'admin', '$2y$10$JUsmyOfdpq.A6CFD.nwyGeT6.BZIM6m1LLhQ6ZJTn3TnZEVKRTtVu', '2025-07-14 11:05:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_message_id` (`message_id`);

--
-- Indexes for table `ev_categories`
--
ALTER TABLE `ev_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inves_categories`
--
ALTER TABLE `inves_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inves_orders`
--
ALTER TABLE `inves_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inves_order_items`
--
ALTER TABLE `inves_order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item_options`
--
ALTER TABLE `item_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tx_ref` (`tx_ref`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `order_sequence`
--
ALTER TABLE `order_sequence`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dish_id` (`dish_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `set_menus`
--
ALTER TABLE `set_menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock_history`
--
ALTER TABLE `stock_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stock_id` (`stock_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `ev_categories`
--
ALTER TABLE `ev_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `inves_categories`
--
ALTER TABLE `inves_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `inves_orders`
--
ALTER TABLE `inves_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `inves_order_items`
--
ALTER TABLE `inves_order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `item_options`
--
ALTER TABLE `item_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `set_menus`
--
ALTER TABLE `set_menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `stock_history`
--
ALTER TABLE `stock_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD CONSTRAINT `fk_message_id` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `stock_history`
--
ALTER TABLE `stock_history`
  ADD CONSTRAINT `stock_history_ibfk_1` FOREIGN KEY (`stock_id`) REFERENCES `stock` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
