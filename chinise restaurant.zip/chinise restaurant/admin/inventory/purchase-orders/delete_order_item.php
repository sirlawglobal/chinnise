<?php
require_once __DIR__ . '/../../../BackEnd/config/init.php';

header("Content-Type: application/json");

// Get and log input data
$rawInput = file_get_contents('php://input');
error_log("Raw input for delete: " . $rawInput);
$input = json_decode($rawInput, true);
error_log("Decoded input for delete: " . print_r($input, true));

// Validate input
if (!isset($input['order_id'])) {
    error_log("Invalid input: order_id missing");
    echo json_encode(['success' => false, 'message' => 'Invalid order ID']);
    exit;
}

// Just trim and use the full order_id (like "PO10047")
$orderId = trim($input['order_id']);
error_log("Using raw order_id: $orderId");

try {
    // Validate order exists
    $checkSql = "SELECT COUNT(*) AS count FROM inves_orders WHERE order_id = :order_id";
    $checkResult = db_query($checkSql, [':order_id' => $orderId]);
    if ($checkResult === false) {
        error_log("Database query failed for order_id $orderId: " . ($GLOBALS['DB_STATE']['error'] ?? 'No error details'));
        throw new Exception("Database query failed");
    }
    if (empty($checkResult) || !isset($checkResult[0]) || $checkResult[0]->count == 0) {
        error_log("Order ID $orderId not found in database");
        throw new Exception("Order ID $orderId not found");
    }

    // Delete from inves_order_items (using order_id too)
    $itemSql = "DELETE FROM inves_order_items WHERE order_id = :order_id";
    $itemResult = db_query($itemSql, [':order_id' => $orderId]);
    if ($itemResult === false) {
        error_log("Failed to delete items for order_id $orderId: " . ($GLOBALS['DB_STATE']['error'] ?? 'No error'));
        throw new Exception("Failed to delete order items: " . ($GLOBALS['DB_STATE']['error'] ?? 'Unknown error'));
    }
    error_log("Deleted items for order_id: $orderId");

    // Delete from inves_orders using order_id
    $orderSql = "DELETE FROM inves_orders WHERE order_id = :order_id";
    $orderResult = db_query($orderSql, [':order_id' => $orderId]);
    if ($orderResult === false) {
        error_log("Failed to delete order $orderId: " . ($GLOBALS['DB_STATE']['error'] ?? 'No error details'));
        throw new Exception("Failed to delete order: " . ($GLOBALS['DB_STATE']['error'] ?? 'Unknown error'));
    }
    error_log("Deleted order_id: $orderId");

    echo json_encode([
        'success' => true,
        'message' => 'Order deleted successfully'
    ]);
} catch (Exception $e) {
    error_log("Exception in delete_order_item: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
