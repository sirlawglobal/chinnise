<?php
require_once __DIR__ . '/../../../BackEnd/config/init.php';
header("Content-Type: application/json");

// Get and log input data
$rawInput = file_get_contents('php://input');
error_log("Raw input for update: " . $rawInput);
$input = json_decode($rawInput, true);
error_log("Decoded input for update: " . print_r($input, true));

// Validate input
if (!isset($input['order_id']) || !isset($input['items']) || empty($input['items'])) {
    error_log("Invalid input: order_id or items missing/empty");
    echo json_encode(['success' => false, 'message' => 'Invalid order ID or no items provided']);
    exit;
}

$orderIdInput = trim($input['order_id']);
error_log("Received order_id: " . $orderIdInput);
$orderId = $orderIdInput;
error_log("Data type of orderId: " . gettype($orderId));

$items = $input['items'];
$updatedItems = [];

try {
    // Validate order exists
    $checkSql = "SELECT COUNT(*) AS count FROM inves_orders WHERE order_id = :order_id";
    $checkResult = db_query($checkSql, [':order_id' => $orderId]);
    if (!$checkResult || $checkResult[0]->count == 0) {
        throw new Exception("Order ID $orderId not found");
    }

    $item = $items[0];

    // Validate required fields
    if (!isset($item['item_name'], $item['unit_price'], $item['vendor'], $item['category'], $item['quantity'], $item['status'])) {
        throw new Exception("Missing required fields for item");
    }

    $itemName = $item['item_name'];
    $unitPrice = floatval($item['unit_price']);
    $vendor = $item['vendor'];
    $quantity = intval($item['quantity']);
    $status = strtolower(trim($item['status']));
    $categoryInput = trim($item['category']);
    $totalPrice = $unitPrice * $quantity;

    // Validate status
    if (!in_array($status, ['pending', 'shipped', 'delivered'])) {
        throw new Exception("Invalid status provided");
    }

    // Handle category
    $categoryId = null;
    error_log("Raw category input: " . $categoryInput);

    if (is_numeric($categoryInput)) {
        $categoryId = intval($categoryInput);
    } else {
        // Check if category exists
        $catCheckSql = "SELECT id FROM inves_categories WHERE name = :name LIMIT 1";
        $catCheckResult = db_query($catCheckSql, [':name' => $categoryInput]);

        if ($catCheckResult && isset($catCheckResult[0]->id)) {
            $categoryId = $catCheckResult[0]->id;
        } else {
            // Insert new category
            $insertCatSql = "INSERT INTO inves_categories (category_name) VALUES (:name)";
            $insertCatResult = db_query($insertCatSql, [':name' => $categoryInput]);

            if ($insertCatResult === false) {
                throw new Exception("Failed to insert new category");
            }

            // Get inserted category ID
            $catIdResult = db_query("SELECT LAST_INSERT_ID() AS id");
            $categoryId = $catIdResult[0]->id ?? null;
        }
    }

    if (!$categoryId) {
        throw new Exception("Unable to resolve or insert category");
    }

    if ($unitPrice <= 0 || $quantity <= 0) {
        throw new Exception("Unit price and quantity must be positive");
    }

    // Update inves_orders
    $orderSql = "UPDATE inves_orders SET 
        vendor_supplier = :vendor, 
        unit_price = :unit_price, 
        quantity = :quantity, 
        total_price = :total_price, 
        status = :status, 
        delivery_date = :delivery_date 
        WHERE order_id = :order_id";
    $orderParams = [
        ':vendor' => $vendor,
        ':unit_price' => $unitPrice,
        ':quantity' => $quantity,
        ':total_price' => $totalPrice,
        ':status' => $status,
        ':delivery_date' => date('Y-m-d', strtotime('2025-06-12')), // Placeholder date
        ':order_id' => $orderId
    ];
    $orderResult = db_query($orderSql, $orderParams);
    if ($orderResult === false) {
        throw new Exception("Failed to update order: " . ($GLOBALS['DB_STATE']['error'] ?? 'Unknown error'));
    }

    // Update inves_order_items
    $itemSql = "UPDATE inves_order_items SET 
        item_name = :item_name, 
        category_id = :category_id, 
        price = :price, 
        quantity = :quantity 
        WHERE order_id = :order_id";
    $itemParams = [
        ':item_name' => $itemName,
        ':category_id' => $categoryId,
        ':price' => $unitPrice,
        ':quantity' => $quantity,
        ':order_id' => $orderId
    ];
    $itemResult = db_query($itemSql, $itemParams);
    if ($itemResult === false) {
        throw new Exception("Failed to update item: " . ($GLOBALS['DB_STATE']['error'] ?? 'Unknown error'));
    }

    $updatedItems[] = array_merge($item, ['order_id' => $orderId]);

    echo json_encode([
        'success' => true,
        'data' => $updatedItems,
        'message' => 'Order updated successfully'
    ]);
} catch (Exception $e) {
    error_log("Exception in update: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
