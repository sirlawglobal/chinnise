<?php
require_once '../../BackEnd/config/db.php';
session_start();

if (!isset($_SESSION['user']['id']) || !isset($_SESSION['user']['role'])) {
    header("Location: /chinnese-restaurant/login/");
    exit();
}

//  $nameParts = explode(' ', trim($user['name']));
//       $firstName = $nameParts[0];
//       $lastName = isset($nameParts[1]) ? implode(' ', array_slice($nameParts, 1)) : '';

// $username = $_SESSION['user']['name'] ?? '';
// $parts = explode(" ", $username);
// $first_name = $parts[0];

// echo'<pre>';
// // print_r($first_name);
// print_r($username);
// echo'</pre>';

$username = $_SESSION['user']['name'] ?? '';
$parts = explode(" ", trim($username));

// Assign first and last name if available
$first_name = $parts[0] ?? '';
$last_name = $parts[1] ?? ''; // This assumes the last name is the second word


// echo '<pre>';
// echo "Full Name: $username\n";
// echo "First Name: $first_name\n";
// echo "Last Name: $last_name\n";
// echo '</pre>';

// exit();

// var_dump($first_name);
// var_dump($username);

// error_log(print_r($username, true));
// error_log(print_r($first_name, true));

$userRole = $_SESSION['user']['role'] ?? '';
$profilePicture = $_SESSION['user']['profile_picture'] ?? 'https://picsum.photos/40';

// Fetch all users for the "All Users" tab
$users = db_query(
    "SELECT id, name, email, phone, role FROM users WHERE role IN ('admin', 'staff') ORDER BY name",
    [],
    'assoc'
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Bootstrap 5 CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <!-- SweetAlert2 CDN -->
  <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" />
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <script type="text/javascript">
    $(document).ready(function () {
      $("#users-table").DataTable({
        paging: true,
        pageLength: 10,
        language: {
          paginate: {
            previous: `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.9254 4.55806C13.1915 4.80214 13.1915 5.19786 12.9254 5.44194L8.4375 9.55806C8.17138 9.80214 8.17138 10.1979 8.4375 10.4419L12.9254 14.5581C13.1915 14.8021 13.1915 15.1979 12.9254 15.4419C12.6593 15.686 12.2278 15.686 11.9617 15.4419L7.47378 11.3258C6.67541 10.5936 6.67541 9.40641 7.47378 8.67418L11.9617 4.55806C12.2278 4.31398 12.6593 4.31398 12.9254 4.55806Z" fill="#1C1C1C"/></svg>`,
            next: `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.07459 15.4419C6.80847 15.1979 6.80847 14.8021 7.07459 14.5581L11.5625 10.4419C11.8286 10.1979 11.8286 9.80214 11.5625 9.55806L7.07459 5.44194C6.80847 5.19786 6.80847 4.80214 7.07459 4.55806C7.34072 4.31398 7.77219 4.31398 8.03831 4.55806L12.5262 8.67418C13.3246 9.40641 13.3246 10.5936 12.5262 11.3258L8.03831 15.4419C7.77219 15.686 7.34072 15.686 7.07459 15.4419Z" fill="#1C1C1C"/></svg>`,
          },
          lengthMenu: "Show _MENU_ entries",
          info: "Showing _START_ to _END_ of _TOTAL_ entries",
          infoEmpty: "Showing 0 to 0 of 0 entries",
          infoFiltered: "(filtered from _MAX_ total entries)",
          search: "Search:",
          zeroRecords: "No matching records found",
        },
      });

      // Handle Add User form submission via AJAX
    //   $('#add-user-form').on('submit', function (e) {
    //     e.preventDefault();
        
    //     // Convert form data to regular object instead of FormData
    //     const formData = $(this).serialize();
        
    //     $.ajax({
    //       url: 'add_user.php',
    //       type: 'POST',
    //       data: formData,
    //       success: function (response) {
    //         try {
    //           const data = JSON.parse(response);
    //           if (data.success) {
    //             Swal.fire({
    //               icon: 'success',
    //               title: 'Success',
    //               text: data.message,
    //               confirmButtonText: 'OK'
    //             }).then(() => {
    //               $('#add-user-form')[0].reset();
    //               $('#all-users-tab').tab('show'); // Switch to All Users tab
    //               setTimeout(() => location.reload(), 1000); // Reload after 1 second
    //             });
    //           } else {
    //             Swal.fire({
    //               icon: 'error',
    //               title: 'Error',
    //               text: data.message,
    //               confirmButtonText: 'OK'
    //             });
    //           }
    //         } catch (e) {
    //           Swal.fire({
    //             icon: 'success',
    //             title: 'Success',
    //             text: 'Saved successfully',
    //             confirmButtonText: 'OK'
    //           }).then(() => {
    //             location.reload();
    //           });
    //         }
    //       },
    //       error: function (xhr, status, error) {
    //         Swal.fire({
    //           icon: 'error',
    //           title: 'Error',
    //           text: 'AJAX Error: ' + status + ' - ' + error,
    //           confirmButtonText: 'OK'
    //         });
    //       }
    //     });
    //   });
    
    // Handle Add User form submission via AJAX
$('#add-user-form').on('submit', function (e) {
    e.preventDefault();
    
    // Get password and confirm password values
    const password = $('input[name="password"]').val();
    // const confirmPassword = $('input[name="confirm_password"]').val();
    
    // Validate password match
    // if (password !== confirmPassword) {
    //     Swal.fire({
    //         icon: 'error',
    //         title: 'Error',
    //         text: 'Passwords do not match!',
    //         confirmButtonText: 'OK'
    //     });
    //     return false;
    // }
    
    // Convert form data to regular object instead of FormData
    const formData = $(this).serialize();
    
    $.ajax({
        url: 'add_user.php',
        type: 'POST',
        data: formData,
        success: function (response) {
            try {
                const data = JSON.parse(response);
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: data.message,
                        confirmButtonText: 'OK'
                    }).then(() => {
                        // Clear the form
                        $('#add-user-form')[0].reset();
                        
                        // Refresh the DataTable
                        $('#users-table').DataTable().ajax.reload();
                        
                        // Switch to All Users tab
                        $('#all-users-tab').tab('show');
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.message,
                        confirmButtonText: 'OK'
                    });
                }
            } catch (e) {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Saved successfully',
                    confirmButtonText: 'OK'
                }).then(() => {
                    // Clear the form
                    $('#add-user-form')[0].reset();
                    
                    // Full page reload as fallback
                    location.reload();
                });
            }
        },
        error: function (xhr, status, error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'AJAX Error: ' + status + ' - ' + error,
                confirmButtonText: 'OK'
            });
        }
    });
});

      // Handle Delete User via AJAX
      $(document).on('click', '.delete-user', function (e) {
        e.preventDefault();
        const userId = $(this).data('id');
        Swal.fire({
          title: 'Are you sure?',
          text: 'Do you want to delete this user?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
          if (result.isConfirmed) {
            $.ajax({
              url: 'delete_user.php',
              type: 'POST',
              data: { id: userId },
              success: function (response) {
                try {
                  const data = JSON.parse(response);
                  if (data.success) {
                    Swal.fire({
                      icon: 'success',
                      title: 'Deleted',
                      text: data.message,
                      confirmButtonText: 'OK'
                    }).then(() => {
                      location.reload(); // Reload to update user table
                    });
                  } else {
                    Swal.fire({
                      icon: 'error',
                      title: 'Error',
                      text: data.message,
                      confirmButtonText: 'OK'
                    });
                  }
                } catch (e) {
                  Swal.fire({
                    icon: 'success',
                    title: 'Deleted',
                    text: 'User deleted successfully',
                    confirmButtonText: 'OK'
                  }).then(() => {
                    location.reload();
                  });
                }
              },
              error: function () {
                Swal.fire({
                  icon: 'success',
                  title: 'Deleted',
                  text: 'User deleted successfully',
                  confirmButtonText: 'OK'
                }).then(() => {
                  location.reload();
                });
              }
            });
          }
        });
      });

      // Handle Edit User form submission via AJAX
      $('.edit-user-form').on('submit', function (e) {
        e.preventDefault();
        const form = this;
        const formData = new FormData(form);
        const userId = $(form).data('id');

        $.ajax({
          url: 'edit_user.php',
          type: 'POST',
          data: formData,
          processData: false,
          contentType: false,
          success: function (response) {
            try {
              const data = JSON.parse(response);
              if (data.success) {
                Swal.fire({
                  icon: 'success',
                  title: 'Success',
                  text: data.message,
                  confirmButtonText: 'OK'
                }).then(() => {
                  bootstrap.Modal.getInstance(document.getElementById('editUserModal' + userId)).hide();
                  location.reload(); // Reload to update user table
                });
              } else {
                Swal.fire({
                  icon: 'error',
                  title: 'Error',
                  text: data.message,
                  confirmButtonText: 'OK'
                });
              }
            } catch (e) {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'User updated successfully',
                confirmButtonText: 'OK'
              }).then(() => {
                bootstrap.Modal.getInstance(document.getElementById('editUserModal' + userId)).hide();
                location.reload();
              });
            }
          },
          error: function () {
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: 'Failed to update user',
              confirmButtonText: 'OK'
            });
          }
        });
      });
    });
  </script>
  <title>Users</title>
  <link rel="stylesheet" href="../assets/styles/general.css" />
  <link rel="stylesheet" href="../assets/styles/panels.css" />
  <link rel="stylesheet" href="../assets/styles/orders.css" />

  <style>
    .nav-tabs {
      display: flex;
      justify-content: space-between;
    }
    .nav-tabs clic-link {
      flex: 1;
      text-align: center;
      font-weight: bold;
      color: #333;
      border: none;
      border-bottom: 2px solid transparent;
      transition: border-bottom 0.2s ease;
    }
    .nav-tabs .nav-link.active {
      color: #007bff;
      border-bottom: 2px solid #007bff;
    }
    .tab-content {
      padding: 20px;
    }
    .card {
      border: none;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body class="flex">
  <main>
    <div class="content">
      <!-- Tabs Navigation -->
      <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
          <a class="nav-link active" id="all-users-tab" data-bs-toggle="tab" href="#all-users">All Users</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="current-user-tab" data-bs-toggle="tab" href="#current-user">Current User</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="add-user-tab" data-bs-toggle="tab" href="#add-user">Add User</a>
        </li>
      </ul>

      <!-- Tab Content -->
      <div class="tab-content">
        <!-- All Users Tab -->
        <div class="tab-pane fade show active" id="all-users">
          <div class="card">
           
            
            <table id="users-table" class="table table-hover">
  <thead class="header">
    <tr>
      <th>ID</th>
      <th>FIRST NAME</th>
      <th>LAST NAME</th>
      <th>EMAIL</th>
      <th>PHONE</th>
      <th>ROLE</th>
      <th>ACTION</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $sn = 1000;
    foreach ($users as $user):
        
        // echo'<pre>';
        // print_r($user);
        // echo'</pre>';
        // exit();
      $sn++;
      $nameParts = explode(' ', trim($user['name']));
      $firstName = $nameParts[0];
      $lastName = isset($nameParts[1]) ? implode(' ', array_slice($nameParts, 1)) : '';
    ?>
      <tr>
        <td><?= $sn ?></td>
        <td><?= htmlspecialchars($firstName) ?></td>
        <td><?= htmlspecialchars($lastName) ?></td>
        <td><?= htmlspecialchars($user['email']) ?></td>
        <td><?= htmlspecialchars($user['phone'] ?? '-') ?></td>
        <td><?= htmlspecialchars($user['role']) ?></td>
        <td>
          <div class="dropdown">
            <button class="btn btn-sm btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
              Action
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#editUserModal<?= $user['id'] ?>">Edit</a></li>
              <li><a class="dropdown-item text-danger delete-user" href="#" data-id="<?= $user['id'] ?>">Delete</a></li>
            </ul>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
          </div>
        </div>

        <!-- Current User Tab -->
        <div class="tab-pane fade" id="current-user">
          <div class="card p-4">
            <h5 class="mb-4">Current User Details</h5>
            <div class="row">
                <div class="col-md-6 mb-3">
  <label class="form-label fw-bold">First Name:</label>
  <input type="text" class="form-control" value="<?= htmlspecialchars($first_name) ?>" readonly>
</div>
<div class="col-md-6 mb-3">
  <label class="form-label fw-bold">Last Name:</label>
  <input type="text" class="form-control" value="<?= htmlspecialchars($last_name) ?>" readonly>
</div>
             
              <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Email:</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($_SESSION['user']['email'] ?? '') ?>" readonly>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Phone:</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($_SESSION['user']['phone'] ?? '-') ?>" readonly>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Role:</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($userRole) ?>" readonly>
              </div>
            </div>
          </div>
        </div>

        <!-- Add User Tab -->
        <div class="tab-pane fade" id="add-user">
          <div class="card p-4">
            <h5 class="mb-4">Add New User</h5>
            <form id="add-user-form">
              <div class="row">
                <!--<div class="col-md-6 mb-3">-->
                <!--  <label class="form-label fw-bold">Name:</label>-->
                <!--  <input type="text" class="form-control" name="name" required>-->
                <!--</div>-->
                        <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">First Name:</label>
                    <input type="text" class="form-control" name="first_name" required>
                    </div>
                    <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Last Name:</label>
                    <input type="text" class="form-control" name="last_name" required>
                    </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label fw-bold">Email:</label>
                  <input type="email" class="form-control" name="email" required>
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label fw-bold">Phone:</label>
                  <input type="text" class="form-control" name="phone">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label fw-bold">Role:</label>
                  <select class="form-control" name="role" required>
                    <option value="admin">Admin</option>
                    <option value="staff">Staff</option>
                  </select>
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label fw-bold">Password:</label>
                  <input type="password" class="form-control" name="password" required>
                </div>
                <!--<div class="col-md-6 mb-3">-->
                <!--  <label class="form-label fw-bold">Confirm Password:</label>-->
                <!--  <div class="input-group">-->
                <!--    <input type="password" class="form-control" name="confirm_password" id="confirm_password" required>-->
                <!--    <button class="btn btn-outline-secondary" type="button" id="toggleConfirmPassword">-->
                <!--      <i class="bi bi-eye"></i>-->
                <!--    </button>-->
                <!--  </div>-->
                <!--</div>-->
              </div>
              <button type="submit" class="btn btn-success">Create User</button>
              <button type="button" class="btn btn-secondary" onclick="this.form.reset()">Reset</button>
            </form>
          </div>
        </div>
      </div>

      <!-- Edit User Modals -->
      <?php foreach ($users as $user): ?>
        <div class="modal fade" id="editUserModal<?= $user['id'] ?>" tabindex="-1" aria-labelledby="editUserModalLabel<?= $user['id'] ?>" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <form class="edit-user-form" data-id="<?= $user['id'] ?>">
                <div class="modal-header">
                  <h5 class="modal-title" id="editUserModalLabel<?= $user['id'] ?>">Edit User #<?= $user['id'] ?></h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <input type="hidden" name="id" value="<?= $user['id'] ?>">
                  <div class="row">
                    <!--<div class="col-md-6 mb-3">-->
                    <!--  <label class="form-label fw-bold">Name:</label>-->
                    <!--  <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>-->
                    <!--</div>-->
                    
                    <div class="col-md-6 mb-3">
  <label class="form-label fw-bold">First Name:</label>
  <?php 
  $nameParts = explode(' ', trim($user['name']));
  $firstName = $nameParts[0];
  $lastName = isset($nameParts[1]) ? implode(' ', array_slice($nameParts, 1)) : '';
  ?>
  <input type="text" class="form-control" name="first_name" value="<?= htmlspecialchars($firstName) ?>" required>
</div>
<div class="col-md-6 mb-3">
  <label class="form-label fw-bold">Last Name:</label>
  <input type="text" class="form-control" name="last_name" value="<?= htmlspecialchars($lastName) ?>">
</div>
                    <div class="col-md-6 mb-3">
                      <label class="form-label fw-bold">Email:</label>
                      <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                      <label class="form-label fw-bold">Phone:</label>
                      <input type="text" class="form-control" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                      <label class="form-label fw-bold">Role:</label>
                      <select class="form-control" name="role" required>
                        <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                        <option value="staff" <?= $user['role'] == 'staff' ? 'selected' : '' ?>>Staff</option>
                      </select>
                    </div>
                    <div class="col-md-6 mb-3"'>
                      <label class="form-label fw-bold">Password </label>
                      <input type="password" class="form-control" name="password">
                    </div>
                   
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-success">Update User</button>
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </main>

  <script>
    const username = '<?php echo addslashes($first_name); ?>';
    const userRole = '<?php echo addslashes($userRole); ?>';
    const profilePicture = '<?php echo addslashes($profilePicture); ?>';
  </script>
  <script src="../scripts/components.js"></script>
</body>
</html>