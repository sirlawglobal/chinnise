<?php
require_once '../../BackEnd/config/db.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

// Debugging: Log received data
error_log(print_r($_POST, true));

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method. Expected POST, got ' . $_SERVER['REQUEST_METHOD']);
    }

    // Get input data
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    
    // For add_user.php
$name = trim($_POST['first_name'] . ' ' . $_POST['last_name']);

// // For edit_user.php
// $fullName = trim($_POST['first_name'] . ' ' . $_POST['last_name']);
    
    // $name = trim($input['name'] ?? '');
    $email = trim($input['email'] ?? '');
    $phone = trim($input['phone'] ?? '');
    $role = trim($input['role'] ?? '');
    $password = $input['password'] ?? '';
    $confirm_password = $input['confirm_password'] ?? '';

    // Validation
    if (empty($name) || empty($email) || empty($role) || empty($password)) {
        throw new Exception('All required fields must be filled');
    }

    // if ($password !== $confirm_password) {
    //     throw new Exception('Passwords do not match');
    // }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format');
    }

    // Check if email exists
    $existing = db_query("SELECT id FROM users WHERE email = ?", [$email], 'assoc');
    if (!empty($existing)) {
        throw new Exception('Email already exists');
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert user
    $query = "INSERT INTO users (name, email, phone, role, password, created_at) 
              VALUES (?, ?, ?, ?, ?, NOW())";
    $params = [$name, $email, $phone, $role, $hashed_password];
    $result = db_query($query, $params, 'exec');

    if ($result) {
        $response['success'] = true;
        $response['message'] = 'User created successfully';
    } else {
        throw new Exception('Database error: Failed to create user');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log('Error in add_user.php: ' . $e->getMessage());
}

echo json_encode($response);
?>