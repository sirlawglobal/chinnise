<?php
require_once '../../BackEnd/config/db.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    $id = trim($_POST['id'] ?? '');

    if (empty($id)) {
        throw new Exception('User ID is required');
    }

    // Check if user exists
    $existing = db_query("SELECT id FROM users WHERE id = ?", [$id], 'assoc');
    if (empty($existing)) {
        throw new Exception('User not found');
    }

    // Delete user
    $query = "DELETE FROM users WHERE id = ?";
    $result = db_query($query, [$id], 'exec');

    if ($result) {
        $response['success'] = true;
        $response['message'] = 'User deleted successfully';
    } else {
        throw new Exception('Failed to delete user');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>