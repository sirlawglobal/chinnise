<?php
require_once '../../BackEnd/config/db.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }
$name = trim($_POST['first_name'] . ' ' . $_POST['last_name']);
    $id = trim($_POST['id'] ?? '');
    // $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validation
    if (empty($id) || empty($name) || empty($email) || empty($role)) {
        throw new Exception('All required fields must be filled');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format');
    }

    // Check if email is taken by another user
    $existing = db_query("SELECT id FROM users WHERE email = ? AND id != ?", [$email, $id], 'assoc');
    if (!empty($existing)) {
        throw new Exception('Email already in use by another user');
    }

    // Prepare update query
    $query = "UPDATE users SET name = ?, email = ?, phone = ?, role = ?";
    $params = [$name, $email, $phone, $role];

    // Handle password update if provided
    if (!empty($password)) {
        if ($password !== $confirm_password) {
            throw new Exception('Passwords do not match');
        }
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $query .= ", password = ?";
        $params[] = $hashed_password;
    }

    $query .= " WHERE id = ?";
    $params[] = $id;

    // Execute update
    $result = db_query($query, $params, 'exec');

    if ($result) {
        $response['success'] = true;
        $response['message'] = 'User updated successfully';
    } else {
        throw new Exception('Failed to update user');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>