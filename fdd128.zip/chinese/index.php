<?php 
require_once __DIR__ . '/BackEnd/config/init.php';

// Get visitor IP
function getUserIP() {
  if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    return $_SERVER['HTTP_CLIENT_IP'];
  } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    return $_SERVER['HTTP_X_FORWARDED_FOR'];
  } else {
    return $_SERVER['REMOTE_ADDR'];
  }
}


$pdo=db_connect();
// Get location from IP using ip-api
function getGeoLocation($ip) {
  $response = @file_get_contents("http://ip-api.com/json/{$ip}");
  return json_decode($response, true);
}

// Get details
$ip = getUserIP();
$location = getGeoLocation($ip);
$date = date("Y-m-d");
$time = date("H:i:s");
$state = $location['regionName'] ?? 'Unknown';
$country = $location['country'] ?? 'Unknown';
$visitor_name = isLoggedIn() ? ($_SESSION['user']['name'] ?? 'LoggedInUser') : 'Guest';

$lat = $location['lat'] ?? null;
$lon = $location['lon'] ?? null;

// Insert into database
// try {
//   $stmt = $pdo->prepare("INSERT INTO visitor_logs (visit_date, visit_time, ip_address, state, country, visitor_name) 
//                          VALUES (?, ?, ?, ?, ?, ?)");
//   $stmt->execute([$date, $time, $ip, $state, $country, $visitor_name]);
// } catch (PDOException $e) {
//   error_log("Error saving visitor log: " . $e->getMessage());
// }

try {
  $stmt = $pdo->prepare("INSERT INTO visitor_logs (visit_date, visit_time, ip_address, state, country, visitor_name, latitude, longitude) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  $stmt->execute([$date, $time, $ip, $state, $country, $visitor_name, $lat, $lon]);
} catch (PDOException $e) {
  error_log("Error saving visitor log: " . $e->getMessage());
}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./assets/styles/main.css" />
    <link rel="stylesheet" href="./assets/styles/index.css" />
    <title>Golden Dish</title>
  </head>
  <body>
    <header class="flex justify-between">
      <div class="logo">
        <a href="index.html">
          <img src="./assets/images/logo.webp" alt="Golden Dish" />
        </a>
      </div>
      <nav class="flex">
        <ul class="flex justify-between">
          <li><a href="./menu/">Menu</a></li>
          <li><a href="#">About</a></li>
          <li><a href="./contact/">Contact</a></li>
        </ul>
 

        <div class="buttons"> 
          <?php  if(isLoggedIn()): ?> 
         <a class="button button-primary" href="BackEnd/controller/auth/logout.php">Logout</a>
           <?php  else: ?> 
            <a class="button button-primary" href="login/">Log in</a>
              <?php  endif; ?> 
          <!-- <a class="button button-primary" href="./menu/">Order Now</a> -->
        </div>
      </nav>
    </header>
    <main>
      <section id="hero" class="flex justify-between align-center">
        <div class="text">
          <h1>Your Favorite Chinese Dishes, Just a Tap Away!</h1>
          <p>
            Savor the taste of tradition with fresh, chef-prepared meals at your
            doorstep. Order now and experience real Chinese cuisine!
          </p>
          <a class="button button-secondary" href="./menu/">Menu</a>
        </div>
        <div class="images flex align-center justify-between">
          <img src="./assets/images/p1.webp" alt="Golden Dish" />
          <img src="./assets/images/p2.webp" alt="Golden Dish" />
          <img src="./assets/images/p3.webp" alt="Golden Dish" />
        </div>
      </section>
    </main>
  </body>
</html>
