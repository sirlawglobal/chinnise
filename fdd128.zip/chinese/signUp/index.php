<?php

echo 'hi';