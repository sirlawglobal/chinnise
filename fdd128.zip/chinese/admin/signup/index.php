<?php

header("Location: ../../signUp/");
exit();
