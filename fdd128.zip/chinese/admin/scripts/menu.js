document.addEventListener("DOMContentLoaded", () => {
  const menuItemsContainer = document.querySelector(".menu-items-container");
  const categoryTabs = document.querySelectorAll(".category-tabs .tab");
  const searchInput = document.getElementById("search-input");
  const searchButton = document.getElementById("search-button");
  const sortDropdown = document.getElementById("sort-dropdown");
  const sortDropdownMenu = document.querySelector(".sort-dropdown-menu");
  const sortLinks = sortDropdownMenu.querySelectorAll("a");
  
  const modal = document.getElementById("editModal");
  const closeModalBtn = document.getElementById("closeModal");
  const editForm = document.getElementById("editForm");
  const editIdInput = document.getElementById("edit-id");
  const editNameInput = document.getElementById("edit-name");
  const editPriceInput = document.getElementById("edit-price");

  let currentCategory = "all";
  let searchTerm = "";
  let sortOption = "popular";
  let allMenuItems = [];
  let currentPage = 1;
  let totalPages = 1;

  // Static template for menu items
  const staticMenuItemTemplates = [
    {
      id: 1,
      category: "toast",
      difficulty: "easy",
      healthScore: 9,
      kcal: 320,
      carbs: 30,
      protein: 14,
      fats: 18,
    },
    {
      id: 2,
      category: "shrimp",
      difficulty: "medium",
      healthScore: 8,
      kcal: 400,
      carbs: 45,
      protein: 28,
      fats: 12,
    },
    {
      id: 3,
      category: "chicken",
      difficulty: "medium",
      healthScore: 9,
      kcal: 480,
      carbs: 50,
      protein: 40,
      fats: 15,
    },
    {
      id: 4,
      category: "soups",
      difficulty: "easy",
      healthScore: 7,
      kcal: 250,
      carbs: 20,
      protein: 25,
      fats: 10,
    },
    {
      id: 5,
      category: "noodles",
      difficulty: "medium",
      healthScore: 8,
      kcal: 380,
      carbs: 55,
      protein: 15,
      fats: 12,
    },
    {
      id: 6,
      category: "rice",
      difficulty: "easy",
      healthScore: 9,
      kcal: 420,
      carbs: 40,
      protein: 30,
      fats: 18,
    },
  ];

  // Fetch menu items from the database
  
  async function fetchMenuItems(page) {
  try {
    const response = await fetch(`../menu2/get_menu_items.php?page=${page}`);
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    const dbItems = await response.json();
    console.log('dbItems', dbItems);
    totalPages = dbItems.total_pages || 1;
    currentPage = page;

    allMenuItems = dbItems.data.map((dbItem, index) => {
      const staticTemplate = staticMenuItemTemplates[index % staticMenuItemTemplates.length];
      // Normalize category name to match data-category values
      const normalizedCategory = dbItem.category_name.toLowerCase();
      return {
        id: dbItem.id,
        name: dbItem.name,
        image: dbItem.image_url || '../../avarterdefault.jpg',
        category: normalizedCategory, // Use normalized category
        price: dbItem.price,
        difficulty: staticTemplate.difficulty,
        healthScore: staticTemplate.healthScore,
        kcal: staticTemplate.kcal,
        carbs: staticTemplate.carbs,
        protein: staticTemplate.protein,
        fats: staticTemplate.fats,
      };
    });

    filterMenuItems();
  } catch (error) {
    console.error('Error fetching menu items:', error);
    allMenuItems = staticMenuItemTemplates.map((item, index) => ({
      ...item,
      name: `Placeholder Item ${index + 1}`,
      image: `https://picsum.photos/300?random=${index + 5}`,
      category: item.category.toLowerCase(), // Normalize static template categories
    }));
    filterMenuItems();
  }
}


function renderMenuItems(items) {
  menuItemsContainer.innerHTML = "";
  items.forEach((item) => {
    console.log('item.category', item.category);
    const card = document.createElement("div");
    card.classList.add("menu-item-card", "cream-card", "card");
    card.innerHTML = `
      <div class="item-image">
        <img src="${item.image}" alt="${item.name}">
      </div>
      <div class="item-details">
        <div class="item-header">
          <div class="flex align-center">
            <span class="item-category ${item.category}" style='background:#ff6c1f'>${
              item.category.charAt(0).toUpperCase() + item.category.slice(1)
            }</span>
            <span class="item-difficulty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-check-circle"><path d="M22 11.08V12a10 10 0 1 1-5.92-9.43"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg> ${
              item.difficulty.charAt(0).toUpperCase() + item.difficulty.slice(1)
            }</span>
          </div>
          <div class="health-score">
            <span>Health Score:</span>
            <span class="score">${item.healthScore}/10</span>
            <span class="progress-bar">
              <span style="width: ${item.healthScore * 10}%;"></span>
            </span>
          </div>
        </div>
        <h3 class="item-name">${item.name}</h3>
        <span>£${item.price}</span>
        <div class="flex justify-between align-center">
          <div class="nutrition-info">
            <span class="nutrition-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-sun"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="17" y1="5" x2="19" y2="7"></line><line x1="7" y1="5" x2="5" y2="7"></line><line x1="17" y1="17" x2="19" y2="19"></line><line x1="7" y1="17" x2="5" y2="19"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="1" y1="12" x2="3" y2="12"></line></svg> ${
              item.kcal
            } kcal</span>
            <span class="nutrition-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-leaf"><path d="M18.6 13.4c-.9 1.5-2.4 2.6-4.1 3.2l-6.2 2.5a2 2 0 0 1-2.3-.1c-2.1-.2-2.2-2-2.2-2.2l2.5-6.2c.3-1.7-.7-3.2-2.2-4.1-2.4-1.3 0 0 0 0z"></path><path d="M12 0l.5-3.2"></path><path d="M15 3l-3.2-.5"></path></svg> ${
              item.carbs
            }g carbs</span>
            <span class="nutrition-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-zap"><polygon points="13 2 3 14 12 15 11 22 21 10 12 9 13 2"></polygon></svg> ${
              item.protein
            }g protein</span>
            <span class="nutrition-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-egg"><path d="M13 6c0-3.5-5-3.5-5 0 0 2.1.8 4 2 5.3 1.2 1.5 3 2.2 5 2.2s3.8-.7 5-2.2c1.2-1.3 2-3.2 2-5.3 0-3.5-5-3.5-5 0"></path></svg> ${
              item.fats
            }g fats</span>
          </div>
          <div class="item-actions" style="display:flex; gap:4px">
            <button class="edit-menu-button">Edit</button>
            <button class="delete-menu-button">Delete</button>
          </div>
        </div>
      </div>
    `;
    menuItemsContainer.appendChild(card);
  });
  renderPagination();
  attachEditButtons(items); // Pass the items array
}



function attachEditButtons(items) {
  const editButtons = document.querySelectorAll(".edit-menu-button");
  const deleteButtons = document.querySelectorAll(".delete-menu-button");

  editButtons.forEach((button, index) => {
    button.onclick = () => {
      const item = items[index];
      openEditModal(item);
    };
  });

  deleteButtons.forEach((button, index) => {
    button.onclick = async () => {
      const item = items[index];
      const result = await Swal.fire({
        title: `Delete "${item.name}"?`,
        text: "Are you sure you want to delete this menu item?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "Cancel",
      });

      if (result.isConfirmed) {
        try {
          button.disabled = true;
          button.innerHTML = `<span class="spinner"></span> Deleting...`;

          const response = await fetch(`../../BackEnd/controller/inventory/delete_menu_item.php/${item.id}`, {
            method: "DELETE",
          });

          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }

          const result = await response.json();
          if (!result.success) {
            throw new Error(result.message || "Failed to delete item");
          }

          await Swal.fire({
            title: "Deleted!",
            text: `"${item.name}" has been deleted.`,
            icon: "success",
            timer: 1500,
            showConfirmButton: false,
          });

          fetchMenuItems(currentPage);
        } catch (error) {
          console.error("Error deleting menu item:", error);
          await Swal.fire({
            title: "Error!",
            text: `Failed to delete item: ${error.message}`,
            icon: "error",
            confirmButtonText: "OK",
          });
          button.disabled = false;
          button.textContent = "Delete";
        }
      }
    };
  });
}

  // Open edit modal
  function openEditModal(item) {
 
    editIdInput.value = item.id;
    editNameInput.value = item.name;
    editPriceInput.value = item.price || 0;
    modal.style.display = "flex";
  }

  // Close modal
  closeModalBtn.onclick = () => {
    modal.style.display = "none";
  };

  modal.addEventListener("click", (e) => {
    if (e.target === modal) modal.style.display = "none";
  });

  // Handle form submission
  editForm.onsubmit = async (e) => {
    e.preventDefault();
  
    const id = editIdInput.value.trim();
    const newName = editNameInput.value.trim();
    const newPrice = parseFloat(editPriceInput.value.trim());
    const submitButton = document.getElementById('edit-submit-button');
  
    if (!id || !newName || isNaN(newPrice)) {
      await Swal.fire({
        title: "Invalid Input",
        text: "Please fill out both name and price correctly.",
        icon: "warning",
        confirmButtonText: "OK"
      });
      return;
    }
    
    submitButton.disabled = true;
    const originalText = submitButton.textContent;
    submitButton.innerHTML = `<span class="spinner"></span> Saving...`;
  
    try {
      const formData = new URLSearchParams();
      formData.append('name', newName);
      formData.append('price', newPrice);
  
      const response = await fetch(`../../BackEnd/controller/inventory/update_menu_item.php/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData
      });
  
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
  
      const result = await response.json();
      if (!result.success) {
        throw new Error(result.message || 'Unknown error occurred while updating.');
      }
  
      await Swal.fire({
        title: "Success!",
        text: "Menu item updated successfully!",
        icon: "success",
        timer: 1500,
        showConfirmButton: false
      });
      
      fetchMenuItems(currentPage);
      modal.style.display = "none";
  
    } catch (error) {
      console.error('Error updating menu item:', error);
      await Swal.fire({
        title: "Error!",
        text: `Failed to update item: ${error.message}`,
        icon: "error",
        confirmButtonText: "OK"
      });
    } finally {
      submitButton.disabled = false;
      submitButton.textContent = originalText;
    }
  };

  // Render pagination
  function renderPagination() {
    const container = document.getElementById("pagination");
    if (!container) return;
    container.innerHTML = "";
  
    const pagination = document.createElement("div");
    pagination.className = "pagination";
  
    const createBtn = (label, page, isActive = false, isDisabled = false) => {
      const btn = document.createElement("button");
      btn.textContent = label;
      btn.className = isActive ? "page active" : "page";
      if (isDisabled) {
        btn.disabled = true;
        btn.classList.add("disabled");
      }
      btn.onclick = (e) => {
        e.preventDefault();
        if (!isDisabled && page !== currentPage) {
          currentPage = page;
          fetchMenuItems(currentPage);
        }
      };
      return btn;
    };
  
    const createEllipsis = () => {
      const span = document.createElement("span");
      span.textContent = "...";
      span.className = "ellipsis";
      return span;
    };
  
    pagination.appendChild(
      createBtn("« Prev", currentPage - 1, false, currentPage === 1)
    );
  
    pagination.appendChild(createBtn(1, 1, currentPage === 1));
  
    if (currentPage > 4) pagination.appendChild(createEllipsis());
  
    if (currentPage - 1 > 1) {
      pagination.appendChild(
        createBtn(currentPage - 1, currentPage - 1)
      );
    }
  
    if (currentPage !== 1 && currentPage !== totalPages) {
      pagination.appendChild(createBtn(currentPage, currentPage, true));
    }
  
    if (currentPage + 1 < totalPages) {
      pagination.appendChild(
        createBtn(currentPage + 1, currentPage + 1)
      );
    }
  
    if (currentPage < totalPages - 3) pagination.appendChild(createEllipsis());
  
    if (totalPages > 1) {
      pagination.appendChild(
        createBtn(totalPages, totalPages, currentPage === totalPages)
      );
    }
  
    pagination.appendChild(
      createBtn("Next »", currentPage + 1, false, currentPage === totalPages)
    );
  
    container.appendChild(pagination);
  }

  // Filter menu items
  function filterMenuItems() {
    const filteredByCategory =
      currentCategory === "all"
        ? allMenuItems
        : allMenuItems.filter((item) => item.category === currentCategory);

    const filteredBySearch = searchTerm
      ? filteredByCategory.filter((item) =>
          item.name.toLowerCase().includes(searchTerm.toLowerCase())
        )
      : filteredByCategory;

    let sortedItems = [...filteredBySearch];
    if (sortOption === "name") {
      sortedItems.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortOption === "health") {
      sortedItems.sort((a, b) => b.healthScore - a.healthScore);
    } else if (sortOption === "popular") {
      sortedItems.sort((a, b) => a.id - b.id);
    }

    renderMenuItems(sortedItems);
  }

  // Event listeners for tabs, search, and sort
  categoryTabs.forEach((tab) => {
    tab.addEventListener("click", function () {
      categoryTabs.forEach((t) => t.classList.remove("active"));
      this.classList.add("active");
      currentCategory = this.dataset.category;
      filterMenuItems();
    });
  });

  searchButton.addEventListener("click", () => {
    searchTerm = searchInput.value;
    filterMenuItems();
  });

  searchInput.addEventListener("keypress", (event) => {
    if (event.key === "Enter") {
      searchTerm = searchInput.value;
      filterMenuItems();
    }
  });

  sortDropdown.addEventListener("click", () => {
    sortDropdownMenu.style.display =
      sortDropdownMenu.style.display === "block" ? "none" : "block";
  });

  sortLinks.forEach((link) => {
    link.addEventListener("click", function (event) {
      event.preventDefault();
      sortOption = this.dataset.sort;
      sortDropdown.textContent = this.textContent;
      sortDropdownMenu.style.display = "none";
      filterMenuItems();
    });
  });

  // Fetch and render menu items on load
  fetchMenuItems(currentPage);
});