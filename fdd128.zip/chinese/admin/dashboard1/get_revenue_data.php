<?php
header('Content-Type: application/json');
require_once '../../BackEnd/config/db.php';

try {
    $pdo = db_connect();

    // Get income from orders table
    // $incomeQuery = "
    //     SELECT 
    //         DATE_FORMAT(created_at, '%b') AS month,
    //         DATE_FORMAT(created_at, '%Y-%m') AS ym,
    //         SUM(total_amount) AS income
    //     FROM orders
    //     WHERE created_at >= DATE_SUB(NOW(), INTERVAL 8 MONTH)
    //     GROUP BY ym
    // ";
    
    $incomeQuery = "
    SELECT 
        DATE_FORMAT(created_at, '%b') AS month,
        DATE_FORMAT(created_at, '%Y-%m') AS ym,
        SUM(total_amount) AS income
    FROM orders
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 8 MONTH)
      AND status = 'completed'
    GROUP BY ym
";

    $incomeStmt = $pdo->query($incomeQuery);
    $incomeData = $incomeStmt->fetchAll(PDO::FETCH_ASSOC);

    // Get expenses from inves_orders table
    $expenseQuery = "
        SELECT 
            DATE_FORMAT(created_at, '%b') AS month,
            DATE_FORMAT(created_at, '%Y-%m') AS ym,
            SUM(total_price) AS expense
        FROM inves_orders
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 8 MONTH)
          AND status = 'delivered'
        GROUP BY ym
    ";
    $expenseStmt = $pdo->query($expenseQuery);
    $expenseData = $expenseStmt->fetchAll(PDO::FETCH_ASSOC);

    // Merge by month
    $merged = [];

    foreach ($incomeData as $row) {
        $merged[$row['ym']] = [
            'month' => $row['month'],
            'revenue' => (float)$row['income'],
            'expense' => 0
        ];
    }

    foreach ($expenseData as $row) {
        if (isset($merged[$row['ym']])) {
            $merged[$row['ym']]['expense'] = (float)$row['expense'];
        } else {
            $merged[$row['ym']] = [
                'month' => $row['month'],
                'revenue' => 0,
                'expense' => (float)$row['expense']
            ];
        }
    }

    // Sort by year-month descending, take latest 8, then reverse for chronological order
    krsort($merged);
    $merged = array_slice($merged, 0, 8);
    $merged = array_reverse($merged);

    // Format for Chart.js
    $labels = array_column($merged, 'month');
    $revenue = array_column($merged, 'revenue');
    $expense = array_column($merged, 'expense');

    echo json_encode([
        'labels' => $labels,
        'revenue' => $revenue,
        'expense' => $expense
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}




// header('Content-Type: application/json');
// require_once '../../BackEnd/config/db.php';

// try {
//     $pdo = db_connect();
    
//     // Get monthly revenue data (last 8 months)
//     $query = "SELECT 
//                 DATE_FORMAT(created_at, '%b') AS month,
//                 SUM(total_amount) AS revenue,
//                 SUM(total_amount * 0.5) AS expense -- Assuming 50% expense for demo
//               FROM orders
//               WHERE created_at >= DATE_SUB(NOW(), INTERVAL 8 MONTH)
//               GROUP BY DATE_FORMAT(created_at, '%Y-%m')
//               ORDER BY created_at DESC
//               LIMIT 8";
    
//     $stmt = $pdo->query($query);
//     $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
//     // Format data for Chart.js
//     $result = [
//         'labels' => array_column($data, 'month'),
//         'revenue' => array_column($data, 'revenue'),
//         'expense' => array_column($data, 'expense')
//     ];
    
//     echo json_encode($result);
// } catch (PDOException $e) {
//     http_response_code(500);
//     echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
// }
?>