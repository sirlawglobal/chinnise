<?php
require_once '../../BackEnd/config/db.php';
require_once 'country.php';
session_start();

if (!isset($_SESSION['user']['id']) || !isset($_SESSION['user']['role'])) {
    header("Location: /login/");
    exit();
}

$username = $_SESSION['user']['name'] ?? '';
$parts = explode(" ", trim($username));
$first_name = $parts[0] ?? '';
$last_name = $parts[1] ?? '';
$userRole = $_SESSION['user']['role'] ?? '';
$profilePicture = $_SESSION['user']['profile_picture'] ?? 'https://picsum.photos/40';



// Fetch visitor logs
$visitorLogs = db_query(
    "SELECT id, visit_date, visit_time, ip_address, state, country, visitor_name FROM visitor_logs ORDER BY id DESC",
    [],
    'assoc'
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Bootstrap 5 CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <!-- SweetAlert2 CDN -->
  <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" />
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <script type="text/javascript">
    $(document).ready(function () {
      $("#visitor-logs-table").DataTable({
        paging: true,
        pageLength: 30,
        language: {
          paginate: {
            previous: `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.9254 4.55806C13.1915 4.80214 13.1915 5.19786 12.9254 5.44194L8.4375 9.55806C8.17138 9.80214 8.17138 10.1979 8.4375 10.4419L12.9254 14.5581C13.1915 14.8021 13.1915 15.1979 12.9254 15.4419C12.6593 15.686 12.2278 15.686 11.9617 15.4419L7.47378 11.3258C6.67541 10.5936 6.67541 9.40641 7.47378 8.67418L11.9617 4.55806C12.2278 4.31398 12.6593 4.31398 12.9254 4.55806Z" fill="#1C1C1C"/></svg>`,
            next: `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.07459 15.4419C6.80847 15.1979 6.80847 14.8021 7.07459 14.5581L11.5625 10.4419C11.8286 10.1979 11.8286 9.80214 11.5625 9.55806L7.07459 5.44194C6.80847 5.19786 6.80847 4.80214 7.07459 4.55806C7.34072 4.31398 7.77219 4.31398 8.03831 4.55806L12.5262 8.67418C13.3246 9.40641 13.3246 10.5936 12.5262 11.3258L8.03831 15.4419C7.77219 15.686 7.34072 15.686 7.07459 15.4419Z" fill="#1C1C1C"/></svg>`,
          },
          lengthMenu: "Show _MENU_ entries",
          info: "Showing _START_ to _END_ of _TOTAL_ entries",
          infoEmpty: "Showing 0 to 0 of 0 entries",
          infoFiltered: "(filtered from _MAX_ total entries)",
          search: "Search:",
          zeroRecords: "No matching records found",
        },
      });
    });
  </script>
  <title>Visitor Logs</title>
  <link rel="stylesheet" href="../assets/styles/general.css" />
  <link rel="stylesheet" href="../assets/styles/panels.css" />
  <link rel="stylesheet" href="../assets/styles/orders.css" />

  <style>
    .nav-tabs {
      display: flex;
      justify-content: space-between;
    }
    .nav-tabs clic-link {
      flex: 1;
      text-align: center;
      font-weight: bold;
      color: #333;
      border: none;
      border-bottom: 2px solid transparent;
      transition: border-bottom 0.2s ease;
    }
    .nav-tabs .nav-link.active {
      color: #007bff;
      border-bottom: 2px solid #007bff;
    }
    .tab-content {
      padding: 20px;
    }
    .card {
      border: none;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body class="flex">
  <main>
    <div class="content">
      <!-- Tabs Navigation -->
      <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
          <a class="nav-link active" id="visitor-logs-tab" data-bs-toggle="tab" href="#visitor-logs">Visitor Logs</a>
        </li>
        <!--<li class="nav-item">-->
        <!--  <a class="nav-link" id="current-user-tab" data-bs-toggle="tab" href="#current-user">Current User</a>-->
        <!--</li>-->
      </ul>

      <!-- Tab Content -->
      <div class="tab-content">
        <!-- Visitor Logs Tab -->
        <div class="tab-pane fade show active" id="visitor-logs">
          <div class="card">
            <table id="visitor-logs-table" class="table table-hover">
              <thead class="header">
                <tr>
                  <th>ID</th>
                  <th> NAME</th>
                  <th>DATE</th>
                  <th>TIME</th>
                  <th>IP ADDRESS</th>
                  <th>STATE</th>
                  <th>COUNTRY</th>
                  <th>FLAG</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $sn = 1000;
                foreach ($visitorLogs as $log):
                    // echo '<pre>';
                    // print_r($log);
                    // echo '</pre>';
                  $sn++;
                ?>
                <tr>
    <td><?= $sn ?></td>
    <td  style='width:7%'><?= htmlspecialchars($log['visitor_name'] ?? 'Anonymous') ?></td>
    
    <!-- Format date -->
    <td>
        <?php
        $visitDate = $log['visit_date'] ?? '';
        if ($visitDate) {
            $date = DateTime::createFromFormat('Y-m-d', $visitDate);
            echo $date ? $date->format('d/m/Y') : $visitDate;
        } else {
            echo '';
        }
        ?>
    </td>
    
    <!-- Format time -->
    <td>
        <?php
        $visitTime = $log['visit_time'] ?? '';
        if ($visitTime) {
            $time = DateTime::createFromFormat('H:i:s', $visitTime);
            echo $time ? $time->format('h:i A') : $visitTime;
        } else {
            echo '';
        }
        ?>
    </td>
    
     <?php 
        $country = htmlspecialchars($log['country'] ?? '');
        $code = getCountryCode($country);
        // var_dump($code);
        ?>
    
    <td><?= htmlspecialchars($log['ip_address'] ?? '') ?></td>
    <td><?= htmlspecialchars($log['state'] ?? '') ?></td>
    <td><?= htmlspecialchars($log['country'] ?? '') ?></td>
    <td>
       
        <img src="https://flagcdn.com/24x18/<?= $code ?>.png" alt="<?= $country ?> flag" style="margin-right:5px;" />
        <!--<?= $code ?>-->
    </td>
</tr>

                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>

     
      </div>
    </div>
  </main>

  <script>
    const username = '<?php echo addslashes($first_name); ?>';
    const userRole = '<?php echo addslashes($userRole); ?>';
    const profilePicture = '<?php echo addslashes($profilePicture); ?>';
  </script>
  <script src="../scripts/components.js"></script>
</body>
</html>