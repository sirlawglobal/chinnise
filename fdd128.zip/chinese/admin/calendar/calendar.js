// DOM Elements
const container = document.getElementById("container");
const scheduleDetails = document.getElementById("scheduleDetails");
const newSchedule = document.getElementById("newSchedule");
const addScheduleBtn = document.getElementById("addScheduleBtn");
const closeNewScheduleBtn = document.getElementById("closeNewSchedule");

const newScheduleForm = document.getElementById("newSchedule");
const createScheduleBtn = document.getElementById("createScheduleBtn");
const titleInput = document.getElementById("scheduleTitle");
const categoryInput = document.getElementById("scheduleCategory");
const dateInput = document.getElementById("scheduleDate");
const timeInput = document.getElementById("scheduleTime");
const endTimeInput = document.getElementById("scheduleEndTime");
const teamInput = document.getElementById("scheduleTeam");
const venueInput = document.getElementById("scheduleVenue");
const notesInput = document.getElementById("scheduleNotes");

const calendarHeader = document.getElementById("calendarDayHeader");
const calendarHeaderTitle = document.getElementById("calendarTitle");
const weekHeader = document.querySelector(".week-header");
const monthSelector = document.getElementById("monthSelector");
const yearSelector = document.getElementById("yearSelector");
const calendarGrid = document.getElementById("calendarGrid");
const viewButtons = document.querySelectorAll(".view-btn");
const prevViewBtn = document.getElementById("prevViewBtn");
const nextViewBtn = document.getElementById("nextViewBtn");

prevViewBtn.addEventListener("click", navigatePrevious);
nextViewBtn.addEventListener("click", navigateNext);

let currentDate = new Date();
let currentMonth = currentDate.getMonth();
let currentYear = currentDate.getFullYear();
let currentView = "month"; // Default view

let months = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

// Calendar events
let events = [];

const API_URL = '/chinnese-restaurant/admin/calendar/schedules.php';

function formatDate(dateStr) {
  const options = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateStr).toLocaleDateString(undefined, options);
}

function renderSidebar(events) {
  const sidebar = document.querySelector('.sidebar');
  if (!sidebar) {
    console.warn('Sidebar element not found.');
    return;
  }

  sidebar.innerHTML = '<h2>Schedule Details</h2>';

  if (!events.length) {
    sidebar.innerHTML += '<div class="empty-state">No schedules found.</div>';
    return;
  }

  events.forEach(event => {
    const teamList = (event.people || []).map(name => `
      <div class="team-member">
        <div class="avatar">${name}</div>
        ${name}
      </div>`).join('');

    const scheduleHTML = `
      <div class="schedule-item">
        <div class="schedule-title">${event.title}</div>
        <div class="menu-updates-tag ${event.type}">${event.category}</div>
        <div class="schedule-details-row">📅 ${formatDate(event.date)}</div>
        <div class="schedule-details-row">🕒 ${event.startTime} - ${event.endTime}</div>
        <div class="schedule-details-row">📍 ${event.venue || "No venue"}</div>
        <div class="team-section">
          <div class="team-title">Team</div>
          <div class="team-members">${teamList}</div>
        </div>
        <div class="notes-section">
          <div class="notes-title">Notes</div>
          <div class="notes-content">${event.notes || "No notes available"}</div>
        </div>
      </div>
    `;

    sidebar.insertAdjacentHTML('beforeend', scheduleHTML);
  });
}

addScheduleBtn.addEventListener("click", showNewScheduleForm);
closeNewScheduleBtn.addEventListener("click", hideNewScheduleForm);

const today = new Date();
const defaultDateFormatted = `${today.getFullYear()}-${String(
  today.getMonth() + 1
).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
let selectedDate = defaultDateFormatted;

function populateYearSelector() {
  const startYear = currentYear - 10;
  const endYear = currentYear + 10;
  for (let i = startYear; i <= endYear; i++) {
    const option = document.createElement("option");
    option.value = i;
    option.textContent = i;
    if (i === currentYear) {
      option.selected = true;
    }
    yearSelector.appendChild(option);
  }
}

function navigatePrevious() {
  if (currentView === "month") {
    currentMonth--;
    if (currentMonth < 0) {
      currentMonth = 11;
      currentYear--;
    }
  } else if (currentView === "week") {
    const firstDayOfCurrentWeek = getStartOfWeek(currentDate);
    currentDate = new Date(
      firstDayOfCurrentWeek.getFullYear(),
      firstDayOfCurrentWeek.getMonth(),
      firstDayOfCurrentWeek.getDate() - 7
    );
  } else if (currentView === "day") {
    currentDate.setDate(currentDate.getDate() - 1);
  } else if (currentView === "year") {
    currentYear--;
  }
  updateCalendarView(currentView);
}

function navigateNext() {
  if (currentView === "month") {
    currentMonth++;
    if (currentMonth > 11) {
      currentMonth = 0;
      currentYear++;
    }
  } else if (currentView === "week") {
    const firstDayOfCurrentWeek = getStartOfWeek(currentDate);
    currentDate = new Date(
      firstDayOfCurrentWeek.getFullYear(),
      firstDayOfCurrentWeek.getMonth(),
      firstDayOfCurrentWeek.getDate() + 7
    );
  } else if (currentView === "day") {
    currentDate.setDate(currentDate.getDate() + 1);
  } else if (currentView === "year") {
    currentYear++;
  }
  updateCalendarView(currentView);
}

function generateMonthView(month, year, eventsData = events) {
  calendarHeaderTitle.innerHTML = `${months[month]} ${year}`;
  weekHeader.textContent = "";
  calendarGrid.classList.add("month-view");
  calendarGrid.classList.remove("year-view", "week-view", "day-view");

  calendarGrid.innerHTML = `
    <div class="calendar-day-header">Sun</div>
    <div class="calendar-day-header">Mon</div>
    <div class="calendar-day-header">Tue</div>
    <div class="calendar-day-header">Wed</div>
    <div class="calendar-day-header">Thu</div>
    <div class="calendar-day-header">Fri</div>
    <div class="calendar-day-header">Sat</div>
  `;

  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  const daysInMonth = lastDayOfMonth.getDate();
  const startingDay = firstDayOfMonth.getDay();

  const today = new Date();
  const currentMonthToday = today.getMonth();
  const currentYearToday = today.getFullYear();
  const currentDateToday = today.getDate();

  for (let i = 0; i < startingDay; i++) {
    const emptyCell = document.createElement("div");
    emptyCell.classList.add("calendar-day", "empty");
    calendarGrid.appendChild(emptyCell);
  }

  for (let i = 1; i <= daysInMonth; i++) {
    const dayCell = document.createElement("div");
    dayCell.classList.add("calendar-day");
    dayCell.dataset.year = year;
    dayCell.dataset.month = month;
    dayCell.dataset.day = i;
    dayCell.style.cursor = "pointer";

    if (
      currentYearToday === year &&
      currentMonthToday === month &&
      currentDateToday === i
    ) {
      dayCell.classList.add("today");
    }

    dayCell.addEventListener("click", (event) => {
      if (
        event.target === dayCell ||
        event.target.classList.contains("day-number")
      ) {
        const year = parseInt(dayCell.dataset.year);
        const month = parseInt(day 업데이트Cell.dataset.month);
        const day = parseInt(dayCell.dataset.day);
        const newSelectedDate = new Date(year, month, day);
        const formattedDate = `${newSelectedDate.getFullYear()}-${String(
          newSelectedDate.getMonth() + 1
        ).padStart(2, "0")}-${String(newSelectedDate.getDate()).padStart(2, "0")}`;

        document.getElementById("scheduleDate").value = formattedDate;
        selectedDate = formattedDate;
        showNewScheduleForm();
      }
    });

    const dayNumber = document.createElement("div");
    dayNumber.classList.add("day-number");
    dayNumber.textContent = i;
    dayCell.appendChild(dayNumber);

    const eventsOnThisDay = getEventsForDate(new Date(year, month, i), eventsData);
    eventsOnThisDay.forEach((event) => {
      if (!event || !event.title) return;

      const eventDiv = document.createElement("div");
      eventDiv.classList.add("event", event.type);
      eventDiv.style.cursor = "pointer";
      eventDiv.dataset.year = year;
      eventDiv.dataset.month = month;
      eventDiv.dataset.day = i;

      eventDiv.innerHTML = `
        <div class="event-title">${event.title}</div>
        <div class="event-time">${event.time}</div>
        <div class="event-actions">
          <button class="edit-event" data-id="${event.id}">✏️</button>
          <button class="delete-event" data-id="${event.id}">🗑️</button>
        </div>
        ${
          event.people
            ? `<div class="event-people">${event.people
                .map((person) => `<div class="avatar">${person}</div>`)
                .join("")}</div>`
            : ""
        }
      `;

      dayCell.appendChild(eventDiv);
    });

    calendarGrid.appendChild(dayCell);
  }

  setTimeout(() => {
    document.querySelectorAll(".edit-event").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const id = btn.dataset.id;
        const event = events.find((ev) => ev.id == id);
        if (event) openEditForm(event);
      });
    });

    document.querySelectorAll(".delete-event").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const id = btn.dataset.id;
        Swal.fire({
          title: 'Are you sure?',
          text: 'Do you want to delete this event?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Yes, delete it!',
          cancelButtonText: 'Cancel',
        }).then((result) => {
          if (result.isConfirmed) {
            deleteEventById(id);
          }
        });
      });
    });
  }, 0);
}

function showDayViewForEvent(event) {
  event.stopPropagation();
  const eventDiv = event.target.closest(".event");
  if (eventDiv) {
    const year = parseInt(eventDiv.dataset.year);
    const month = parseInt(eventDiv.dataset.month);
    const day = parseInt(eventDiv.dataset.day);

    if (!isNaN(year) && !isNaN(month) && !isNaN(day)) {
      const newSelectedDate = new Date(year, month, day);
      currentDate = newSelectedDate;
      updateCalendarView("day");
    } else {
      console.error("Could not parse date from event dataset:", eventDiv.dataset);
    }
  } else {
    console.error("Clicked element is not within an event div.");
  }
}

function generateWeekView(date, eventsData = events) {
  calendarHeaderTitle.innerHTML = `Week of ${date.toDateString()}`;
  weekHeader.textContent = "";
  calendarGrid.innerHTML = "";
  calendarGrid.classList.add("week-view");
  calendarGrid.classList.remove("day-view", "month-view", "year-view");

  const startOfWeek = new Date(date);
  startOfWeek.setDate(date.getDate() - date.getDay());

  for (let i = 0; i < 7; i++) {
    const currentDate = new Date(startOfWeek);
    currentDate.setDate(startOfWeek.getDate() + i);

    const dayColumn = document.createElement("div");
    dayColumn.classList.add("week-day-column");

    const header = document.createElement("div");
    header.classList.add("week-day-header");
    header.innerText = currentDate.toDateString();
    dayColumn.appendChild(header);

    const eventsForDay = getEventsForDate(currentDate, eventsData);

    eventsForDay.forEach(event => {
      const eventDiv = document.createElement("div");
      eventDiv.classList.add("event", event.type);
      eventDiv.innerHTML = `
        <div>${event.title}</div>
        <div class="event-time">${event.time}</div>
      `;
      dayColumn.appendChild(eventDiv);
    });

    calendarGrid.appendChild(dayColumn);
  }
}

function addEventToCellInWeekView(cell, event) {
  const eventDiv = document.createElement("div");
  eventDiv.classList.add("event", event.type, "week-event");
  eventDiv.innerHTML = `
    <div class="event-title">${event.title}</div>
    <div class="event-time">${event.time}</div>
    ${
      event.people
        ? `<div class="event-people">${event.people
            .map((person) => `<div class="avatar">${person}</div>`)
            .join("")}</div>`
        : ""
    }
  `;
  cell.appendChild(eventDiv);
}

viewButtons.forEach((button) => {
  button.addEventListener("click", (e) => {
    const view = e.target.dataset.view;
    updateCalendarView(view);
  });
});

function generateYearView(year, eventsData = events) {
  calendarHeaderTitle.innerHTML = `${year}`;
  weekHeader.textContent = "";
  calendarGrid.innerHTML = "";
  calendarGrid.classList.add("year-view");
  calendarGrid.classList.remove("day-view", "week-view", "month-view");

  for (let month = 0; month < 12; month++) {
    const monthContainer = document.createElement("div");
    monthContainer.classList.add("month-container");
    generateMiniMonth(month, year, monthContainer, eventsData);
    calendarGrid.appendChild(monthContainer);
  }
}

function generateMiniMonth(month, year, container, eventsData = events) {
  const monthName = months[month];
  const title = document.createElement("div");
  title.classList.add("mini-month-title");
  title.textContent = monthName;
  container.appendChild(title);

  const daysGrid = document.createElement("div");
  daysGrid.classList.add("mini-month-grid");

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  for (let i = 0; i < firstDay; i++) {
    const empty = document.createElement("div");
    empty.classList.add("mini-day", "empty");
    daysGrid.appendChild(empty);
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const cell = document.createElement("div");
    cell.classList.add("mini-day");
    const cellDate = new Date(year, month, day);
    const eventsOnDay = getEventsForDate(cellDate, eventsData);
    if (eventsOnDay.length) cell.classList.add("has-event");
    cell.textContent = day;
    daysGrid.appendChild(cell);
  }

  container.appendChild(daysGrid);
}

function navigateToMonthView(event) {
  const month = parseInt(event.target.dataset.month);
  const year = parseInt(event.target.dataset.year);
  currentMonth = month;
  currentYear = year;
  monthSelector.value = currentMonth;
  yearSelector.value = currentYear;
  updateCalendarView("month");
}

function getStartOfWeek(date) {
  const day = date.getDay();
  const diff = date.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(date.setDate(diff));
}

function getEventsForDate(date, data = events) {
  return data.filter((event) => {
    const eventDate = new Date(event.date);
    return (
      eventDate.getFullYear() === date.getFullYear() &&
      eventDate.getMonth() === date.getMonth() &&
      eventDate.getDate() === date.getDate()
    );
  });
}

function getEventsForDateTime(date) {
  const year = date.getFullYear();
  const month = date.getMonth();
  const day = date.getDate();
  return events.filter((event) => {
    const eventDate = new Date(event.date);
    return (
      eventDate.getFullYear() === year &&
      eventDate.getMonth() === month &&
      eventDate.getDate() === day
    );
  });
}

function addEventToCell(event) {
  const eventDiv = document.createElement("div");
  eventDiv.classList.add("event", event.type);
  eventDiv.innerHTML = `
    <div>${event.title}</div>
    <div class="event-time">${event.time}</div>
    ${
      event.people
        ? `<div class="event-people">${event.people
            .map((person) => `<div class="avatar">${person}</div>`)
            .join("")}</div>`
        : ""
    }
  `;

  const eventDate = new Date(event.date);
  const dayOfMonth = eventDate.getDate();

  const dayCells = calendarGrid.querySelectorAll(".calendar-day:not(.empty)");
  dayCells.forEach((cell) => {
    const dayNumberElement = cell.querySelector(".day-number");
    if (
      dayNumberElement &&
      parseInt(dayNumberElement.textContent) === dayOfMonth
    ) {
      cell.appendChild(eventDiv);
    }
  });
}

function updateCalendarView(view, data = events) {
  currentView = view;

  viewButtons.forEach((btn) => btn.classList.remove("active"));
  const activeBtn = document.querySelector(`.view-btn[data-view="${view}"]`);
  if (activeBtn) activeBtn.classList.add("active");

  if (currentView === "month") {
    generateMonthView(currentMonth, currentYear, data);
    monthSelector.value = currentMonth;
    yearSelector.value = currentYear;
  } else if (currentView === "week") {
    generateWeekView(currentDate, data);
  } else if (currentView === "day") {
    generateDayView(currentDate, data);
  } else if (currentView === "year") {
    generateYearView(currentYear, data);
    yearSelector.value = currentYear;
  }
}

function generateDayView(date, eventsData = events) {
  calendarHeaderTitle.innerHTML = `${date.toDateString()}`;
  weekHeader.textContent = "";
  calendarGrid.classList.add("day-view");
  calendarGrid.classList.remove("year-view", "week-view", "month-view");
  calendarGrid.innerHTML = `<div class="calendar-day-header">Time</div><div class="day-view-column"></div>`;
  const dayViewColumn = calendarGrid.querySelector(".day-view-column");

  const eventsOnThisDay = getEventsForDateTime(date, eventsData);

  for (let hour = 0; hour < 24; hour++) {
    const timeSlotContainer = document.createElement("div");
    timeSlotContainer.classList.add("time-slot-container");

    const timeLabel = document.createElement("div");
    timeLabel.classList.add("time-slot-label");
    timeLabel.textContent = `${String(hour).padStart(2, "0")}:00`;
    timeSlotContainer.appendChild(timeLabel);

    const eventArea = document.createElement("div");
    eventArea.classList.add("event-area");
    timeSlotContainer.appendChild(eventArea);

    const eventsInThisHour = eventsOnThisDay.filter((event) => {
      const eventStartHour = parseInt(event.startTime.split(":")[0]);
      const eventEndHour = event.endTime
        ? parseInt(event.endTime.split(":")[0])
        : eventStartHour + 1;
      return eventStartHour <= hour && hour < eventEndHour;
    });

    if (eventsInThisHour.length > 0) {
      const overlaps = findOverlappingEvents(eventsInThisHour);
      const positions = calculateEventPositions(eventsInThisHour, overlaps);

      eventsInThisHour.forEach((event) => {
        const eventDiv = addEventToDayView(event);
        eventDiv.style.width = `${positions[event.id].width}%`;
        eventDiv.style.left = `${positions[event.id].left}%`;
        eventArea.appendChild(eventDiv);
      });
    }

    dayViewColumn.appendChild(timeSlotContainer);
  }
}

function addEventToDayView(event) {
  const eventDiv = document.createElement("div");
  eventDiv.classList.add("event", event.type, "day-event");
  eventDiv.innerHTML = `
    <div class="event-title">${event.title}</div>
    <div class="event-details">${event.time} ${
      event.venue ? `(${event.venue})` : ""
    }</div>
    ${
      event.people
        ? `<div class="event-people">${event.people
            .map((person) => `<div class="avatar">${person}</div>`)
            .join("")}</div>`
        : ""
    }
    <div class="event-notes">${event.notes || ""}</div>
  `;
  return eventDiv;
}

function findOverlappingEvents(events) {
  const overlaps = {};
  for (let i = 0; i < events.length; i++) {
    overlaps[events[i].id] =
      events.filter(
        (e) =>
          e.id !== events[i].id &&
          parseInt(e.time.split(":")[0]) ===
            parseInt(events[i].time.split(":")[0])
      ).length > 0;
  }
  return overlaps;
}

function calculateEventPositions(events, overlaps) {
  const positions = {};
  const numOverlapping = events.filter((e) => overlaps[e.id]).length;
  const baseWidth = numOverlapping > 0 ? 100 / (numOverlapping + 1) : 100;
  let currentLeft = 0;

  events.forEach((event) => {
    positions[event.id] = { width: baseWidth, left: currentLeft };
    if (overlaps[event.id]) {
      currentLeft += baseWidth;
    } else {
      currentLeft = 0;
    }
  });

  return positions;
}

function showNewScheduleForm() {
  container.classList.add("slide-left");
}

function hideNewScheduleForm() {
  container.classList.remove("slide-left");
}

function getCategoryClass(slug) {
  return slug || "new-dish";
}

function addEventToCalendar(event) {
  const eventDate = new Date(event.date);
  const day = eventDate.getDate();

  const dayCells = document.querySelectorAll(".calendar-day");
  let targetCell = null;

  dayCells.forEach((cell) => {
    const dayNumber = cell.querySelector(".day-number").textContent;
    if (parseInt(dayNumber) === day) {
      targetCell = cell;
    }
  });

  if (targetCell) {
    const eventElement = document.createElement("div");
    eventElement.className = `event ${event.type}`;
    let eventContent = `
      <div>${event.title}</div>
      <div class="event-time">${event.time}</div>
    `;
    if (event.team) {
      eventContent += `
        <div class="event-people">
          <div class="avatar">HC</div>
        </div>
      `;
    }
    eventElement.innerHTML = eventContent;
    targetCell.appendChild(eventElement);
  }
}

function resetForm() {
  const form = document.getElementById("newSchedule");
  if (form) form.reset();
  document.getElementById("scheduleId").value = "";
  document.getElementById("createScheduleBtn").textContent = "Create";
}

function fetchSchedulesFromServer() {
  console.log("Fetching schedules from API...");

  fetch(API_URL)
    .then(response => response.json())
    .then(data => {
      console.log("API data received:", data);
      events = data.map(event => ({
        id: event.id,
        ...event,
        type: getCategoryClass(event.category_slug),
        category: event.category_name,
        time: `${event.start_time} - ${event.end_time}`,
        startTime: event.start_time,
        endTime: event.end_time,
        people: JSON.parse(event.team || "[]"),
        venue: event.venue,
        notes: event.notes,
        date: event.date,
      }));
      console.log("Event IDs:", events.map(e => e.id));

      updateCalendarView(currentView);
      renderSidebar(events);
      updateFilterCounts(events);
    })
    .catch(error => {
      console.error("Failed to fetch schedules:", error);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Failed to load schedules from server.',
        confirmButtonText: 'OK',
      });
    });
}

function updateFilterCounts(eventsData = events) {
  const countMap = {};
  eventsData.forEach(event => {
    const categorySlug = getCategoryClass(event.category_slug);
    countMap[categorySlug] = (countMap[categorySlug] || 0) + 1;
  });

  const filterTags = document.querySelectorAll(".filter-tag");
  filterTags.forEach(tag => {
    const category = tag.dataset.category;
    const countSpan = tag.querySelector(".filter-count");
    const count = countMap[category] || 0;
    if (countSpan) {
      countSpan.textContent = count;
    }
  });
}

function deleteEventById(id) {
  Swal.fire({
    title: 'Are you sure?',
    text: 'Do you want to delete this event?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!',
    cancelButtonText: 'Cancel',
  }).then((result) => {
    if (result.isConfirmed) {
      fetch(API_URL, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `id=${encodeURIComponent(id)}`
      })
        .then(response => response.json())
        .then(data => {
          if (data.status === 'success') {
            events = events.filter(ev => ev.id != id);
            fetchSchedulesFromServer();
            updateFilterCounts(events);
            Swal.fire({
              icon: 'success',
              title: 'Deleted!',
              text: 'Event deleted successfully.',
              confirmButtonText: 'OK',
            });
          } else {
            console.error("Delete failed:", data.message);
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: 'Failed to delete event.',
              confirmButtonText: 'OK',
            });
          }
        })
        .catch(err => {
          console.error("Delete error:", err);
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Something went wrong while deleting the event.',
            confirmButtonText: 'OK',
          });
        });
    }
  });
}

function openEditForm(event) {
  showNewScheduleForm();
  document.getElementById("scheduleId").value = event.id || '';
  document.getElementById("scheduleTitle").value = event.title || '';
  document.getElementById("scheduleDate").value = event.date || '';
  document.getElementById("scheduleTime").value = event.startTime || '';
  document.getElementById("scheduleEndTime").value = event.endTime || '';
  document.getElementById("scheduleVenue").value = event.venue || '';
  document.getElementById("scheduleNotes").value = event.notes || '';
  document.getElementById("scheduleTeam").value = (event.people || []).join(', ');
  const categorySelect = document.getElementById("scheduleCategory");
  if (categorySelect) {
    categorySelect.value = event.category_id || event.category || '';
  }
  document.getElementById("createScheduleBtn").textContent = "Update";
}

function saveSchedule() {
  const id = document.getElementById("scheduleId").value;
  const title = document.getElementById("scheduleTitle").value;
  const category_id = parseInt(document.getElementById("scheduleCategory").value, 10);
  const date = document.getElementById("scheduleDate").value;
  const startTime = document.getElementById("scheduleTime").value;
  const endTime = document.getElementById("scheduleEndTime").value;
  const team = document.getElementById("scheduleTeam").value;
  const venue = document.getElementById("scheduleVenue").value;
  const notes = document.getElementById("scheduleNotes").value;

  if (!title || !category_id || !date || !startTime || !endTime) {
    Swal.fire({
      icon: 'warning',
      title: 'Missing Information',
      text: 'Please fill in all required fields.',
      confirmButtonText: 'OK',
    });
    return;
  }

  const payload = {
    id: id ? parseInt(id, 10) : 0,
    title,
    category_id,
    date,
    startTime,
    endTime,
    venue,
    notes,
    team: team ? team.split(",").map(t => t.trim()) : []
  };

  console.log("Payload being sent:", payload);
  console.log("Request URL:", API_URL);

  fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
    .then(res => {
      console.log("Response received:", {
        status: res.status,
        ok: res.ok,
        url: res.url
      });
      if (!res.ok) {
        throw new Error(`HTTP error! Status: ${res.status} ${res.statusText}`);
      }
      return res.text();
    })
    .then(text => {
      console.log("Raw response:", text);
      if (!text) {
        throw new Error("Empty response from server");
      }
      try {
        const data = JSON.parse(text);
        console.log("Parsed JSON:", data);
        return data;
      } catch (e) {
        console.error("JSON parse error:", e.message, "Raw response:", text);
        throw new Error(`Invalid JSON response: ${text}`);
      }
    })
    .then(data => {
      console.log("Data received:", data);
      if (typeof data !== "object" || data === null) {
        throw new Error("Response is not a valid JSON object");
      }
      if (data.status === "success") {
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: id ? 'Schedule updated successfully!' : 'Schedule created successfully!',
          confirmButtonText: 'OK',
        }).then(() => {
          fetchSchedulesFromServer();
          hideNewScheduleForm();
          resetForm();
        });
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'Save failed: ' + (data.message || 'Unknown error'),
          confirmButtonText: 'OK',
        });
      }
    })
    .catch(err => {
      console.error("Fetch error:", err);
      Swal.fire({
        icon: 'error',
        title: 'Request Failed',
        text: 'Request failed: ' + err.message,
        confirmButtonText: 'OK',
      });
    });
}

document.addEventListener("DOMContentLoaded", () => {
  const filterTags = document.querySelectorAll(".filter-tag");

  filterTags.forEach(tag => {
    tag.addEventListener("click", () => {
      const selectedCategory = tag.dataset.category;
      filterTags.forEach(t => t.classList.remove("active"));
      tag.classList.add("active");
      const filteredEvents = events.filter(e => getCategoryClass(e.category_slug) === selectedCategory);
      updateCalendarView(currentView, filteredEvents);
      renderSidebar(filteredEvents);
    });
  });

  const createBtn = document.getElementById("createScheduleBtn");
  if (createBtn) {
    createBtn.addEventListener("click", (e) => {
      e.preventDefault();
      saveSchedule();
    });
  }

  console.log("DOM fully loaded 🚀");
  populateYearSelector();
  monthSelector.addEventListener("change", (e) => {
    currentMonth = parseInt(e.target.value);
    updateCalendarView(currentView);
  });
  yearSelector.addEventListener("change", (e) => {
    currentYear = parseInt(e.target.value);
    updateCalendarView(currentView);
  });
  fetchSchedulesFromServer();
});