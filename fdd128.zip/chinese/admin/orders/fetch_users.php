<?php
require_once '../../BackEnd/config/db.php';
header('Content-Type: application/json');

$users = db_query(
    "SELECT id, name, email, phone, role FROM users WHERE role IN ('admin', 'staff') ORDER BY name",
    [],
    'assoc'
);

echo json_encode($users);
?>
