<?php
session_start();
require_once '../../BackEnd/config/db.php'; // Ensure db_connect() is defined

header('Content-Type: application/json'); // Set JSON response header


// echo '<pre>';
// print_r($_GET);
// echo '</pre>';

// Get order ID from GET or POST
$orderId = isset($_GET['id']) ? intval($_GET['id']) : (isset($_POST['id']) ? intval($_POST['id']) : 0);


if ($orderId <= 0) {
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'message' => 'Invalid order ID']);
    exit();
}

try {
    $pdo = db_connect();

    // Check if the order exists
    $checkStmt = $pdo->prepare("SELECT * FROM orders WHERE id = :id");
    $checkStmt->execute([':id' => $orderId]);

    if ($checkStmt->rowCount() === 0) {
        http_response_code(404); // Not Found
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit();
    }

    // Delete the order
    $deleteStmt = $pdo->prepare("DELETE FROM orders WHERE id = :id");
    $deleteStmt->execute([':id' => $orderId]);

    echo json_encode(['success' => true, 'message' => "Order #$orderId has been successfully deleted"]);
} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['success' => false, 'message' => 'Unexpected error: ' . $e->getMessage()]);
}

exit();