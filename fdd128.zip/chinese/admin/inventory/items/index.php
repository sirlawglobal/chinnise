<?php
require_once __DIR__ . '/../../../BackEnd/config/init.php';

if (!isset($_SESSION['user']['id']) || !isset($_SESSION['user']['role'])) {
    header("Location: /login/");
    exit();
}

$username = $_SESSION['user']['name'] ?? '';
$parts = explode(" ", $username);
$first_name = $parts[0];
$userRole = $_SESSION['user']['role'] ?? '';
$profilePicture = $_SESSION['user']['profile_picture'] ?? 'https://picsum.photos/40';
$categories = getCategories();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link
      rel="stylesheet"
      type="text/css"
      href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css"
    />
    <!-- Add SweetAlert2 CDN -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Inventory Management</title>
    <link rel="stylesheet" href="../../assets/styles/general.css" />
    <link rel="stylesheet" href="../../assets/styles/panels.css" />
    <link rel="stylesheet" href="../../assets/styles/inventory.css" />
    <style>
      .inventory-dropdown-toggle {
        padding: 8px 16px;
        border: 1px solid #ccc;
        border-radius: 4px;
        background: white;
        cursor: pointer;
        width: 150px;
      }
      .modal {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 24px;
        border-radius: 12px;
        z-index: 1000;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        max-width: 900px;
        width: 90%;
        opacity: 0;
        transition: opacity 0.3s ease, transform 0.3s ease;
      }
      .modal.show {
        display: block;
        opacity: 1;
        transform: translate(-50%, -50%) scale(1);
      }
      .modal-content {
        position: relative;
      }
      .modal-close-button {
        background: transparent;
        border: none;
        font-size: 24px;
        position: absolute;
        top: 12px;
        right: 12px;
        cursor: pointer;
        color: #555;
        transition: color 0.2s ease;
      }
      .modal-close-button:hover {
        color: #000;
      }
      #modal-backdrop {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: 999;
        transition: opacity 0.3s ease;
      }
      #modal-backdrop.show {
        display: block;
        opacity: 1;
      }
      .modal-form-group {
        margin-bottom: 16px;
      }
      .modal-form-label {
        display: block;
        margin-bottom: 6px;
        font-weight: 600;
        color: #333;
        font-size: 14px;
      }
      .modal-form-input {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 14px;
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
      }
      .modal-form-input:focus {
        outline: none;
        border-color: #28a745;
        box-shadow: 0 0 0 3px rgba(40, 167, 69, 0.1);
      }
      .modal-form-input:invalid:focus {
        border-color: #dc3545;
        box-shadow: 0 0 0 3px rgba(220, 53, 69, 0.1);
      }
      .modal-action-button {
        background: linear-gradient(90deg, #28a745, #34c759);
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        font-weight: 600;
        transition: background 0.2s ease, transform 0.1s ease;
      }
      .modal-action-button:hover {
        background: linear-gradient(90deg, #218838, #2ea44f);
        transform: translateY(-1px);
      }
      .modal-action-button:active {
        transform: translateY(0);
      }
      .view-button {
        background: linear-gradient(90deg, #007bff, #00aaff);
        color: white;
        padding: 8px 16px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        transition: background 0.2s ease;
      }
      .view-button:hover {
        background: linear-gradient(90deg, #0056b3, #0088cc);
      }
      .secondary-button {
        background: linear-gradient(90deg, #6b7280, #8b95a5);
        color: white;
        padding: 8px 16px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        transition: background 0.2s ease;
      }
      .secondary-button:hover {
        background: linear-gradient(90deg, #4b5563, #6b7280);
      }
      .modal-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
      }
      .modal-table th, .modal-table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
      }
      .modal-table th {
        background-color: #f2f2f2;
        font-weight: bold;
      }
      .modal-table td {
        background-color: #fff;
      }
      .add-form-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
        margin-bottom: 20px;
      }
      .add-form-grid.full-width {
        grid-column: 1 / -1;
      }
      @media (max-width: 768px) {
        .add-form-grid {
          grid-template-columns: 1fr;
        }
      }
      .modal-title {
        font-size: 20px;
        font-weight: 700;
        color: #222;
        margin-bottom: 20px;
        text-align: center;
      }
      .modal-actions {
        text-align: center;
        margin-top: 20px;
      }
      
      .modal {
        max-height: 80vh;
        overflow-y: auto;
      }

      .modal-content {
        max-height: calc(80vh - 48px);
        display: flex;
        flex-direction: column;
      }

      .modal-table-container {
        overflow-y: auto;
        max-height: calc(80vh - 150px);
        margin-top: 10px;
      }
      
      .modal-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
          font-size: 14px;
        }
        
        .modal-table thead {
          background-color: #f5f5f5;
        }
        
        .modal-table th,
        .modal-table td {
          padding: 10px;
          border: 1px solid #ddd;
          text-align: left;
        }
        
        .modal-table tr:nth-child(even) {
          background-color: #fafafa;
        }
        
        .modal-table th {
          font-weight: bold;
          color: #333;
        }
        
        /* Close button (optional) */
        .modal-close {
          float: right;
          font-size: 20px;
          font-weight: bold;
          cursor: pointer;
          color: #333;
        }
        
        .modal-close:hover {
          color: #f00;
        }
    </style>
  </head>
  <body class="flex">
    <main>
      <div class="content flex">
        <div class="grid g-af2">
          <div class="card">
            <p>Supply Overview</p>
            <div class="title flex justify-between align-center">
              <h3 id="weeklyTotal">0</h3>
              <div class="filter">
                <strong id="dateRangeLabel" class="flex align-center justify-content-xxl-between">
                  This Week
                  <svg class="icon caret"><use href="#caret-down"></use></svg>
                </strong>
                <div class="dropdown"></div>
              </div>
            </div>
            <div style="height: 250px;">
              <canvas id="supplyChart" style="height: 100%; width: 100%;"></canvas>
            </div>
          </div>
          <div class="card">
            <div class="total flex align-center">
              <h2 id="totalProducts"></h2>
              Products
            </div>
            <div style="height: 250px;">
              <canvas id="stockChart" style="height: 100%; width: 100%;"></canvas>
            </div>
            <div class="legend flex justify-between align-center">
              <div class="legend-item">
                <div class="flex align-center">
                  <span class="legend-color"></span> In Stock:
                </div>
                <div class="flex align-center">
                  <h1 id="inStock1"></h1>
                  Products
                </div>
              </div>
              <div class="legend-item">
                <div class="flex align-center">
                  <span class="legend-color"></span> Low:
                </div>
                <div class="flex align-center">
                  <h1 id="inStock2"></h1>
                  Products
                </div>
              </div>
              <div class="legend-item">
                <div class="flex align-center">
                  <span class="legend-color"></span> Out of Stock:
                </div>
                <div class="flex align-center">
                  <h1 id="inStock3"></h1>
                  Products
                </div>
              </div>
            </div>
          </div>
          <div class="inventory-overview card table">
            <div class="inventory-actions">
              <div class="tabs">
                <button class="tab active">Inventory</button>
                <a href="../purchase-orders" class="tab">Purchase Order</a>
              </div>
              <div class="search-filter-add">
                <div class="search-bar">
                  <input type="text" id="inventorySearch" placeholder="Search for menu" />
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                  </svg>
                </div>
                <div class="filter-dropdowns">
                  <div class="dropdown">
                    <select id="categoryFilter" class="inventory-dropdown-toggle">
                      <option value="">All Category</option>
                      <?php if(isset($categories)):?>
                        <?php foreach ($categories as $category): ?>
                          <option value="<?= $category['name'] ?>"><?= $category['name'] ?></option>
                        <?php endforeach; ?>
                      <?php endif; ?>
                    </select>
                  </div>
                  <div class="dropdown">
                    <select id="statusFilter" class="inventory-dropdown-toggle">
                      <option value="">All Status</option>
                      <option value="Available">Available</option>
                      <option value="Low">Low</option>
                      <option value="Out of Stock">Out of Stock</option>
                    </select>
                  </div>
                </div>
                <button class="add-product-button" id="addProduct">
                  + Add Inventory
                </button>
              </div>
            </div>
            <div class="modal" id="addModal">
              <div class="modal-content">
                <button class="modal-close-button">×</button>
                <h2 class="modal-title">Add Inventory Item</h2>
                <form id="add-stock-item-form" method="POST">
                  <div class="add-form-grid">
                    <div class="modal-form-group">
                      <label for="category" class="modal-form-label">Category</label>
                      <div class="select-wrapper">
                        <select id="category" name="category_id" class="modal-form-input" required>
                          <option value="">Select Category</option>
                          <?php if (isset($categories)): ?>
                            <?php foreach ($categories as $category): ?>
                              <option value="<?= $category['id'] ?>"><?= $category['name'] ?></option>
                            <?php endforeach; ?>
                          <?php endif; ?>
                        </select>
                      </div>
                    </div>
                    <div class="modal-form-group">
                      <label for="name" class="modal-form-label">Description</label>
                      <select id="name" name="description" class="modal-form-input" required>
                        <option value="">Select an item or add new</option>
                        <option value="__add_new__" class="add-new-option">+ Add New Item</option>
                      </select>
                      <div id="newItemContainer" style="display: none; margin-top: 8px;">
                        <input type="text" id="newItemName" class="modal-form-input" placeholder="Enter new item name">
                      </div>
                    </div>
                    <div class="modal-form-group">
                      <label for="qty_ordered" class="modal-form-label">Quantity Ordered</label>
                      <input
                        type="number"
                        id="qty_ordered"
                        name="qty_ordered"
                        placeholder="e.g., 50"
                        class="modal-form-input"
                        required
                      />
                    </div>
                    <div class="modal-form-group">
                      <label for="qty_delivered" class="modal-form-label">Quantity Delivered</label>
                      <input
                        type="number"
                        id="qty_delivered"
                        name="qty_delivered"
                        placeholder="e.g., 50"
                        class="modal-form-input"
                        required
                      />
                    </div>
                  </div>
                  <div class="modal-actions">
                    <button type="submit" class="modal-action-button">Add Stock Item</button>
                  </div>
                </form>
              </div>
            </div>
            <table id="inventory-table" class="display">
              <thead>
                <tr>
                  <th></th>
                  <th>Date</th>
                  <th>InvID</th>
                  <th>Category</th>
                  <th>Description</th>
                  <th>Status</th>
                  <th>Previous Qty</th>
                  <th>Qty Delivered</th>
                  <th>Qty in Stock</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <!-- Data will be populated dynamically via DataTable -->
              </tbody>
            </table>
            <div class="modal" id="summaryViewModal">
              <div class="modal-content">
                <h2 class="modal-title">Inventory Item Details</h2>
                <div class="modal-table-container">
                  <table class="modal-table">
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>InvID</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Qty Ordered</th>
                        <th>Qty Delivered</th>
                      </tr>
                    </thead>
                    <tbody>
                      <!-- Content will be populated here -->
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div class="modal" id="updateStockModal">
              <div class="modal-content">
                <button class="modal-close-button">×</button>
                <h2 class="modal-title">Update Stock</h2>
                <form id="updateStockForm" class="modal-form">
                  <div class="modal-form-group">
                    <label for="updateItemName" class="modal-form-label">Item Name</label>
                    <input type="text" id="updateItemName" class="modal-form-input" readonly>
                  </div>
                  <div class="modal-form-group">
                    <label for="newStockQuantity" class="modal-form-label">New Stock Quantity</label>
                    <input type="number" id="newStockQuantity" class="modal-form-input" min="0" required>
                  </div>
                  <div class="modal-form-group">
                    <label for="actionS" class="modal-form-label">Action</label>
                    <select id="actionS" class="modal-form-input" required>
                      <option value="">Select Action</option>
                      <option value="1">Subtract</option>
                      <option value="2">Addition</option>
                    </select>
                  </div>
                  <input type="hidden" id="updateItemId">
                  <div class="modal-actions">
                    <button type="submit" class="modal-action-button">Update</button>
                  </div>
                </form>
              </div>
            </div>
            <div class="modal" id="reorderModal">
              <div class="modal-content">
                <button class="modal-close-button">×</button>
                <h2 class="modal-title">Reorder Item</h2>
                <form id="reorderForm" class="modal-form">
                  <div class="modal-form-group">
                    <label for="reorderItemName" class="modal-form-label">Item Name</label>
                    <input type="text" id="reorderItemName" class="modal-form-input" readonly>
                  </div>
                  <div class="modal-form-group">
                    <label for="reorderQuantity" class="modal-form-label">Reorder Quantity</label>
                    <input type="number" id="reorderQuantity" class="modal-form-input" min="1" required>
                  </div>
                  <div class="modal-form-group">
                    <label for="actionS" class="modal-form-label">Action</label>
                    <select id="record" class="modal-form-input" required>
                      <option value="">Select Action</option>
                      <option value="1">Subtract</option>
                      <option value="2">Addition</option>
                    </select>
                  </div>
                  <input type="hidden" id="reorderItemId">
                  <div class="modal-actions">
                    <button type="submit" class="modal-action-button">Place Reorder</button>
                  </div>
                </form>
              </div>
            </div>
            <div id="modal-backdrop"></div>
          </div>
        </div>
      </div>
    </main>
    
    <script>
      function formatDate(dateString) {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = String(date.getFullYear()).slice(-2);
        return `${day}/${month}/${year}`;
      }
    </script>

    <script
      type="text/javascript"
      charset="utf8"
      src="https://code.jquery.com/jquery-3.6.0.min.js"
    ></script>
    <script
      type="text/javascript"
      charset="utf8"
      src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"
    ></script>
    <script>
      let table;
      const modalBackdrop = $('#modal-backdrop');
      $(document).ready(function () {
        let ROOTS = "<?= ROOT ?>";

        // Initialize DataTable
        table = $('#inventory-table').DataTable({
          ajax: {
            url: '../../../BackEnd/controller/inventory/fetch_inventory.php',
            dataSrc: function (json) {
              console.log('Database Response:', json);
              if (!json || !json.data) {
                console.error('Invalid or empty data received');
                return [];
              }
              return json.data;
            },
            error: function (xhr, error, thrown) {
              console.error('AJAX Error:', error, thrown);
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Failed to load inventory data: ' + error,
                confirmButtonText: 'OK',
                confirmButtonColor: '#28a745'
              });
            }
          },
          columns: [
            { 
              data: null, 
              defaultContent: '<input type="checkbox" />',
              orderable: false,
              searchable: false
            },
            { 
              data: 'delivery_date',
              render: function (data) {
                if (!data) return 'N/A';
                const date = new Date(data);
                const day = String(date.getDate()).padStart(2, '0');
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const year = String(date.getFullYear()).slice(-2);
                return `${day}/${month}/${year}`;
              }
            },
            { 
              data: 'inventory_id',
              render: function (data) {
                return data ? 'InV0' + data : 'N/A';
              }
            },
            { 
              data: 'category',
              render: function (data) {
                return data || 'N/A';
              }
            },
            { 
              data: 'description',
              render: function (data) {
                return data || 'N/A';
              }
            },
            { 
              data: 'status',
              render: function (data, type, row) {
                if (type === 'display') {
                  const className = data ? data.toLowerCase().replace(' ', '-') : 'unknown';
                  return `<span class="status ${className}">${data || 'Unknown'}</span>`;
                }
                return data || '';
              }
            },
            { 
              data: 'current_qty',
              render: function (data) {
                return data !== null && data !== undefined ? data : 0;
              }
            },
            { 
              data: 'qty_delivered',
              render: function (data) {
                return data !== null && data !== undefined ? data : 0;
              }
            },
            { 
              data: 'qty_in_stock',
              render: function (data) {
                return data || 'N/A';
              }
            },
            {
              data: null,
              render: function (data, type, row) {
                return `<button class="view-button" data-id="${row.inventory_id}">View</button>`;
              },
              orderable: false,
              searchable: false
            }
          ],
          paging: true,
          pageLength: 10,
          language: {
            paginate: {
              previous: '‹',
              next: '›'
            },
            lengthMenu: "Show _MENU_ entries",
            info: "Showing _START_ to _END_ of _TOTAL_ entries",
            search: "",
            zeroRecords: "No matching records found"
          }
        });

        // Search bar functionality
        $('#inventorySearch').on('keyup', function () {
          table.search(this.value).draw();
        });

        // Custom filtering for category and status
        $.fn.dataTable.ext.search.push(function (settings, data, dataIndex) {
          const categoryFilter = $('#categoryFilter').val();
          const statusFilter = $('#statusFilter').val();
          const category = data[3] || '';
          const status = data[5] || '';
          const categoryMatch = !categoryFilter || category === categoryFilter;
          const statusMatch = !statusFilter || status === statusFilter;
          return categoryMatch && statusMatch;
        });

        // Apply filters when dropdowns change
        $('#categoryFilter, #statusFilter').on('change', function () {
          table.draw();
        });

        // Toggle add product modal
        $('#addProduct').on('click', function () {
          $('#addModal').add(modalBackdrop).addClass('show');
        });

        // Close modals
        $('.modal-close-button').on('click', function () {
          $('.modal').add(modalBackdrop).removeClass('show');
        });

        // Close modal when clicking backdrop
        modalBackdrop.on('click', function () {
          $('.modal').add(modalBackdrop).removeClass('show');
        });

        // Add stock item form submission
        document.getElementById("add-stock-item-form").addEventListener("submit", function (e) {
          e.preventDefault();
          const formData = new FormData(this);
          console.log(formData);
          fetch("../../../BackEnd/controller/inventory/add_stock_item.php", {
            method: "POST",
            body: formData
          })
            .then(response => response.json())
            .then(data => {
              Swal.fire({
                icon: data.success ? 'success' : 'error',
                title: data.success ? 'Success' : 'Error',
                text: data.message,
                confirmButtonText: 'OK',
                confirmButtonColor: '#28a745'
              });
              if (data.success) {
                this.reset();
                $('#addModal').add(modalBackdrop).removeClass('show');
                table.ajax.reload(null, false);
              }
            })
            .catch(err => {
              console.error("Error adding stock item:", err);
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Error adding stock item: ' + err.message,
                confirmButtonText: 'OK',
                confirmButtonColor: '#28a745'
              });
            });
        });

        // Update stock form submission
        document.getElementById("updateStockForm").addEventListener("submit", function (e) {
          e.preventDefault();
          const itemId = $('#updateItemId').val();
          const newStock = $('#newStockQuantity').val();
          const action = $('#actionS').val();
          fetch("../../../BackEnd/controller/inventory/update_stock.php", {
            method: "POST",
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ inventory_id: itemId, qty_in_stock: newStock, action: action })
          })
            .then(response => response.json())
            .then(data => {
              Swal.fire({
                icon: data.success ? 'success' : 'error',
                title: data.success ? 'Success' : 'Error',
                text: data.message,
                confirmButtonText: 'OK',
                confirmButtonColor: '#28a745'
              });
              if (data.success) {
                $('#updateStockModal').add(modalBackdrop).removeClass('show');
                table.ajax.reload(null, false);
              }
            })
            .catch(err => {
              console.error("Error updating stock:", err);
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Error updating stock: ' + err.message,
                confirmButtonText: 'OK',
                confirmButtonColor: '#28a745'
              });
            });
        });

        // Reorder form submission
        document.getElementById("reorderForm").addEventListener("submit", function (e) {
          e.preventDefault();
          const itemId = $('#reorderItemId').val();
          const reorderQty = $('#reorderQuantity').val();
          const action = $('#record').val();
          fetch("../../../BackEnd/controller/inventory/reorder_item.php", {
            method: "POST",
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ inventory_id: itemId, qty_ordered: reorderQty, action: action })
          })
            .then(response => response.json())
            .then(data => {
              Swal.fire({
                icon: data.success ? 'success' : 'error',
                title: data.success ? 'Success' : 'Error',
                text: data.message,
                confirmButtonText: 'OK',
                confirmButtonColor: '#28a745'
              });
              if (data.success) {
                $('#reorderModal').add(modalBackdrop).removeClass('show');
                table.ajax.reload(null, false);
              }
            })
            .catch(err => {
              console.error("Error reordering item:", err);
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Error reordering item: ' + err.message,
                confirmButtonText: 'OK',
                confirmButtonColor: '#28a745'
              });
            });
        });

        // Update stock button click handler
        $('#inventory-table').on('click', '.update-stock-button', function () {
          const id = $(this).data('id');
          const name = $(this).data('name');
          $('#updateItemId').val(id);
          $('#updateItemName').val(name);
          $('#newStockQuantity').val('');
          $('#actionS').val('');
          $('#updateStockModal').add(modalBackdrop).addClass('show');
        });

        // Reorder button click handler
        $('#inventory-table').on('click', '.reorder-button', function () {
          const id = $(this).data('id');
          const name = $(this).data('name');
          $('#reorderItemId').val(id);
          $('#reorderItemName').val(name);
          $('#reorderQuantity').val('');
          $('#record').val('');
          $('#reorderModal').add(modalBackdrop).addClass('show');
        });
      });

      $('#category').on('change', function() {
        const categoryId = $(this).val();
        const itemDropdown = $('#name');
        const parentContainer = itemDropdown.parent();

        if (itemDropdown.is('input')) {
          itemDropdown.replaceWith('<select id="name" name="description" class="modal-form-input" required><option value="">Select an item</option></select>');
        }

        $('#name').empty().append('<option value="">Select an item</option>');

        if (!categoryId) {
          return;
        }

        fetch(`../../../BackEnd/controller/inventory/fetch_items.php?category_id=${categoryId}`)
          .then(response => response.json())
          .then(data => {
            $('#name').empty().append('<option value="">Select an item</option>');
            if (data.success && data.items.length > 0) {
              data.items.forEach(item => {
                $('#name').append(`<option value="${item.name}">${item.name}</option>`);
              });
            }
            $('#name').append('<option value="add_new_item">Add New Item</option>');
          })
          .catch(err => {
            console.error('Error fetching items:', err);
            $('#name').empty().append('<option value="">Error loading items</option>');
            $('#name').append('<option value="add_new_item">Add New Item</option>');
          });
      });

      $('#add-stock-item-form').on('change', '#name', function() {
        if ($(this).val() === 'add_new_item') {
          const parentContainer = $(this).parent();
          $(this).replaceWith(`
            <input 
              type="text" 
              id="name" 
              name="description" 
              class="modal-form-input" 
              placeholder="Enter new item description" 
              required
            />
          `);
          parentContainer.find('#name').focus();
        }
      });
      
      // View button click handler
      $('#inventory-table').on('click', '.view-button', function() {
        const row = $(this).closest('tr');
        const rowData = table.row(row).data();
        const itemName = rowData.description;
        
        fetch(`../../../BackEnd/controller/inventory/fetch_stock_history.php?item_name=${encodeURIComponent(itemName)}`)
          .then(response => response.json())
          .then(data => {
            if (data.success) {
              $('#summaryViewModal tbody').empty();
              const stockName = data.stock?.name || 'Unknown';
              const catName = data.stock?.category_name || 'Unknown';
              console.log('datastock', data.stock);
              if (data.history && data.history.length > 0) {
                data.history.forEach(history => {
                  console.log('history', history);
                  $('#summaryViewModal tbody').append(`
                    <tr>
                      <td>${formatDate(history.change_date)}</td>
                      <td>${history.stock_id ? 'InV0' + history.stock_id : 'N/A'}</td>
                      <td>${catName}</td>
                      <td>${stockName}</td>
                      <td>${history.new_qty}</td>
                      <td>${history.qty_change > 0 ? '+' : ''}${history.qty_change}</td>
                    </tr>
                  `);
                });
              } else {
                $('#summaryViewModal tbody').append(`
                  <tr>
                    <td colspan="8" style="text-align: center;">No history records found</td>
                  </tr>
                `);
              }
              
              $('#summaryViewModal .modal-title').text(`Stock History for ${itemName}`);
              $('#summaryViewModal').add(modalBackdrop).addClass('show');
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: data.message || 'Error fetching history',
                confirmButtonText: 'OK',
                confirmButtonColor: '#28a745'
              });
            }
          })
          .catch(err => {
            console.error('Error fetching stock history:', err);
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: 'Error loading stock history',
              confirmButtonText: 'OK',
              confirmButtonColor: '#28a745'
            });
          });
      });
    </script>
    <script>
      const username = '<?php echo addslashes($first_name); ?>';
      const userRole = '<?php echo addslashes($userRole); ?>';
      const profilePicture = '<?php echo addslashes($profilePicture); ?>';
      
      console.log('username', username);
      console.log('userRole', userRole);
      console.log('profilePicture', profilePicture);
    </script>
    <script src="../../scripts/components.js"></script>
    <script src="../../scripts/inventory.js"></script>
  </body>
</html>