<?php
require_once __DIR__ . '/../../../BackEnd/config/init.php';

header("Content-Type: application/json");

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get and log input data for debugging
$rawInput = file_get_contents('php://input');
error_log("Raw input: " . $rawInput);
$input = json_decode($rawInput, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    error_log("JSON decode error: " . json_last_error_msg());
    echo json_encode(['success' => false, 'message' => 'Invalid JSON input']);
    exit;
}

error_log("Decoded input: " . print_r($input, true));

// Validate input structure
if (!isset($input['items']) || !is_array($input['items']) || empty($input['items'])) {
    error_log("Items not found or empty in input");
    echo json_encode(['success' => false, 'message' => 'No items provided']);
    exit;
}

// Generate a unique order ID (P10001 format)
// function generateOrderId() {
//     return 'P' . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);
// }


function generateOrderId() {
    $sql = "SELECT MAX(id) AS last_id FROM inves_orders";
    $result = db_query($sql);

    if ($result === false || count($result) === 0) {
        $lastId = 0;
    } else {
        // FIX: Access stdClass property with -> instead of array
        $lastId = $result[0]->last_id ?? 0;
    }

    $nextId = $lastId + 1;
    return 'PO100' . $nextId;
}



// $orderId = generateOrderId();
$orderId = generateOrderId();
$success = true;
$message = "Purchase order created successfully";
$addedItems = [];
$errors = [];

try {
    // Begin transaction
    db_query("START TRANSACTION");
    
    // First create the main order record
    $orderSql = "INSERT INTO inves_orders (
        order_id, 
        vendor_supplier, 
        status, 
        order_date,
        delivery_date, 
        total_price,
        created_at
    ) VALUES (
        :order_id,
        :vendor, 
        :status, 
        :order_date,
        :delivery_date, 
        :total_price,
        NOW()
    )";
    
    // Calculate total order price
    $orderTotal = 0;
    foreach ($input['items'] as $item) {
        if (!isset($item['unit_price'], $item['quantity'])) {
            throw new Exception("Missing price or quantity for an item");
        }
        $orderTotal += (floatval($item['unit_price']) * intval($item['quantity']));
    }
    
    $orderParams = [
        ':order_id' => $orderId,
        ':vendor' => $input['items'][0]['vendor'] ?? 'Unknown Vendor', // Using first item's vendor
        ':status' => $input['items'][0]['status'] ?? 'pending',
        ':order_date' => date('Y-m-d'),
        ':delivery_date' => date('Y-m-d', strtotime('+7 days')),
        ':total_price' => $orderTotal
    ];
    
    $orderResult = db_query($orderSql, $orderParams);
    if ($orderResult === false) {
        throw new Exception("Failed to create order: " . ($GLOBALS['DB_STATE']['error'] ?? 'No error details'));
    }
    
    $insertedOrderId = $GLOBALS['DB_STATE']['insert_id'];
    error_log("Created order with ID: $insertedOrderId");
    
    // Process each item
    foreach ($input['items'] as $item) {
        // Validate required fields
        $requiredFields = ['item_name', 'unit_price', 'vendor', 'category', 'quantity'];
        foreach ($requiredFields as $field) {
            if (!isset($item[$field]) || empty($item[$field])) {
                throw new Exception("Missing required field: $field");
            }
        }
        
        $itemName = $item['item_name'];
        $unitPrice = floatval($item['unit_price']);
        $vendor = $item['vendor'];
        $categoryId = intval($item['category']);
        $quantity = intval($item['quantity']);
        $status = $item['status'] ?? 'pending';
        $totalPrice = $unitPrice * $quantity;
        
        $categoryInput = $item['category']; // This can be an ID or a name

        if (is_numeric($categoryInput)) {
            // If it's already an ID, use it directly
            $categoryId = intval($categoryInput);
        } else {
            // If it's a string, insert it into inves_categories
            $categorySql = "INSERT INTO inves_categories (name, created_at) VALUES (:name, NOW())";
            $categoryParams = [':name' => $categoryInput];
            $categoryResult = db_query($categorySql, $categoryParams);
        
            if ($categoryResult === false) {
                throw new Exception("Failed to insert new category: " . ($GLOBALS['DB_STATE']['error'] ?? 'No error details'));
            }
        
            // Get the inserted ID
            $categoryId = $GLOBALS['DB_STATE']['insert_id'];
            error_log("Inserted new category ID: " . $categoryId);
        }
        
        // Insert order item
        $itemSql = "INSERT INTO inves_order_items (
            order_id, 
            item_name, 
            category_id, 
            price, 
            quantity,
            vendor,
            status,
            created_at
        ) VALUES (
            :order_id, 
            :item_name, 
            :category_id, 
            :price, 
            :quantity,
            :vendor,
            :status,
            NOW()
        )";
        
        $itemParams = [
            ':order_id' => $insertedOrderId,
            ':item_name' => $itemName,
            ':category_id' => $categoryId,
            ':price' => $unitPrice,
            ':quantity' => $quantity,
            ':vendor' => $vendor,
            ':status' => $status
        ];
        
        error_log("Inserting item with params: " . print_r($itemParams, true));
        $itemResult = db_query($itemSql, $itemParams);
        
        if ($itemResult === false) {
            throw new Exception("Failed to insert order item: " . ($GLOBALS['DB_STATE']['error'] ?? 'No error details'));
        }
        
        $addedItems[] = [
            'order_id' => $orderId,
            'item_name' => $itemName,
            'category_id' => $categoryId,
            'unit_price' => $unitPrice,
            'quantity' => $quantity,
            'total_price' => $totalPrice,
            'status' => $status
        ];
    }
    
    // Commit transaction if all went well
    db_query("COMMIT");
    
    // Prepare response data for frontend
    $responseData = [
        'order_id' => $orderId,
        'order_date' => date('Y-m-d'),
        'vendor' => $input['items'][0]['vendor'] ?? 'Unknown Vendor',
        'total_price' => $orderTotal,
        'status' => $input['items'][0]['status'] ?? 'pending',
        'items' => $addedItems
    ];
    
    echo json_encode([
        'success' => true,
        'message' => $message,
        'data' => $responseData
    ]);
    
} catch (Exception $e) {
    // Rollback on error
    db_query("ROLLBACK");
    error_log("Error processing order: " . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'message' => 'Error creating purchase order: ' . $e->getMessage(),
        'error_details' => $errors
    ]);
}