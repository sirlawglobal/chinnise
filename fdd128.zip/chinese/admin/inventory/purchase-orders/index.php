<?php 
require_once __DIR__ . '/../../../BackEnd/config/init.php';
UserSession::requireLogin();
UserSession::requireRole(['staff', 'admin', 'super_admin']);
$first_name = UserSession::getFirstName();
$userRole = UserSession::get('role');
$profilePicture = UserSession::getProfilePicture();
$categories = getCategories();
$items = getstock();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css" />
    <script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>User Reports</title>
    <link rel="stylesheet" href="../../assets/styles/general.css" />
    <link rel="stylesheet" href="../../assets/styles/panels.css" />
    <link rel="stylesheet" href="../../assets/styles/inventory.css" />
  </head>
  <body class="flex">
    <style>
      #inventory-table_wrapper { position: relative; overflow: visible; }
      .inventory-overview, .content, main { position: relative; overflow: visible; }
      .action-block { display: none; position: absolute; z-index: 2000; background-color: lightgray; border: 6px solid #ccc; border-radius: 4px; padding: 5px; flex-direction: row; gap: 5px; }
      .action-block.show { display: flex; flex-direction: column; background: red;}
      #inventory-table th, #inventory-table td { padding: 10px; text-align: left; vertical-align: middle; position: relative; }
      .status { display: flex; align-items: center; gap: 5px; }
      .status::before { content: ''; width: 10px; height: 10px; border-radius: 50%; display: inline-block; }
      .status.pending::before { background-color: black; }
      .status.shipped::before, .status.delivered::before { background-color: #f5a623; }
      .delivery-progress { display: flex; flex-direction: column; gap: 5px; }
      .progress-bar-container { width: 100px; height: 8px; background-color: #e0e0e0; border-radius: 4px; }
      .progress-bar { height: 100%; border-radius: 4px; }
      .progress-bar.pending { background-color: black; }
      .progress-bar.shipped, .progress-bar.delivered { background-color: #f5a623; }
      .receive-button { padding: 5px 10px; border: 1px solid #e0e0e0; background-color: white; border-radius: 4px; cursor: pointer; }
      .receive-button.received { background-color: #f5a623; color: white; border: none; }
      .action-trigger, .action-icon { cursor: pointer; font-size: 18px; color: #007bff; }
      .action-trigger:hover, .action-icon:hover { color: #0056b3; }
      .action-trigger { margin-right: 5px; }
      .action-btn { background: none; border: none; cursor: pointer; font-size: 16px; padding: 2px 5px; border-radius: 4px; transition: background-color 0.3s; }
      .action-btn:hover { background-color: #f0f0f0; }
      .modal { display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 0; border-radius: 8px; z-index: 1001; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15); max-height: 80vh; overflow-y: auto; }
      .modal.show, #modal-backdrop.show { display: block !important; }
      #modal-backdrop { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 1000; }
      .modal-content { padding: 20px; }
      .modal-close-button { position: absolute; top: 10px; right: 10px; background: none; border: none; font-size: 18px; cursor: pointer; color: #666; }
      .modal-close-button:hover { color: #000; }
      .modal-title { font-size: 20px; font-weight: 600; margin-bottom: 20px; color: #333; }
      .view-modal-content { display: grid; gap: 15px; }
      .view-modal-field { display: flex; justify-content: space-between; align-items: flex-start; padding: 10px; background: #f9f9f9; border-radius: 4px; }
      .view-modal-label { font-weight: 500; color: #555; width: 40%; }
      .view-modal-value { color: #333; width: 55%; word-break: break-word; }
      .view-modal-status { display: flex; align-items: center; gap: 5px; }
      .view-modal-progress { display: flex; flex-direction: column; gap: 5px; }
      .view-modal-progress-bar-container { width: 150px; height: 8px; background-color: #e0e0e0; border-radius: 4px; }
      .view-modal-progress-bar { height: 100%; border-radius: 4px; }
      .view-modal-progress-bar.pending { background-color: black; }
      .view-modal-progress-bar.shipped, .view-modal-progress-bar.delivered { background-color: #f5a623; }
      .add-item-button { background-color:#28a745; color: white; padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; margin-top: 10px; font-size: 14px; transition: background-color 0.3s ease; }
      .add-item-button:hover { background-color: #218838; }
      .item-row { display: flex; gap: 10px; margin-bottom: 15px; padding: 10px; border: 1px solid #eee; border-radius: 4px; align-items: center; flex-wrap: nowrap; }
      .item-group { flex: 1; display: flex; gap: 10px; align-items: center; }
      .remove-item { background-color: #dc3545; color: white; padding: 5px 10px; border: none; border-radius: 4px; cursor: pointer; }
      .remove-item:hover { background-color: #c82333; }
      .category-custom { margin-left: 10px; }
      .modal-form-group { display: flex; flex-direction: column; min-width: 120px; }
      .modal-form-label { font-size: 14px; font-weight: 500; margin-bottom: 5px; color: #333; }
      .modal-form-input { padding: 8px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; width: 100%; box-sizing: border-box; transition: border-color 0.3s ease; }
      .modal-form-input:focus { outline: none; border-color: #28a745; box-shadow: 0 0 5px rgba(40, 167, 69, 0.3); }
      .category-select, .modal-form-input[type="text"], .modal-form-input[type="number"] { padding: 8px; }
      .category-select:focus { outline: none; border-color: #28a745; box-shadow: 0 0 5px rgba(40, 167, 69, 0.3); }
      .modal-action-button { background-color: #28a745; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 14px; transition: background-color 0.3s ease; }
      .modal-action-button:hover { background-color: #218838; }
      .item-name-container { position: relative; display: flex; align-items: center; width: 100%; }
      .modal-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
          font-size: 14px;
        }
        
        .modal-table thead {
          background-color: #f5f5f5;
        }
        
        .modal-table th,
        .modal-table td {
          padding: 10px;
          border: 1px solid #ddd;
          text-align: left;
        }
        
        .modal-table tr:nth-child(even) {
          background-color: #fafafa;
        }
        
        .modal-table th {
          font-weight: bold;
          color: #333;
        }
        
        /* Close button (optional) */
        .modal-close {
          float: right;
          font-size: 20px;
          font-weight: bold;
          cursor: pointer;
          color: #333;
        }
        
        .modal-close:hover {
          color: #f00;
        }
        .action-block {
            position: absolute;
    top: 29px;
    left: 10px;
    z-index: 2000;
    display: flex
;
color:white ! important;
    background-color:#ff6c1f ! important;
    border: 5px solid red ;
    border-radius: 4px;
    padding: 5px;
   
        }
    </style>
    <main>
      <div class="content">
        <div class="top tabs">
          <a href="../items/" class="tab">Inventory</a>
          <button class="tab active">Purchase Order</button>
        </div>
        <div class="inventory-overview card table">
          <div class="inventory-actions">
            <div class="tabs">
              <button class="tab active">All</button>
              <button class="tab">Pending</button>
              <button class="tab">Shipped</button>
              <button class="tab">Delivered</button>
            </div>
            <div class="search-filter-add">
              <div class="search-bar">
                <input type="text" placeholder="Search for menu" />
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search">
                  <circle cx="11" cy="11" r="8"></circle>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
              </div>
              <div class="filter-dropdowns">
                <div class="dropdown">
                  <button class="inventory-dropdown-toggle">
                    All Category
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
                      <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                  </button>
                  <div class="dropdown-menu">
                    <a href="#">Food Ingredients</a>
                    <a href="#">Kitchen Tools</a>
                    <a href="#">Other</a>
                  </div>
                </div>
              </div>
              <button class="add-product-button">+ Add New Purchase Order</button>
            </div>
          </div>
          <div class="modal" id="actionModal" style="display: none;">
            <div class="modal-content" style="width: 300px;">
              <button class="modal-close-button">×</button>
              <h2 class="modal-title">Order Actions</h2>
              <div class="modal-actions">
                <button type="button" class="modal-action-button" id="viewAction">View</button>
                <button type="button" class="modal-action-button" id="editAction">Edit</button>
                <button type="button" class="modal-action-button" id="deleteAction">Delete</button>
              </div>
            </div>
          </div>
          <table id="inventory-table" class="display">
            <thead>
              <tr>
                <th></th>
                <th>Order Date</th>
                <th>Order ID</th>
                <th>Vendor</th>
                <th>Category</th>
                <th>Item Name</th>
                <th>Qty</th>
                <th>Unit Price</th>
                <th>Total Price</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
      </div>
    </main>
    <div id="modal-backdrop"></div>
    <div class="modal" id="addOrderModal">
      <div class="modal-content">
        <button class="modal-close-button">×</button>
        <h2 class="modal-title">Add Purchase Order Items</h2>
        <form id="addOrderForm" class="modal-form">
          <div class="items-container">
            <div class="item-row" data-index="0">
              <div class="item-group">
                <div class="modal-form-group" style="flex-direction: row; min-width: 240px;">
                    <div style="display: flex; flex-direction: column; width: 100%;">
                      <label for="categorySelect_0" class="modal-form-label">Category</label>
                      <select id="categorySelect_0" name="categorySelect_0" class="modal-form-input category-select" required>
                        <option value="">Select Category</option>
                        <?php foreach ($categories as $category): ?>
                          <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                        <?php endforeach; ?>
                        <option value="4">Custom</option>
                      </select>
                  </div>
                  <input type="text" id="categoryCustom_0" name="categoryCustom_0" class="modal-form-input category-custom" placeholder="Enter custom category" style="display: none; max-height: 40px; margin-top: 25px;">
                </div>
                <div class="modal-form-group item-name-container">
                  <label for="itemName_0" class="modal-form-label">Item Name</label>
                  <select id="itemName_0" name="itemName_0" class="modal-form-input item-name-select" required>
                    <option value="">Select items</option>
                    <option value="add_new">Add New</option>
                  </select>
                  <input type="text" id="itemNameCustom_0" name="itemNameCustom_0" class="modal-form-input item-name-custom" placeholder="Enter item name" style="display: none;" required>
                </div>
                <div class="modal-form-group">
                  <label for="vendor_0" class="modal-form-label">Vendor/Supplier</label>
                  <input type="text" id="vendor_0" name="vendor_0" class="modal-form-input" placeholder="e.g., General Food" required>
                </div>
                <div class="modal-form-group">
                  <label for="quantity_0" class="modal-form-label">Quantity</label>
                  <input type="number" id="quantity_0" name="quantity_0" class="modal-form-input" min="1" placeholder="e.g., 1" required>
                </div>
                <div class="modal-form-group">
                  <label for="unitPrice_0" class="modal-form-label">Unit Price ($)</label>
                  <input type="number" id="unitPrice_0" name="unitPrice_0" class="modal-form-input" step="0.01" placeholder="e.g., 12.00" required>
                </div>
                <div class="modal-form-group">
                  <label for="status_0" class="modal-form-label">Status</label>
                  <select id="status_0" name="status_0" class="modal-form-input status-select" required>
                    <option value="pending">Pending</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                  </select>
                </div>
                <button type="button" class="remove-item">Remove</button>
              </div>
            </div>
          </div>
          <button type="button" id="addItemButton" class="add-item-button">+ Add Another Item</button>
          <div class="items-summary" style="margin-top: 15px; display: none;">
            <h3>Items to Add</h3>
            <ul id="itemsSummary"></ul>
          </div>
          <div class="modal-actions">
            <button type="submit" class="modal-action-button">Submit All Items</button>
          </div>
        </form>
      </div>
    </div>
    <!--<div class="modal" id="viewOrderModal" >-->
    <!--  <div class="modal-content">-->
    <!--    <button class="modal-close-button">×</button>-->
    <!--    <h2 class="modal-title">View Purchase Order</h2>-->
    <!--    <div class="view-modal-content">-->
    <!--      <div class="view-modal-field">-->
    <!--        <span class="view-modal-label">Order Date</span>-->
    <!--        <span class="view-modal-value" id="viewOrderDate"></span>-->
    <!--      </div>-->
    <!--      <div class="view-modal-field">-->
    <!--        <span class="view-modal-label">Order ID</span>-->
    <!--        <span class="view-modal-value" id="viewOrderId"></span>-->
    <!--      </div>-->
    <!--      <div class="view-modal-field">-->
    <!--        <span class="view-modal-label">Vendor</span>-->
    <!--        <span class="view-modal-value" id="viewVendor"></span>-->
    <!--      </div>-->
    <!--      <div class="view-modal-field">-->
    <!--        <span class="view-modal-label">Total Price</span>-->
    <!--        <span class="view-modal-value" id="viewTotalPrice"></span>-->
    <!--      </div>-->
    <!--      <div class="view-modal-field">-->
    <!--        <span class="view-modal-label">Status</span>-->
    <!--        <span class="view-modal-value view-modal-status" id="viewStatus"></span>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--  </div>-->
    <!--</div>-->
    <div id="viewOrderModal" class="modal" style="width: 80%;">
      <div class="modal-content">
        <h3>Order History</h3>
        <table class="modal-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Date</th>
              <th>Item</th>
              <th>Vendor</th>
              <th>Quantity</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody id="modal-history-body"></tbody>
        </table>
      </div>
    </div>
    <script>
      $(document).ready(function () {
        console.log('Document ready, jQuery version:', $.fn.jquery);
        console.log('Binding status tab click handler');
        $(document).on('click', '.inventory-actions .tabs .tab', function (e) {
          e.preventDefault();
          console.log('Status tab clicked:', $(this).text());
          $('.inventory-actions .tabs .tab').removeClass('active');
          $(this).addClass('active');
          var status = $(this).text().toLowerCase().trim();
          console.log('Filtering status:', `"${status}"`);
          if (status === 'all') {
            table.column(9).search('').draw();
          } else {
            table.column(9).search(status, false, true).draw();
          }
          console.log('Filtered rows:', table.rows({ search: 'applied' }).data().toArray());
          console.log('All statuses in table:', table.column(9).data().toArray());
        });
        console.log('Status tabs found:', $('.inventory-actions .tabs .tab').length);
        $('.search-bar input').on('input', function () {
          var searchTerm = $(this).val().trim();
          console.log('Search term:', searchTerm);
          table.search(searchTerm).draw();
          console.log('Search results:', table.rows({ search: 'applied' }).data().toArray());
        });
        
        function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
        // function escapeHtml(str) {
        //   if (!str) return '';
        //   return str.replace(/&/g, '&').replace(/</g, '<').replace(/>/g, '>').replace(/"/g, '"').replace(/'/g, ''');
        // }
        // function formatWATDate(dateStr) {
        //   if (!dateStr) return 'TBD';
        //   try {
        //     var date = new Date(dateStr);
        //     if (isNaN(date.getTime())) return 'TBD';
        //     return date.toLocaleDateString('en-US', {
        //       month: 'short',
        //       day: '2-digit',
        //       year: 'numeric',
        //       timeZone: 'Africa/Lagos'
        //     });
        //   } catch (e) {
        //     console.error('Date parsing error:', e, dateStr);
        //     return 'TBD';
        //   }
        // }
        function formatWATDate(dateStr) {
  if (!dateStr) return 'TBD';
  try {
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return 'TBD';

    // Convert to Africa/Lagos time using options
    const options = {
      timeZone: 'Africa/Lagos',
      day: '2-digit',
      month: '2-digit',
      year: '2-digit'
    };

    const formatter = new Intl.DateTimeFormat('en-GB', options); // en-GB gives dd/mm/yy
    return formatter.format(date);
  } catch (e) {
    console.error('Date parsing error:', e, dateStr);
    return 'TBD';
  }
}

        var table = $("#inventory-table").DataTable({
          paging: true,
          pageLength: 10,
          language: {
            paginate: {
              previous: '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.9254 4.55806C13.1915 4.80214 13.1915 5.19786 12.9254 5.44194L8.4375 9.55806C8.17138 9.80214 8.17138 10.1979 8.4375 10.4419L12.9254 14.5581C13.1915 14.8021 13.1915 15.1979 12.9254 15.4419C12.6593 15.686 12.2278 15.686 11.9617 15.4419L7.47378 11.3258C6.67541 10.5936 6.67541 9.40641 7.47378 8.67418L11.9617 4.55806C12.2278 4.31398 12.6593 4.31398 12.9254 4.55806Z" fill="#1C1C1C"/></svg>',
              next: '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.07459 15.4419C6.80847 15.1979 6.80847 14.8021 7.07459 14.5581L11.5625 10.4419C11.8286 10.1979 11.8286 9.80214 11.5625 9.55806L7.07459 5.44194C6.80847 5.19786 6.80847 4.80214 7.07459 4.55806C7.34072 4.31398 7.77219 4.31398 8.03831 4.55806L12.5262 8.67418C13.3246 9.40641 13.3246 10.5936 12.5262 11.3258L8.03831 15.4419C7.77219 15.686 7.34072 15.686 7.07459 15.4419Z" fill="#1C1C1C"/></svg>',
            },
            lengthMenu: "Show _MENU_ entries",
            info: "Showing _START_ to _END_ of _TOTAL_ entries",
            infoEmpty: "Showing 0 to 0 of 0 entries",
            infoFiltered: "(filtered from _MAX_ total entries)",
            search: "Search:",
            zeroRecords: "No matching records found",
          },
          columns: [
            {
              data: null,
              render: function () {
                return '<input type="checkbox" />';
              },
              orderable: false,
            },
            {
              data: "order_date",
              render: function (data) {
                return formatWATDate(data);
              },
            },
            { data: "order_id" },
            { data: "vendor", render: function (data) { return escapeHtml(data || 'N/A'); } },
            {
              data: "category",
              render: function (data) {
                return escapeHtml(data || 'N/A');
              },
            },
            {
              data: "item",
              render: function (data) {
                return escapeHtml(data || 'N/A');
              },
            },
            { data: "quantity" },
            {
              data: "unit_price",
              render: function (data) {
                try {
                  return '$' + parseFloat(data || 0).toFixed(2);
                } catch (e) {
                  console.error('Unit price error:', e);
                  return '$0.00';
                }
              },
            },
            {
              data: "total_price",
              render: function (data) {
                try {
                  return '$' + parseFloat(data || 0).toFixed(2);
                } catch (e) {
                  console.error('Total price error:', e);
                  return '$0.00';
                }
              },
            },
            {
              data: "status",
              render: function (data) {
                if (!data) return '<span class="status">N/A</span>';
                return '<span class="status ' + data.toLowerCase() + '">' + escapeHtml(data) + '</span>';
              },
            },
            {
              data: null,
              render: function (data) {
                if (!data || !data.order_id) return '';
                return '<span class="action-trigger" data-order-id="' + data.order_id + '">⋯</span>';
              },
              orderable: false,
            },
          ],
        });
        $.ajax({
          url: './api.php',
          method: 'GET',
          dataType: 'json',
          cache: false,
          success: function (response) {
            console.log(response);
            if (response && response.success && Array.isArray(response.data)) {
              response.data.forEach(function (row, index) {
                console.log(`Row ${index} raw status: "${row.status}"`);
                row.status = row.status ? row.status.toLowerCase().trim() : 'pending';
                if (!['pending', 'shipped', 'delivered'].includes(row.status)) {
                  console.warn(`Invalid status in row ${index}: "${row.status}", defaulting to 'pending'`);
                  row.status = 'pending';
                }
                row.category = row.category === '2' ? 'Food Ingredients' : row.category === '1' ? 'Kitchen Tools' : row.category === '3' ? 'Other' : row.category || 'Other';
                row.order_date = row.order_date || row.schedule_date || formatWATDate(new Date());
                console.log(`Row ${index} normalized status: "${row.status}"`);
                console.log(`Row ${index} category: "${row.category}"`);
              });
              table.clear().rows.add(response.data).draw();
              console.log('Table rows added:', table.data().length);
              console.log('All statuses in table:', table.column(9).data().toArray());
            } else {
              console.error('API Error:', response.message || 'No message');
              table.clear().draw();
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Failed to load data: ' + (response.message || 'Unknown error'),
              });
            }
          },
          error: function (xhr, status, error) {
            console.error('AJAX Error:', status, error, xhr.responseText);
            table.clear().draw();
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: 'Error loading data.',
            });
          }
        });
        $('.dropdown-menu a').on('click', function (e) {
          e.preventDefault();
          var category = $(this).text().trim();
          console.log('Filtering category:', category);
          var dropdownToggle = $(this).closest('.dropdown').find('.inventory-dropdown-toggle');
          dropdownToggle.contents().first().replaceWith(category);
          if (category === 'All Category') {
            table.column(4).search('').draw();
          } else {
            table.column(4).search(category, false, true).draw();
          }
          console.log('Filtered rows (category):', table.rows({ search: 'applied' }).data().toArray());
        });
        var currentActionBlock = null;
        var currentTrigger = null;
        function positionActionBlock($trigger, $actionBlock) {
          if (!$trigger || !$trigger.length || !$actionBlock || !$actionBlock.length) {
            console.error('Invalid trigger or actionBlock:', { trigger: $trigger, actionBlock: $actionBlock });
            return;
          }
          var $cell = $trigger.closest('td');
          if (!$cell.length) {
            console.error('No parent td found for trigger:', $trigger);
            return;
          }
          var triggerOffset = $trigger.offset() || { top: 0, left: 0 };
          var cellOffset = $cell.offset() || { top: 0, left: 0 };
          var tableOffset = $('#inventory-table').offset() || { top: 0, left: 0 };
          var viewportWidth = $(window).width();
          var actionBlockWidth = 100;
          var leftPos = triggerOffset.left - cellOffset.left;
          var topPos = $trigger.outerHeight() + 5;
          if (triggerOffset.left + actionBlockWidth > viewportWidth) {
            leftPos = cellOffset.left - tableOffset.left - actionBlockWidth + $trigger.outerWidth();
          }
          try {
            $actionBlock.css({
              position: 'absolute',
              top: topPos + 'px',
              left: leftPos + 'px',
              zIndex: 2000,
              display: 'flex',
              backgroundColor: '#ffeb3b',
              border: '1px solid #ccc',
              borderRadius: '4px',
              padding: '5px',
              gap: '5px'
            });
            console.log('Positioned action block:', { top: topPos, left: leftPos });
          } catch (e) {
            console.error('Error setting action block CSS:', e);
          }
        }
        $('#inventory-table').on('click', '.action-trigger', function (e) {
          e.preventDefault();
          e.stopPropagation();
          var $trigger = $(this);
          var orderId = $trigger.data('order-id');
          var rowData = table.row($trigger.closest('tr')).data();
          var $cell = $trigger.closest('td');
          if (!rowData || !orderId) {
            console.error('Invalid rowData or orderId:', { orderId, rowData });
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: 'Invalid order data.',
            });
            return;
          }
          if (currentActionBlock && currentTrigger && currentTrigger[0] !== $trigger[0]) {
            currentActionBlock.removeClass('show').remove();
            currentActionBlock = null;
            currentTrigger = null;
          }
          if (currentActionBlock) {
            currentActionBlock.removeClass('show').remove();
            currentActionBlock = null;
            currentTrigger = null;
          } else {
            var $actionBlock = $('<div class="action-block"></div>').html(
              '<button class="action-btn" data-action="view" title="View">View</button>' +
              '<button class="action-btn" data-action="edit" title="Edit">Edit</button>' +
              '<button class="action-btn" data-action="delete" title="Delete">Delete</button>'
            );
            $cell.append($actionBlock);
            $actionBlock.data('order-id', orderId).data('row-data', rowData);
            currentActionBlock = $actionBlock;
            currentTrigger = $trigger;
            positionActionBlock($trigger, $actionBlock);
            $actionBlock.addClass('show');
            console.log('Added action block for orderId:', orderId, rowData);
          }
          $(document).one('click', function (e) {
            if (!$(e.target).closest('.action-block').length && !$(e.target).closest('.action-trigger').length) {
              console.log('Closing action block due to outside click');
              if (currentActionBlock) {
                currentActionBlock.removeClass('show').remove();
                currentActionBlock = null;
                currentTrigger = null;
              }
            }
          });
        });
        $(window).on('scroll', function () {
          if (currentActionBlock && currentTrigger && currentTrigger.length) {
            var triggerOffset = currentTrigger.offset() || { top: 0 };
            var viewportTop = $(window).scrollTop();
            var viewportBottom = viewportTop + $(window).height();
            if (triggerOffset.top < viewportTop || triggerOffset.top > viewportBottom) {
              console.log('Closing action block due to scroll out of viewport');
              currentActionBlock.removeClass('show').remove();
              currentActionBlock = null;
              currentTrigger = null;
            } else {
              positionActionBlock(currentTrigger, currentActionBlock);
            }
          }
        });
        $('#inventory-table').on('click', '.action-btn', function (e) {
          e.stopPropagation();
          var $actionBlock = $(this).closest('.action-block');
          var orderId = $actionBlock.data('order-id');
          var rowData = $actionBlock.data('row-data');
          var action = $(this).data('action');
          if (!rowData || !orderId) {
            console.error('Invalid action data:', { orderId, rowData });
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: 'Invalid order data.',
            });
            return;
          }
          $actionBlock.removeClass('show').remove();
          currentActionBlock = null;
          currentTrigger = null;
          if (action === 'view') {
            $('#modal-history-body').html('');

              // Loop through history
              if (Array.isArray(rowData.history)) {
                rowData.history.forEach(entry => {
                  $('#modal-history-body').append(`
                    <tr>
                      <td>${entry.order_id || 'N/A'}</td>
                      <td>${formatWATDate(entry.order_date)}</td>
                      <td>${entry.item || 'N/A'}</td>
                      <td>${entry.vendor || 'N/A'}</td>
                      <td>${entry.quantity || 0}</td>
                      <td>$${parseFloat(entry.total_price || 0).toFixed(2)}</td>
                    </tr>
                  `);
                });
              }

            $('#viewOrderModal').add('#modal-backdrop').addClass('show');
          } else if (action === 'edit') {
            $('#addOrderModal').addClass('show');
            $('#modal-backdrop').addClass('show');
            $('#addOrderForm')[0].reset();
            $('#addOrderModal .modal-title').text('Edit Purchase Order Item');
            var itemName = rowData.item || '';
            var unitPrice = parseFloat(rowData.unit_price || 0) || 0;
            var vendor = rowData.vendor || '';
            var quantity = parseInt(rowData.quantity, 10) || 1;
            var category = rowData.category || '';
            var status = rowData.status || 'pending';
            var isCustomCategory = category && !['Food Ingredients', 'Kitchen Tools', 'Other'].includes(category);
            var categoryId = isCustomCategory ? '4' : (category === 'Food Ingredients' ? '2' : category === 'Kitchen Tools' ? '1' : category === 'Other' ? '3' : '');
            var isCustomItem = itemName && !$('#itemName_0 option').filter(function() { return $(this).val() === itemName; }).length;
            var $itemRow = $('.items-container .item-row').first();
            $('#categorySelect_0', $itemRow).val(categoryId).trigger('change');
            var $itemSelect = $('#itemName_0', $itemRow);
            var $itemCustomInput = $('#itemNameCustom_0', $itemRow);
            if (isCustomItem) {
              $itemSelect.val('add_new').trigger('change');
              $itemCustomInput.val(itemName);
            } else {
              $itemSelect.val(itemName);
            }
            $('#unitPrice_0', $itemRow).val(unitPrice.toFixed(2));
            $('#vendor_0', $itemRow).val(vendor);
            $('#quantity_0', $itemRow).val(quantity);
            $('#status_0', $itemRow).val(status.toLowerCase());
            $('#categoryCustom_0', $itemRow).val(isCustomCategory ? category : '').css('display', isCustomCategory ? 'block' : 'none');
            itemIndex = 0;
            setupCategoryToggle(0);
            $('#addOrderForm').off('submit').on('submit', function (e) {
              e.preventDefault();
              var items = [];
              var index = 0;
              var itemName = $('#itemName_' + index).val() === 'add_new' ? $('#itemNameCustom_' + index).val() : $('#itemName_' + index).val();
              var unitPrice = parseFloat($('#unitPrice_' + index).val()) || 0;
              var vendor = $('#vendor_' + index).val();
              var category = $('#categorySelect_' + index).val();
              if (category === '4') {
                category = $('#categoryCustom_' + index).val() || '';
              }
              var quantity = parseInt($('#quantity_' + index).val()) || 0;
              var status = $('#status_' + index).val();
              if (itemName && unitPrice > 0 && vendor && category && quantity > 0 && status) {
                items.push({
                  item_name: itemName,
                  unit_price: unitPrice,
                  vendor: vendor,
                  category: category,
                  quantity: quantity,
                  status: status,
                  order_date: formatWATDate(new Date())
                });
              } else {
                Swal.fire({
                  icon: 'warning',
                  title: 'Invalid Input',
                  text: 'Please fill all fields with valid values.',
                });
                return;
              }
              console.log('Sending update:', { order_id: orderId, items: items });
              $.ajax({
                url: './update_order_item.php',
                method: 'POST',
                dataType: 'json',
                data: JSON.stringify({ order_id: orderId, items: items }),
                contentType: 'application/json',
                success: function (response) {
                  console.log('Update response:', response);
                  if (response.success) {
                    var rowIdx = -1;
                    table.rows().every(function (idx) {
                      if (this.data().order_id === orderId) {
                        rowIdx = idx;
                      }
                    });
                    if (rowIdx !== -1) {
                      var newData = {
                        order_id: orderId,
                        item: items[0].item_name,
                        category: isCustomCategory ? items[0].category : (items[0].category === '2' ? 'Food Ingredients' : items[0].category === '1' ? 'Kitchen Tools' : 'Other'),
                        vendor: items[0].vendor,
                        status: items[0].status,
                        order_date: items[0].order_date,
                        unit_price: items[0].unit_price,
                        quantity: items[0].quantity,
                        total_price: items[0].unit_price * items[0].quantity
                      };
                      table.row(':eq(' + rowIdx + ')').data(newData).draw();
                      $('#addOrderModal').removeClass('show');
                      $('#modal-backdrop').removeClass('show');
                      $('#addOrderModal .modal-title').text('Add Purchase Order Items');
                      Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Order updated successfully!',
                      });
                    } else {
                      console.error('Row not found for orderId:', orderId);
                      Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Could not find order to update.',
                      });
                    }
                  } else {
                    console.error('Update failed:', response.message);
                    Swal.fire({
                      icon: 'error',
                      title: 'Error',
                      text: 'Error updating order item: ' + response.message,
                    });
                  }
                },
                error: function (xhr, status, error) {
                  console.error('Update AJAX Error:', status, error, xhr.responseText);
                  Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error updating order: ' + error,
                  });
                }
              });
            });
          } else if (action === 'delete') {
            Swal.fire({
              title: 'Are you sure?',
              text: 'You are about to delete this order.',
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
              if (result.isConfirmed) {
                $.ajax({
                  url: './delete_order_item.php',
                  method: 'POST',
                  dataType: 'json',
                  data: JSON.stringify({ order_id: orderId }),
                  contentType: 'application/json',
                  success: function (response) {
                    console.log('Delete response:', response);
                    if (response.success) {
                      var rowIdx = -1;
                      table.rows().every(function (idx) {
                        if (this.data().order_id === orderId) {
                          rowIdx = idx;
                        }
                      });
                      if (rowIdx !== -1) {
                        table.row(':eq(' + rowIdx + ')').remove().draw();
                        Swal.fire({
                          icon: 'success',
                          title: 'Deleted',
                          text: 'Order deleted successfully!',
                        });
                      } else {
                        console.error('Row not found for orderId:', orderId);
                        Swal.fire({
                          icon: 'error',
                          title: 'Error',
                          text: 'Could not find order to delete.',
                        });
                      }
                    } else {
                      console.error('Delete failed:', response.message);
                      Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Error deleting order: ' + response.message,
                      });
                    }
                  },
                  error: function (xhr, status, error) {
                    console.error('Delete AJAX Error:', status, error, xhr.responseText);
                    Swal.fire({
                      icon: 'error',
                      title: 'Error',
                      text: 'Error deleting order: ' + error,
                    });
                  }
                });
              }
            });
          }
        });
        $('#viewOrderModal .modal-close-button, #modal-backdrop').on('click', function () {
          $('#viewOrderModal').removeClass('show');
          $('#modal-backdrop').removeClass('show');
        });
        var addOrderModal = $('#addOrderModal');
        var modalBackdrop = $('#modal-backdrop');
        var itemIndex = 0;
        $('.add-product-button').on('click', function () {
          console.log('Add Product button clicked');
          if (addOrderModal.length) {
            addOrderModal.add(modalBackdrop).addClass('show');
            $('#addOrderModal .modal-title').text('Add Purchase Order Items');
            $('#addOrderForm')[0].reset();
            $('.items-container').html($('.items-container .item-row').first().clone());
            $('#itemName_0').empty().append('<option value="">Select items</option><option value="add_new">Add New</option>');
            $('#itemNameCustom_0').hide().val('');
            itemIndex = 0;
            setupCategoryToggle(0);
            setupItemNameToggle(0);
            console.log('Modal should be visible');
          }
        });
        modalBackdrop.on('click', function () {
          addOrderModal.add(modalBackdrop).add('#viewOrderModal').removeClass('show');
          $('#addOrderModal .modal-title').text('Add Purchase Order Items');
          resetForm();
        });
        $('.modal-close-button').on('click', function () {
          $(this).closest('.modal').add(modalBackdrop).removeClass('show');
          $('#addOrderModal .modal-title').text('Add Purchase Order Items');
          resetForm();
        });
        $('#addItemButton').on('click', function (e) {
          e.preventDefault();
          console.log('Add Item button clicked');
          var newIndex = itemIndex + 1;
          var $newRow = $(`
            <div class="item-row" data-index="${newIndex}">
              <div class="item-group">
                <div class="modal-form-group">
                  <label for="categorySelect_${newIndex}" class="modal-form-label">Category</label>
                  <select id="categorySelect_${newIndex}" name="categorySelect_${newIndex}" class="modal-form-input category-select" required>
                    <option value="">Select Category</option>
                    <?php foreach ($categories as $category): ?>
                      <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                    <?php endforeach; ?>
                    <option value="4">Custom</option>
                  </select>
                  <input type="text" id="categoryCustom_${newIndex}" name="categoryCustom_${newIndex}" class="modal-form-input category-custom" placeholder="Enter custom category" style="display: none;">
                </div>
                <div class="modal-form-group item-name-container">
                  <label for="itemName_${newIndex}" class="modal-form-label">Item Name</label>
                  <select id="itemName_${newIndex}" name="itemName_${newIndex}" class="modal-form-input item-name-select" required>
                    <option value="">Select items</option>
                    <option value="add_new">Add New</option>
                  </select>
                  <input type="text" id="itemNameCustom_${newIndex}" name="itemNameCustom_${newIndex}" class="modal-form-input item-name-custom" placeholder="Enter item name" style="display: none;" required>
                </div>
                <div class="modal-form-group">
                  <label for="vendor_${newIndex}" class="modal-form-label">Vendor/Supplier</label>
                  <input type="text" id="vendor_${newIndex}" name="vendor_${newIndex}" class="modal-form-input" placeholder="e.g., General Food" required>
                </div>
                <div class="modal-form-group">
                  <label for="quantity_${newIndex}" class="modal-form-label">Quantity</label>
                  <input type="number" id="quantity_${newIndex}" name="quantity_${newIndex}" class="modal-form-input" min="1" placeholder="e.g., 1" required>
                </div>
                <div class="modal-form-group">
                  <label for="unitPrice_${newIndex}" class="modal-form-label">Unit Price ($)</label>
                  <input type="number" id="unitPrice_${newIndex}" name="unitPrice_${newIndex}" class="modal-form-input" step="0.01" placeholder="e.g., 12.00" required>
                </div>
                <div class="modal-form-group">
                  <label for="status_${newIndex}" class="modal-form-label">Status</label>
                  <select id="status_${newIndex}" name="status_${newIndex}" class="modal-form-input status-select" required>
                    <option value="pending">Pending</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                  </select>
                </div>
                <button type="button" class="remove-item">Remove</button>
              </div>
            </div>
          `);
          $('.items-container').append($newRow);
          itemIndex = newIndex;
          setupCategoryToggle(newIndex);
          setupItemNameToggle(newIndex);
          console.log('Added row with index ' + newIndex);
        });
        $(document).on('change', '.category-select', function () {
          var index = $(this).attr('id').split('_')[1];
          var categoryId = $(this).val();
          var $itemSelect = $('#itemName_' + index);
          var customInput = $('#categoryCustom_' + index);
          var $itemCustomInput = $('#itemNameCustom_' + index);
          $itemSelect.empty().append('<option value="">Select items</option><option value="add_new">Add New</option>');
          $itemCustomInput.hide().val('').prop('required', false);
          if (categoryId === '4') {
            customInput.show().prop('required', true);
            $itemCustomInput.show().prop('required', true);
            $(this).prop('required', false);
            $itemSelect.hide();
          } else if (categoryId) {
            customInput.hide().prop('required', false).val('');
            $(this).prop('required', true);
            $itemSelect.show().prop('required', true);
            $itemSelect.prop('disabled', true).html('<option value="">Loading items...</option>');
            $.ajax({
              url: '../../../BackEnd/controller/inventory/get_items.php',
              method: 'GET',
              data: { category_id: categoryId },
              dataType: 'json',
              success: function (response) {
                if (response.success && response.data) {
                  $itemSelect.empty().append('<option value="">Select items</option>');
                  response.data.forEach(function (item) {
                    $itemSelect.append($('<option>').val(item.name).text(item.name));
                  });
                  $itemSelect.append('<option value="add_new">Add New</option>');
                } else {
                  console.error('Failed to load items:', response.message);
                  $itemSelect.empty().append('<option value="">Failed to load items</option><option value="add_new">Add New</option>');
                }
              },
              error: function (xhr, status, error) {
                console.error('AJAX error:', error);
                $itemSelect.empty().append('<option value="">Error loading items</option><option value="add_new">Add New</option>');
              },
              complete: function () {
                $itemSelect.prop('disabled', false);
              }
            });
          }
        });
        $(document).on('change', '.item-name-select', function () {
          var index = $(this).attr('id').split('_')[1];
          var $itemSelect = $(this);
          var $itemCustomInput = $('#itemNameCustom_' + index);
          if ($itemSelect.val() === 'add_new') {
            $itemSelect.hide().prop('required', false);
            $itemCustomInput.show().prop('required', true).focus();
          } else {
            $itemCustomInput.hide().prop('required', false).val('');
            $itemSelect.show().prop('required', true);
          }
        });
        $(document).on('click', '.remove-item', function () {
          if ($('.item-row').length > 1) {
            $(this).closest('.item-row').remove();
          }
        });
        $('#addOrderForm').on('submit', function (e) {
          e.preventDefault();
          var items = [];
          $('.item-row').each(function () {
            var index = $(this).data('index');
            var itemName = $('#itemName_' + index).val() === 'add_new' ? $('#itemNameCustom_' + index).val() : $('#itemName_' + index).val();
            var unitPrice = parseFloat($('#unitPrice_' + index).val()) || 0;
            var vendor = $('#vendor_' + index).val();
            var category = $('#categorySelect_' + index).val();
            if (category === '4') {
              category = $('#categoryCustom_' + index).val() || '';
              itemName = $('#itemNameCustom_' + index).val();
            }
            var quantity = parseInt($('#quantity_' + index).val()) || 0;
            var status = $('#status_' + index).val();
            if (itemName && unitPrice > 0 && vendor && category && quantity > 0 && status) {
              items.push({
                item_name: itemName,
                unit_price: unitPrice,
                vendor: vendor,
                category: category,
                quantity: quantity,
                status: status,
                order_date: formatWATDate(new Date())
              });
            }
          });
          if (items.length === 0) {
            Swal.fire({
              icon: 'warning',
              title: 'Invalid Input',
              text: 'Please add at least one item and fill all fields.',
            });
            return;
          }
          console.log('Sending add:', { items });
          $.ajax({
            url: './add_order_items.php',
            method: 'POST',
            dataType: 'json',
            data: JSON.stringify({ items: items }),
            contentType: 'application/json',
            success: function (response) {
              console.log('Add response:', response);
              if (response.success && Array.isArray(response.data.items)) {
                response.data.items.forEach(function (item) {
                  var orderItem = {
                    order_id: item.order_id,
                    item: item.item_name,
                    category: item.category === '2' ? 'Food Ingredients' : item.category === '1' ? 'Kitchen Tools' : item.category === '3' ? 'Other' : item.category,
                    vendor: item.vendor,
                    status: item.status || 'pending',
                    order_date: item.order_date || formatWATDate(new Date()),
                    unit_price: item.unit_price,
                    quantity: item.quantity,
                    total_price: item.unit_price * item.quantity
                  };
                  table.row.add(orderItem).draw();
                });
                $('#addOrderModal').add(modalBackdrop).removeClass('show');
                $('#addOrderModal .modal-title').text('Add Purchase Order Items');
                resetForm();
                Swal.fire({
                  icon: 'success',
                  title: 'Success',
                  text: 'Order items added successfully!',
                });
              } else {
                console.error('Add order failed:', response.message || 'Unknown error');
                Swal.fire({
                  icon: 'error',
                  title: 'Error',
                  text: 'Error adding items: ' + (response.message || 'Unknown error'),
                });
              }
            },
            error: function (xhr, status, error) {
              console.error('Add AJAX Error:', status, error, xhr.responseText);
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Error adding items. Check console for details.',
              });
            }
          });
        });
        function updateSummary() {
          var summary = $('#itemsSummary').empty();
          $('.item-row').each(function () {
            var index = $(this).data('index');
            var itemName = $('#itemName_' + index).val() === 'add_new' ? $('#itemNameCustom_' + index).val() : $('#itemName_' + index).val();
            var vendor = $('#vendor_' + index).val();
            var category = $('#categorySelect_' + index).val() === '4' ? $('#categoryCustom_' + index).val() : $('#categorySelect_' + index).find('option:selected').text();
            var quantity = $('#quantity_' + index).val();
            var unitPrice = $('#unitPrice_' + index).val();
            var status = $('#status_' + index).val();
            if (itemName && vendor && category && quantity && unitPrice && status) {
              summary.append('<li>Item: ' + escapeHtml(itemName) + ', Vendor: ' + escapeHtml(vendor) + ', Category: ' + escapeHtml(category) + ', Qty: ' + escapeHtml(quantity) + ', Unit Price: $' + escapeHtml(unitPrice) + ', Status: ' + escapeHtml(status) + '</li>');
            }
          });
          if (summary.children().length) {
            summary.parent().show();
          } else {
            summary.parent().hide();
          }
        }
        function resetForm() {
          $('.items-container').html($('.items-container .item-row').first().clone());
          $('#itemName_0').empty().append('<option value="">Select items</option><option value="add_new">Add New</option>');
          $('#itemNameCustom_0').hide().val('').prop('required', false);
          itemIndex = 0;
          $('#itemsSummary').empty().parent().hide();
          $('#addOrderForm')[0].reset();
          setupCategoryToggle(0);
          setupItemNameToggle(0);
        }
        function setupCategoryToggle(index) {
          $('#categorySelect_' + index).off('change').on('change', function () {
            var categoryId = $(this).val();
            var $itemSelect = $('#itemName_' + index);
            var customInput = $('#categoryCustom_' + index);
            var $itemCustomInput = $('#itemNameCustom_' + index);
            $itemSelect.empty().append('<option value="">Select items</option><option value="add_new">Add New</option>');
            $itemCustomInput.hide().val('').prop('required', false);
            if (categoryId === '4') {
              customInput.show().prop('required', true);
              $(this).prop('required', false);
              $itemSelect.prop('disabled', true);
            } else if (categoryId) {
              customInput.hide().prop('required', false).val('');
              $(this).prop('required', true);
              $itemSelect.prop('disabled', true).html('<option value="">Loading items...</option>');
              $.ajax({
                url: '../../../BackEnd/controller/inventory/get_items.php',
                method: 'GET',
                data: { category_id: categoryId },
                dataType: 'json',
                success: function (response) {
                  if (response.success && response.data) {
                    $itemSelect.empty().append('<option value="">Select items</option>');
                    response.data.forEach(function (item) {
                      console.log('Item ' + index + ':', item);
                      $itemSelect.append($('<option>').val(item.name).text(item.name));
                    });
                    $itemSelect.append('<option value="add_new">Add New</option>');
                  } else {
                    console.error('Failed to load items:', response.message);
                    $itemSelect.empty().append('<option value="">Failed to load items</option><option value="add_new">Add New</option>');
                  }
                },
                error: function (xhr, status, error) {
                  console.error('AJAX error:', error);
                  $itemSelect.empty().append('<option value="">Error loading items</option><option value="add_new">Add New</option>');
                },
                complete: function () {
                  $itemSelect.prop('disabled', false);
                }
              });
            }
          });
        }
        function setupItemNameToggle(index) {
          $('#itemName_' + index).off('change').on('change', function () {
            var $itemSelect = $(this);
            var $itemCustomInput = $('#itemNameCustom_' + index);
            if ($itemSelect.val() === 'add_new') {
              $itemSelect.hide().prop('required', false);
              $itemCustomInput.show().prop('required', true).focus();
            } else {
              $itemCustomInput.hide().prop('required', false).val('');
              $itemSelect.show().prop('required', true);
            }
          });
        }
        setupCategoryToggle(0);
        setupItemNameToggle(0);
        updateSummary();
        const username = '<?php echo addslashes($first_name); ?>';
        const userRole = '<?php echo addslashes($userRole); ?>';
        const profilePicture = '<?php echo addslashes($profilePicture); ?>';
      });
    </script>
    <script>
      const username = '<?php echo addslashes($first_name); ?>';
      const userRole = '<?php echo addslashes($userRole); ?>';
      const profilePicture = '<?php echo addslashes($profilePicture); ?>';
    </script>
    <script src="./mockup.js"></script>
    <script src="../../scripts/components.js"></script>
  </body>
</html>