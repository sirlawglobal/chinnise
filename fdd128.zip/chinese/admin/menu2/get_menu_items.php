<?php
require_once '../../BackEnd/config/init.php';

$pdo = db_connect();

try {
    // Pagination Setup
    $itemsPerPage = 10;
    $currentPage = isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] > 0 ? (int)$_GET['page'] : 1;
    $offset = ($currentPage - 1) * $itemsPerPage;

    // Total items count (for pagination)
    $countStmt = $pdo->query("SELECT COUNT(*) AS total FROM items");
    $totalItems = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    $totalPages = ceil($totalItems / $itemsPerPage);

    // Search Handling
    $searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
    $searchQuery = '';
    $params = [];

    if ($searchTerm !== '') {
        $searchQuery = "WHERE items.name LIKE :search OR items.description LIKE :search OR items.price LIKE :search";
        $params[':search'] = '%' . $searchTerm . '%';
    }

    // Main Data Query
    $dataSql = "SELECT 
                    items.id,
                    items.category_id,
                    categories.name AS category_name,
                    items.name,
                    items.description,
                    items.price,
                    items.has_options,
                    items.is_set_menu,
                    items.image_url,
                    items.created_at
                FROM items
                JOIN categories ON items.category_id = categories.id
                $searchQuery
                LIMIT :limit OFFSET :offset";

    $stmt = $pdo->prepare($dataSql);

    // Bind values
    if ($searchTerm !== '') {
        $stmt->bindValue(':search', $params[':search'], PDO::PARAM_STR);
    }

    $stmt->bindValue(':limit', $itemsPerPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Process each item
    foreach ($items as &$item) {
        // Default values for set_menu fields
        $item['set_menu_name'] = null;
        $item['set_menu_items'] = null;

        // Handle SET MENU
        if (strtoupper($item['category_name']) === 'SET MENU') {
            $setMenuStmt = $pdo->prepare("SELECT name AS set_menu_name, price AS set_menu_price, items AS set_menu_items FROM set_menus WHERE item_id = :item_id");
            $setMenuStmt->execute([':item_id' => $item['id']]);
            $setMenuData = $setMenuStmt->fetch(PDO::FETCH_ASSOC);

            if ($setMenuData) {
                $item['price'] = $setMenuData['set_menu_price'];
                $item['set_menu_name'] = $setMenuData['set_menu_name'];
                $item['set_menu_items'] = $setMenuData['set_menu_items'];
            }
        }

        // Handle has_options
        if ($item['has_options'] == 1) {
            $optionStmt = $pdo->prepare("SELECT price FROM item_options WHERE item_id = :item_id ORDER BY id ASC LIMIT 1");
            $optionStmt->execute([':item_id' => $item['id']]);
            $option = $optionStmt->fetch(PDO::FETCH_ASSOC);

            if ($option) {
                $item['price'] = $option['price'];
            }
        }
    }

    // Set JSON header and output
    header('Content-Type: application/json');
    echo json_encode([
        'current_page' => $currentPage,
        'per_page' => $itemsPerPage,
        'total_items' => (int)$totalItems,
        'total_pages' => $totalPages,
        'data' => $items
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
