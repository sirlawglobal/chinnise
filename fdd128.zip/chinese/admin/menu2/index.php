<?php
session_start();

if (!isset($_SESSION['user']['id']) || !isset($_SESSION['user']['role'])) {
    header("Location: /login/");
    exit();
}

$username = $_SESSION['user']['name'] ?? '';
$parts = explode(" ", $username);
$first_name = $parts[0];

$userRole = $_SESSION['user']['role'] ?? '';
$profilePicture = $_SESSION['user']['profile_picture'] ?? 'https://picsum.photos/40';

require_once '../../BackEnd/config/init.php'; // Use the same init file for consistency

$pdo = db_connect(); // Use the same db_connect function from init.php

try {
    $query = "SELECT `id`, `name` FROM `categories`";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://js.pusher.com/8.2/pusher.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Billing Alerts</title>
    <link rel="stylesheet" href="../assets/styles/general.css" />
    <link rel="stylesheet" href="../assets/styles/panels.css" />
    <link rel="stylesheet" href="../assets/styles/menu.css" />
    <link rel="stylesheet" href="../assets/styles/inventory.css" />
    <style>
      .modal-container {
        background-color: #fff;
        border-radius: 0.5rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        padding: 1rem;
        width: 100%;
        max-width: 23rem;
        margin: auto;
        position: fixed;
        right: 0;
        top: 20%;
        z-index: 10;
        display: none;
        opacity: unset !important;
        visibility: unset !important;
        transition: all 0.3s;
        pointer-events: unset !important;
      }
      .modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .modal-content {
        background: white;
        padding: 20px;
        border-radius: 8px;
        max-width: 500px;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
      }
      .add-product-button {
        margin-left: auto;
      }
      .form-group {
        margin-bottom: 15px;
      }
      .form-label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
      }
      .form-input,
      .select-wrapper select {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
      }
      .secondary-button {
        background-color: #6c757d;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
      }
      .primary-button {
        background-color: #007bff;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
      }
      .form-actions {
        display: flex;
        justify-content: flex-end;
        margin-top: 20px;
      }
      .close-button {
        background: none;
        border: none;
        font-size: 1.5rem;
        cursor: pointer;
      }
      .close-button svg {
        width: 24px;
        height: 24px;
      }
      .pagination {
        display: flex;
        gap: 0.3rem;
        flex-wrap: wrap;
        justify-content: center;
        padding: 1rem 0;
      }
      .pagination button.page {
        padding: 0.4rem 0.8rem;
        border: 1px solid #ccc;
        background: white;
        color: #333;
        cursor: pointer;
        border-radius: 5px;
        transition: 0.2s;
      }
      .pagination button.page:hover:not(.active):not(:disabled) {
        background: #f0f0f0;
      }
      .pagination button.active {
        background: #007bff;
        color: white;
        border-color: #007bff;
      }
      .pagination button.disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }
      .pagination .ellipsis {
        padding: 0.5rem;
        color: #999;
      }
      .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.6);
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 1000;
      }
      .modal-content {
        background: white;
        padding: 2rem;
        border-radius: 10px;
        max-width: 400px;
        width: 100%;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
      }
      .modal-buttons {
        margin-top: 1rem;
        display: flex;
        justify-content: flex-end;
        gap: 1rem;
      }
      .modal-content label {
        display: block;
        margin-top: 1rem;
        font-weight: 600;
      }
      .modal-content input {
        width: 100%;
        padding: 0.5rem;
        margin-top: 0.3rem;
        border: 1px solid #ccc;
        border-radius: 5px;
      }
      .modal-content .submit-btn {
        padding: 7px 10px;
        border-radius: 5px;
        border: 0;
        background-color: #ff6c1f;
        color: white;
      }
      .modal-content .cancel-btn {
        padding: 7px 10px;
        border-radius: 5px;
        border: 0;
      }
      .modal-container.active {
        display: flex !important;
      }
      .spinner {
        border: 2px solid #f3f3f3;
        border-top: 2px solid #555;
        border-radius: 50%;
        width: 14px;
        height: 14px;
        display: inline-block;
        margin-right: 6px;
        animation: spin 0.6s linear infinite;
        vertical-align: middle;
      }
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      form {
        z-index: 1000;
      }
    </style>
</head>
<body class="flex">
    <main>
      <div class="content flex">
        <div class="inner-content card">
          <div class="all-menu">
            <div class="menu-controls">
              <div class="flex align-center justify-between">
                <h6>All Menu</h6>
                <div class="menu-actions">
                  <button class="add-product-button" id="addProduct">
                    + Add Product
                  </button>
                  <div class="search-bar">
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      class="feather feather-search"
                    >
                      <circle cx="11" cy="11" r="8"></circle>
                      <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                    <input
                      type="text"
                      placeholder="Search for menu"
                      id="search-input"
                    />
                  </div>
                  <button class="search-button" id="search-button">
                    Search
                  </button>
                </div>
              </div>
              <div class="flex justify-between align-center">
                <div class="category-tabs">
                  <button class="tab active" data-category="all">All</button>
                  <?php foreach ($categories as $category): ?>
                    <button class="tab" data-category="<?php echo htmlspecialchars(strtolower($category['name'])); ?>">
                      <?php echo htmlspecialchars($category['name']); ?>
                    </button>
                  <?php endforeach; ?>
                </div>
                <div class="sort-options" style="display: none">
                  <span>Sort by:</span>
                  <button class="sort-dropdown" id="sort-dropdown">
                    Popular
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      class="feather feather-chevron-down"
                    >
                      <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                  </button>
                  <div class="sort-dropdown-menu">
                    <a href="#" data-sort="popular">Popular</a>
                    <a href="#" data-sort="name">Name</a>
                    <a href="#" data-sort="health">Health Score</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="menu-items-container"></div>
            <div id="pagination"></div>
          </div>
          <div class="modal-container" id="addModal">
            <div class="modal-content">
              <div class="modal-header">
                <h2 class="modal-title">Add Product</h2>
                <button id="close-modal" class="close-button">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    class="h-5 w-5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="2"
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>
              <form id="add-menu-item-form" enctype="multipart/form-data" method="POST">
                <div class="form-group">
                  <label for="category" class="form-label">Category</label>
                  <div class="select-wrapper">
                    <select id="category" name="category_id" class="form-input" required>
                      <option value="">Select Category</option>
                      <?php foreach ($categories as $category): ?>
                        <option value="<?php echo htmlspecialchars($category['id']); ?>">
                          <?php echo htmlspecialchars($category['name']); ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label for="name" class="form-label">Item Name</label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    placeholder="e.g., Crispy Seaweed"
                    class="form-input"
                    required
                  />
                </div>
                <div class="form-group">
                  <label for="description" class="form-label">Description (Optional)</label>
                  <textarea
                    id="description"
                    name="description"
                    placeholder="e.g., With Sweet & Sour Sauce"
                    class="form-input"
                  ></textarea>
                </div>
                <div class="form-group">
                  <label for="price" class="form-label">Price (£)</label>
                  <input
                    type="number"
                    id="price"
                    name="basePrice"
                    placeholder="e.g., 5.5"
                    step="0.01"
                    class="form-input"
                  />
                </div>
                <div class="form-group">
                  <label for="image" class="form-label">Item Image (Optional)</label>
                  <input
                    type="file"
                    id="image"
                    name="image"
                    accept="image/*"
                    class="form-input"
                  />
                </div>
                <div class="form-group">
                  <label class="form-label">
                    <input type="checkbox" id="has_options" name="has_options" value="1" />
                    Has Portion Options (e.g., 1/4, 1/2, Whole)
                  </label>
                </div>
                <div id="options-section" style="display: none;">
                  <div class="form-group option-group">
                    <div class="flex justify-between align-center">
                      <div class="form-group">
                        <label for="portion_0" class="form-label">Portion</label>
                        <input
                          type="text"
                          id="portion_0"
                          name="options[0][portion]"
                          placeholder="e.g., 1/4 (6 pancakes)"
                          class="form-input"
                        />
                      </div>
                      <div class="form-group">
                        <label for="portion_price_0" class="form-label">Price (£)</label>
                        <input
                          type="number"
                          id="portion_price_0"
                          name="options[0][price]"
                          placeholder="e.g., 13.5"
                          step="0.01"
                          class="form-input"
                        />
                      </div>
                    </div>
                  </div>
                  <button type="button" id="add-option" class="secondary-button">Add Another Option</button>
                </div>
                <div class="form-group">
                  <label class="form-label">
                    <input type="checkbox" id="is_set_menu" name="is_set_menu" value="1" />
                    Is Set Menu (e.g., Menu for 1 Person)
                  </label>
                </div>
                <div id="set-menu-section" style="display: none;">
                  <div class="form-group">
                    <label for="set_menu_name" class="form-label">Set Menu Name</label>
                    <input
                      type="text"
                      id="set_menu_name"
                      name="set_menu[name]"
                      placeholder="e.g., Menu F - For 4 Persons"
                      class="form-input"
                    />
                  </div>
                  <div class="form-group">
                    <label for="set_menu_price" class="form-label">Set Menu Price (£)</label>
                    <input
                      type="number"
                      id="set_menu_price"
                      name="set_menu[price]"
                      placeholder="e.g., 60.0"
                      step="0.01"
                      class="form-input"
                    />
                  </div>
                  <div class="form-group">
                    <label for="set_menu_items" class="form-label">Set Menu Items</label>
                    <textarea
                      id="set_menu_items"
                      name="set_menu[items]"
                      placeholder="e.g., Crispy Seaweed, Chicken Curry"
                      class="form-input"
                    ></textarea>
                  </div>
                </div>
                <div class="form-actions">
                  <button type="submit" class="primary-button">Add Menu Item</button>
                </div>
              </form>
            </div>
          </div>
          <!--Edit Modal-->
          <div id="editModal" class="modal-overlay">
            <div class="modal-content">
              <h4>Edit Menu Item</h4>
              <form id="editForm" enctype="multipart/form-data">
                <input type="hidden" id="edit-id" />
                <label for="edit-name">Name:</label>
                <input type="text" id="edit-name" required />
                <label for="edit-price">Price:</label>
                <input type="number" id="edit-price" step="0.01" min="0" required />
                <label for="edit-image">Item Image (Optional):</label>
                <input type="file" id="edit-image" accept="image/*" />
                <div class="modal-buttons">
                  <button type="submit" id="edit-submit-button" class="submit-btn">Save Changes</button>
                  <button type="button" class="cancel-btn" id="closeModal">Cancel</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </main>
    <script>
      const username = '<?php echo addslashes($first_name); ?>';
      const userRole = '<?php echo addslashes($userRole); ?>';
      const profilePicture = '<?php echo addslashes($profilePicture); ?>';
      const categories = <?php echo json_encode($categories); ?>;
    </script>
    <script src="../scripts/components.js"></script>
    <script src="../scripts/menu.js"></script>
    <script>
      document.addEventListener('DOMContentLoaded', () => {
        // Cache DOM elements
        const elements = {
          addProduct: document.getElementById('addProduct'),
          addModal: document.getElementById('addModal'),
          closeModal: document.getElementById('close-modal'),
          form: document.getElementById('add-menu-item-form'),
          category: document.getElementById('category'),
          name: document.getElementById('name'),
          price: document.getElementById('price'),
          image: document.getElementById('image'),
          hasOptions: document.getElementById('has_options'),
          optionsSection: document.getElementById('options-section'),
          addOption: document.getElementById('add-option'),
          isSetMenu: document.getElementById('is_set_menu'),
          setMenuSection: document.getElementById('set-menu-section'),
          sortDropdown: document.getElementById('sort-dropdown'),
          sortDropdownMenu: document.querySelector('.sort-dropdown-menu'),
        };

        // Ensure modal is hidden initially
        elements.addModal.classList.remove('active');

        // Modal visibility
        elements.addProduct.addEventListener('click', (e) => {
          e.stopPropagation();
          elements.addModal.classList.add('active');
        });
        elements.closeModal.addEventListener('click', () => {
          elements.addModal.classList.remove('active');
        });
        elements.addModal.addEventListener('click', (e) => {
          if (e.target === elements.addModal) {
            elements.addModal.classList.remove('active');
          }
        });
        document.addEventListener('keydown', (e) => {
          if (e.key === 'Escape' && elements.addModal.classList.contains('active')) {
            elements.addModal.classList.remove('active');
          }
        });

        // Sort dropdown toggle
        elements.sortDropdown.addEventListener('click', () => {
          elements.sortDropdownMenu.style.display =
            elements.sortDropdownMenu.style.display === 'none' || elements.sortDropdownMenu.style.display === ''
              ? 'block'
              : 'none';
        });
        document.addEventListener('click', (e) => {
          if (!elements.sortDropdown.contains(e.target) && !elements.sortDropdownMenu.contains(e.target)) {
            elements.sortDropdownMenu.style.display = 'none';
          }
        });

        // Dynamic form behavior: Has Portion Options
        elements.hasOptions.addEventListener('change', function () {
          elements.optionsSection.style.display = this.checked ? 'block' : 'none';
          elements.price.disabled = this.checked;
          elements.image.disabled = this.checked;
          if (this.checked) {
            elements.price.value = '';
            elements.isSetMenu.disabled = true;
            elements.setMenuSection.style.display = 'none';
          } else {
            elements.price.disabled = false;
            elements.image.disabled = false;
            elements.isSetMenu.disabled = false;
          }
        });

        // Dynamic form behavior: Is Set Menu
        elements.isSetMenu.addEventListener('change', function () {
          elements.setMenuSection.style.display = this.checked ? 'block' : 'none';
          elements.price.disabled = this.checked;
          elements.image.disabled = this.checked;
          if (this.checked) {
            elements.price.value = '';
            elements.hasOptions.disabled = true;
            elements.optionsSection.style.display = 'none';
          } else {
            elements.price.disabled = false;
            elements.image.disabled = false;
            elements.hasOptions.disabled = false;
          }
        });

        // Add portion options dynamically
        let optionCount = 1;
        elements.addOption.addEventListener('click', () => {
          const optionGroup = document.createElement('div');
          optionGroup.className = 'form-group option-group';
          optionGroup.innerHTML = `
            <div class="flex justify-between align-center">
              <div class="form-group">
                <label for="portion_${optionCount}" class="form-label">Portion</label>
                <input
                  type="text"
                  id="portion_${optionCount}"
                  name="options[${optionCount}][portion]"
                  placeholder="e.g., 1/4 (6 pancakes)"
                  class="form-input"
                />
              </div>
              <div class="form-group">
                <label for="portion_price_${optionCount}" class="form-label">Price (£)</label>
                <input
                  type="number"
                  id="portion_price_${optionCount}"
                  name="options[${optionCount}][price]"
                  placeholder="e.g., 13.5"
                  step="0.01"
                  class="form-input"
                />
              </div>
              <button type="button" class="remove-option secondary-button" style="margin-top: 20px;">Remove</button>
            </div>
          `;
          elements.optionsSection.insertBefore(optionGroup, elements.addOption);
          optionGroup.querySelector('.remove-option').addEventListener('click', () => optionGroup.remove());
          optionCount++;
        });

        // Form submission
        elements.form.addEventListener('submit', async (e) => {
          e.preventDefault();
          const submitButton = e.target.querySelector('.primary-button');
          submitButton.disabled = true;
          submitButton.innerHTML = '<span class="spinner"></span> Adding...';

          // Validation
          if (!elements.category.value) {
            await Swal.fire({
              title: 'Validation Error',
              text: 'Please select a category.',
              icon: 'warning',
              confirmButtonText: 'OK',
              confirmButtonColor: '#007bff',
            });
            submitButton.disabled = false;
            submitButton.textContent = 'Add Menu Item';
            return;
          }
          if (!elements.name.value) {
            await Swal.fire({
              title: 'Validation Error',
              text: 'Please enter an item name.',
              icon: 'warning',
              confirmButtonText: 'OK',
              confirmButtonColor: '#007bff',
            });
            submitButton.disabled = false;
            submitButton.textContent = 'Add Menu Item';
            return;
          }
          if (!elements.hasOptions.checked && !elements.isSetMenu.checked && !elements.price.value) {
            await Swal.fire({
              title: 'Validation Error',
              text: 'Please enter a price or select portion options/set menu.',
              icon: 'warning',
              confirmButtonText: 'OK',
              confirmButtonColor: '#007bff',
            });
            submitButton.disabled = false;
            submitButton.textContent = 'Add Menu Item';
            return;
          }

          const formData = new FormData();
          formData.append('category_id', elements.category.value);
          formData.append('name', sanitizeInput(elements.name.value));
          formData.append('description', sanitizeInput(document.getElementById('description').value));
          if (!elements.hasOptions.checked && !elements.isSetMenu.checked) {
            formData.append('price', elements.price.value ? parseFloat(elements.price.value) : '');
          } else {
            formData.append('price', '');
          }
          formData.append('has_options', elements.hasOptions.checked ? '1' : '0');
          formData.append('is_set_menu', elements.isSetMenu.checked ? '1' : '0');
          if (elements.image.files[0] && !elements.hasOptions.checked && !elements.isSetMenu.checked) {
            formData.append('image', elements.image.files[0]);
          }

          if (elements.hasOptions.checked) {
            const options = [];
            const optionGroups = document.querySelectorAll('.option-group');
            optionGroups.forEach((group, i) => {
              const portionInput = group.querySelector(`[name="options[${i}][portion]"]`);
              const priceInput = group.querySelector(`[name="options[${i}][price]"]`);
              const portion = portionInput?.value;
              const price = priceInput ? parseFloat(priceInput.value) : '';
              if (portion && !isNaN(price) && price !== '') {
                options.push({ portion, price });
              }
            });
            if (options.length === 0) {
              await Swal.fire({
                title: 'Validation Error',
                text: 'Please add at least one valid portion option (portion and price).',
                icon: 'warning',
                confirmButtonText: 'OK',
                confirmButtonColor: '#007bff',
              });
              submitButton.disabled = false;
              submitButton.textContent = 'Add Menu Item';
              return;
            }
            formData.append('options', JSON.stringify(options));
          }

          if (elements.isSetMenu.checked) {
            const setMenu = {
              name: sanitizeInput(document.getElementById('set_menu_name').value),
              price: parseFloat(document.getElementById('set_menu_price').value),
              items: document.getElementById('set_menu_items')
                .value.split(',')
                .map(item => sanitizeInput(item.trim()))
                .filter(item => item !== ''),
            };
            if (!setMenu.name || isNaN(setMenu.price) || setMenu.items.length === 0) {
              await Swal.fire({
                title: 'Validation Error',
                text: 'Please fill all set menu fields including name, price, and at least one item.',
                icon: 'warning',
                confirmButtonText: 'OK',
                confirmButtonColor: '#007bff',
              });
              submitButton.disabled = false;
              submitButton.textContent = 'Add Menu Item';
              return;
            }
            formData.append('set_menu', JSON.stringify(setMenu));
          }

          try {
            const response = await fetch('../../BackEnd/controller/inventory/add_menu_item.php', {
              method: 'POST',
              body: formData,
            });
            if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const result = await response.json();
            if (!result.success) {
              throw new Error(result.message || 'Unknown error');
            }
            await Swal.fire({
              title: 'Success!',
              text: `Menu item added successfully! Item ID: ${result.item_id || 'N/A'}, Image URL: ${result.image_url || 'None'}`,
              icon: 'success',
              timer: 1500,
              showConfirmButton: false,
            });
            location.reload();
            elements.form.reset();
            elements.optionsSection.style.display = 'none';
            elements.setMenuSection.style.display = 'none';
            elements.price.disabled = false;
            elements.image.disabled = false;
            elements.hasOptions.disabled = false;
            elements.isSetMenu.disabled = false;
            elements.addModal.classList.remove('active');
            const currentOptionGroups = document.querySelectorAll('.option-group');
            currentOptionGroups.forEach((group, index) => {
              if (index > 0) group.remove();
            });
            optionCount = 1;
          } catch (error) {
            console.error('Error adding menu item:', error);
            await Swal.fire({
              title: 'Error!',
              text: `Error adding menu item: ${error.message}`,
              icon: 'error',
              confirmButtonText: 'OK',
              confirmButtonColor: '#007bff',
            });
          } finally {
            submitButton.disabled = false;
            submitButton.textContent = 'Add Menu Item';
          }
        });

        // Input sanitization
        const sanitizeInput = (input) => {
          return input.trim().replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
        };

        // Menu items handling
        const menuItemsContainer = document.querySelector(".menu-items-container");
        const categoryTabs = document.querySelectorAll(".category-tabs .tab");
        const searchInput = document.getElementById("search-input");
        const searchButton = document.getElementById("search-button");
        const sortDropdown = document.getElementById("sort-dropdown");
        const sortDropdownMenu = document.querySelector(".sort-dropdown-menu");
        const sortLinks = sortDropdownMenu.querySelectorAll("a");
        const modal = document.getElementById("editModal");
        const closeModalBtn = document.getElementById("closeModal");
        const editForm = document.getElementById("editForm");
        const editIdInput = document.getElementById("edit-id");
        const editNameInput = document.getElementById("edit-name");
        const editPriceInput = document.getElementById("edit-price");
        const editImageInput = document.getElementById("edit-image");

        let currentCategory = "all";
        let searchTerm = "";
        let sortOption = "popular";
        let allMenuItems = [];
        let currentPage = 1;
        let totalPages = 1;

        // Static template for menu items
        const staticMenuItemTemplates = [
          {
            id: 1,
            category: "toast",
            difficulty: "easy",
            healthScore: 9,
            kcal: 320,
            carbs: 30,
            protein: 14,
            fats: 18,
          },
          {
            id: 2,
            category: "shrimp",
            difficulty: "medium",
            healthScore: 8,
            kcal: 400,
            carbs: 45,
            protein: 28,
            fats: 12,
          },
          {
            id: 3,
            category: "chicken",
            difficulty: "medium",
            healthScore: 9,
            kcal: 480,
            carbs: 50,
            protein: 40,
            fats: 15,
          },
          {
            id: 4,
            category: "soups",
            difficulty: "easy",
            healthScore: 7,
            kcal: 250,
            carbs: 20,
            protein: 25,
            fats: 10,
          },
          {
            id: 5,
            category: "noodles",
            difficulty: "medium",
            healthScore: 8,
            kcal: 380,
            carbs: 55,
            protein: 15,
            fats: 12,
          },
          {
            id: 6,
            category: "rice",
            difficulty: "easy",
            healthScore: 9,
            kcal: 420,
            carbs: 40,
            protein: 30,
            fats: 18,
          },
        ];

        // Fetch menu items from the database
        async function fetchMenuItems(page) {
          try {
            const response = await fetch(`../menu2/get_menu_items.php?page=${page}`);
            if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const dbItems = await response.json();
            totalPages = dbItems.total_pages || 1;
            currentPage = page;

            allMenuItems = dbItems.data.map((dbItem, index) => {
              const staticTemplate = staticMenuItemTemplates[index % staticMenuItemTemplates.length];
              const normalizedCategory = dbItem.category_name.toLowerCase();
              return {
                id: dbItem.id,
                name: dbItem.name,
                image: dbItem.image_url ? '/BackEnd/uploads/' + dbItem.image_url : '../../avarterdefault.jpg',
                category: normalizedCategory,
                price: dbItem.price,
                difficulty: staticTemplate.difficulty,
                healthScore: staticTemplate.healthScore,
                kcal: staticTemplate.kcal,
                carbs: staticTemplate.carbs,
                protein: staticTemplate.protein,
                fats: staticTemplate.fats,
              };
            });

            filterMenuItems();
          } catch (error) {
            console.error('Error fetching menu items:', error);
            allMenuItems = staticMenuItemTemplates.map((item, index) => ({
              ...item,
              name: `Placeholder Item ${index + 1}`,
              image: `https://picsum.photos/300?random=${index + 5}`,
              category: item.category.toLowerCase(),
            }));
            filterMenuItems();
          }
        }

        // Render menu items
        function renderMenuItems(items) {
 
          menuItemsContainer.innerHTML = "";
          items.forEach((item) => {
            console.log('items',item)
            const card = document.createElement("div");
            card.classList.add("menu-item-card", "cream-card", "card");
            card.innerHTML = `
              <div class="item-image">
              
                <img src="${item.image}" alt="${item.name}" 
         loading="lazy" width="300" height="200" 
         onerror="this.src='https://via.placeholder.com/300x200.png?text=FOOD+IMAGE'" 
         class="menu-image">
             
              </div>
              <div class="item-details">
                <div class="item-header">
                  <div class="flex align-center">
                    <span class="item-category ${item.category}" style='background:#ff6c1f'>${
                      item.category.charAt(0).toUpperCase() + item.category.slice(1)
                    }</span>
                    <span class="item-difficulty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-check-circle"><path d="M22 11.08V12a10 10 0 1 1-5.92-9.43"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg> ${
                      item.difficulty.charAt(0).toUpperCase() + item.difficulty.slice(1)
                    }</span>
                  </div>
                  <div class="health-score">
                    <span>Health Score:</span>
                    <span class="score">${item.healthScore}/10</span>
                    <span class="progress-bar">
                      <span style="width: ${item.healthScore * 10}%;"></span>
                    </span>
                  </div>
                </div>
                <h3 class="item-name">${item.name}</h3>
                <span>£${item.price}</span>
                <div class="flex justify-between align-center">
                  <div class="nutrition-info">
                    <span class="nutrition-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-sun"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="17" y1="5" x2="19" y2="7"></line><line x1="7" y1="5" x2="5" y2="7"></line><line x1="17" y1="17" x2="19" y2="19"></line><line x1="7" y1="17" x2="5" y2="19"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="1" y1="12" x2="3" y2="12"></line></svg> ${
                      item.kcal
                    } kcal</span>
                    <span class="nutrition-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-leaf"><path d="M18.6 13.4c-.9 1.5-2.4 2.6-4.1 3.2l-6.2 2.5a2 2 0 0 1-2.3-.1c-2.1-.2-2.2-2-2.2-2.2l2.5-6.2c.3-1.7-.7-3.2-2.2-4.1-2.4-1.3 0 0 0 0z"></path><path d="M12 0l.5-3.2"></path><path d="M15 3l-3.2-.5"></path></svg> ${
                      item.carbs
                    }g carbs</span>
                    <span class="nutrition-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-zap"><polygon points="13 2 3 14 12 15 11 22 21 10 12 9 13 2"></polygon></svg> ${
                      item.protein
                    }g protein</span>
                    <span class="nutrition-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-egg"><path d="M13 6c0-3.5-5-3.5-5 0 0 2.1.8 4 2 5.3 1.2 1.5 3 2.2 5 2.2s3.8-.7 5-2.2c1.2-1.3 2-3.2 2-5.3 0-3.5-5-3.5-5 0"></path></svg> ${
                      item.fats
                    }g fats</span>
                  </div>
                  <div class="item-actions" style="display:flex; gap:4px">
                    <button class="edit-menu-button">Edit</button>
                    <button class="delete-menu-button">Delete</button>
                  </div>
                </div>
              </div>
            `;
            menuItemsContainer.appendChild(card);
          });
          renderPagination();
          attachEditButtons(items);
        }

        // Attach edit and delete buttons
        function attachEditButtons(items) {
          const editButtons = document.querySelectorAll(".edit-menu-button");
          const deleteButtons = document.querySelectorAll(".delete-menu-button");

          editButtons.forEach((button, index) => {
            button.onclick = () => {
              const item = items[index];
              openEditModal(item);
            };
          });

          deleteButtons.forEach((button, index) => {
            button.onclick = async () => {
              const item = items[index];
              const result = await Swal.fire({
                title: `Delete "${item.name}"?`,
                text: "Are you sure you want to delete this menu item?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Yes, delete it!",
                cancelButtonText: "Cancel",
              });

              if (result.isConfirmed) {
                try {
                  button.disabled = true;
                  button.innerHTML = `<span class="spinner"></span> Deleting...`;

                  const response = await fetch(`../../BackEnd/controller/inventory/delete_menu_item.php/${item.id}`, {
                    method: "DELETE",
                  });

                  if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                  }

                  const result = await response.json();
                  if (!result.success) {
                    throw new Error(result.message || "Failed to delete item");
                  }

                  await Swal.fire({
                    title: "Deleted!",
                    text: `"${item.name}" has been deleted.`,
                    icon: "success",
                    timer: 1500,
                    showConfirmButton: false,
                  });

                  fetchMenuItems(currentPage);
                } catch (error) {
                  console.error("Error deleting menu item:", error);
                  await Swal.fire({
                    title: "Error!",
                    text: `Failed to delete item: ${error.message}`,
                    icon: "error",
                    confirmButtonText: "OK",
                  });
                  button.disabled = false;
                  button.textContent = "Delete";
                }
              }
            };
          });
        }

        // Open edit modal
        function openEditModal(item) {
          editIdInput.value = item.id;
          editNameInput.value = item.name;
          editPriceInput.value = item.price || 0;
          editImageInput.value = ''; // Reset file input
          modal.style.display = "flex";
        }

        // Close modal
        closeModalBtn.onclick = () => {
          modal.style.display = "none";
        };

        modal.addEventListener("click", (e) => {
          if (e.target === modal) modal.style.display = "none";
        });

      
        
        // Replace the editForm.onsubmit handler with this:
editForm.onsubmit = async (e) => {
  e.preventDefault();
  const id = editIdInput.value.trim();
  const newName = editNameInput.value.trim();
  const newPrice = parseFloat(editPriceInput.value.trim());
  const imageFile = editImageInput.files[0];
  const submitButton = document.getElementById('edit-submit-button');

  if (!id || !newName || isNaN(newPrice)) {
    await Swal.fire({
      title: "Invalid Input",
      text: "Please fill out both name and price correctly.",
      icon: "warning",
      confirmButtonText: "OK"
    });
    return;
  }

  submitButton.disabled = true;
  const originalText = submitButton.textContent;
  submitButton.innerHTML = `<span class="spinner"></span> Saving...`;

  try {
    const formData = new FormData();
    formData.append('id', id);
    formData.append('name', newName);
    formData.append('price', newPrice);
    if (imageFile) {
      formData.append('image', imageFile);
    }

    const response = await fetch(`../../BackEnd/controller/inventory/update_menu_item.php`, {
      method: 'POST', // Changed from PATCH to POST
      headers: {
        'X-HTTP-Method-Override': 'PATCH' // Add this header
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const result = await response.json();
    if (!result.success) {
      throw new Error(result.message || 'Unknown error occurred while updating.');
    }

    await Swal.fire({
      title: "Success!",
      text: `Menu item updated successfully! Image URL: ${result.image_url || 'No new image uploaded'}`,
      icon: "success",
      timer: 1500,
      showConfirmButton: false
    });

    fetchMenuItems(currentPage);
    modal.style.display = "none";
  } catch (error) {
    console.error('Error updating menu item:', error);
    await Swal.fire({
      title: "Error!",
      text: `Failed to update item: ${error.message}`,
      icon: "error",
      confirmButtonText: "OK"
    });
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = originalText;
  }
};

        // Render pagination
        function renderPagination() {
          const container = document.getElementById("pagination");
          if (!container) return;
          container.innerHTML = "";

          const pagination = document.createElement("div");
          pagination.className = "pagination";

          const createBtn = (label, page, isActive = false, isDisabled = false) => {
            const btn = document.createElement("button");
            btn.textContent = label;
            btn.className = isActive ? "page active" : "page";
            if (isDisabled) {
              btn.disabled = true;
              btn.classList.add("disabled");
            }
            btn.onclick = (e) => {
              e.preventDefault();
              if (!isDisabled && page !== currentPage) {
                currentPage = page;
                fetchMenuItems(currentPage);
              }
            };
            return btn;
          };

          const createEllipsis = () => {
            const span = document.createElement("span");
            span.textContent = "...";
            span.className = "ellipsis";
            return span;
          };

          pagination.appendChild(
            createBtn("« Prev", currentPage - 1, false, currentPage === 1)
          );

          pagination.appendChild(createBtn(1, 1, currentPage === 1));

          if (currentPage > 4) pagination.appendChild(createEllipsis());

          if (currentPage - 1 > 1) {
            pagination.appendChild(
              createBtn(currentPage - 1, currentPage - 1)
            );
          }

          if (currentPage !== 1 && currentPage !== totalPages) {
            pagination.appendChild(createBtn(currentPage, currentPage, true));
          }

          if (currentPage + 1 < totalPages) {
            pagination.appendChild(
              createBtn(currentPage + 1, currentPage + 1)
            );
          }

          if (currentPage < totalPages - 3) pagination.appendChild(createEllipsis());

          if (totalPages > 1) {
            pagination.appendChild(
              createBtn(totalPages, totalPages, currentPage === totalPages)
            );
          }

          pagination.appendChild(
            createBtn("Next »", currentPage + 1, false, currentPage === totalPages)
          );

          container.appendChild(pagination);
        }

        // Filter menu items
        function filterMenuItems() {
          const filteredByCategory =
            currentCategory === "all"
              ? allMenuItems
              : allMenuItems.filter((item) => item.category === currentCategory);

          const filteredBySearch = searchTerm
            ? filteredByCategory.filter((item) =>
                item.name.toLowerCase().includes(searchTerm.toLowerCase())
              )
            : filteredByCategory;

          let sortedItems = [...filteredBySearch];
          if (sortOption === "name") {
            sortedItems.sort((a, b) => a.name.localeCompare(b.name));
          } else if (sortOption === "health") {
            sortedItems.sort((a, b) => b.healthScore - a.healthScore);
          } else if (sortOption === "popular") {
            sortedItems.sort((a, b) => a.id - b.id);
          }

          renderMenuItems(sortedItems);
        }

        // Event listeners for tabs, search, and sort
        categoryTabs.forEach((tab) => {
          tab.addEventListener("click", function () {
            categoryTabs.forEach((t) => t.classList.remove("active"));
            this.classList.add("active");
            currentCategory = this.dataset.category;
            filterMenuItems();
          });
        });

        searchButton.addEventListener("click", () => {
          searchTerm = searchInput.value;
          filterMenuItems();
        });

        searchInput.addEventListener("keypress", (event) => {
          if (event.key === "Enter") {
            searchTerm = searchInput.value;
            filterMenuItems();
          }
        });

        sortDropdown.addEventListener("click", () => {
          sortDropdownMenu.style.display =
            sortDropdownMenu.style.display === "block" ? "none" : "block";
        });

        sortLinks.forEach((link) => {
          link.addEventListener("click", function (event) {
            event.preventDefault();
            sortOption = this.dataset.sort;
            sortDropdown.textContent = this.textContent;
            sortDropdownMenu.style.display = "none";
            filterMenuItems();
          });
        });

        // Fetch and render menu items on load
        fetchMenuItems(currentPage);
      });
    </script>
</body>
</html>