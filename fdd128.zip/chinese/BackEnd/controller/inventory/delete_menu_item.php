<?php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error_log.txt');

require_once '../../config/db.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method. Only DELETE is allowed']);
    exit;
}

// Extract item ID from URI
$requestUri = $_SERVER['REQUEST_URI'];
$parts = explode('/', $requestUri);
$itemId = intval(end($parts));

if (!$itemId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing or invalid item ID']);
    exit;
}

try {
    // Check if item exists
    $checkQuery = "SELECT id FROM items WHERE id = :id";
    $exists = db_query($checkQuery, ['id' => $itemId]);

    if (!$exists || count($exists) === 0) {
        http_response_code(404);
        throw new Exception('Item not found');
    }

    // Delete from related tables
    $deleteReviewsQuery = "DELETE FROM reviews WHERE dish_id = :item_id";
    if (!db_query($deleteReviewsQuery, ['item_id' => $itemId])) {
        throw new Exception("Failed to delete related reviews");
    }

    $deleteOptionsQuery = "DELETE FROM item_options WHERE item_id = :item_id";
    if (!db_query($deleteOptionsQuery, ['item_id' => $itemId])) {
        throw new Exception("Failed to delete item options");
    }

    $deleteSetMenusQuery = "DELETE FROM set_menus WHERE item_id = :item_id";
    if (!db_query($deleteSetMenusQuery, ['item_id' => $itemId])) {
        throw new Exception("Failed to delete from set menus");
    }

    // Delete from items table
    $deleteItemQuery = "DELETE FROM items WHERE id = :id";
    if (!db_query($deleteItemQuery, ['id' => $itemId])) {
        throw new Exception("Delete failed: " . ($GLOBALS['DB_STATE']['error'] ?? 'Unknown database error'));
    }

    $response['success'] = true;
    $response['message'] = 'Item and related records deleted successfully';

} catch (Exception $e) {
    http_response_code(500);
    $response['message'] = $e->getMessage();
    error_log("ERROR: " . $e->getMessage());
}

// Return JSON response
echo json_encode($response);
exit;
