<?php 


require_once __DIR__ . '/../../config/init.php';

header('Content-Type: application/json');

// ============ STOCK CHART LOGIC ============
if (isset($_GET['chart']) && $_GET['chart'] === 'stock') {
    $sql = "SELECT qty, record_qty FROM stock";
    $rows = db_query($sql, [], 'assoc');

    $available = $low = $out = 0;

    foreach ($rows as $row) {
        $qty = (int)$row['qty'];
        $record = (int)$row['record_qty'];

        if ($qty === 0) {
            $out++;
        } elseif ($qty <= 10 || $qty <= $record) {
            $low++;
        } else {
            $available++;
        }
    }

    echo json_encode([
        'available' => $available,
        'low' => $low,
        'out' => $out
    ]);
    exit;
}

// ============ SUPPLY LINE CHART LOGIC ============
if (isset($_GET['chart']) && $_GET['chart'] === 'supply') {
    $sql = "
        SELECT DATE_FORMAT(created_at, '%b') AS month, COUNT(*) AS total
        FROM stock
        GROUP BY MONTH(created_at)
        ORDER BY MONTH(created_at)
    ";
    $rows = db_query($sql, [], 'assoc');

    $labels = [];
    $data = [];

    foreach ($rows as $row) {
        $labels[] = $row['month'];
        $data[] = (int)$row['total'];
    }

    echo json_encode([
        'labels' => $labels,
        'data' => $data
    ]);
    exit;
}

// ============ DEFAULT: INVENTORY TABLE ============
if (isset($_GET['action']) && $_GET['action'] === 'get_item_history') {
    // Return individual records for a specific item when viewing details
    $itemName = $_GET['name'] ?? '';
    
    $sql = "
        SELECT 
            s.id,
            s.name,
            c.name AS category,
            s.qty AS qty_in_stock,
            s.record_qty AS reorder_quantity,
            DATE_FORMAT(s.created_at, '%Y-%m-%d') AS delivery_date,
            s.created_at
        FROM stock s
        LEFT JOIN inves_categories c ON s.category_id = c.id
        WHERE s.name = :name
        ORDER BY s.created_at DESC
    ";
    
    $params = [':name' => $itemName];
    $items = db_query($sql, $params, 'assoc');
    
    $data = [];
    if ($items !== false) {
        foreach ($items as $item) {
            $data[] = [
                'delivery_date' => htmlspecialchars($item['delivery_date'] ?? 'N/A'),
                'inventory_id' => htmlspecialchars($item['id']),
                'category' => htmlspecialchars($item['category'] ?? 'Uncategorized'),
                'description' => htmlspecialchars($item['name']),
                'qty_in_stock' => (int)$item['qty_in_stock'],
                'created_at' => $item['created_at']
            ];
        }
    }
    
    echo json_encode(['data' => $data]);
    exit;
}

// Main inventory table with aggregated quantities
$sql = "
    SELECT 
        s.name,
        s.id,
        c.name AS category,
        SUM(s.qty) AS total_qty,
        MIN(s.record_qty) AS reorder_quantity,
        MAX(s.created_at) AS last_updated
    FROM stock s
    LEFT JOIN inves_categories c ON s.category_id = c.id
    GROUP BY s.name, c.name
    ORDER BY last_updated DESC
";

$items = db_query($sql, [], 'assoc');
$data = [];
$counter = 1;

if ($items !== false) {
    foreach ($items as $item) {
        $delivered = (int)$item['total_qty']; // qty → qty_delivered
        $recorded = (int)$item['reorder_quantity'] - $delivered; // record_qty → current_qty
        $inStock = $delivered + $recorded; // total in stock = both
        // $inStock = $delivered + $recorded; // total in stock = both
        $percent = ($inStock > 0) ? min(100, ($delivered / $inStock) * 100) : 0;
        $percent = number_format($percent, 2);

        // $status = 'Available';
        // $statusClass = 'available';
        // if ($stock === 0) {
        //     $status = 'Out of Stock';
        //     $statusClass = 'out-of-stock';
        // } elseif ($stock <= 10 || $stock <= $reorder) {
        //     $status = 'Low';
        //     $statusClass = 'low';
        // }
        
        $status = 'Available';
$statusClass = 'available';

if ($inStock === 0) {
    $status = 'Out of Stock';
    $statusClass = 'out-of-stock';
} elseif ($inStock <= 10 || $inStock <= $recorded) {
    $status = 'Low';
    $statusClass = 'low';
}

        $stockHtml = "
            <div class='stock-level' data-stock='{$inStock}' data-reorder='{$recorded}'>
                <div class='progress-bar-container'>
                    <div class='progress-bar {$statusClass}' style='width: {$percent}%'></div>
                </div>
                {$inStock}
            </div>
        ";
        
        
        $formattedId = 'INV' . str_pad($counter, 4, '0', STR_PAD_LEFT);

        $data[] = [
            'delivery_date' => htmlspecialchars(date('Y-m-d', strtotime($item['last_updated'])) ?? 'N/A'),
            'inventory_id' => $item['id'],
            // 'inventory_id' => $formattedId,
            'category' => htmlspecialchars($item['category'] ?? 'Uncategorized'),
            'description' => htmlspecialchars($item['name']),
            'status' => "<span class='status {$statusClass}'>" . htmlspecialchars($status) . "</span>",
            'qty_in_stock' => $inStock,
            'qty_delivered' => $delivered, // ✅ Mapped correctly
            'current_qty' => $recorded,
            'item_name' => htmlspecialchars($item['name']), // Add original name for view details
            'is_aggregated' => true // Flag to indicate this is an aggregated row
        ];
        
        $counter++;
    }
}

echo json_encode(['data' => $data]);