<?php
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error_log.txt');

require_once '../../config/db.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

$pdo = db_connect();

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || 
    (empty($_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE']) || $_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'] !== 'PATCH')) {
    http_response_code(405);
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
    exit;
}

// Get input data
$itemId = isset($_POST['id']) ? intval($_POST['id']) : 0;
$name = isset($_POST['name']) ? trim(filter_var($_POST['name'], FILTER_SANITIZE_STRING)) : null;
$price = isset($_POST['price']) ? filter_var($_POST['price'], FILTER_VALIDATE_FLOAT) : null;
$hasImage = isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK;

if (!$itemId) {
    http_response_code(400);
    $response['message'] = 'Missing or invalid item ID';
    echo json_encode($response);
    exit;
}

try {
    // Prepare update query
    $query = "UPDATE items SET ";
    $params = [':id' => $itemId];
    $updates = [];

    if ($name !== null) {
        $updates[] = "name = :name";
        $params[':name'] = $name;
    }

    if ($price !== null && $price !== false) {
        $updates[] = "price = :price";
        $params[':price'] = $price;
    }

    // Handle image upload and WebP conversion
    if ($hasImage) {
        $uploadDir = __DIR__ . '/../../uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxFileSize = 5 * 1024 * 1024; // 5MB
        $fileType = $_FILES['image']['type'];
        $fileSize = $_FILES['image']['size'];
        $tmpPath = $_FILES['image']['tmp_name'];

        if (!in_array($fileType, $allowedTypes)) {
            throw new Exception('Invalid file type. Only JPEG, PNG, and GIF are allowed.');
        }

        if ($fileSize > $maxFileSize) {
            throw new Exception('File size exceeds 5MB limit.');
        }

        // Load original image
        switch ($fileType) {
            case 'image/jpeg':
                $image = imagecreatefromjpeg($tmpPath);
                break;
            case 'image/png':
                $image = imagecreatefrompng($tmpPath);
                imagepalettetotruecolor($image);
                imagealphablending($image, true);
                imagesavealpha($image, true);
                break;
            case 'image/gif':
                $image = imagecreatefromgif($tmpPath);
                break;
            default:
                throw new Exception('Unsupported image type.');
        }

        if (!$image) {
            throw new Exception('Failed to load uploaded image.');
        }

        // Generate WebP file name and save
        $webpFileName = uniqid('img_') . '.webp';
        $webpFilePath = $uploadDir . $webpFileName;

        if (!imagewebp($image, $webpFilePath, 80)) {
            imagedestroy($image);
            throw new Exception('Failed to convert image to WebP.');
        }

        imagedestroy($image);

        $updates[] = "image_url = :image_url";
        $params[':image_url'] = $webpFileName;
    }

    if (empty($updates)) {
        throw new Exception('No fields provided for update.');
    }

    $query .= implode(', ', $updates) . " WHERE id = :id";

    // Execute the query
    $stmt = $pdo->prepare($query);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }

    if (!$stmt->execute()) {
        throw new Exception('Database update failed.');
    }

    $response['success'] = true;
    $response['message'] = 'Item updated successfully';
    if ($hasImage) {
        $response['image_url'] = $webpFileName;
    }

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log("ERROR: " . $e->getMessage());
}

echo json_encode($response);
exit;
