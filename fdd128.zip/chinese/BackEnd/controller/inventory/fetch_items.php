<?php
require_once '../../config/db.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => '', 'items' => []];

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
    exit;
}

try {
    $category_id = filter_input(INPUT_GET, 'category_id', FILTER_VALIDATE_INT);

    if (!$category_id) {
        throw new Exception('Category ID is required and must be a valid number.');
    }

    // Prepare and execute query
    $query = "SELECT id, name FROM stock WHERE category_id = :category_id";
    $params = ['category_id' => $category_id];

    $result = db_query($query, $params, true); // Assuming true enables fetchAll

    if ($result === false) {
        throw new Exception("Database error: " . $GLOBALS['DB_STATE']['error']);
    }

    $response['success'] = true;
    $response['items'] = $result;

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
exit;