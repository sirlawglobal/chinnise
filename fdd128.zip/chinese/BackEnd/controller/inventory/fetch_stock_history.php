<?php
require_once '../../config/db.php';

header('Content-Type: application/json');

define('DEBUG_MODE', true); // Set to false in production
function debug_log($data) {
    if (DEBUG_MODE) {
        error_log(print_r($data, true));
    }
}

$response = ['success' => false, 'message' => '', 'stock' => null, 'history' => []];

// Get item name from GET request
$itemName = $_GET['item_name'] ?? '';

if (!$itemName) {
    $response['message'] = 'Item name is required';
    echo json_encode($response);
    exit;
}

try {
    // Step 1: Query stock table to get item by name
    $stockQuery = "SELECT id, category_id, qty, record_qty, cat_id, updated_at, created_at, name 
                   FROM stock 
                   WHERE name = :item_name 
                   LIMIT 1";
    $stockParams = ['item_name' => $itemName];
    $stockData = db_query($stockQuery, $stockParams, false); // fetch one row

    debug_log(['Stock result' => $stockData]);

    if (!$stockData) {
        $response['message'] = 'Item not found in stock table';
        echo json_encode($response);
        exit;
    }

    // Since db_query may return an array of rows, we ensure $stockData is the first row
    if (isset($stockData[0])) {
        $stockData = $stockData[0];
    }

    $stockId = $stockData['id'];
    $categoryId = $stockData['category_id'];
    debug_log(['Using stock ID' => $stockId, 'Category ID' => $categoryId]);

    // Step 1.1: Get category name from inves_categories
    $categoryQuery = "SELECT name FROM inves_categories WHERE id = :category_id LIMIT 1";
    $categoryParams = ['category_id' => $categoryId];
    $categoryData = db_query($categoryQuery, $categoryParams, false); // fetch one row

    debug_log(['Category result' => $categoryData]);

    if ($categoryData && isset($categoryData[0]['name'])) {
        $stockData['category_name'] = $categoryData[0]['name'];
    } else {
        $stockData['category_name'] = null;
    }

    // Step 2: Query stock_history table using the stock ID
    $historyQuery = "
        SELECT id, stock_id, old_qty, new_qty, qty_change, change_date, notes, changed_by 
        FROM stock_history 
        WHERE stock_id = :stock_id 
        ORDER BY change_date DESC
    ";
    $historyParams = ['stock_id' => $stockId];
    $historyData = db_query($historyQuery, $historyParams, true); // fetchAll

    debug_log(['History result' => $historyData]);

    // Step 3: Return response
    $response['success'] = true;
    $response['stock'] = $stockData;
    $response['history'] = $historyData ?: [];

} catch (Exception $e) {
    $response['message'] = 'Error: ' . $e->getMessage();
    debug_log(['Exception' => $e->getMessage()]);
}

echo json_encode($response);
exit;
