
<?php
require_once __DIR__ . '/../../config/init.php';
header('Content-Type: application/json');

define('DEBUG_MODE', true); // Set to false in production

function debug_log($data) {
    if (DEBUG_MODE) {
        error_log(print_r($data, true));
    }
}

// Debug POST data
debug_log(['POST Data' => $_POST]);

$categoryId = $_POST['category_id'] ?? null;
$name = trim($_POST['description'] ?? '');
$qty = (int)($_POST['qty_delivered'] ?? 0);
$currentTime = date("Y-m-d H:i:s");

// Validation
if (!$categoryId) {
    echo json_encode(['success' => false, 'message' => 'Category is required']);
    exit;
}
if (!$name) {
    echo json_encode(['success' => false, 'message' => 'Item name is required']);
    exit;
}
if ($qty < 0) {
    echo json_encode(['success' => false, 'message' => 'Quantity must be zero or more']);
    exit;
}

try {
    // Check if item exists
    $checkSql = "SELECT id, qty, record_qty FROM stock WHERE name = :name AND category_id = :category_id LIMIT 1";
    $existingItem = db_query($checkSql, [
        'name' => $name,
        'category_id' => $categoryId
    ], true);

    debug_log(['Existing item result' => $existingItem]);

    if ($existingItem) {
        // Update existing item
        $existingItem = $existingItem[0];
        $oldQty = (int)$existingItem['qty'];
        $newQty = $qty;
        $qtyChange = $qty; // The amount we're adding now
        
        debug_log([
            'Old Qty' => $oldQty,
            'New Qty' => $newQty,
            'Qty Change' => $qtyChange,
        ]);

        // // Update stock
        // $updateSql = "UPDATE stock SET 
        //               qty = :qty, 
        //               record_qty = record_qty + :qty_added, 
        //               updated_at = :updated_at 
        //               WHERE id = :id";


    $updateSql = "UPDATE stock SET 
    qty = :qty, 
    record_qty = record_qty + :qty_added, 
    updated_at = :updated_at 
    WHERE id = :id";
        // $result = db_query($updateSql, [
        //     'qty' => $newQty,
        //     'qty_added' => $qty, // Add to record_qty only the newly delivered quantity
        //     'updated_at' => $currentTime,
        //     'id' => $existingItem['id']
        // ]);
        
        
    $result = db_query($updateSql, [
    'qty' => $newQty,       // ⚠️ Replace qty with just the delivered qty
    'qty_added' => $qty,    // Add this to record_qty
    'updated_at' => $currentTime,
    'id' => $existingItem['id']
]);

        debug_log(['Update result' => $result]);

        // Always log to history for updates
        $historySql = "INSERT INTO stock_history 
                      (stock_id, old_qty, new_qty, qty_change, change_date, notes) 
                      VALUES 
                      (:stock_id, :old_qty, :new_qty, :qty_change, :change_date, :notes)";
        
        db_query($historySql, [
            'stock_id' => $existingItem['id'],
            'old_qty' => $oldQty,
            'new_qty' => $newQty,
            'qty_change' => $qtyChange,
            'change_date' => $currentTime,
            'notes' => 'Manual update via form - added '.$qty.' items'
        ]);

        debug_log('History logged for update');
        $message = 'Stock item updated successfully';
    } else {
        // Create new item
        $insertSql = "INSERT INTO stock 
                     (category_id, qty, record_qty, updated_at, created_at, name) 
                     VALUES 
                     (:category_id, :qty, :record_qty, :updated_at, :created_at, :name)";

        $result = db_query($insertSql, [
            'category_id' => $categoryId,
            'qty' => $qty,
            'record_qty' => $qty, // For new items, record_qty equals initial qty
            'updated_at' => $currentTime,
            'created_at' => $currentTime,
            'name' => $name
        ]);

        // $newStockId = db_last_insert_id
          $newStockId = $GLOBALS['DB_STATE']['insert_id'];

        debug_log([
            'Insert result' => $result,
            'New Stock ID' => $newStockId,
        ]);

        if ($result && $newStockId) {
            // Log initial stock to history
            $historySql = "INSERT INTO stock_history 
                          (stock_id, old_qty, new_qty, qty_change, change_date, notes) 
                          VALUES 
                          (:stock_id, :old_qty, :new_qty, :qty_change, :change_date, :notes)";
            
            db_query($historySql, [
                'stock_id' => $newStockId,
                'old_qty' => 0,
                'new_qty' => $qty,
                'qty_change' => $qty,
                'change_date' => $currentTime,
                'notes' => 'Initial stock entry'
            ]);

            debug_log('History logged for insert');
        }

        $message = 'New stock item added successfully';
    }

    echo json_encode([
        'success' => $result !== false,
        'message' => $result ? $message : 'Database error'
    ]);
} catch (Exception $e) {
    debug_log(['Exception' => $e->getMessage()]);
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
