function renderTickets() {
  const container = document.getElementById("tickets-container");
  container.innerHTML = "";

  if (ticketsData.length === 0) {
    container.innerHTML = `<tr><td colspan="8" style="text-align:center">No tickets found.</td></tr>`;
    return;
  }

  ticketsData.forEach((ticket, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${index + 1}</td>
      <td>${ticket.date || ""}</td>
      <td>${ticket.time || ""}</td>
      <td>${ticket.ticketNumber || ""}</td>
     
      <td><span class="circle ${getPriorityClass(ticket.priority)}-circle"></span> ${ticket.priority}</td>
      <td><span class="circle ${getStatusColorClass(ticket.status)}-circle"></span> ${ticket.status}</td>
      <td>${ticket.title}</td>
 <td>
  <a style="text-decoration: none;" href="#" onclick='showTicketModal(${JSON.stringify(ticket)})'>👁️</a> |  
  <a style="text-decoration: none;" href="#" onclick='openModal(${JSON.stringify(ticket)})'>📝</a> |
 <a style="text-decoration: none;" href="#" onclick='editTicket(${JSON.stringify(ticket)})'>✏️</a>
<a style="text-decoration: none;" href="#" onclick='deleteTicket(${ticket.id})'>🗑️</a>
</td>

    `;
    container.appendChild(row);
  });
}


function renderSummary(summary) {
  const container = document.getElementById("ticket-summary");
  if (!summary) return;

  container.innerHTML = `
    <div class="summary-item"><strong>Name:</strong> ${summary.user}</div>
    <div class="summary-item"><strong>Total Tickets:</strong> ${summary.total}</div>
    <div class="summary-item"><strong>Open:</strong> ${summary.open}</div>
    <div class="summary-item"><strong>Closed:</strong> ${summary.closed}</div>
    <div class="summary-item"><strong>Pending:</strong> ${summary.pending}</div>
  `;
}


  // === PAGINATION RENDERING ===
  function renderPagination(pager) {
    const pagination = document.getElementById("pagination-container");
    pagination.innerHTML = "";

    if (!pager || pager.total_links < 2) return;

    if (pager.current > 1) {
      const prev = document.createElement("button");
      prev.textContent = "Previous";
      prev.onclick = () => send_data(lastAction, lastExtraData, pager.current - 1);
      pagination.appendChild(prev);
    }

    for (let i = pager.total_start; i <= pager.total_end; i++) {
      const btn = document.createElement("button");
      btn.textContent = i;
      btn.className = "page-link";
      if (i === pager.current) btn.classList.add("active");
      btn.onclick = () => send_data(lastAction, lastExtraData, i);
      pagination.appendChild(btn);
    }

    if (pager.current < pager.total_end) {
      const next = document.createElement("button");
      next.textContent = "Next";
      next.onclick = () => send_data(lastAction, lastExtraData, pager.current + 1);
      pagination.appendChild(next);
    }
  }

  // === MODAL: SHOW / HIDE ===
function showTicketModal(ticket) {
  // Populate basic ticket fields
  document.getElementById("modalTicketTitle").textContent = ticket.title;
  document.getElementById("modalTicketNumber").textContent = ticket.ticketNumber;
  document.getElementById("modalTicketPriority").textContent = ticket.priority;
  document.getElementById("modalTicketStatus").textContent = ticket.status;
  document.getElementById("modalTicketDate").textContent = ticket.date;
  document.getElementById("modalTicketTime").textContent = ticket.time;
  document.getElementById("modalTicketDescription").textContent = ticket.description;

  // Populate comments or fallback text
  let commentsHtml = "";

  if (ticket.comments && ticket.comments.length > 0) {
    commentsHtml = `
     <div class="ticket-comments">
          <h4>Comments:</h4>
          <ul class="comment-list">
            ${ticket.comments.map(comment => `
              <li class="comment">
                <div class="comment-row">
                  <div class="comment-body">${comment.comment}</div>
                  <div class="comment-by">${comment.comment_by}</div>
                </div>
                <div class="comment-date">${comment.commented_at}</div>
              </li>
            `).join("")}
          </ul>
        </div>
    `;
  } else {
    commentsHtml = `<p><em>No comments yet.</em></p>`;
  }

  document.getElementById("modalTicketComments").innerHTML = commentsHtml;
  document.getElementById("ticketModal").style.display = "flex";
}

function hideTicketModal() {
  document.getElementById("ticketModal").style.display = "none";
}

//   function hideTicketModal() {
//     document.getElementById("ticketModal").style.display = "none";
//   }

  // === HELPERS ===
  function randomColor() {
    return colors[Math.floor(Math.random() * colors.length)];
  }

 function getPriorityClass(priority) {
  console.log("Priority input:", priority);
  switch (priority.toLowerCase()) {
    case 'low': return 'low';
    case 'medium': return 'medium';
    case 'high': return 'high';
    case 'urgent': return 'urgent';
    default:
      console.log("Unknown priority:", priority);
      return 'status-default';
  }
}
   

function getStatusColorClass(status) {
  //console.log("Status input:", status);
  switch (status.toLowerCase()) {
    case 'open': return 'open';
    case 'closed': return 'closed';
    case 'pending': return 'pending';
    default:
      //console.log("Unknown status:", status);
      return 'default';
  }
}
  // === INIT ON PAGE LOAD ===
  document.addEventListener("DOMContentLoaded", () => {
    send_data("fetch_tickets", {}, 1);

    document.getElementById("ticket-search").addEventListener("input", function () {
      const q = this.value.trim();
      if (q.length >= 2) {
        send_data("search_tickets", { query: q }, 1);
      } else if (q.length === 0) {
        send_data("fetch_tickets", {}, 1);
      }
    });

    modalCloseBtn.onclick = hideTicketModal;
    document.getElementById("ticketModal").onclick = (e) => {
      if (e.target.id === "ticketModal") hideTicketModal();
    };
  });

function openModal(ticket, index = null) {
  document.getElementById("id_s").value = ticket.id || "";
  document.getElementById("user-email").value = ticket.email || "";
  document.getElementById("ticket-title").value = ticket.title || "";
  document.getElementById("ticket-status").value = ticket.status || "";
  document.getElementById("modalTitle").textContent = ticket.title || "Ticket Title";
  document.getElementById("modalDescription").textContent = ticket.description || "";
  document.getElementById("ticketNumber").textContent = "Ticket# " + (ticket.ticketNumber || "N/A");
  document.querySelector("#modal .ticket-time").textContent = "Posted at " + (ticket.time || "");

  const circle = document.querySelector("#modal .circle");
  if (circle) {
    circle.className = "circle " + (getStatusColorClass(ticket.status) || "default") + "-circle";
  }
  // Show modal
  document.getElementById("modal").classList.add("show");
}



 document.addEventListener("DOMContentLoaded", function () {
    const modal = document.getElementById("modal");
    const closeIcon = document.getElementById("modal-close-icon");
    const closeButton = document.getElementById("modal-close-button");

    // Close modal when clicking the close icon (×)
    if (closeIcon) {
      closeIcon.addEventListener("click", function () {
        modal.classList.remove("show");
      });
    }

    // Close modal when clicking the "Close" button
    if (closeButton) {
      closeButton.addEventListener("click", function () {
        modal.classList.remove("show");
      });
    }
  });
  
 const newModal = document.getElementById('newTicketModal');
const openNewBtn = document.getElementById('openNewTicketModal');

openNewBtn.addEventListener('click', function () {
  // Clear the form fields
  document.getElementById("ticketForm").reset();

  // Reset to 'create' mode
  document.getElementById("form-mode").value = "create";
  document.getElementById("edit-ticket-id").value = "";

  // Reset modal title and button text (optional)
  document.querySelector("#newTicketModal h3").textContent = "Create New Ticket";
  document.querySelector("#ticketForm .submit-button").textContent = "Submit Ticket";

  // Show the modal
  newModal.classList.add('show');
});

  function hideNewTicketModal() {
    newModal.classList.remove('show');
  }



 