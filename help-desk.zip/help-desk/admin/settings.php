<?php 
session_start();
require_once __DIR__ . '/../settings/init.php';
requireLogin();
requireAdmin();
$errors = $_SESSION['errors'] ?? [];
$old = $_SESSION['old'] ?? [];
unset($_SESSION['errors'], $_SESSION['old']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>User Management</title>
  <link rel="stylesheet" href="../styles/settings.css" />
  <link rel="stylesheet" href="../styles/model.css" />
  <link rel="stylesheet" href="../styles/style.css" />
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f4f6f8;
      margin: 0;
      padding: 0; 
      
    }
.sele {
   width: 100%;max-width: 100%; box-sizing: border-box;
  padding: 10px 12px;
  margin: 10px 0;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 14px;
}
    
  </style>
</head>
<body>

<header class="page-header">
  <div class="header-content">
    <a style="text-decoration: none;" href="<?= ROOT ?>admin/">
      <h2 class="page-title" style="color:#fff;text-decoration: none;">Back To Admin</h2>
    </a>
    
    <div class="header-links">
      <?php if (isAdmin()): ?>
        <a href="<?= ROOT ?>admin/settings.php" class="header-link">Settings</a>
       
      <?php endif; ?>
      <a href="<?= ROOT ?>user/logout.php" class="header-link logout-link">Logout</a>
    </div>
  </div>
</header>

<div class="container">
  <div class="table-header">
    <input type="text" id="searchInput" placeholder="Search users..." />
    <button id="addUserBtn" onclick="openAddUserModal()">+ Add User</button>
    
  </div>

  <table>
    <thead>
      <tr>
        <th>S/N</th>
        <th>Name</th>
        <th>Lastname</th>
        <th>Roles</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody id="user-table-body">
      <!-- User rows will go here via JS or PHP -->
    </tbody>
  </table>
  <div id="pagination-container"></div>
</div>

<!-- Edit Modal -->
<div id="editModal">
  <div class="modal-content">
    <h3>Edit User</h3>
    <input type="hidden" id="editId">
    <input type="text" id="editName" placeholder="Name">
    <input type="text" id="editlastName" placeholder="lastName">
    <input type="email" id="editEmail" placeholder="Email">
    <input type="text" id="editPhone" placeholder="Phone">
<select id="editRole" class="sele">
  <option value="1">Admin</option>
  <option value="2">User</option>
</select>

    <input type="password" id="editPassword" placeholder="New Password (optional)">
    <button onclick="submitEdit()">Save</button>
    <button onclick="closeModal()">Cancel</button>
  </div>
</div>

<!-- Add Modal -->
<div id="addModal">
  <div class="modal-content">
    <h3>Add New User</h3>
    <input type="text" id="addName" placeholder="Name">
    <input type="text" id="lastName" placeholder="lastName">
    <input type="email" id="addEmail" placeholder="Email">
    <input type="number" id="addPhone" placeholder="Phone">
    <select id="addRole" class="sele">
      <option value="">Select Roles</option>
  <option value="1">Admin</option>
  <option value="2">User</option>
</select>
    <input type="password" id="addPassword" placeholder="Password">
    <button onclick="submitAdd()">Add</button>
    <button onclick="closeAddModal()">Cancel</button>
  </div>
</div>

<script>
  function openAddUserModal() {
    document.getElementById("addModal").style.display = "block";
  }

  function closeAddModal() {
  document.getElementById("addModal").style.display = "none";

  // Optionally clear the form after closing
  document.getElementById("addName").value = "";
  document.getElementById("addRole").value = "";
  document.getElementById("lastName").value = "";
  document.getElementById("addEmail").value = "";
  document.getElementById("addPhone").value = "";
  document.getElementById("addPassword").value = "";
}


  function closeModal() {
    document.getElementById("editModal").style.display = "none";
  }

   let lastAction = "users", lastExtraData = {}, currentPage = 1;

    function send_data(data_type = "users", extraData = {}, page = 1) {
  console.log("Sending request for page:", page);
  lastAction = data_type;
  lastExtraData = extraData;
  currentPage = page;

  const ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function () {
    if (ajax.readyState === 4 && ajax.status === 200) {
      if (ajax.responseText.trim() !== "") {
        handle_result(ajax.responseText, data_type);
      }
    }
  };

  const payload = {
    data_type: data_type,
    page: page,
    ...extraData
  };

  ajax.open("POST", "<?=ROOT?>admin/settings_pro.php", true);
  ajax.setRequestHeader("Content-Type", "application/json");
  ajax.send(JSON.stringify(payload));
}

  function handle_result(result, data_type) {
 //   console.log(result);
    const obj = JSON.parse(result);

    // Ignore mismatched data_type
    if (obj.data_type !== data_type) return;

    if (data_type === "users") {
        // Update user table and pagination
        document.getElementById("user-table-body").innerHTML = obj.html;
        renderPagination(obj.pagination);
    }

    if (data_type === "add_user") {
        // Show success or error message after adding user
        if (obj.status === "success") {
            alert(obj.message);
            // Optionally refresh the user list
            send_data({ data_type: "users", page: 1 });
        } else {
            alert("Error: " + obj.message);
        }
    }
    if (data_type === "update_user") {
        // Show success or error message after adding user
        if (obj.status === "success") {
            alert(obj.message);
            // Optionally refresh the user list
            send_data({ data_type: "users", page: 1 });
        } else {
            alert("Error: " + obj.message);
        }
    }
    if (data_type === "delete_user") {
        // Show success or error message after adding user
        if (obj.status === "success") {
            alert(obj.message);
            // Optionally refresh the user list
            send_data({ data_type: "users", page: 1 });
        } else {
            alert("Error: " + obj.message);
        }
    }

    // You can add more handlers like "delete_user", "update_user", etc.
}


   function openModal(user) {
  document.getElementById("editId").value = user.id;
  document.getElementById("editName").value = user.name;
  document.getElementById("editlastName").value = user.last_name;
  document.getElementById("editEmail").value = user.email;
  document.getElementById("editPhone").value = user.phone;
  document.getElementById("editPassword").value = "";
  document.getElementById("editRole").value = user.roles; // Set selected role

  document.getElementById("editModal").style.display = "flex";
}

    function closeModal() {
      document.getElementById("editModal").style.display = "none";
    }

    function submitEdit() {
  const id = document.getElementById("editId").value;
  const name = document.getElementById("editName").value;
  const lastname = document.getElementById("editlastName").value;
  const email = document.getElementById("editEmail").value;
  const phone = document.getElementById("editPhone").value;
  const password = document.getElementById("editPassword").value;
  const roles = document.getElementById("editRole").value;

  const ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function () {
    if (ajax.readyState === 4 && ajax.status === 200) {
      closeModal();
      send_data("users", lastExtraData, currentPage);
    }
  };

  ajax.open("POST", "<?= ROOT ?>admin/settings_pro.php", true);
  ajax.setRequestHeader("Content-Type", "application/json");
  ajax.send(JSON.stringify({
    data_type: "update_user",
    id, name, lastname, email, phone, password, roles
  }));
}


function submitAdd() {
  const name = document.getElementById("addName").value;
  const lastname = document.getElementById("lastName").value;
  const email = document.getElementById("addEmail").value;
  const phone = document.getElementById("addPhone").value;
  const password = document.getElementById("addPassword").value;
  const roles = document.getElementById("addRole").value;

  const ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function () {
    if (ajax.readyState === 4 && ajax.status === 200) {
      const res = JSON.parse(ajax.responseText);
      if (res.status === "success") {
        closeAddModal();
        send_data("users", lastExtraData, currentPage);
      } else {
        let msg = res.message;
        if (res.errors) {
          msg += "\n" + Object.values(res.errors).join("\n");
        }
        alert(msg);
      }
    }
  };

  ajax.open("POST", "<?= ROOT ?>admin/settings_pro.php", true);
  ajax.setRequestHeader("Content-Type", "application/json");
  ajax.send(JSON.stringify({
    data_type: "add_user",
    name, lastname, email, phone, password, roles
  }));
}



    document.getElementById("searchInput").addEventListener("input", function () {
      send_data("users", { search: this.value }, 1);
    });

    window.onload = function () {
      send_data();
    };

      function deleteUser(id) {
    if (!confirm("Are you sure you want to delete this user?")) return;

    const ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function () {
      if (ajax.readyState === 4 && ajax.status === 200) {
        const res = JSON.parse(ajax.responseText);
        if (res.data_type === "delete_user" && res.status === "success") {
          send_data("users", lastExtraData, currentPage);
        } else {
          alert("Delete failed");
        }
      }
    };

    ajax.open("POST", "<?= ROOT ?>admin/settings_pro.php", true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify({
      data_type: "delete_user",
      id: id
    }));
  }
    // === PAGINATION RENDERING ===
  function renderPagination(pager) {
    const pagination = document.getElementById("pagination-container");
    pagination.innerHTML = "";

    if (!pager || pager.total_links < 2) return;

    if (pager.current > 1) {
      const prev = document.createElement("button");
      prev.textContent = "Previous";
      prev.onclick = () => send_data(lastAction, lastExtraData, pager.current - 1);
      pagination.appendChild(prev);
    }

    for (let i = pager.total_start; i <= pager.total_end; i++) {
      const btn = document.createElement("button");
      btn.textContent = i;
      btn.className = "page-link";
      if (i === pager.current) btn.classList.add("active");
      btn.onclick = () => send_data(lastAction, lastExtraData, i);
      pagination.appendChild(btn);
    }

    if (pager.current < pager.total_end) {
      const next = document.createElement("button");
      next.textContent = "Next";
      next.onclick = () => send_data(lastAction, lastExtraData, pager.current + 1);
      pagination.appendChild(next);
    }
  }

</script>

</body>
</html>
