<?php 
session_start();
require_once __DIR__ . '/../settings/init.php';
//requireLogin();
$errors = $_SESSION['errors'] ?? [];
$old = $_SESSION['old'] ?? [];
unset($_SESSION['errors'], $_SESSION['old']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Support Tickets</title>


  <link rel="stylesheet" href="../styles/comment.css" />
  <link rel="stylesheet" href="../styles/style.css" />
  <style>
/* -------------- Table Styles (your original) -------------- */
/* Table Styles */
/* Pagination container styles */
/* Search box styles */
.top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 20px;
      background-color: #f6f6f6;
      border-bottom: 1px solid #ccc;
      flex-wrap: wrap;
      gap: 15px;
      margin: 20px 0;
    }

    .user-summary {
      font-size: 16px;
      font-weight: bold;
      white-space: nowrap;
    }

    .controls {
      display: flex;
      align-items: center;
      gap: 10px;
    }

   #ticket-summary {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  align-items: stretch;
  margin-top: 10px;
}

.summary-card {
  background-color: #ffffff;
  padding: 15px 50px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  min-width: 160px;
  flex: 1 1 160px;
  border:1px solid #00ee;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.summary-heading {
  font-size: 14px;
  font-weight: 600;
  color: #555;
  margin-bottom: 5px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.summary-value {
  font-size: 20px;
  font-weight: bold;
  color: #333;
}


  </style>
</head>
<body>
  
<header class="page-header">
  <div class="header-content">
    <h2 class="page-title">
       <?php if (isAdmin()): ?>
       HELP DESK ADMIN
        
      <?php else: ?>
       HELP DESK USER
       <?php endif; ?>
    </h2>
    <div class="header-links">
          <input type="text" placeholder="Search Tickets" id="ticket-search" />
      <?php if (isAdmin()): ?>
        <a href="<?= ROOT ?>admin/settings.php" class="header-link">Settings</a>
        
      <?php endif; ?>
      <a href="<?= ROOT ?>user/logout.php" class="header-link logout-link">Logout</a>
    </div>
  </div>
</header>
  <div class="content-wrappers">
  

 <div class="top-bar">
    <div id="ticket-summary" class="user-summary"></div>
    <div class="controls">
  
      <!-- <button id="add-ticket">Add New Tkt</button> -->


 <?php if (!isAdmin()): ?>
       <button id="openNewTicketModal" style="margin: 1px 10px 10px 10px; padding: 10px 15px; background-color: #28a745; color: white; border: none; border-radius: 6px; cursor: pointer;">
    + Add New Ticket
  </button>
   <?php endif; ?>
    </div>
  </div>

<div class="filters" style="margin-bottom: 15px; display: flex; gap: 10px;">
  <select id="filter-priority" style="padding: 10px; width: 180px; font-size: 14px;">
    <option value="">All Priorities</option>
    <option value="low">Low</option>
    <option value="medium">Medium</option>
    <option value="high">High</option>
  </select>

  <select id="filter-status" style="padding: 10px; width: 180px; font-size: 14px;">
    <option value="">All Status</option>
    <option value="open">Open</option>
    <option value="pending">Pending</option>
    <option value="closed">Closed</option>
  </select>
</div>


<div style="max-height: 500px; overflow-y: auto; border: 1px solid #ddd;">
  <table id="ticket_table" style="width: 100%; table-layout: fixed; border-collapse: collapse;">
    <thead>
      <tr style="background-color: #007bff; color: white; position: sticky; top: 0; z-index: 1;">
        <th style="width: 8%;">S/N</th>
        <th style="width: 12%;">Date</th>
        <th style="width: 12%;">Time</th>
        <th style="width: 13%;">Ticket No</th>
        <th style="width: 10%;">Priority</th>
        <th style="width: 10%;">Status</th>
        <th style="width: 20%;">Ticket Summary</th>
        <th style="width: 15%;">Action</th>
      </tr>
    </thead>
    <tbody id="tickets-container">
      <!-- Rows inserted via JS -->
    </tbody>
  </table>
</div>


  <div style="margin-bottom:20px;" id="pagination-container"></div>
<!-- Ticket Modal (ONE modal only) -->
<div id="ticketModal" class="ticket-modal" style="display: none;">
  <div class="ticket-modal-content">
    <span class="ticket-modal-close" onclick="hideTicketModal()">&times;</span>
    <h2 class="modal-title">Ticket Information</h2>
    <div id="modalTicketComments" class="comment-section">
      <!-- Dynamic content inserted here -->
    </div>
  </div>
 </div>

<!-- Ticket Reply Modal -->
<div id="modal" class="ticket-modal">
  <div class="ticket-modal-content">
    <span id="modal-close-icon" class="ticket-modal-close">&times;</span>
<!-- New header section goes here -->
<div id="modal-header-section"></div>

    <form action="<?=ROOT?>admin/admin.php" method="post">
      <input type="hidden" id="id_s" name="tick_id" />

      <div class="form-group">
        <label for="user-email">User Email</label>
        <input type="email" id="user-email" name="user_email" disabled />
      </div>

      <div class="form-group">
        <label for="ticket-title">Ticket Summary</label>
        <input type="text" id="ticket-title" name="ticket_title" disabled />
      </div>

      <div class="form-group">
  <label for="ticket-status">Status</label>
<select id="ticket-status" name="ticket_status">
  <option value="Open">Open</option>
  <option value="Pending">Pending</option>
  <option value="Closed">Closed</option>
</select>

</div>

      <div class="form-group">
        <label for="ticket-comments">Comments</label>
        <textarea
          id="ticket-comments"
          name="ticket_comments"
          placeholder="Type ticket resolution here..."
          required
        ></textarea>
      </div>

      <div class="modal-buttons">
  <button type="submit" class="submit-button" name="submit" value="form1">Submit</button>
  <!-- <button type="button" class="close-button" onclick="document.getElementById('modal').classList.remove('show')">Close</button> -->

<button type="button" class="close-button" id="modal-close-button">Close</button>
</div>

    </form>
  </div>
</div>
</div>
<!-- New Ticket Modal -->
<div id="newTicketModal" class="ticket-modal">
  <div class="ticket-modal-content">
    <span class="ticket-modal-close" onclick="hideNewTicketModal()">&times;</span>
    <h3>Create New Ticket</h3>

    <form action="<?=ROOT?>admin/admin.php" method="post">
      <div class="form-group">
        <label for="new-title">Ticket Summary</label>
        <input type="text" id="new-title" name="title" required />
      </div>

      <div class="form-group">
        <label for="new-desc">Description</label>
        <textarea id="new-desc" name="description" required></textarea>
      </div>

      <div class="form-group">
        <label for="new-priority">Priority</label>
        <select id="new-priority" name="priority" required>
          <option value="Low">Low</option>
          <option value="Medium">Medium</option>
          <option value="High">High</option>
        </select>
      </div>

      <button type="submit" class="submit-button" name="submit" value="form2">Submit Ticket</button>
    </form>
  </div>
</div>

  <!-- JavaScript -->
 <script>
  let ticketsData = [];
  let currentPage = 1;
  const colors = ["orange", "blue", "green"];
  let lastAction = "";
  let lastExtraData = {};

  const ticketsContainer = document.getElementById("tickets-container");
  const modal = document.getElementById("modal");
  const ticketNumber = document.getElementById("ticket-number");
  const modalTitle = document.getElementById("modal-title");
  const modalDescription = document.getElementById("modal-description");
  const modalCloseBtn = document.querySelector(".close-button");

  // === MAIN AJAX HANDLER ===
  function send_data(data_type = "fetch_tickets", extraData = {}, page = 1) {
    lastAction = data_type;
    lastExtraData = extraData;
    currentPage = page;

    const ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function () {
      if (ajax.readyState === 4 && ajax.status === 200) {
        if (ajax.responseText.trim() !== "") {
          handle_result(ajax.responseText, data_type);
        }
      }
    };

    const payload = {
      data_type: data_type,
      page: page,
      ...extraData,
    };
    ajax.open("POST", "<?=ROOT?>admin/admin.php", true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify(payload));
  }

// function handle_result(result, data_type) {
//  // console.log(result);
//   const obj = JSON.parse(result);
//   if (obj.data_type !== data_type) return;

//   if (data_type === "fetch_tickets" || data_type === "search_tickets") {
//     ticketsData = obj.data || [];
//     renderTickets();
//     renderPagination(obj.pagination);
//     renderSummary(obj.summary); // ✅ Use `obj`, not `response`
//   }
// }

function handle_result(result, data_type) {
  const obj = JSON.parse(result);
  if (obj.data_type !== data_type) return;

  if (data_type === "fetch_tickets" || data_type === "search_tickets") {
    ticketsData = obj.data || [];
    const currentPage = obj.pagination?.currentPage || 1;
    const itemsPerPage = obj.pagination?.itemsPerPage || 10;

    renderTickets(currentPage, itemsPerPage);
    renderPagination(obj.pagination);
    renderSummary(obj.summary);
  }
}

</script>
 <script src="../scripts/admin.js"></script>

</body>
</html>
