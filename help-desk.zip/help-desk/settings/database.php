<?php

$GLOBALS['DB_STATE'] = [
    'affected_rows'   => 0,
    'insert_id'       => 0,
    'error'           => '',
    'has_error'       => false,
    'query_id'        => '',
    'table_schema'    => DB_NAME,
    'missing_tables'  => [],
];

/**
 * Establish a PDO connection to the database
 *
 * @return PDO
 */
// function db_connect()
// {
//     try {
//         $dsn = DB_DRIVER . ":host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
//         $pdo = new PDO($dsn, DB_USER, DB_PASSWORD);
//         $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//         return $pdo;
//     } catch (PDOException $e) {
//         die("DB connection failed: " . $e->getMessage());
//     }
// }
function db_connect()
{
    try {
        $dsn = DB_DRIVER . ":host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $pdo = new PDO($dsn, DB_USER, DB_PASSWORD);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // ✅ Set MySQL timezone to your local time
        $pdo->exec("SET time_zone = '+01:00'"); // Use your actual timezone offset here

        return $pdo;
    } catch (PDOException $e) {
        die("DB connection failed: " . $e->getMessage());
    }
}
/**
 * Execute a query (SELECT, INSERT, UPDATE, DELETE)
 *
 * @param string $query
 * @param array $data
 * @param string $data_type 'object' or 'assoc'
 * @return array|false
 */
function db_query(string $query, array $data = [], string $data_type = 'object')
{
    $GLOBALS['DB_STATE']['error'] = '';
    $GLOBALS['DB_STATE']['has_error'] = false;
    $GLOBALS['DB_STATE']['affected_rows'] = 0;
    $GLOBALS['DB_STATE']['insert_id'] = 0;

    $con = db_connect();

    try {
        $stm = $con->prepare($query);

        $is_named = false;
        if (!empty($data)) {
            $first_key = array_key_first($data);
            $is_named = is_string($first_key);
        }

        // Bind parameters
        if ($is_named) {
            foreach ($data as $key => $value) {
                $type = PDO::PARAM_STR;
                if (is_int($value)) $type = PDO::PARAM_INT;
                elseif (is_bool($value)) $type = PDO::PARAM_BOOL;
                elseif (is_null($value)) $type = PDO::PARAM_NULL;

                if (strpos($key, ':') !== 0) {
                    $key = ':' . $key;
                }

                $stm->bindValue($key, $value, $type);
            }
        } else {
            foreach (array_values($data) as $index => $value) {
                $type = PDO::PARAM_STR;
                if (is_int($value)) $type = PDO::PARAM_INT;
                elseif (is_bool($value)) $type = PDO::PARAM_BOOL;
                elseif (is_null($value)) $type = PDO::PARAM_NULL;

                $stm->bindValue($index + 1, $value, $type); // 1-based index for positional params
            }
        }

        $stm->execute();

        $GLOBALS['DB_STATE']['affected_rows'] = $stm->rowCount();
        $GLOBALS['DB_STATE']['insert_id'] = $con->lastInsertId();

        if (stripos(trim($query), 'SELECT') === 0) {
            return $data_type === 'object'
                ? $stm->fetchAll(PDO::FETCH_OBJ)
                : $stm->fetchAll(PDO::FETCH_ASSOC);
        }

        return true;

    } catch (PDOException $e) {
        $GLOBALS['DB_STATE']['error'] = $e->getMessage();
        $GLOBALS['DB_STATE']['has_error'] = true;
        return false;
    }
}




/**
 * Get a single row result from the database
 *
 * @param string $query
 * @param array $data
 * @param string $data_type
 * @return mixed
 */
function db_get_row(string $query, array $data = [], string $data_type = 'object')
{
    $result = db_query($query, $data, $data_type);
    return ($result && count($result)) ? $result[0] : false;
}

function db_get_column(string $query, array $params = [])
{
    $result = db_query($query, $params, 'assoc');
    return ($result && isset($result[0])) ? array_values($result[0])[0] : null;
}
