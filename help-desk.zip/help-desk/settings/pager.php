<?php
function paginate(int $total_rows, int $limit = 10, int $page_number = 1, int $extras = 1): array
{
    $page_number = max((int)$page_number, 1);

    $total_pages = max(ceil($total_rows / $limit), 1);

    $start = max($page_number - $extras, 1);
    $end = min($page_number + $extras, $total_pages);
    $offset = ($page_number - 1) * $limit;

    return [
        'offset' => $offset,
        'limit' => $limit,
        'page_number' => $page_number,
        'start' => $start,
        'end' => $end,
        'total_pages' => $total_pages,
    ];
}

function display_pagination(array $pager): void
{
    if ($pager['total_pages'] <= 1) return; // No pagination needed

    echo '<nav aria-label="Page navigation example">';
    echo '<ul class="pagination">';

    echo '<li class="page-item"><a class="page-link" href="' . $pager['links']['first'] . '">First</a></li>';

    for ($x = $pager['start']; $x <= $pager['end']; $x++) {
        $active = $x == $pager['page_number'] ? 'active' : '';
        $link = preg_replace("/page=[0-9]+/", "page=" . $x, $pager['links']['current']);
        echo '<li class="page-item ' . $active . '"><a class="page-link" href="' . $link . '">' . $x . '</a></li>';
    }

    // Only show "Next" if we're not on the last page
    if ($pager['page_number'] < $pager['total_pages']) {
        echo '<li class="page-item"><a class="page-link" href="' . $pager['links']['next'] . '">Next</a></li>';
    }

    echo '</ul>';
    echo '</nav>';
}

?>