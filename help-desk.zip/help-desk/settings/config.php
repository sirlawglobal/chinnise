<?php 

if($_SERVER['SERVER_NAME'] == 'localhost')
{
	/** database config **/
	define('DB_NAME', 'my_db');
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASSWORD', '');
	define('DB_DRIVER', 'mysql');
	
	define('ROOT', 'http://localhost/help-desk/');

}else
{
	/** database config **/
	define('DB_NAME', 'dgn128_helpdesk');
	define('DB_HOST', 'localhost');
	define('DB_USER', 'dgn128_user');
	define('DB_PASSWORD', 'uBpOR2C1K[m$');
	define('DB_DRIVER', 'mysql');

	define('ROOT', 'http://dgn128.pro/help-desk/');

}

define('APP_NAME', "Help");
define('APP_DESC', "Best website on the planet");

/** true means show errors **/
define('DEBUG', true);