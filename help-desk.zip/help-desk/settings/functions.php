<?php
function redirect($url)
{
	header("Location: ". ROOT . $url);
	die;
}
function generate_ticket_code($id) {
    $year = date('Y'); // current year
    return sprintf('%s-CSI%02d', $year, $id); // pads ID to 2 digits
}

function validate_ticket_datas(array $data, array &$errors): bool
{
    // if (empty($data['email'])) {
    //     $errors['email'] = "Email is required";
    // } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
    //     $errors['email'] = "Invalid email format";
    // }

    if (empty($data['title'])) {
        $errors['title'] = "Title is required";
    }

    if (empty($data['priority'])) {
        $errors['priority'] = "Priority is required";
    }

    if (empty($data['description'])) {
        $errors['description'] = "Description is required";
    }

    return empty($errors);
}



function validate_ticket(array $data, array &$errors): bool
{
    //var_dump($data);die;
   
    if (empty($data['comments'])) {
        $errors['comments'] = 'Ticket_comments is required';
    }

    return empty($errors);
}


function validate_user_signup(array $data, array &$errors): bool
{ 
    //var_dump($data['token']);die;
   // var_dump(db_get_row("SELECT name FROM token WHERE name = :token LIMIT 1", ['token' => $data['token']]));die;
    
    // Validate email
    if (empty($data['email'])) {
        $errors['email'] = 'Email is required';
    } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    } elseif (db_get_row("SELECT id FROM users WHERE email = :email LIMIT 1", ['email' => $data['email']])) {
        $errors['email'] = 'Email is already in use';
    }
  if (empty($data['name'])) {
        $errors['name'] = 'Name is required';
    }
 // Validate phone number (Nigerian format example)
    $cleaned = preg_replace('/[\s\-\(\)]/', '', $data['phone']);
    if (empty($data['phone'])) {
        $errors['phone'] = 'Phone number is required';
    } else
    if (!preg_match('/^\+?[0-9]{10,15}$/', $cleaned)) {
        $errors['phone'] = 'Invalid  phone number';
    }
    // if (!preg_match('/^[A-Za-z]{2,}[A-Za-z0-9]{6}$/', $data['token'])) {
    //     $errors['token'] = 'The Token must start with at least two letters followed by exactly six letters or digits.';
    // }elseif (!db_get_row("SELECT name FROM token WHERE name = :token LIMIT 1", ['token' => $data['token']])) {
    //     $errors['token'] = 'You are not an admin please sorry';
    // }
    // Validate password
    if (empty($data['password'])) {
        $errors['password'] = 'Password is required';
    } elseif (strlen($data['password']) < 6) {
        $errors['password'] = 'Password must be at least 6 characters long';
    } elseif (!preg_match("/[A-Z]/", $data['password']) || !preg_match("/[0-9]/", $data['password'])) {
        $errors['password'] = 'Password must contain at least one uppercase letter and one number';
    }

    return empty($errors);
}

function isLoggedIn()
{
    return isset($_SESSION['user']);
}


function requireLogin($redirectTo = 'user/login.php')
{
    if (!isLoggedIn()) {
        $_SESSION['fail'] = "You must log in to access this page.";
        redirect($redirectTo);
        exit;
    }
}
function isAdmin()
{
    return isset($_SESSION['user']) && $_SESSION['user']['roles'] == 1;
}
function requireAdmin($redirectTo = 'user/login.php')
{
    if (!isAdmin()) {
        $_SESSION['fail'] = "Access denied. Admins only.";
        redirect($redirectTo);
        exit;
    }
}

