<?php
date_default_timezone_set('Africa/Lagos');
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/pager.php';
