<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);

// echo 1;
session_start();
require_once __DIR__ . '/../settings/init.php';
requireLogin();
$errors = $_SESSION['errors'] ?? [];
$old = $_SESSION['old'] ?? [];
unset($_SESSION['errors'], $_SESSION['old']);
?>

 <!--1224 -->
 <!-- admin@admin -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Support Tickets</title>
  <link rel="stylesheet" href="../styles/comment.css" />
  <link rel="stylesheet" href="../styles/style.css" />
  <style>
  .submits{background-color:rgb(31, 225, 183);
  color: white;
  border: none;
  padding: 10px 14px;
  font-size: 14px;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;}

   #ticket-summary {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  align-items: stretch;
  margin-top: 10px;
}

.summary-card {
  background-color: #ffffff;
  padding: 15px 50px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  min-width: 160px;
  flex: 1 1 160px;
  border:1px solid #00ee;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.summary-heading {
  font-size: 14px;
  font-weight: 600;
  color: #555;
  margin-bottom: 5px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.summary-value {
  font-size: 20px;
  font-weight: bold;
  color: #333;
}
.top-bar {
  display: flex;
  justify-content: space-between;
  align-items: flex-start; /* fix vertical alignment issue */
  padding: 10px 20px;
  background-color: #f6f6f6;
  border-bottom: 1px solid #ccc;
  flex-wrap: wrap;
  gap: 15px;
  margin: 20px 0;
}

#ticket-summary {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  align-items: stretch;
  flex-grow: 1; /* allow it to grow but not push controls */
}

.controls {
  margin-left: auto; /* forces it to the far right */
  display: flex;
  align-items: center;
}

.add-ticket-btn {
  padding: 10px 15px;
  background-color: #28a745;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: bold;
}


</style>
</head>
<body>
  
<header class="page-header">
  <div class="header-content">
    <h2 class="page-title">
       <?php if (isAdmin()): ?>
       HELP DESK ADMIN
      <?php else: ?>
       HELP DESK USER
       <?php endif; ?>
    </h2>
    <div class="header-links">
          <input type="text" placeholder="Search Tickets" id="ticket-search" />
      <?php if (isAdmin()): ?>
        <a href="<?= ROOT ?>admin/settings.php" class="header-link">Settings</a>
      <?php endif; ?>
      <a href="logout.php" class="header-link logout-link">Logout</a>
    </div>
  </div>
</header>
<div class="content-wrappers">
  <?php if(isset($_SESSION["success"])):?>
    <div class="custom-alert success"><?=$_SESSION["success"]?><?php unset($_SESSION["success"]);?></div>
  <?php endif?>
  <?php if(isset($_SESSION["fail"])):?>
    <div class="custom-alert error"><?=$_SESSION["fail"]?><?php unset($_SESSION["fail"]);?></div>
  <?php endif?>
<div class="top-bar">
  <div id="ticket-summary"></div>
  <div class="controls">
    <button id="openNewTicketModal" class="add-ticket-btn">+ Add New Ticket</button>
  </div>
</div>


  <?php if (isAdmin()): ?>
  <div class="filters" style="margin-bottom: 15px; display: flex; gap: 10px;">
    <select id="filter-priority" style="padding: 10px; width: 180px; font-size: 14px;">
      <option value="">All Priorities</option>
      <option value="low">Low</option>
      <option value="medium">Medium</option>
      <option value="high">High</option>
    </select>

    <select id="filter-status" style="padding: 10px; width: 180px; font-size: 14px;">
      <option value="">All Status</option>
      <option value="open">Open</option>
      <option value="pending">Pending</option>
      <option value="closed">Closed</option>
    </select>
  </div>
  <?php endif; ?>

  
<div style="max-height: 500px; overflow-y: auto; border: 1px solid #ddd;">
  <table id="ticket_table" style="width: 100%; table-layout: fixed; border-collapse: collapse;">
    <thead>
      <tr style="background-color: #007bff; color: white; position: sticky; top: 0; z-index: 1;">
        <th style="width: 8%;">S/N</th>
        <th style="width: 12%;">Date</th>
        <th style="width: 12%;">Time</th>
        <th style="width: 13%;">Ticket No</th>
        <th style="width: 10%;">Priority</th>
        <th style="width: 10%;">Status</th>
        <th style="width: 20%;">Ticket Summary</th>
        <th style="width: 15%;">Action</th>
      </tr>
    </thead>
    <tbody id="tickets-container">
       Rows inserted via JS 
    </tbody>
  </table>
</div>





  <div style="margin-bottom:20px;" id="pagination-container"></div>
      </div>
 Ticket Modal 
<div id="ticketModal" class="ticket-modal" style="display: none;">
  <div class="ticket-modal-content">
    <span class="ticket-modal-close" onclick="hideTicketModal()">&times;</span>
    <h2 class="modal-title">Ticket Information</h2>
    <div id="modalTicketComments" class="comment-section">
       Dynamic content inserted here 
    </div>
  </div>
</div>
   Ticket Reply Modal 
  <div id="modal" class="ticket-modal">
  <div class="ticket-modal-content">
    <span id="modal-close-icon" class="ticket-modal-close">&times;</span>
 New header section goes here 
<div id="modal-header-section"></div>
  <form action="<?=ROOT?>user/user.php" method="post">
        <input type="hidden" id="id_s" name="tick_id" />
        <div class="form-group">
          <label for="user-email">User Email</label>
          <input type="email" id="user-email" name="user_email" disabled />
        </div>
        <div class="form-group">
          <label for="ticket-title">Ticket Summary</label>
          <input type="text" id="ticket-title" name="ticket_title" disabled />
        </div>
        <div class="form-group">
          <label for="ticket-status">Status</label>
          <input type="text" id="ticket-status" name="ticket_status" disabled />
        </div>
        <div class="form-group">
          <label for="ticket-comments">Comments</label>
          <textarea id="ticket-comments" name="ticket_comments" placeholder="Type ticket resolution here..." required></textarea>
        </div>


<input type="hidden" id="editMode" value="">
<input type="hidden" id="editIndex" value="">

        <div class="modal-buttons">
          <button type="submit" class="submit-button" name="submit" value="form1">Submit</button>
          <button type="button" class="close-button" id="modal-close-button">Close</button>
        </div>
      </form>
    </div>
  </div>

   New Ticket Modal 
  <div id="newTicketModal" class="ticket-modal">
    <div class="ticket-modal-content">
      <span class="ticket-modal-close" onclick="hideNewTicketModal()">&times;</span>
      <h3>Create New Ticket</h3>
      <form id="ticketForm" action="<?=ROOT?>user/user.php" method="post">
  <input type="hidden" id="edit-ticket-id" name="ticket_id" value="" />
  <input type="hidden" name="form_mode" id="form-mode" value="create" />

  <div class="form-group">
    <label for="new-title">Ticket Summary</label>
    <input type="text" id="new-title" name="title" required />
  </div>
  <div class="form-group">
    <label for="new-desc">Description</label>
    <textarea id="new-desc" name="description" required></textarea>
  </div>
  <div class="form-group">
    <label for="new-priority">Priority</label>
    <select id="new-priority" name="priority" required>
      <option value="Low">Low</option>
      <option value="Medium">Medium</option>
      <option value="High">High</option>
    </select>
  </div>
<div style="  display: flex;
  
  "></div>
<button type="submit" class="submit-button"   name="submit" value="form2">Submit Ticket</button>
 <button type="button" class="submits" style="margin-left:80%"  onclick="triggerCommentModal()">Add Comment</button>  


<button
  type="button"
  class="submits"
  id="add-comment-button"
  style="margin-left:80%; display: none;"
  onclick="triggerCommentModal()"> Add Comment
</button>
</form>

    </div>
  </div>
</div>

 <script>
  let ticketsData = [];
  let currentPage = 1;
  const colors = ["orange", "blue", "green"];
  let lastAction = "";
  let lastExtraData = {};


  const ticketsContainer = document.getElementById("tickets-container");
  const modal = document.getElementById("modal");
  const ticketNumber = document.getElementById("ticket-number");
  const modalTitle = document.getElementById("modal-title");
  const modalDescription = document.getElementById("modal-description");
  const modalCloseBtn = document.querySelector(".close-button");

  // === MAIN AJAX HANDLER ===
  function send_data(data_type = "fetch_tickets", extraData = {}, page = 1) {
    lastAction = data_type;
    lastExtraData = extraData;
    currentPage = page;

    const ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function () {
      if (ajax.readyState === 4 && ajax.status === 200) {
        if (ajax.responseText.trim() !== "") {
          // console.log(ajax.responseText, data_type);
          handle_result(ajax.responseText, data_type);
        }
      }
    };

    const payload = {
      data_type: data_type,
      page: page,
      ...extraData,
    };

    ajax.open("POST", "<?=ROOT?>user/user.php", true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify(payload));
  }

function handle_result(result, data_type) {
  //console.log(data_type);
  const obj = JSON.parse(result);
  if (obj.data_type !== data_type) return;

  if (data_type === "fetch_tickets" || data_type === "search_tickets") {
  ticketsData = obj.data || [];
    const currentPage = obj.pagination?.currentPage || 1;
    const itemsPerPage = obj.pagination?.itemsPerPage || 10;

    renderTickets(currentPage, itemsPerPage);
    renderPagination(obj.pagination);
    renderSummary(obj.summary);
  }

  if (data_type === "delete_ticket") {
    console.log(obj.message);
  if (obj.success) {
    alert(obj.message); // Or use your own toast/snackbar
    send_data("fetch_tickets");
  } else {
    alert("Error: " + (obj.message || "Could not delete."));
  }
}

}





// function handle_result(result, data_type) {
//   const obj = JSON.parse(result);
//   if (obj.data_type !== data_type) return;

//   if (data_type === "fetch_tickets" || data_type === "search_tickets") {
//     ticketsData = obj.data || [];
//     const currentPage = obj.pagination?.currentPage || 1;
//     const itemsPerPage = obj.pagination?.itemsPerPage || 10;

//     renderTickets(currentPage, itemsPerPage);
//     renderPagination(obj.pagination);
//     renderSummary(obj.summary);
//   }
// }

let currentEditingTicket = null;
function editTicket(ticket) {
  currentEditingTicket = ticket;

  document.getElementById("form-mode").value = "edit";
  document.getElementById("edit-ticket-id").value = ticket.id || "";
  document.getElementById("new-title").value = ticket.title || "";
  document.getElementById("new-desc").value = ticket.description || "";
  document.getElementById("new-priority").value = ticket.priority || "Low";

  document.querySelector("#newTicketModal h3").textContent = "Edit Ticket";
  document.querySelector("#ticketForm .submit-button").textContent = "Update Ticket";

  // ✅ Show "Add Comment" only in edit mode
  document.getElementById("add-comment-button").style.display = "inline-block";

  document.getElementById("newTicketModal").classList.add("show");
}



function triggerCommentModal() {
  if (currentEditingTicket) {
    document.getElementById("newTicketModal").classList.remove("show"); // hide edit modal
    openModal(currentEditingTicket); // show comment modal
  } else {
    alert("No ticket loaded to comment on.");
  }
}



function deleteTicket(ticketId) {
  if (!confirm("Are you sure you want to delete this ticket?")) return;

  send_data("delete_ticket", { ticket_id: ticketId });
}
</script>
 <script src="../scripts/control.js"></script>
</body>
</html>
