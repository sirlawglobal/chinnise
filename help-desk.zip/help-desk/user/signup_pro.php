<?php
session_start();
require_once __DIR__ . '/../settings/init.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //var_dump($_POST);die;
if(count($_POST) > 0){
    $data = (object)$_POST;


if (isset($_POST['submit']) && $_POST['submit'] === "admin") {


  $errors = [];
 if (!validate_user_signup($_POST, $errors)) {
    //var_dump($errors);die;
      $_SESSION['errors'] = $errors;
      $_SESSION['old'] = $_POST;
      $_SESSION["fail"] = "❌ Failed to submit ticket filled accordingly: ";
      redirect('user/signup.php');
      exit;
  }

  $data = [
'name'         => trim($_POST['name'] ?? ''),
'roles'         => trim($_POST['roles'] ?? ''),
'email'        => trim($_POST['email'] ?? ''),
'phone'        => trim($_POST['phone'] ?? ''),
'password'     => password_hash($_POST['password'], PASSWORD_DEFAULT) ?? '',    
     
  ];
//var_dump($data);die;
  $query = "INSERT INTO users (name, email, phone, password, roles) 
          VALUES (:name, :email, :phone, :password, :roles)";
 //db_query($query, $data)
//var_dump($_POST);die; 
  if (db_query($query, $data)) {

      $_SESSION['success'] = "✅ Signup successfully!";

      // var_dump( $_SESSION['success']);die;
      header('Location: index.php');
      exit;
  } else {
      $_SESSION['fail'] = "❌ Failed to submit: " . $GLOBALS['DB_STATE']['error'];
      $_SESSION['old'] = $data;
      header('Location: signup.php');
      exit;
  }

}



}



}

 


