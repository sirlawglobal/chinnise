<?php
session_start();
require_once __DIR__ . '/../settings/init.php';

function flash_and_redirect($type, $msg, $location = 'user/index.php') {
    $_SESSION[$type] = $msg;
    redirect($location);
    exit;
}

function validate_ticket_data($data, &$errors) {
    if (empty($data['title'])) $errors[] = 'Title is required.';
    if (empty($data['description'])) $errors[] = 'Description is required.';
    return empty($errors);
}

function validate_comment_data($data, &$errors) {
    if (empty($data['id'])) $errors[] = 'Ticket ID is required.';
    if (empty($data['comments'])) $errors[] = 'Comment is required.';
    return empty($errors);
}

// === FORM SUBMISSION ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
//var_dump($_POST);die;
    $roles = $_SESSION['user']['roles'] ?? 0;
    $email = $_SESSION['user']['email'] ?? '';
    $name  = $_SESSION['user']['name'] ?? '';
    $user_id = $_SESSION['user']['id'] ?? '';
    $last_name = $_SESSION['user']['last_name'] ?? '';
$usernames  = $last_name . " " . $name;
    if ($_POST['submit'] === "form2") {


// Collect and trim incoming data
$data = [
      'email'       => trim($email),
    'created_at'       => date('Y-m-d H:i:s'),
    'user_name'       => trim($usernames),
    'user_id'     => trim($user_id),
    'title'       => trim($_POST['title'] ?? ''),
    'priority'    => trim($_POST['priority'] ?? ''),
    'description' => trim($_POST['description'] ?? ''),
];
//var_dump($data);die;
// Capture edit mode and ID if set
$form_mode = $_POST['form_mode'] ?? 'create';
//$ticket_id = $_POST['edit_ticket_id'] ?? null;
$ticket_id = $_POST['ticket_id'] ?? null;
// Validate input
$errors = [];
if (!validate_ticket_data($data, $errors)) {
    $_SESSION['errors'] = $errors;
    $_SESSION['old'] = $data;
    flash_and_redirect("fail", "Failed to submit ticket.");
}

// Handle create or update
if ($form_mode === 'edit' && $ticket_id) {
    $query = "UPDATE ticket_open SET title = ?, priority = ?, description = ? WHERE id = ?";
    if (db_query($query, [$data['title'], $data['priority'], $data['description'], $ticket_id])) {
        flash_and_redirect("success", "Ticket updated successfully!", 'user/index.php');
    } else {
        flash_and_redirect("fail", "DB Error (Update): " . $GLOBALS['DB_STATE']['error']);
    }
} else {
    $query = "INSERT INTO ticket_open (email, created_at, user_name, user_id, title, priority, description) VALUES (?, ?, ?, ?,?,?,?)";
    
    if (db_query($query, array_values($data))) {
        $id = $GLOBALS['DB_STATE']['insert_id'];
        $ticket_no = generate_ticket_code($id);
        db_query("UPDATE ticket_open SET ticket_no = ? WHERE id = ?", [$ticket_no, $id]);
        flash_and_redirect("success", "Ticket submitted successfully!", 'user/index.php');
    } else {
        flash_and_redirect("fail", "DB Error (Insert): " . $GLOBALS['DB_STATE']['error']);
    }
}



 } elseif ($_POST['submit'] === "form1") {
        $comment_by = ($roles == 1) ? 'admin' : 'user';
        $data = [
            'id'           => trim($_POST['tick_id'] ?? ''),
            'comments'     => trim($_POST['ticket_comments'] ?? ''),
            'comment_by'   => $comment_by,
            'comment_name' => $name,
        ];

        $errors = [];
        if (!validate_comment_data($data, $errors)) {
            $_SESSION['errors'] = $errors;
            $_SESSION['old'] = $data;
            flash_and_redirect("fail", "Failed to submit comment.", 'user/index.php');
        }

        $query = "INSERT INTO comments (ticket_id, comment, comment_by, comment_name) VALUES (?, ?, ?, ?)";
        if (db_query($query, [$data['id'], $data['comments'], $data['comment_by'], $data['comment_name']])) {
            flash_and_redirect("success", "Comment submitted!", 'user/index.php');
        } else {
            flash_and_redirect("fail", "DB Error: " . $GLOBALS['DB_STATE']['error'], 'user/index.php');
        }
    }
    exit;
}

// === AJAX JSON FETCH HANDLER ===
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $raw = file_get_contents("php://input");
    $data = json_decode($raw);
    $user_id = $_SESSION['user']['id'] ?? '';
    $email   = $_SESSION['user']['email'] ?? '';
    $name    = $_SESSION['user']['name'] ?? '';
    $last_name  = $_SESSION['user']['last_name'] ?? '';
    if (!$data || !isset($data->data_type)) {
        echo json_encode(['data_type' => 'error', 'message' => 'Invalid request']);
        exit;
    }

    try {
        $page = isset($data->page) && is_numeric($data->page) ? (int)$data->page : 1;

        $sql = '';
        $params = [':user_id' => $user_id];
        $pagination = null;

        // Counts based on user_id only
        $total_tickets = db_get_column("SELECT COUNT(*) FROM ticket_open WHERE user_id = :user_id", [':user_id' => $user_id]);
        $total_open    = db_get_column("SELECT COUNT(*) FROM ticket_open WHERE status = 'open' AND user_id = :user_id", [':user_id' => $user_id]);
        $total_closed  = db_get_column("SELECT COUNT(*) FROM ticket_open WHERE status = 'closed' AND user_id = :user_id", [':user_id' => $user_id]);
        $total_pending = db_get_column("SELECT COUNT(*) FROM ticket_open WHERE status = 'pending' AND user_id = :user_id", [':user_id' => $user_id]);

        if ($data->data_type === 'fetch_tickets') {
            $_GET['page'] = $page;

            $total_rows = db_get_column("SELECT COUNT(*) FROM ticket_open WHERE user_id = :user_id", [':user_id' => $user_id]);
         //   $pager = paginate($total_rows, 3, 1);
$pager = paginate($total_rows, 25, $page);
            $sql = "SELECT * FROM ticket_open WHERE user_id = :user_id ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
            $params[':limit'] = $pager['limit'];
            $params[':offset'] = $pager['offset'];

            $pagination = [
                'current' => $pager['page_number'],
                'total_start' => $pager['start'],
                'total_end' => $pager['end'],
                'total_links' => $pager['end'] - $pager['start'] + 1,
                'total_pages' => $pager['total_pages'],
            ];
        }

        elseif ($data->data_type === 'search_tickets') {
            $term = trim($data->query ?? '');
            $sql = "SELECT * FROM ticket_open WHERE user_id = :user_id AND title LIKE :search ORDER BY created_at DESC";
            $params[':search'] = "%$term%";
        }
        
        
        elseif ($data->data_type === 'delete_ticket') {
    $ticket_id = (int)($data->ticket_id ?? 0);

    if ($ticket_id <= 0) {
        echo json_encode([
            'data_type' => 'delete_ticket',
            'success' => false,
            'message' => 'Invalid ticket ID.'
        ]);
        exit;
    }

    // Ensure the ticket belongs to the user
    $check = db_get_row("SELECT * FROM ticket_open WHERE id = :id AND user_id = :user_id", [
        ':id' => $ticket_id,
        ':user_id' => $user_id
    ]);

    if (!$check) {
        echo json_encode([
            'data_type' => 'delete_ticket',
            'success' => false,
            'message' => 'Ticket not found or access denied.'
        ]);
        exit;
    }

    // Proceed to delete
    $deleted = db_query("DELETE FROM ticket_open WHERE id = :id", [':id' => $ticket_id]);
    if ($deleted) {
        $deleted = db_query("DELETE FROM comments WHERE ticket_id = :id", [':id' => $ticket_id]);
        echo json_encode([
            'data_type' => 'delete_ticket',
            'success' => true,
            'message' => 'Ticket deleted successfully.'
        ]);
    } else {
        echo json_encode([
            'data_type' => 'delete_ticket',
            'success' => false,
            'message' => 'Failed to delete ticket.',
            'error' => $GLOBALS['DB_STATE']['error'] ?? 'Unknown error'
        ]);
    }
    exit;
}


        else {
            throw new Exception("Unknown action: " . $data->data_type);
        }

        $tickets_result = db_query($sql, $params, 'assoc');
        if ($tickets_result === false) {
            throw new Exception($GLOBALS['DB_STATE']['error'] ?? 'DB error');
        }

        $ticket_ids = array_column($tickets_result, 'id');
        $comments_grouped = [];
        if ($ticket_ids) {
            $in = implode(',', array_fill(0, count($ticket_ids), '?'));
            $comment_sql = "SELECT * FROM comments WHERE ticket_id IN ($in) ORDER BY created_at ASC";
            $all_comments = db_query($comment_sql, $ticket_ids, 'assoc');

            if (is_array($all_comments)) {
foreach ($all_comments as $comment) {
    $tid = $comment['ticket_id'];
    $comments_grouped[$tid][] = [
        'id' => $comment['id'],
        'comment' => $comment['comment'],
        'comment_by' => strtolower($comment['comment_by']) === 'admin' ? "Admin" : 'User',
        'comment_name' => $comment['comment_name'] ?? '',
        'commented_at' => date('M d, Y h:i A', strtotime($comment['created_at']))
    ];
}

      }
        }

$tickets = [];
foreach ($tickets_result as $row) {
    $tid = $row['id'];
    $comments = $comments_grouped[$tid] ?? [];

    // Get last admin comment
    $last_admin_comment = null;
    foreach (array_reverse($comments) as $c) {
        if ($c['comment_by'] === 'Admin') {
            $last_admin_comment = $c;
            break;
        }
    }

    // Split commented_at into date/time parts
    $resolved_date = '-';
    $resolved_time = '-';
    $resolved_by = '-';
    if ($last_admin_comment) {
        $datetime_parts = explode(' ', $last_admin_comment['commented_at']);
        $resolved_date = $datetime_parts[0] . ' ' . $datetime_parts[1] . ' ' . $datetime_parts[2]; // May 28, 2025
        $resolved_time = $datetime_parts[3] . ' ' . $datetime_parts[4]; // 01:58 PM
        $resolved_by = $last_admin_comment['comment_name'] ?? 'Admin';
    }

    $tickets[] = [
        'id' => $tid,
        'ticketNumber' => $row['ticket_no'],
        'priority' => ucfirst($row['priority']),
        'priorityClass' => 'priority-' . strtolower($row['priority']),
        'user' => $name,
        'userImg' => 'https://ui-avatars.com/api/?name=' . urlencode($email),
        'email' => $email,
        'title' => $row['title'],
        'status' => ucfirst($row['status']),
        'time' => date('h:i A', strtotime($row['created_at'] ?? 'now')),
       'date' => date('n/j/Y', strtotime($row['created_at'] ?? 'now')),
        'description' => $row['description'],
        'comments' => $comments,
        'resolved_by' => $resolved_by,
        'resolved_date' => $resolved_date,
        'resolved_time' => $resolved_time,
    ];
}

    echo json_encode([
            'data_type' => $data->data_type,
            'data' => $tickets,
            'pagination' => $pagination,
            'summary' => [
               
                  'user' => $name. " " . $last_name,
                'total' => (int)$total_tickets,
                'open' => (int)$total_open,
                'closed' => (int)$total_closed,
                'pending' => (int)$total_pending
            ]
        ]);
    } catch (Exception $e) {
        echo json_encode(['data_type' => 'error', 'message' => 'Server error: ' . $e->getMessage()]);
    }
}
