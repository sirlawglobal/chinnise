<?php 
session_start();
require_once __DIR__ . '/../settings/init.php';
$errors = $_SESSION['errors'] ?? [];
$old = $_SESSION['old'] ?? [];
unset($_SESSION['errors'], $_SESSION['old']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="../styles/auth.css" />
  <title>Login Page</title>

</head>
<body>
    <style>
    .custom-alert {
  padding: 15px 20px;
  margin: 15px auto;
  width: 90%;
  max-width: 600px;
  border-radius: 5px;
  text-align: center;
  font-family: Arial, sans-serif;
  font-size: 16px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.custom-alert.success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}
.custom-alert.error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}
/* for error check */
.error {
  color: red;
  font-size: 0.85rem;
}


  </style>
  <div class="signup-container">
     <?php if(isset($_SESSION["success"])):?>
	      	<div class="custom-alert success"><?=$_SESSION["success"]?>
          <?php unset($_SESSION["success"]);
          ?></div>
          
	    <?php endif?>
      <?php if(isset($_SESSION["fail"])):?>
          <div class="custom-alert error"><?=$_SESSION["fail"]?>
           <?php unset($_SESSION["fail"]);
          ?></div>
      <?php endif?>
    <h2>Login</h2>
    <form action="login_pro.php" method="POST">
      
      <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email" required />
      </div>
      
      
      <div class="form-group">
        <label for="password">Password</label>
        <input type="text" id="password" name="password" required />
      </div>
      <button type="submit" class="submit-btn">Login</button>
    </form>
   
    
  </div>
</body>
</html>
