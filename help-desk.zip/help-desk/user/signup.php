<?php 
session_start();
require_once __DIR__ . '/../settings/init.php';
$errors = $_SESSION['errors'] ?? [];
$old = $_SESSION['old'] ?? [];
unset($_SESSION['errors'], $_SESSION['old']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Signup Page</title>
    <link rel="stylesheet" href="../styles/auth.css" />
  <style>
   
  </style>
</head>
<body>
  <style>
    .custom-alert {
  padding: 15px 20px;
  margin: 15px auto;
  width: 90%;
  max-width: 600px;
  border-radius: 5px;
  text-align: center;
  font-family: Arial, sans-serif;
  font-size: 16px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.custom-alert.success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}
.custom-alert.error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}
/* for error check */
.error {
  color: red;
  font-size: 0.85rem;
}


  </style>
  <div class="signup-container">
    <?php if(isset($_SESSION["success"])):?>
	      	<div class="custom-alert success"><?=$_SESSION["success"]?>
          <?php unset($_SESSION["success"]);
          ?></div>
          
	    <?php endif?>
      <?php if(isset($_SESSION["fail"])):?>
          <div class="custom-alert error"><?=$_SESSION["fail"]?>
           <?php unset($_SESSION["fail"]);
          ?></div>
      <?php endif?>
    <h2>Create Account</h2>
    <form action="signup_pro.php" method="POST">
      <div class="form-group">
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" required   value="<?= htmlspecialchars($old['name'] ?? '') ?>"/>
        <?php if (!empty($errors['name'])): ?>
        <div class="error-message" style="color: red; font-size: 0.9em;">
          <?= htmlspecialchars($errors['name']) ?>
        </div>
      <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email" required   value="<?= htmlspecialchars($old['email'] ?? '') ?>"/>
        <?php if (!empty($errors['email'])): ?>
        <div class="error-message" style="color: red; font-size: 0.9em;">
          <?= htmlspecialchars($errors['email']) ?>
        </div>
      <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="phone">Phone Number</label>
        <input type="tel" id="phone" name="phone" required  value="<?= htmlspecialchars($old['phone'] ?? '') ?>"/>
        <?php if (!empty($errors['phone'])): ?>
        <div class="error-message" style="color: red; font-size: 0.9em;">
          <?= htmlspecialchars($errors['phone']) ?>
        </div>
      <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="phone">Token Number</label>
        <input type="text" id="token" name="token" required  value="<?= htmlspecialchars($old['token'] ?? '') ?>"/>
        <?php if (!empty($errors['token'])): ?>
        <div class="error-message" style="color: red; font-size: 0.9em;">
          <?= htmlspecialchars($errors['token']) ?>
        </div>
      <?php endif; ?>
      </div>
      <div class="form-group">
  <label for="roles">Role</label>
  <select id="roles" name="roles" required>
    <option value="">-- Select Role --</option>
    <option value="1" <?= isset($old['roles']) && $old['roles'] == 1 ? 'selected' : '' ?>>Admin</option>
    <option value="2" <?= isset($old['roles']) && $old['roles'] == 2 ? 'selected' : '' ?>>User</option>
  </select>
  
  <?php if (!empty($errors['roles'])): ?>
    <div class="error-message" style="color: red; font-size: 0.9em;">
      <?= htmlspecialchars($errors['roles']) ?>
    </div>
  <?php endif; ?>
</div>

      <div class="form-group">
        <label for="password">Create Password</label>
        <input type="text" id="password" name="password" required  value="<?= htmlspecialchars($old['password'] ?? '') ?>"/>
        <?php if (!empty($errors['password'])): ?>
        <div class="error-message" style="color: red; font-size: 0.9em;">
          <?= htmlspecialchars($errors['password']) ?>
        </div>
      <?php endif; ?>
      </div>
      <button  name="submit" value="admin" type="submit" class="submit-btn">Sign Up</button>
    </form>
     
  </div>
</body>
</html>
