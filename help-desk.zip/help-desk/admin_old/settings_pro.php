<?php
require_once "../settings/init.php";
$input = json_decode(file_get_contents("php://input"), true);
$data_type = $input['data_type'] ?? '';
$search = $input['search'] ?? '';
if ($data_type == "users") {
//file_put_contents("debug.txt", "Requested Page: " . $page);
    $page = isset($input['page']) && is_numeric($input['page']) ? (int)$input['page'] : 1;
    $limit = 5;
    $offset = ($page - 1) * $limit;
file_put_contents("page_debug.txt", "Received page: " . ($input['page'] ?? 'null') . "\n", FILE_APPEND);

    // Search filtering
    $search = $input['search'] ?? '';
    $countParams = [];
    $queryParams = [];

    // === Count total users with optional search ===
    $countQuery = "SELECT COUNT(*) FROM users WHERE 1";
    if (!empty($search)) {
        $countQuery .= " AND (name LIKE ? OR email LIKE ?)";
        $countParams[] = "%$search%";
        $countParams[] = "%$search%";
    }
    $total_rows = db_get_column($countQuery, $countParams);

    // === Paginate ===
    $pager = paginate($total_rows, $limit, $page);
    $offset = $pager['offset'];

    // === Main query with the same filtering ===
    $query = "SELECT * FROM users WHERE 1";
    if (!empty($search)) {
        $query .= " AND (name LIKE ? OR email LIKE ?)";
        $queryParams[] = "%$search%";
        $queryParams[] = "%$search%";
    }
    $query .= " LIMIT $offset, $limit";

    $users = db_query($query, $queryParams);

    // === Render HTML table rows ===
    ob_start();
    $sn = $offset + 1;
    foreach ($users as $row) {
        echo "<tr>
            <td>$sn</td>
            <td>{$row->name}</td>
            <td>{$row->last_name}</td>
            <td>{$row->email}</td>
            <td>{$row->phone}</td>
            <td>
                <button class='btn-edit' title='Edit' onclick='openModal(" . json_encode($row) . ")'>✏️</button>
                <button class='btn-delete' title='Delete' onclick='deleteUser({$row->id})'>🗑️</button>
            </td>
        </tr>";
        $sn++;
    }
    $html = ob_get_clean();

    // === Pagination info for frontend ===
    $pagination = [
        'current' => $pager['page_number'],
        'total_start' => $pager['start'],
        'total_end' => $pager['end'],
        'total_links' => $pager['end'] - $pager['start'] + 1,
        'total_pages' => $pager['total_pages'],
    ];

    echo json_encode([
        'data_type' => 'users',
        'html' => $html,
        'pagination' => $pagination
    ]);
    exit;
}


if ($data_type === "update_user") {
    $id       = $input['id'] ?? null;
    $name     = trim($input['name'] ?? '');
    $last_name = trim($input['lastname'] ?? '');
    $email    = trim($input['email'] ?? '');
    $phone    = trim($input['phone'] ?? '');
    $password = trim($input['password'] ?? '');
    $roles    = trim($input['roles'] ?? '');

    $fields = "name = ?, last_name = ?, email = ?, phone = ?, roles = ?";
    $params = [$name, $last_name, $email, $phone, $roles];

    if (!empty($password)) {
        $fields .= ", password = ?";
        $params[] = password_hash($password, PASSWORD_DEFAULT);
    }

    $params[] = $id;
    $query = "UPDATE users SET $fields WHERE id = ?";
    db_query($query, $params);

    echo json_encode([
        'data_type' => 'update_user',
        'status' => 'success',
        'message' => 'User updated successfully'
    ]);
    exit;
}

if ($data_type === "delete_user") {
    $id = (int)($input['id'] ?? 0);
    if ($id > 0) {
        db_query("DELETE FROM users WHERE id = ?", [$id]);
        echo json_encode([
            'data_type' => 'delete_user',
            'status' => 'success',
             'message' => 'User delete successfully'
        ]);
    } else {
        echo json_encode([
            'data_type' => 'delete_user',
            'status' => 'error',
            'message' => 'Invalid ID'
        ]);
    }
    exit;
}

if ($data_type === "add_user") {
    $formData = [
        'name'      => $input['name'] ?? '',
        'last_name' => $input['lastname'] ?? '',
        'email'     => $input['email'] ?? '',
        'phone'     => $input['phone'] ?? '',
        'password'  => $input['password'] ?? ''
    ];

    $errors = [];
    if (!validate_user_signup($formData, $errors)) {
        echo json_encode([
            'data_type' => 'add_user',
            'status' => 'error',
            'message' => 'Validation failed',
            'errors' => $errors
        ]);
        exit;
    }

    $formData['password'] = password_hash($formData['password'], PASSWORD_DEFAULT);
    $formData['roles'] = $input['roles'] ?? 'staff';

    $query = "INSERT INTO users (name, last_name, email, phone, password, roles)
              VALUES (:name, :last_name, :email, :phone, :password, :roles)";

    if (db_query($query, $formData)) {
        echo json_encode([
            'data_type' => 'add_user',
            'status' => 'success',
            'message' => 'User added successfully.'
        ]);
    } else {
        echo json_encode([
            'data_type' => 'add_user',
            'status' => 'error',
            'message' => 'Database error. Could not add user.'.$GLOBALS['DB_STATE']['error']
        ]);
    }

    exit;
}

// Fallback error
echo json_encode([
    'status' => 'error',
    'message' => 'Invalid request or unsupported data_type'
]);
