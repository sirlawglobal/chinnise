<?php
session_start();
require_once __DIR__ . '/../settings/init.php';
if (!isAdmin()){
   $_SESSION['fail'] = "Login as Admin to have access.";
        redirect('user/login.php');  
}
   
// Helper: Flash message and redirect
function flash_and_redirect($type, $msg, $location = 'admin/index.php') {
    $_SESSION[$type] = $msg;
    redirect($location);
    exit;
}

// Helper: Validate ticket data
function validate_ticket_data($data, &$errors) {
    if (empty($data['title'])) $errors[] = 'Title is required.';
    if (empty($data['priority'])) $errors[] = 'Priority is required.';
    if (empty($data['description'])) $errors[] = 'Description is required.';
    return empty($errors);
}

function validate_comment_data($data, &$errors) {
    if (empty($data['id'])) $errors[] = 'Ticket ID is required.';
    if (empty($data['comments'])) $errors[] = 'Comment is required.';
    return empty($errors);
}

// === FORM SUBMISSION ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
  
    $roles = $_SESSION['user']['roles'] ?? 0;
    $email = $_SESSION['user']['email'] ?? '';
    $name  = $_SESSION['user']['name'] ?? '';
    $user_id  = $_SESSION['user']['id'] ?? '';

    if ($_POST['submit'] === "form2") {
        $data = [
            'email'       => trim($email),
            'user_id'       => trim($user_id),
            'title'       => trim($_POST['title'] ?? ''),
            'priority'    => trim($_POST['priority'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
        ];

        $errors = [];
        if (!validate_ticket_data($data, $errors)) {
            $_SESSION['errors'] = $errors;
            $_SESSION['old'] = $data;
            flash_and_redirect("fail", "Failed to submit ticket.");
        }

        $query = "INSERT INTO ticket_open (email, user_id, title, priority, description) VALUES (?, ?, ?, ?,?)";
        if (db_query($query, array_values($data))) {
            $id = $GLOBALS['DB_STATE']['insert_id'];
            $ticket_no = generate_ticket_code($id);
            db_query("UPDATE ticket_open SET ticket_no = ? WHERE id = ?", [$ticket_no, $id]);
            flash_and_redirect("success", "Ticket submitted successfully!", 'admin/index.php');
        } else {
            flash_and_redirect("fail", "DB Error: " . $GLOBALS['DB_STATE']['error']);
        }

    } elseif ($_POST['submit'] === "form1") {
        $comment_by = ($roles == 1) ? 'admin' : 'user';
        $data = [
            'id'        => trim($_POST['tick_id'] ?? ''),
            'comments'  => trim($_POST['ticket_comments'] ?? ''),
            'comment_by'=> $comment_by,
            'comment_name'=> $name,
        ];
//var_dump($_POST);die;
        $errors = [];
        if (!validate_comment_data($data, $errors)) {
            $_SESSION['errors'] = $errors;
            $_SESSION['old'] = $data;
            flash_and_redirect("fail", "Failed to submit comment.", 'admin/index.php');
        }
$id = array();
        $query = "INSERT INTO comments (ticket_id, comment, comment_by,comment_name) VALUES (?, ?, ?,?)";
        if (db_query($query, [$data['id'], $data['comments'], $data['comment_by'],$data['comment_name']])) {

          //var_dump(trim(strtolower($_POST['ticket_status'] ?? '')));die;   
//  $id['status'] = trim(strtolower($_POST['ticket_status'] ?? ''));
//     $id['ids'] = $data['id'];
   
$params = [
    'status' => trim(strtolower($_POST['ticket_status'] ?? '')),
    'id'     => $data['id'],
];


$upquery = "UPDATE ticket_open SET status = :status WHERE id = :id";
db_query($upquery, $params);


//       $upquery = "UPDATE ticket_open SET status = :status WHERE id = :ids";
//    db_query($upquery, $id);
            flash_and_redirect("success", "Comment submitted!", 'admin/index.php');
        } else {
            flash_and_redirect("fail", "DB Error: " . $GLOBALS['DB_STATE']['error'], 'admin/index.php');
        }
    }
    exit;
}

// === AJAX JSON FETCH HANDLER ===
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $raw = file_get_contents("php://input");
    $data = json_decode($raw);
    $email = $_SESSION['user']['email'] ?? '';
    $name  = $_SESSION['user']['name'] ?? '';

    if (!$data || !isset($data->data_type)) {
        echo json_encode(['data_type' => 'error', 'message' => 'Invalid request']);
        exit;
    }

    try {
        $page = isset($data->page) && is_numeric($data->page) ? (int)$data->page : 1;
        $sql = '';
        $params = [];
        $pagination = null;
        // Calculate full counts before pagination
$total_tickets = db_get_column("SELECT COUNT(*) FROM ticket_open");
$total_open = db_get_column("SELECT COUNT(*) FROM ticket_open WHERE status = 'open'");
$total_closed = db_get_column("SELECT COUNT(*) FROM ticket_open WHERE status = 'closed'");
$total_pending = db_get_column("SELECT COUNT(*) FROM ticket_open WHERE status = 'pending'");

if ($data->data_type === 'fetch_tickets') {
    $_GET['page'] = $page;

    // === Build filtering conditions
    $conditions = [];
    $queryParams = [];

    if (!empty($data->priority)) {
        $conditions[] = "priority = :priority";
        $queryParams[':priority'] = $data->priority;
    }

    if (!empty($data->status)) {
        $conditions[] = "status = :status";
        $queryParams[':status'] = $data->status;
    }

    $whereClause = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

    // === Count total filtered rows
    $totalQuery = "SELECT COUNT(*) FROM ticket_open $whereClause";
    $total_rows = db_get_column($totalQuery, $queryParams);

$pager = paginate($total_rows, 5, $page);
    // === Main data query with limit and offset
    $sql = "SELECT * FROM ticket_open $whereClause ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
    $params = array_merge($queryParams, [
        ':limit' => $pager['limit'],
        ':offset' => $pager['offset']
    ]);

    // === Pagination summary for frontend
    $pagination = [
        'current' => $pager['page_number'],
        'total_start' => $pager['start'],
        'total_end' => $pager['end'],
        'total_links' => $pager['end'] - $pager['start'] + 1,
        'total_pages' => $pager['total_pages'],
    ];
}

 elseif ($data->data_type === 'search_tickets') {
            $term = trim($data->query ?? '');
            $sql = "SELECT * FROM ticket_open WHERE title LIKE :search ORDER BY created_at DESC";
            $params = [':search' => "%$term%"];
        } else {
            throw new Exception("Unknown action: " . $data->data_type);
        }

        $tickets_result = db_query($sql, $params, 'assoc');
        if ($tickets_result === false) {
            throw new Exception($GLOBALS['DB_STATE']['error'] ?? 'DB error');
        }

        $ticket_ids = array_column($tickets_result, 'id');
        $comments_grouped = [];
        if ($ticket_ids) {
            $in = implode(',', array_fill(0, count($ticket_ids), '?'));
            $comment_sql = "SELECT * FROM comments WHERE ticket_id IN ($in) ORDER BY created_at ASC";
            $all_comments = db_query($comment_sql, $ticket_ids, 'assoc');
            if (is_array($all_comments)) {
                foreach ($all_comments as $comment) {
                    $comment_name   =   $comment['comment_name'];
                    $tid = $comment['ticket_id'];
                    $comments_grouped[$tid][] = [
                        'id' => $comment['id'],
                        'comment' => $comment['comment'],
                        'comment_by' => $comment['comment_by'] === 'admin' ? "Admin | $comment_name" : 'User',
                        'commented_at' => date('M d, Y h:i A', strtotime($comment['created_at']))
                    ];
                }
            }
        }

        $tickets = [];
        foreach ($tickets_result as $row) {
            $tid = $row['id'];
            $tickets[] = [
                'id' => $tid,
                'ticketNumber' => $row['ticket_no'],
                'priority' => ucfirst($row['priority']),
                'priorityClass' => 'priority-' . strtolower($row['priority']),
                'user' => $name,
                'userImg' => 'https://ui-avatars.com/api/?name=' . urlencode($email),
                'email' => $email,
                'title' => $row['title'],
                'status' => $row['status'],
                'time' => date('h:i A', strtotime($row['created_at'] ?? 'now')),
                'date' => date('M d, Y', strtotime($row['created_at'] ?? 'now')),
                'description' => $row['description'],
                'comments' => $comments_grouped[$tid] ?? [],
            ];
        }

        echo json_encode([
    'data_type' => $data->data_type,
    'data' => $tickets,
    'pagination' => $pagination,
    'summary' => [
        'user' => $name,
        'total' => (int)$total_tickets,
        'open' => (int)$total_open,
        'closed' => (int)$total_closed,
        'pending' => (int)$total_pending
    ]
]);
    } catch (Exception $e) {
        echo json_encode(['data_type' => 'error', 'message' => 'Server error: ' . $e->getMessage()]);
    }
}
