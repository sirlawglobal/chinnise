<?php 
session_start();
require_once __DIR__ . '/../settings/init.php';
requireLogin();
$errors = $_SESSION['errors'] ?? [];
$old = $_SESSION['old'] ?? [];
unset($_SESSION['errors'], $_SESSION['old']);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../styles/general.css" />
    <link rel="stylesheet" href="../styles/admin.css" />
    <link rel="stylesheet" href="../styles/user.css" />
     <link rel="stylesheet" href="../styles/comments.css" />
    <title>Tickets</title>
    
  
    
  </head>
  <body>
   <style>
/* Header styling */
.ticket{
  width: 1000px !important;
}
.ticket-system {
width: 1000px !important;
margin-top:0;
}

.page-header {
  background-color: #f0f0f0;
  border-bottom: 1px solid #ccc;
  padding: 15px 25px;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.page-title {
  font-size: 1.5em;
  color: #333;
}

.header-links {
  display: flex;
  gap: 20px;
}

.header-link {
  color: #333;
  text-decoration: none;
  font-weight: 500;
}

.header-link:hover {
  text-decoration: underline;
}

.logout-link {
  color: #e60000;
}


   </style>
<div id="sprite" class="hidden"></div>

<header class="page-header">
  <div class="header-content">
    <h2 class="page-title">Ticket System</h2>
    <div class="header-links">
      <?php if (isAdmin()): ?>
        <a href="<?= ROOT ?>admin" class="header-link">Admin</a>
      <?php endif; ?>
      <a href="logout.php" class="header-link logout-link">Logout</a>
    </div>
  </div>
</header>



    <main class="flex">
      <div class="ticket-system">
        <div class="ticket-system__filters">
          <div class="search flex align-center">
            <svg class="icon"><use href="#search"></use></svg>
            
            <input
  type="text"
  id="ticket-search"
  placeholder="Search for ticket"
  class="ticket-search"
/>
          </div>
          <div class="ticket-actions">
            <button id="button" onclick="toggleView()">
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M16 2H8C4 2 2 4 2 8V21C2 21.55 2.45 22 3 22H16C20 22 22 20 22 16V8C22 4 20 2 16 2Z"
                  stroke="white"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
                <path
                  d="M12.91 7.84003L7.72004 13.03C7.52004 13.23 7.33004 13.62 7.29004 13.9L7.01004 15.88C6.91004 16.6 7.41004 17.1 8.13004 17L10.11 16.72C10.39 16.68 10.78 16.49 10.98 16.29L16.17 11.1C17.06 10.21 17.49 9.17003 16.17 7.85003C14.85 6.52003 13.81 6.94003 12.91 7.84003Z"
                  stroke="white"
                  stroke-width="1.5"
                  stroke-miterlimit="10"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
                <path
                  d="M12.17 8.58008C12.61 10.1501 13.84 11.3901 15.42 11.8301"
                  stroke="white"
                  stroke-width="1.5"
                  stroke-miterlimit="10"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>

              New Ticket
            </button>
          </div>
        </div>
       
<?php //var_dump($_SESSION["success"]);die?>
<?php if(isset($_SESSION["success"])):?>
	      	<div class="custom-alert success"><?=$_SESSION["success"]?>
          <?php unset($_SESSION["success"]);
          ?></div>
          
	    <?php endif?>
      <?php if(isset($_SESSION["fail"])):?>
          <div class="custom-alert error"><?=$_SESSION["fail"]?>
           <?php unset($_SESSION["fail"]);
          ?></div>
      <?php endif?>
        <div class="ticket-system__views">
          <span class="active"
            ><svg class="icon"><use href="#sms"></use></svg>Tickets</span
          >
 </div>
        <div class="ticket-system__views">
          
        </div>

        <div id="tickets-container" class="ticket-system__list">
          <!-- Tickets will be inserted dynamically here -->
        </div>

      <div class="pagination" id="pagination-container">
  <!-- AJAX pagination links will be injected here -->
</div>

   <div id="modal" class="ticket-system__modal">
          <div class="ticket-system__modal-content">
            <!-- <span class="ticket-system__close">&times;</span> -->
            <div class="ticket-header">
              <div class="flex align-center">
                <div class="circle"></div>
                <strong id="ticket-number">Ticket# </strong>
                <span class="ticket-priority"> ${ticket.priority} </span>
              </div>
              <span class="ticket-time">Posted at </span>
            </div>
            <p class="title" id="modal-title"></p>
            <p class="desc" id="modal-description"></p>

            <div id="reply-section">
              <h5>Reply</h5>

              <form action="user.php" method="post">
  <div class="flex align-center justify-between wrap">
    <div class="form-group">
      <label for="user-email">User Email</label>
      <input
        type="email"
        id="user-email"
        name="user_email"
        value="<?= htmlspecialchars($old['user_email'] ?? '') ?>"
       disabled
      />
       <input
        type="text"
        id="id_s"
        name="tick_id"
        value="<?= htmlspecialchars($old['ticket_title'] ?? '') ?>"
       hidden
      />
      <?php if (!empty($errors['user_email'])): ?>
        <div class="error-message" style="color: red; font-size: 0.9em;">
          <?= htmlspecialchars($errors['user_email']) ?>
        </div>
      <?php endif; ?>
    </div>

    <div class="form-group">
      <label for="ticket-title">Title</label>
      <input
        type="text"
        id="ticket-title"
        name="ticket_title"
        value="<?= htmlspecialchars($old['ticket_title'] ?? '') ?>"
       disabled
      />
      <?php if (!empty($errors['ticket_title'])): ?>
        <div class="error-message" style="color: red; font-size: 0.9em;">
          <?= htmlspecialchars($errors['ticket_title']) ?>
        </div>
      <?php endif; ?>
    </div>

    <div class="form-group">
      <label for="ticket-status">Status</label>
     
         <input
        type="text"
      id="ticket-status" name="ticket_status"
        value="<?= htmlspecialchars($old['ticket_title'] ?? '') ?>"
       disabled
      />
    
      <?php if (!empty($errors['ticket_status'])): ?>
        <div class="error-message" style="color: red; font-size: 0.9em;">
          <?= htmlspecialchars($errors['ticket_status']) ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="form-group">
    <label for="ticket-comments">Comments</label>
    <textarea
      id="ticket-comments"
      name="ticket_comments"
      placeholder="Type ticket resolutions here.."
      required
    ><?= htmlspecialchars($old['ticket_comments'] ?? '') ?></textarea>
    <?php if (!empty($errors['ticket_comments'])): ?>
      <div class="error-message" style="color: red; font-size: 0.9em;">
        <?= htmlspecialchars($errors['ticket_comments']) ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="flex justify-end align-center">
    <button style="margin-right: 50px;" class="submit-button" name="submit" value="form1" type="submit" id="submit-reply">Submit</button>
   
    <button name="submit" value="form1" type="submit" id="submit-reply" class="close-button">Close</button>
  </div>
</form>

              
            </div>
          </div>
        </div>
      </div>
      <div id="ticket-form">
        <div class="title">
          <h4>Create Quick Ticket</h4>
          <p>Write and address new queries and issues</p>
        </div>
        <form action="user.php" method="POST" id="ticket-forms">
  <!--  -->

  <div class="form-group">
    <label for="ticket-title">Title</label>
    <input 
      type="text" 
      id="ticket-title" 
      name="title" 
      placeholder="Type Title" 
      value="<?= htmlspecialchars($old['title'] ?? '') ?>" 
    />
    <?php if (!empty($errors['title'])): ?>
      <small class="error"><?= $errors['title'] ?></small>
    <?php endif; ?>
  </div>

  <div class="form-group">
    <label for="ticket-priority">Priority</label>
    <select id="ticket-priority" name="priority">
      <option value="">Select Priority</option>
      <option value="low" <?= ($old['priority'] ?? '') === 'low' ? 'selected' : '' ?>>Low</option>
      <option value="medium" <?= ($old['priority'] ?? '') === 'medium' ? 'selected' : '' ?>>Medium</option>
      <option value="high" <?= ($old['priority'] ?? '') === 'high' ? 'selected' : '' ?>>High</option>
      <option value="urgent" <?= ($old['priority'] ?? '') === 'urgent' ? 'selected' : '' ?>>Urgent</option>
    </select>
    <?php if (!empty($errors['priority'])): ?>
      <small class="error"><?= $errors['priority'] ?></small>
    <?php endif; ?>
  </div>

  <div class="form-group">
    <label for="ticket-description">Issue Description</label>
    <textarea 
      id="ticket-description" 
      name="description" 
      placeholder="Type ticket issue here.."
    ><?= htmlspecialchars($old['description'] ?? '') ?></textarea>
    <?php if (!empty($errors['description'])): ?>
      <small class="error"><?= $errors['description'] ?></small>
    <?php endif; ?>
  </div>

  <button name="submit" value="form2" type="submit" id="submit-ticket">Submit</button>
</form>

        
      </div>
    </main>
    
    
    <script src="../scripts/general.js"></script>
    <script src="../scripts/users.js"></script>
  </body>
</html>
