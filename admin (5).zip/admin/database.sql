CREATE DATABASE club_portal;

USE club_portal;

CREATE TABLE members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

/* Replace 'your_hashed_password' with a real hash from password_hash() */
INSERT INTO members (username, password)
VALUES ('admin', 'your_hashed_password');
