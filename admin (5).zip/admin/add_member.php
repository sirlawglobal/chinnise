<?php
include "db_connect.php";

header('Content-Type: application/json');

// Function to sanitize input
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // echo '<pre>';
    // print_r($input);
    // echo '</pre>';
    // exit();
    
    $username = sanitize($input['username']);
    $surname = sanitize($input['surname']);
    $firstname = sanitize($input['firstname']);
    $gender = sanitize($input['gender']);
    $dob = sanitize($input['dob']);
    $phoneno = sanitize($input['phoneno']);
    $email = sanitize($input['email'] ?? '');
    $address = sanitize($input['address'] ?? '');
    $membership_date = sanitize($input['membership_date'] ?? date('Y-m-d'));
    $password = password_hash(sanitize($input['password'] ?? ''), PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO members (username, surname, firstname, gender, dob, phoneno, email, address, join_date, password) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssss", 
        $username, 
        $surname, 
        $firstname, 
        $gender, 
        $dob, 
        $phoneno, 
        $email, 
        $address, 
        $membership_date,
        $password
    );

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Member added successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to add member']);
    }
    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

$conn->close();
?>