// member.js 

document.addEventListener('DOMContentLoaded', function() {
  // Load welcome screen when dashboard link is clicked
  document.getElementById("dashboardLink").addEventListener("click", function(e) {
    e.preventDefault();
    document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
    this.classList.add('active');
    loadWelcomeScreen();
  });

  // Load members when members link is clicked
  document.getElementById("loadMembers").addEventListener("click", function(e) {
    e.preventDefault();
    document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
    this.classList.add('active');
    loadMembers();
  });

  // Load members when "View Members" button is clicked
  document.getElementById("viewMembersBtn").addEventListener("click", function(e) {
    e.preventDefault();
    document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
    document.getElementById("loadMembers").classList.add('active');
    loadMembers();
  });

  // Load attendance years and set up dropdown
  loadAttendanceYears();

  // Add attendance modal trigger
  document.getElementById("addAttendanceLink").addEventListener("click", function(e) {
    e.preventDefault();
    showAddAttendanceModal();
  });
});

function loadWelcomeScreen() {
  const welcomeContent = `
    <div class="welcome-screen">
      <div class="welcome-icon">
        <i class="fas fa-users"></i>
      </div>
      <h1 class="welcome-title">Welcome to Club Portal</h1>
      <p class="welcome-subtitle">Manage your club members efficiently with our comprehensive dashboard</p>
      <div class="mt-4">
        <button class="btn btn-primary btn-lg me-2" id="viewMembersBtn">
          <i class="fas fa-users me-2"></i>View Members
        </button>
      </div>
    </div>
  `;
  document.getElementById("contentArea").innerHTML = welcomeContent;

  // Re-attach event listener for viewMembersBtn
  document.getElementById("viewMembersBtn").addEventListener("click", function(e) {
    e.preventDefault();
    document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
    document.getElementById("loadMembers").classList.add('active');
    loadMembers();
  });
}

function showToast(message, type = 'info') {
  const toastContainer = document.querySelector('.toast-container');
  const toast = document.createElement('div');
  toast.className = `toast align-items-center text-white bg-${type} border-0 show`;
  toast.setAttribute('role', 'alert');
  toast.setAttribute('aria-live', 'assertive');
  toast.setAttribute('aria-atomic', 'true');
  
  toast.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">
        ${message}
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  `;
  
  toastContainer.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, 5000);
}

function loadMembers() {
  fetch("load_members.php")
    .then(response => response.json())
    .then(data => {
      const content = `
        <div class="d-flex justify-content-between align-items-center mb-4">
          <h4 class="mb-0">Member List</h4>
          <button class="btn btn-primary" onclick="showAddMemberModal()">
            <i class="fas fa-plus me-2"></i>Add Member
          </button>
        </div>
        <div class="card shadow-sm">
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table table-hover mb-0">
                <thead class="table-light">
                  <tr>
                    <th>MemID</th>
                    <th>Username</th>
                    <th>Surname</th>
                    <th>Firstname</th>
                    <th>Gender</th>
                    <th>DOB</th>
                    <th>Phone</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  ${
                    data.length === 0
                    ? `<tr><td colspan="8" class="text-center py-4">No members found. <a href="#" class="text-primary" onclick="showAddMemberModal()">Add a new member</a></td></tr>`
                    : data.map(row => {
                        const displayId = parseInt(row.memid) + 1000;
                        return `
                          <tr>
                            <td>${displayId}</td>
                            <td>${row.username}</td>
                            <td>${row.surname}</td>
                            <td>${row.firstname}</td>
                            <td>${row.gender}</td>
                            <td>${row.dob}</td>
                            <td>${row.phoneno}</td>
                            <td>
                              <div class="dropdown">
                                <button class="btn btn-sm btn-outline-success" type="button" data-bs-toggle="dropdown">
                                  <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu">
                                  <li><a class="dropdown-item" onclick='viewMember(${JSON.stringify({...row, displayId: displayId})})'><i class="fas fa-eye me-2"></i>View</a></li>
                                  <li><a class="dropdown-item" onclick='editMember(${JSON.stringify({...row, displayId: displayId})})'><i class="fas fa-edit me-2"></i>Edit</a></li>
                                  <li><hr class="dropdown-divider"></li>
                                  <li><a class="dropdown-item text-danger" onclick='showDeleteModal(${JSON.stringify({...row, displayId: displayId})})'><i class="fas fa-trash me-2"></i>Delete</a></li>
                                </ul>
                              </div>
                            </td>
                          </tr>
                        `;
                      }).join('')
                  }
                </tbody>
              </table>
            </div>
          </div>
        </div>
      `;
      document.getElementById("contentArea").innerHTML = content;
    })
    .catch(error => {
      console.error("Error loading members:", error);
      showToast("Failed to load members. Please try again later.", "danger");
      document.getElementById("contentArea").innerHTML = `
        <div class="alert alert-danger">
          <i class="fas fa-exclamation-circle me-2"></i>Failed to load members. Please try again later.
        </div>
      `;
    });
}

function viewMember(data) {
  let html = `
    <div class="row">
      <div class="col-md-4 text-center mb-4">
        <div class="bg-light p-4 rounded-circle d-inline-flex align-items-center justify-content-center" style="width: 150px; height: 150px;">
          <i class="fas fa-user fa-4x text-muted"></i>
        </div>
        <h4 class="mt-3">${data.firstname} ${data.surname}</h4>
        <p class="text-muted">Member ID: ${data.displayId}</p>
      </div>
      <div class="col-md-8">
        <div class="row g-3">
  `;
  
//   for (let key in data) {
//     //   alert(data);
//     console.log('data', data);
//     return;
//     if (key !== 'memid' && key !== 'firstname' && key !== 'surname' && key !== 'displayId') {
//       html += `
//         <div class="col-md-6">
//           <div class="p-3 bg-light rounded">
//             <small class="text-muted d-block">${key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</small>
//             <strong>${data[key] || 'N/A'}</strong>
//           </div>
//         </div>
//       `;
//     }
//   }

for (let key in data) {
  if (key !== 'memid' && key !== 'firstname' && key !== 'surname' && key !== 'displayId') {
    let value = data[key] || 'N/A';

    // Check if value is a valid date (simple check)
    if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      const [year, month, day] = value.split('-');
      value = `${day}/${month}/${year}`;
    }

    html += `
      <div class="col-md-6">
        <div class="p-3 bg-light rounded">
          <small class="text-muted d-block">${key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</small>
          <strong>${value}</strong>
        </div>
      </div>
    `;
  }
}

  
  html += `
        </div>
      </div>
    </div>
  `;
  
  document.getElementById("viewContent").innerHTML = html;
  new bootstrap.Modal(document.getElementById("viewModal")).show();
}

function editMember(data) {
  const fields = [
    { key: 'username', label: 'Username', icon: 'user', type: 'text', required: true },
    { key: 'surname', label: 'Surname', icon: 'signature', type: 'text', required: true },
    { key: 'firstname', label: 'First Name', icon: 'signature', type: 'text', required: true },
    { key: 'gender', label: 'Gender', icon: 'venus-mars', type: 'select', options: ['Male', 'Female', 'Other'], required: true },
    { key: 'dob', label: 'Date of Birth', icon: 'calendar', type: 'date', required: true },
    { key: 'phoneno', label: 'Phone Number', icon: 'phone', type: 'tel', required: true },
    { key: 'email', label: 'Email', icon: 'envelope', type: 'email', required: false },
    { key: 'address', label: 'Address', icon: 'home', type: 'text', required: false },
    { key: 'membership_date', label: 'Membership Date', icon: 'calendar-check', type: 'date', required: false },
    { key: 'password', label: 'Password', icon: 'lock', type: 'password', required: false }
  ];
  
  let form = `
    <form id="editMemberForm">
      <input type="hidden" name="memid" value="${data.memid}">
      <div class="form-row-3">
  `;
  
  fields.forEach((field, index) => {
    if (field.type === 'select') {
      form += `
        <div class="form-group">
          <label class="form-label"><i class="fas fa-${field.icon} me-2"></i>${field.label}</label>
          <select class="form-select" name="${field.key}" ${field.required ? 'required' : ''}>
            ${field.options.map(option => `
              <option value="${option}" ${data[field.key] === option ? 'selected' : ''}>${option}</option>
            `).join('')}
          </select>
        </div>
      `;
    } else {
      form += `
        <div class="form-group">
          <label class="form-label"><i class="fas fa-${field.icon} me-2"></i>${field.label}</label>
          <input type="${field.type}" class="form-control" name="${field.key}" 
                 value="${data[field.key] || ''}" 
                 ${field.required ? 'required' : ''}>
        </div>
      `;
    }
  });
  
  form += `
      </div>
    </form>
  `;
  
  document.getElementById("editContent").innerHTML = form;
  const editModal = new bootstrap.Modal(document.getElementById("editModal"));
  editModal.show();
  
  document.getElementById("saveChangesBtn").addEventListener("click", function() {
    const form = document.getElementById("editMemberForm");
    if (form.checkValidity()) {
      const formData = new FormData(form);
      const jsonData = {};
      
      for (let [key, value] of formData.entries()) {
        jsonData[key] = value;
      }
      
      fetch('update_member.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(jsonData)
      })
      .then(response => response.json())
      .then(result => {
        if (result.success) {
          showToast('Member updated successfully!', 'success');
          editModal.hide();
          loadMembers();
        } else {
          showToast(result.message || 'Failed to update member', 'danger');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        showToast('An error occurred while updating member', 'danger');
      });
    } else {
      form.reportValidity();
    }
  }, { once: true });
}

function showAddMemberModal() {
  const addModal = new bootstrap.Modal(document.getElementById("addMemberModal"));
  document.getElementById("addMemberForm").reset();
  addModal.show();
  
  document.getElementById("addMemberBtn").addEventListener("click", function() {
    const form = document.getElementById("addMemberForm");
    if (form.checkValidity()) {
      const formData = new FormData(form);
      const jsonData = {};
      
      for (let [key, value] of formData.entries()) {
        jsonData[key] = value;
      }
      
      fetch('add_member.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(jsonData)
      })
      .then(response => response.json())
      .then(result => {
        if (result.success) {
          showToast('Member added successfully!', 'success');
          addModal.hide();
          loadMembers();
        } else {
          showToast(result.message || 'Failed to add member', 'danger');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        showToast('An error occurred while adding member', 'danger');
      });
    } else {
      form.reportValidity();
    }
  }, { once: true });
}

function showDeleteModal(member) {
  document.getElementById("memberToDelete").textContent = 
    `Member ID: ${member.memid} - ${member.firstname} ${member.surname}`;
  
  document.getElementById("confirmDeleteBtn").onclick = function() {
    deleteMember(member.memid);
  };
  
  new bootstrap.Modal(document.getElementById("deleteModal")).show();
}

function deleteMember(memid) {
  fetch('delete_member.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ memid: memid })
  })
  .then(response => response.json())
  .then(result => {
    if (result.success) {
      showToast('Member deleted successfully!', 'success');
      loadMembers();
    } else {
      showToast(result.message || 'Failed to delete member', 'danger');
    }
    bootstrap.Modal.getInstance(document.getElementById("deleteModal")).hide();
  })
  .catch(error => {
    console.error('Error:', error);
    showToast('An error occurred while deleting member', 'danger');
  });
}

function loadAttendanceYears() {
  fetch("load_attendance_years.php")
    .then(response => response.json())
    .then(years => {
      const dropdown = document.getElementById("attendanceYearsDropdown");
      dropdown.innerHTML = '<li><a class="dropdown-item" href="#" id="addAttendanceLink"><i class="fas fa-plus me-2"></i>Add Attendance</a></li>';
      years.forEach(year => {
        dropdown.innerHTML = `<li><a class="dropdown-item" href="#" data-year="${year}">${year}</a></li>` + dropdown.innerHTML;
      });
      // Re-attach event listener for addAttendanceLink
      document.getElementById("addAttendanceLink").addEventListener("click", function(e) {
        e.preventDefault();
        showAddAttendanceModal();
      });
      // Attach event listeners for year links
      document.querySelectorAll('#attendanceYearsDropdown a[data-year]').forEach(link => {
        link.addEventListener('click', function(e) {
          e.preventDefault();
          loadAttendance(this.dataset.year);
        });
      });
    })
    .catch(error => {
      console.error("Error loading attendance years:", error);
      showToast("Failed to load attendance years.", "danger");
    });
}

function showAddAttendanceModal() {
  const addModal = new bootstrap.Modal(document.getElementById("addAttendanceModal"));
  const form = document.getElementById("addAttendanceForm");
  form.reset();
  // Pre-fill current year
  form.querySelector('input[name="year"]').value = new Date().getFullYear();
  addModal.show();
  
  document.getElementById("submitAttendanceYearBtn").addEventListener("click", function() {
    if (form.checkValidity()) {
      const year = form.querySelector('input[name="year"]').value;
      fetch('add_attendance_period.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ year })
      })
      .then(response => response.json())
      .then(result => {
        if (result.success) {
          loadAttendanceYears();
          addModal.hide();
          loadAttendance(year);
        } else {
          showToast(result.message || 'Failed to create attendance period', 'danger');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        showToast('An error occurred while creating attendance period', 'danger');
      });
    } else {
      form.reportValidity();
    }
  }, { once: true });
}



function loadAttendance(year) {
  document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
  document.getElementById("attendanceLink").classList.add('active');
  
  Promise.all([
    fetch("load_members.php").then(response => response.json()),
    fetch(`load_attendance.php?year=${year}`).then(response => response.json())
  ])
  .then(([members, attendanceRecords]) => {
    //   console.log('attendanceRecords',attendanceRecords);
    const content = `
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0">Attendance for ${year}</h4>
        <div>
          <select class="form-select d-inline-block me-2" id="monthSelect" style="width: auto;">
            <option value="">Select Month to Add</option>
            <option value="01">January</option>
            <option value="02">February</option>
            <option value="03">March</option>
            <option value="04">April</option>
            <option value="05">May</option>
            <option value="06">June</option>
            <option value="07">July</option>
            <option value="08">August</option>
            <option value="09">September</option>
            <option value="10">October</option>
            <option value="11">November</option>
            <option value="12">December</option>
          </select>
          <button class="btn btn-primary me-2" id="addAttendeeBtn">
            <i class="fas fa-plus me-2"></i>Add Attendee
          </button>
          <button class="btn btn-success" id="saveAttendanceBtn">
            <i class="fas fa-save me-2"></i>Save Attendance
          </button>
        </div>
      </div>
      <div class="card shadow-sm">
        <div class="card-body p-0">
          <div class="table-responsive">
            <table class="table table-hover mb-0" id="attendanceTable">
              <thead class="table-light">
                <tr>
                  <th>Month</th>
                  <th>Firstname</th>
                  <th>Lastname</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="attendanceTableBody">
                ${attendanceRecords.length === 0 ? `
                  <tr>
                    <td colspan="7" class="text-center py-4">
                      No attendance records found for ${year}. Select a month and add attendees.
                    </td>
                  </tr>
                ` : attendanceRecords.map(record => `
                  <tr data-attendance-id="${record.attendance_id}">
                    <td>${new Date(year, record.month - 1).toLocaleString('default', { month: 'long' })}</td>
                    <td>${record.firstname}</td>
                    <td>${record.surname}</td>
                    <td>${record.username}</td>
                    <td>${record.email || 'N/A'}</td>
                    <td>${record.status}</td>
                    <td>
                      <button class="btn btn-sm btn-primary me-1" onclick='viewAttendance(${JSON.stringify(record)})'>
                        <i class="fas fa-eye"></i> View
                      </button>
                      <button class="btn btn-sm btn-danger" onclick="deleteAttendanceRow(${record.attendance_id}, '${year}')">
                        <i class="fas fa-trash"></i> Remove
                      </button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <style>
        .new-attendance-row {
          background-color: #e6f3ff;
        }
      </style>
    `;
    document.getElementById("contentArea").innerHTML = content;

    // Attach event listeners
    document.getElementById("addAttendeeBtn").addEventListener("click", function() {
      const month = document.getElementById("monthSelect").value;
      if (!month) {
        showToast("Please select a month before adding an attendee.", "warning");
        return;
      }
      addAttendanceRow(members, year, month);
    });

    document.getElementById("saveAttendanceBtn").addEventListener("click", function() {
      saveAttendance(year);
    });
  })
  .catch(error => {
    console.error("Error loading data:", error);
    showToast("Failed to load attendance data.", "danger");
    document.getElementById("contentArea").innerHTML = `
      <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle me-2"></i>Failed to load attendance data. Please try again later.
      </div>
    `;
  });
}

function viewAttendance(data) {

    const displayId = parseInt(data.attendance_id) + 1000;
    const year = parseInt(data.year);
const month = parseInt(data.month);
    let dat22 = new Date(year, month - 1).toLocaleString('default', { month: 'long' })
    //   alert(month);
    //   alert(data.year);
    //   alert(dat22);
  let html = `
    <div class="row">
      <div class="col-md-4 text-center mb-4">
        <div class="bg-light p-4 rounded-circle d-inline-flex align-items-center justify-content-center" style="width: 150px; height: 150px;">
          <i class="fas fa-calendar-check fa-4x text-muted"></i>
        </div>
        <h4 class="mt-3">${data.firstname} ${data.surname}</h4>
        <p class="text-muted">Attendance ID: ${displayId}</p>
      </div>
      <div class="col-md-8">
        <div class="row g-3">
          <div class="col-md-6">
            <div class="p-3 bg-light rounded">
              <small class="text-muted d-block">Month</small>
              <strong>${new Date(data.year, data.month - 1).toLocaleString('default', { month: 'long' })}</strong>
            </div>
          </div>
          <div class="col-md-6">
            <div class="p-3 bg-light rounded">
              <small class="text-muted d-block">Year</small>
              <strong>${data.year}</strong>
            </div>
          </div>
          <div class="col-md-6">
            <div class="p-3 bg-light rounded">
              <small class="text-muted d-block">First Name</small>
              <strong>${data.firstname}</strong>
            </div>
          </div>
          <div class="col-md-6">
            <div class="p-3 bg-light rounded">
              <small class="text-muted d-block">Last Name</small>
              <strong>${data.surname}</strong>
            </div>
          </div>
          <div class="col-md-6">
            <div class="p-3 bg-light rounded">
              <small class="text-muted d-block">Username</small>
              <strong>${data.username}</strong>
            </div>
          </div>
          <div class="col-md-6">
            <div class="p-3 bg-light rounded">
              <small class="text-muted d-block">Email</small>
              <strong>${data.email || 'N/A'}</strong>
            </div>
          </div>
          <div class="col-md-6">
            <div class="p-3 bg-light rounded">
              <small class="text-muted d-block">Status</small>
              <strong>${data.status}</strong>
            </div>
          </div>
          <div class="col-md-6">
            <div class="p-3 bg-light rounded">
              <small class="text-muted d-block">Attendance Date</small>
              <strong>${data.attendance_date}</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
  
  document.getElementById("viewContent").innerHTML = html;
  document.getElementById("viewModal").querySelector('.modal-title').innerHTML = '<i class="fas fa-calendar-check me-2"></i>Attendance Details';
  new bootstrap.Modal(document.getElementById("viewModal")).show();
}

function addAttendanceRow(members, year, month) {
  const tbody = document.getElementById("attendanceTableBody");
  const row = document.createElement("tr");
  row.classList.add("new-attendance-row");
  row.innerHTML = `
    <td>${new Date(year, month - 1).toLocaleString('default', { month: 'long' })}</td>
    <td>
      <select class="form-select attendance-select" data-field="firstname">
        <option value="">Select Member</option>
        ${members.map(member => `
          <option value="${member.memid}" data-firstname="${member.firstname}" data-surname="${member.surname}" data-username="${member.username}" data-email="${member.email || ''}">
            ${member.firstname}
          </option>
        `).join('')}
      </select>
    </td>
    <td><span class="surname-display"></span></td>
    <td><span class="username-display"></span></td>
    <td><span class="email-display"></span></td>
    <td>
      <select class="form-select status-select">
        <option value="Present">Present</option>
        <option value="Absent">Absent</option>
      </select>
    </td>
    <td>
      <button class="btn btn-sm btn-danger" onclick="this.parentElement.parentElement.remove()">
        <i class="fas fa-trash"></i> Remove
      </button>
    </td>
  `;
  tbody.appendChild(row);
  
  row.querySelector('.attendance-select').addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    const surname = selectedOption.dataset.surname || '';
    const username = selectedOption.dataset.username || '';
    const email = selectedOption.dataset.email || '';
    row.querySelector('.surname-display').textContent = surname;
    row.querySelector('.username-display').textContent = username;
    row.querySelector('.email-display').textContent = email;
  });
}

function saveAttendance(year) {
  const rows = document.querySelectorAll('#attendanceTableBody tr.new-attendance-row');
  const attendanceData = [];
  const month = document.getElementById("monthSelect").value;
  
  if (!month) {
    showToast("Please select a month before saving attendance.", "warning");
    return;
  }

  rows.forEach(row => {
    const select = row.querySelector('.attendance-select');
    const memid = select.value;
    if (memid) {
      attendanceData.push({
        memid: memid,
        attendance_date: `${year}-${month}-01`,
        status: row.querySelector('.status-select').value
      });
    }
  });
  
  if (attendanceData.length === 0) {
    showToast("No valid attendees selected.", "warning");
    return;
  }
  
  // Add the year to attendance_periods if it doesn't exist
  fetch('add_attendance_period.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ year })
  })
  .then(response => response.json())
  .then(result => {
    if (result.success) {
      // Save attendance records
      return fetch('add_attendance.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ attendance: attendanceData })
      });
    } else {
      throw new Error(result.message || 'Failed to create attendance period');
    }
  })
  .then(response => response.json())
  .then(result => {
    if (result.success) {
      showToast('Attendance saved successfully!', 'success');
      loadAttendanceYears();
      loadAttendance(year);
    } else {
      showToast(result.message || 'Failed to save attendance', 'danger');
    }
  })
  .catch(error => {
    console.error('Error:', error);
    showToast('An error occurred while saving attendance', 'danger');
  });
}

function deleteAttendanceRow(attendanceId, year) {
  fetch('delete_attendance.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ attendance_id: attendanceId })
  })
  .then(response => response.json())
  .then(result => {
    if (result.success) {
      showToast('Attendance record deleted successfully!', 'success');
      loadAttendance(year);
    } else {
      showToast(result.message || 'Failed to delete attendance record', 'danger');
    }
  })
  .catch(error => {
    console.error('Error:', error);
    showToast('An error occurred while deleting attendance record', 'danger');
  });
}