<?php
include "db_connect.php";
$data = json_decode(file_get_contents('php://input'), true);
$year = mysqli_real_escape_string($conn, $data['year']);

$query = "INSERT IGNORE INTO attendance_periods (year) VALUES ('$year')";
if (mysqli_query($conn, $query)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to create attendance period']);
}
?>