<?php
include "db_connect.php";

header('Content-Type: application/json');

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $memid = intval($input['memid']);
    
    $stmt = $conn->prepare("DELETE FROM members WHERE memid = ?");
    $stmt->bind_param("i", $memid);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Member deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete member']);
    }
    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

$conn->close();
?>