<!--dashboard.php-->
<?php
include "db_connect.php";
session_start();
if (!isset($_SESSION["user"])) {
  header("Location: index.html");
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Club Portal Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="style.css">
  <style>
      .full-width{
          /*border:2px solid red;*/
          width:100%;
      }
  </style>
</head>
<body>
  <div class="sidebar">
    <h4 class="text-center"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></h4>
    <a href="#" id="dashboardLink" class="active"><i class="fas fa-home"></i> <span>Dashboard</span></a>
    <a href="#" id="loadMembers"><i class="fas fa-users"></i> <span>Members</span></a>
    <!--<div class="dropdown">-->
    <!--  <a href="#" id="attendanceLink" data-bs-toggle="dropdown" aria-expanded="false">-->
    <!--    <i class="fas fa-calendar-check"></i> <span>Attendance</span>-->
    <!--  </a>-->
    <!--  <ul class="dropdown-menu" id="attendanceYearsDropdown" style="color:green !important">-->
        <!-- Years will be populated dynamically -->
    <!--    <li><a class="dropdown-item" href="#" id="addAttendanceLink"><i class="fas fa-plus me-2"></i>Add Attendance</a></li>-->
    <!--  </ul>-->
    <!--</div>-->
    <!-- In the sidebar section -->
<div class="dropdown">
  <a href="#" id="attendanceLink" data-bs-toggle="dropdown" aria-expanded="false">
    <i class="fas fa-calendar-check"></i> <span>Attendance</span>
  </a>
  <ul class="dropdown-menu" id="attendanceYearsDropdown" style="color:green !important">
    <!-- Years will be populated dynamically -->
    <li><a class="dropdown-item" href="#" id="addAttendanceLink"><i class="fas fa-plus me-2"></i>Add Attendance</a></li>
  </ul>
</div>
    <!--<a href="logout.php" class="text-white"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>-->
  </div>

  <div class="main-content">
    <div class="header">
      <h4>Welcome, <?= htmlspecialchars($_SESSION["user"]) ?>!</h4>
       <a href="logout.php" class="text-white" style='background:#58803A;padding: 8px 15px;text-decoration: none;'><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
    </div>

    <div id="contentArea">
      <div class="welcome-screen">
        <div class="welcome-icon">
          <i class="fas fa-users"></i>
        </div>
        <h1 class="welcome-title">Welcome to Dare-A-Dream  Portal</h1>
        <p class="welcome-subtitle">Manage your club members efficiently with our comprehensive dashboard</p>
        <div class="mt-4">
          <button class="btn btn-primary btn-lg me-2" id="viewMembersBtn">
            <i class="fas fa-users me-2"></i>View Members
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- View Modal -->
  <div class="modal fade" id="viewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header text-white">
          <h5 class="modal-title"><i class="fas fa-user-circle me-2"></i>Member Details</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4" id="viewContent"></div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Edit Modal -->
  <div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header text-white">
          <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Member</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4" id="editContent"></div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-primary" id="saveChangesBtn">Save Changes</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Delete Confirmation Modal -->
  <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i>Confirm Delete</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to delete this member? This action cannot be undone.</p>
          <p class="fw-bold" id="memberToDelete"></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Add Member Modal -->
  <div class="modal fade" id="addMemberModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header text-white">
          <h5 class="modal-title"><i class="fas fa-user-plus me-2"></i>Add New Member</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <form id="addMemberForm">
            <div class="form-row-3">
              <div class="form-group">
                <label class="form-label"><i class="fas fa-user me-2"></i>Username</label>
                <input type="text" class="form-control" name="username" required>
              </div>
              <div class="form-group">
                <label class="form-label"><i class="fas fa-signature me-2"></i>Surname</label>
                <input type="text" class="form-control" name="surname" required>
              </div>
              <div class="form-group">
                <label class="form-label"><i class="fas fa-signature me-2"></i>First Name</label>
                <input type="text" class="form-control" name="firstname" required>
              </div>
              <div class="form-group">
                <label class="form-label"><i class="fas fa-venus-mars me-2"></i>Gender</label>
                <select class="form-select" name="gender" required>
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label"><i class="fas fa-calendar me-2"></i>Date of Birth</label>
                <input type="date" class="form-control" name="dob" required>
              </div>
              <div class="form-group">
                <label class="form-label"><i class="fas fa-phone me-2"></i>Phone Number</label>
                <input type="tel" class="form-control" name="phoneno" required>
              </div>
              <div class="form-group">
                <label class="form-label"><i class="fas fa-envelope me-2"></i>Email</label>
                <input type="email" class="form-control" name="email">
              </div>
               <div class="form-group">
                <label class="form-label"><i class="fas fa-lock me-2"></i>Password</label>
                <input type="password" class="form-control" name="password">
              </div>
              
              <div class="form-group">
                <label class="form-label"><i class="fas fa-calendar-check me-2"></i>Membership Date</label>
                <input type="date" class="form-control" name="membership_date">
              </div>
              <!--<div class="form-group">-->
              <!--  <label class="form-label"><i class="fas fa-lock me-2"></i>Password</label>-->
              <!--  <input type="password" class="form-control" name="password">-->
              <!--</div>-->
              
             
            </div>
             <div class="form-group full-width">
                <label class="form-label"><i class="fas fa-home me-2"></i>Address/Post code</label>
                <input type="text" class="form-control" name="address" Placeholder='Address/Post code'>
              </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-primary" id="addMemberBtn">Add Member</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Add Attendance Modal -->
  <div class="modal fade" id="addAttendanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header text-white">
          <h5 class="modal-title"><i class="fas fa-calendar-plus me-2"></i>Add Attendance</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <form id="addAttendanceForm">
            <div class="form-group">
              <label class="form-label"><i class="fas fa-calendar me-2"></i>Year</label>
              <input type="number" class="form-control" name="year" min="2000" max="2099" required>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-primary" id="submitAttendanceYearBtn">Submit</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Toast Container -->
  <div class="toast-container"></div>

  <script src="members.js"></script>
</body>
</html>