<?php
// Database connection file

$host = "localhost";
$db = "dareadream_club";
$user = "dareadream_admin";
$pass = "?)}uS2xQoeK2";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
