<?php
include "db_connect.php";

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$sql = "SELECT `memid`, `username`, `surname`, `firstname`, `othername`, `gender`, `dob`, `address`, `email`, `phoneno`, `join_date`, `hobbies` FROM `members`";
$result = $conn->query($sql);

$members = [];

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $members[] = $row;
  }
}

header('Content-Type: application/json');
echo json_encode($members);
?>
