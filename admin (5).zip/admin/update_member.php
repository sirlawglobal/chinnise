<?php
include "db_connect.php";

header('Content-Type: application/json');

// Function to sanitize input
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $memid = intval($input['memid']);
    $username = sanitize($input['username']);
    $surname = sanitize($input['surname']);
    $firstname = sanitize($input['firstname']);
    $gender = sanitize($input['gender']);
    $dob = sanitize($input['dob']);
    $phoneno = sanitize($input['phoneno']);
    $email = sanitize($input['email'] ?? '');
    $address = sanitize($input['address'] ?? '');
    $membership_date = sanitize($input['membership_date'] ?? '');

    $query = "UPDATE members SET 
        username = ?, 
        surname = ?, 
        firstname = ?, 
        gender = ?, 
        dob = ?, 
        phoneno = ?, 
        email = ?, 
        address = ?, 
        join_date = ? 
        WHERE memid = ?";

    // If password is provided, include it in the update
    if (!empty($input['password'])) {
        $password = password_hash(sanitize($input['password']), PASSWORD_DEFAULT);
        $query = "UPDATE members SET 
            username = ?, 
            surname = ?, 
            firstname = ?, 
            gender = ?, 
            dob = ?, 
            phoneno = ?, 
            email = ?, 
            address = ?, 
            join_date = ?, 
            password = ? 
            WHERE memid = ?";
    }

    $stmt = $conn->prepare($query);
    
    if (!empty($input['password'])) {
        $stmt->bind_param("ssssssssssi", 
            $username, 
            $surname, 
            $firstname, 
            $gender, 
            $dob, 
            $phoneno, 
            $email, 
            $address, 
            $membership_date, 
            $password, 
            $memid
        );
    } else {
        $stmt->bind_param("sssssssssi", 
            $username, 
            $surname, 
            $firstname, 
            $gender, 
            $dob, 
            $phoneno, 
            $email, 
            $address, 
            $membership_date, 
            $memid
        );
    }

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Member updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update member']);
    }
    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

$conn->close();
?>