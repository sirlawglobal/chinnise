<?php
include "db_connect.php";
$data = json_decode(file_get_contents('php://input'), true);
$attendance_id = mysqli_real_escape_string($conn, $data['attendance_id']);

$query = "DELETE FROM attendance WHERE attendance_id = '$attendance_id'";
if (mysqli_query($conn, $query)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to delete attendance record']);
}
?>