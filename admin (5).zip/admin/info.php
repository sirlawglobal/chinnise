<?php
$plainPassword = 'member123';
$hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);

echo $hashedPassword;
?>
