<?php
include "db_connect.php";
$data = json_decode(file_get_contents('php://input'), true);
$attendance = $data['attendance'];
$success = true;
$message = '';

foreach ($attendance as $record) {
    $memid = mysqli_real_escape_string($conn, $record['memid']);
    $attendance_date = mysqli_real_escape_string($conn, $record['attendance_date']);
    $status = mysqli_real_escape_string($conn, $record['status']);
    $query = "INSERT INTO attendance (memid, attendance_date, status) VALUES ('$memid', '$attendance_date', '$status')";
    if (!mysqli_query($conn, $query)) {
        $success = false;
        $message = 'Failed to save some attendance records';
        break;
    }
}

echo json_encode(['success' => $success, 'message' => $message]);
?>