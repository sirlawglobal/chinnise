<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include "db_connect.php";

$year = mysqli_real_escape_string($conn, $_GET['year']);

$query = "
    SELECT 
        a.attendance_id, 
        a.memid, 
        m.firstname, 
        m.surname, 
        m.username, 
        m.email, 
        MONTH(a.attendance_date) AS month, 
        YEAR(a.attendance_date) AS year,  
        DAY(a.attendance_date) AS day, 
         DATE_FORMAT(a.attendance_date, '%d/%m/%Y') AS attendance_date,
        a.status
    FROM attendance a
    JOIN members m ON a.memid = m.memid
    WHERE YEAR(a.attendance_date) = '$year'
";

$result = mysqli_query($conn, $query);

$attendance = [];
while ($row = mysqli_fetch_assoc($result)) {
    $attendance[] = $row;
}

echo json_encode($attendance);
?>
