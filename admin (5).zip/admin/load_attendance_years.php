<?php
include "db_connect.php";
$query = "
    SELECT DISTINCT year FROM (
        SELECT year FROM attendance_periods
        UNION
        SELECT YEAR(attendance_date) AS year FROM attendance
    ) AS years
    ORDER BY year DESC";
$result = mysqli_query($conn, $query);
$years = [];
while ($row = mysqli_fetch_assoc($result)) {
    $years[] = $row['year'];
}
echo json_encode($years);
?>